"""Ereigniskern für glatte Phasen. Python >= 3.10, Standardbibliothek."""
import math
from dataclasses import dataclass


@dataclass(frozen=True)
class EventBracket:
    """Vorzeichenklammer ohne darstellbaren inneren Zeitpunkt."""

    left: float
    right: float
    left_value: float
    right_value: float
    diagnosis: str = "time_resolution"


def brent(f, left, right, xtol) -> float | EventBracket:
    """Nullstelle einer stetigen Funktion in einer isolierenden Klammer.

    xtol ist eine absolute Zeittoleranz. Das Ergebnis ist eine Auswertung
    mit Funktionswert 0 oder die Mitte einer ausreichend engen Klammer.
    Wenn die Zeittoleranz ohne darstellbaren inneren Zeitpunkt nicht
    garantiert werden kann, bleibt die Vorzeichenklammer mit der Diagnose
    "time_resolution" erhalten.
    """
    if not (math.isfinite(left) and math.isfinite(right) and left < right
            and math.isfinite(xtol) and xtol > 0):
        raise ValueError("Ungültiges Intervall oder ungültige Zeittoleranz")

    def value(t):
        y = f(t)
        if not math.isfinite(y):
            raise ValueError("Wächterwert ist nicht endlich")
        return y

    a, b = left, right
    fa, fb = value(a), value(b)
    if fa == 0:
        return a
    if fb == 0:
        return b
    if (fa > 0) == (fb > 0):
        raise ValueError("Die Klammer schließt keinen Vorzeichenwechsel ein")
    if abs(fa) < abs(fb):
        a, b, fa, fb = b, a, fb, fa
    c, fc = a, fa
    d = c
    bisected = True

    for _ in range(512):
        mid = a + (b - a) / 2
        if mid == a or mid == b:
            # The rounded midpoint is an endpoint; its maximum possible
            # error is the full width, not half the width.
            if abs(b - a) <= xtol:
                return mid
            if a < b:
                return EventBracket(a, b, fa, fb)
            return EventBracket(b, a, fb, fa)
        if abs(b - a) <= 2 * xtol:
            return mid

        # Inverse quadratische Interpolation, sonst ein Sekantenschritt.
        # Skalierung schützt auch sehr kleine Wächterwerte beim Dividieren.
        scale = max(abs(fa), abs(fb), abs(fc))
        u, v, w = fa / scale, fb / scale, fc / scale
        try:
            if u != w and v != w and u != v:
                s = (a * (v / (u-v)) * (w / (u-w))
                     + b * (u / (v-u)) * (w / (v-w))
                     + c * (u / (w-u)) * (v / (w-v)))
            else:
                s = b - (b-a) * v / (v-u)
        except (ZeroDivisionError, OverflowError):
            s = mid
        guard = b + 0.75 * (a - b)
        previous = abs(b - c) if bisected else abs(c - d)
        safe = (min(b, guard) < s < max(b, guard)
                and abs(s - b) < previous / 2 and previous > xtol)
        bisected = not safe
        if bisected:
            s = mid
        fs = value(s)
        if fs == 0:
            return s
        d, c, fc = c, b, fb
        if (fa > 0) != (fs > 0):
            b, fb = s, fs
        else:
            a, fa = s, fs
        if abs(fa) < abs(fb):
            a, b, fa, fb = b, a, fb, fa
    raise ArithmeticError("Brent-Dekker hat seine Iterationsgrenze erreicht")


def rk4_dense(rhs, t0, y0, t1):
    """RK4 und kubischer Hermite-Interpolant. Zustand und RHS sind Tupel."""
    h = t1 - t0
    if not h > 0:
        raise ValueError("Der Schritt muss die Zeit voranbringen")

    def stage(slope, dt):
        return tuple(y + dt * k for y, k in zip(y0, slope, strict=True))

    k1 = rhs(t0, y0)
    k2 = rhs(t0 + h/2, stage(k1, h/2))
    k3 = rhs(t0 + h/2, stage(k2, h/2))
    k4 = rhs(t1, stage(k3, h))
    y1 = tuple(y + h * (a + 2*b + 2*c + d) / 6
               for y, a, b, c, d in zip(y0, k1, k2, k3, k4, strict=True))
    f1 = rhs(t1, y1)

    def dense(t):
        if not t0 <= t <= t1:
            raise ValueError("Die dichte Ausgabe gilt nur innerhalb des Schritts")
        if t == t0:
            return y0
        if t == t1:
            return y1
        s = (t - t0) / h
        return tuple((1+2*s)*(1-s)**2*y + s*(1-s)**2*h*a
                     + s*s*(3-2*s)*z + s*s*(s-1)*h*b
                     for y, a, z, b in zip(y0, k1, y1, f1, strict=True))

    return y1, dense


def first_crossing(phi, t0, t1, direction, xtol, cuts=(), rate=None) -> float | EventBracket | None:
    """Erster gerichteter Wechsel auf (t0,t1]; cuts isolieren die Wurzeln.

    Eine Null am linken Rand gehört dem vorigen Abschnitt. Gibt das Modell
    rate(t) an, wird ein Berührpunkt mit verschwindender Rate verworfen.
    Eine EventBracket meldet die Grenze der Zeitauflösung. In diesem Fall
    wird kein einzelner Zeitpunkt und somit keine Rate dort behauptet.
    """
    if direction not in (-1, 1):
        raise ValueError("Die Richtung muss -1 oder +1 sein")
    if not t0 < t1 or not math.isfinite(xtol) or xtol <= 0:
        raise ValueError("Intervall oder Zeittoleranz ungültig")
    left = t0
    p = direction * phi(left)
    if not math.isfinite(p):
        raise ValueError("Nichtendlicher Wächter")
    for right in (*sorted({c for c in cuts if t0 < c < t1}), t1):
        q = direction * phi(right)
        if not math.isfinite(q):
            raise ValueError("Nichtendlicher Wächter")
        if p < 0 and q >= 0:
            root = brent(phi, left, right, xtol)
            if isinstance(root, EventBracket) or rate is None or direction * rate(root) > 0:
                return root
        left, p = right, q
    return None
