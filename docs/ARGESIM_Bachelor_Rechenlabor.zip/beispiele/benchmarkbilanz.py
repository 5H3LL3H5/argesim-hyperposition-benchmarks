"""Unabhängige Abnahme des veröffentlichten Achtraster-Versuchs und exakte Gegenproben."""
import csv
from collections import Counter
from fractions import Fraction
from itertools import product
from math import isfinite, isclose
from pathlib import Path
from statistics import median

ROOT = Path(__file__).resolve().parents[1]
CASES = ("C03", "C05", "C07", "C09", "C11", "C12", "C13", "C21")
QUANTA = ("0.005", "0.001", "0.0002")
CLASSIC = ("euler", "rk4", "rk45")
QSS = ("qss1", "qss2", "qss3", "qss4", "cqss1", "liqss1", "liqss2", "liqss3",
       "mliqss1", "mliqss2", "mliqss3", "eliqss1", "eliqss2", "eliqss3",
       "cheqss1", "cheqss2", "cheqss3", "liqss-bdf")


def measured_budget():
    with (ROOT / "daten/qss-extension.csv").open(encoding="utf-8", newline="") as f:
        runs = list(csv.DictReader(f))
    expected = set(product(CASES, QSS, QUANTA)) | set(product(CASES, CLASSIC, ("",)))
    keys = {(r["case"], r["method"], r["quantum_factor"]) for r in runs}
    assert keys == expected and len(runs) == len(keys) == 456
    counts = Counter(row["status"] for row in runs)
    assert counts == {'event_mismatch': 13, 'timeout': 81, 'pass': 224, 'accuracy_miss': 126, 'solver_error': 12}
    for row in runs:
        has_score = row["status"] in {"pass", "accuracy_miss"}
        if not has_score and row["error_over_limit"]:
            assert row["status"] == "timeout"
        if has_score:
            score = float(row["error_over_limit"])
            assert isfinite(score) and score >= 0
            assert (score <= 1.0) == (row["status"] == "pass")
        if row["times_ms"]:
            times = [float(value) for value in row["times_ms"].split()]
            # Zeiten in der CSV sind auf sechs Nachkommastellen in ms gedruckt.
            assert all(t >= 0 and isfinite(t) for t in times)
            assert isclose(median(times), float(row["median_ms"]), rel_tol=0, abs_tol=1.01e-6)
    partial = {(r["case"], r["method"], r["quantum_factor"]) for r in runs
               if r["status"] == "timeout" and r["error_over_limit"]}
    assert partial == {('C12', 'cqss1', '0.0002'), ('C13', 'eliqss2', '0.0002'),
                       ('C11', 'eliqss1', '0.0002'), ('C11', 'cheqss1', '0.0002')}
    for case in CASES:
        case_rows = [r for r in runs if r["case"] == case]
        assert len(case_rows) == 57
        print(case, dict(Counter(r["status"] for r in case_rows)))
    print("456 verschiedene Konfigurationen, 350 abgeschlossene Score-Bewertungen und vier weitere Scorefelder bei Zeitlimit.")


def impulse():
    # F = -800 N auf [4, 7) s. Das Integral ergibt N s.
    def force(t):
        return -800 if 4 <= t < 7 else 0
    def left_rule(edges):
        return sum(force(a) * (b-a) for a, b in zip(edges, edges[1:]))
    assert left_rule((0, 3, 6, 9)) == -2400   # richtiger Endimpuls durch Zufall
    assert left_rule((0, 3, 6)) == 0          # zur Kontrollzeit t=6 falsch
    assert left_rule((0, 3, 4, 6, 7, 9)) == -2400
    assert left_rule((0, 3, 4, 6)) == -1600


def roots():
    # q(s) = s² - s + 3/16. Exakte rationale Auswertung verhindert Rundungsannahmen.
    def q(s):
        return s * (s - 1) + Fraction(3, 16)
    windows = ((Fraction(1, 8), Fraction(3, 8)), (Fraction(5, 8), Fraction(7, 8)))
    assert q(0) == q(1) == Fraction(3, 16)
    for a, b in windows:
        assert q(a) * q(b) < 0
        assert (2*a - 1) * (2*b - 1) > 0  # q' ist affin, gleiches Vorzeichen im Intervall
        assert q((a+b)/2) == 0
    print("Kontrollimpulse und beide rational eingeschlossenen Wurzeln bestätigt.")


if __name__ == "__main__":
    measured_budget()
    impulse()
    roots()
