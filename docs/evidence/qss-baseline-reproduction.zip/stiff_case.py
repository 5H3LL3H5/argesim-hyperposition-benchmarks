"""Additional C01-A stiff comparison. Run after compare.py from the same checkout."""
import argparse
import hashlib
import json
import random
import signal
import subprocess
from pathlib import Path

import numpy as np
from scipy.integrate import solve_ivp as scipy_solve
from compare import Case, LEVELS, METHODS, PIN, TARGET, experiment, expired, solve_ivp
from argesim_benchmarks.models.c01_lithium_cluster import c01_problem

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    meta = json.loads((args.output/"metadata.json").read_text())
    if (subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()!=PIN
            or subprocess.run(["git","diff","--quiet","HEAD","--","argesim_benchmarks"]).returncode):
        raise SystemExit("use the pinned clean model")
    problem = c01_problem()
    def equations(t,y):
        r,m,f = y
        return [f*m-r/10, r/10-m+f*f/10-f*m, r/10+2*m-f*m-f*f/5-1000*f]
    ref = scipy_solve(equations,(0.,10.),[84.99,1.674,9.975],method="Radau",dense_output=True,
                      rtol=2e-12,atol=2e-13)
    if not ref.success:
        raise RuntimeError(ref.message)
    def run(method, options):
        if method=="rk4":
            options["step"]=0.001  # model's published timing baseline
        return solve_ivp(problem,method,options=options)
    case = Case("C01-A",10.,(100.,10.,10.),(2,),run,lambda t:ref.sol(t).T,
                lambda mid,t,y:problem.rhs(t,y))
    schedule = [(m,q) for m in METHODS for q in LEVELS] + [("rk45",None),("rk4",None)]
    random.Random(1702).shuffle(schedule)
    signal.signal(signal.SIGALRM,expired)
    with (args.output/"c01.jsonl").open("w",buffering=1) as out:
        for method,level in schedule:
            row = experiment(case,method,level,meta["repeat"],meta["timeout_seconds"])
            print(json.dumps(row,allow_nan=False),file=out)
    (args.output/"c01_metadata.json").write_text(json.dumps(dict(commit=PIN,
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        scales=case.scales,bdf_indices=case.bdf,t_end=10.,target=TARGET,
        reference_endpoint=ref.y[:,-1].tolist()),indent=2)+"\n")

if __name__=="__main__":
    main()
