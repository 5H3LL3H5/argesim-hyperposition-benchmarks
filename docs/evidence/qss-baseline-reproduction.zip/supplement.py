"""Run inside the pinned Git checkout with the original study scripts on PYTHONPATH."""
import json
import signal
import statistics
import subprocess
import time
from dataclasses import asdict
from pathlib import Path

from scipy.integrate import solve_ivp as scipy_ivp
from compare import Case, LEVELS, PIN, TARGET, cases, expired, get_options, score
from argesim_benchmarks import IntegrationError, solve_ivp
from argesim_benchmarks.models.c01_lithium_cluster import c01_problem
from argesim_benchmarks.models.c21_state_events import simulate_c21_rlc_diode

def c01():
    p=c01_problem()
    def eq(t,y):
        r,m,f=y
        return [f*m-r/10,r/10-m+f*f/10-f*m,r/10+2*m-f*m-f*f/5-1000*f]
    ref=scipy_ivp(eq,(0.,10.),[84.99,1.674,9.975],method="Radau",rtol=2e-12,atol=2e-13,dense_output=True)
    assert ref.success
    return Case("C01-A",10.,(100.,10.,10.),(2,),lambda m,o:solve_ivp(p,m,options=o),
                lambda t:ref.sol(t).T,lambda mid,t,y:p.rhs(t,y))

def trial(case, method, level):
    options=(get_options(case,method,level) if method=="cqss1" else
             {"step":0.0005 if case.name=="C01-A" else case.end/1000})
    row=dict(case=case.name,method=method,level=level,options=options,target=TARGET)
    durations=[]
    try:
        for rep in range(4):
            signal.setitimer(signal.ITIMER_REAL,8.)
            try:
                start=time.perf_counter_ns()
                res=case.run(method,options)
                elapsed=(time.perf_counter_ns()-start)/1e6
            finally:
                signal.setitimer(signal.ITIMER_REAL,0.)
            if rep==0:
                vals=score(case,res)
                row.update(vals,endpoint=res.final_state,work=asdict(res.stats))
                row["status"]=vals.get("status") or ("pass" if vals["error"]<=TARGET else "accuracy_miss")
            else:
                assert row["endpoint"]==res.final_state and row["work"]==asdict(res.stats)
                durations.append(elapsed)
        row.update(times_ms=durations,median_ms=statistics.median(durations))
    except (IntegrationError,TimeoutError,ArithmeticError) as e:
        row.update(status="timeout" if isinstance(e,TimeoutError) else "solver_error",reason=str(e))
    return row

if __name__=="__main__":
    assert subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()==PIN
    signal.signal(signal.SIGALRM,expired)
    out=Path(__file__).resolve().parent
    with (out/"supplement.jsonl").open("w",buffering=1) as f:
        for case in [c01(),*cases()]:
            if not case.hamiltonian:
                for level in LEVELS:
                    print(json.dumps(trial(case,"cqss1",level),allow_nan=False),file=f)
            print(json.dumps(trial(case,"euler",None),allow_nan=False),file=f)
    dae=[]
    for algebraic in ("voltage","current"):
        r=simulate_c21_rlc_diode("shockley-dae",algebraic_state=algebraic)
        dae.append(dict(algebraic=algebraic,method="rk45",t_end=r.times[-1],events=len(r.events),
                        max_algebraic_residual=r.maximum_algebraic_residual))
    (out/"diode.json").write_text(json.dumps(dae,indent=2))
