"""Conservative control energy and CP2 spatial convergence, outside timed runs."""
import argparse
import json
import signal
from pathlib import Path

import numpy as np

from compare import LEVELS, cases, expired, get_options, IntegrationError

def relative_energy(case_name, states):
    if case_name == "CP1-A-control":
        return (450*states[:,1]**2+9000*states[:,0]**2)/2
    u,v = np.split(states,2,axis=1)
    gradients = np.diff(np.pad(u,((0,0),(1,1))),axis=1)/0.125
    return 0.5*0.125*(np.sum(v*v,axis=1)+0.06**2*np.sum(gradients**2,axis=1))

def spatial_defect(n,times):
    x = np.array([0.125,0.25,0.375])
    indices = np.arange(1,n+1)
    dx = 0.5/(n+1)
    modes = np.sqrt(2/(n+1))*np.sin(np.pi*np.outer(indices,indices)/(n+1))
    freq = 2*0.06/dx*np.sin(np.pi*indices/(2*(n+1)))
    initial = 0.05*(1-np.abs(2*indices/(n+1)-1))
    grid = (np.cos(np.outer(times,freq))*(modes.T@initial))@modes.T
    locations = (x/dx).round().astype(int)-1
    # Exact reflected d'Alembert solution for a triangular string, odd periodic extension.
    def extended(s):
        phase = np.mod(s,1.0)
        coord = np.minimum(phase,1-phase)
        return np.where(phase<=0.5,1.,-1.)*0.05*(1-np.abs(4*coord-1))
    exact = (extended(x+0.06*times[:,None])+extended(x-0.06*times[:,None]))/2
    return float(np.abs(grid[:,locations]-exact).max())

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path,required=True)
    dest=p.parse_args().output
    meta=json.loads((dest/"metadata.json").read_text())
    signal.signal(signal.SIGALRM,expired)
    rows=[]
    for case in cases():
        if not case.hamiltonian:
            continue
        for method in ("cqss1","qss2","rk45"):
            for level in (LEVELS if method!="rk45" else [None]):
                row=dict(case=case.name,method=method,level=level)
                options=get_options(case,method,level)
                try:
                    signal.setitimer(signal.ITIMER_REAL,meta["timeout_seconds"])
                    try:
                        result=case.run(method,options)
                    finally:
                        signal.setitimer(signal.ITIMER_REAL,0)
                    if result.final_time != case.end:
                        raise ArithmeticError("incomplete horizon")
                    energy=relative_energy(case.name,np.array(result.states))
                    row.update(status="completed", samples=len(energy),
                               max_relative_energy_drift=float(np.abs(energy/energy[0]-1).max()))
                except (TimeoutError,IntegrationError,ArithmeticError) as exc:
                    row.update(status="incomplete",reason=str(exc))
                rows.append(row)
    result=dict(energy=rows, cp2_max_displacement_error_m={
        n:spatial_defect(n,np.linspace(0,10,201)) for n in (3,7,15,31)})
    (dest/"diagnostics.json").write_text(json.dumps(result,indent=2,allow_nan=False)+"\n")

if __name__=="__main__":
    main()
