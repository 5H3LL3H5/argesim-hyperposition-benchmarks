"""ARGESIM comparison. Run from the pinned repository with python /path/to/compare.py."""
import argparse
import bisect
import csv
import hashlib
import json
import math
import platform
import random
import signal
import statistics
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import scipy

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT))
from argesim_benchmarks import IntegrationError, solve_ivp
from argesim_benchmarks.models.c15_clearance import c15_analytical, solve_c15, C15Parameters
from argesim_benchmarks.models.c17_sir_epidemic import c17_problem
from argesim_benchmarks.models.c21_state_events import (
    C21BouncingBallParameters, c21_analytical_bounce_times, simulate_c21_bouncing_ball_event_contact,
)
from argesim_benchmarks.models.cp1_parallel import cp1_task_a_ivp
from argesim_benchmarks.models.cp2_parallel_and_distributed import (
    CP2SwingingRopeParameters, cp2_swinging_rope_problem,
)
from scripts.c17_reference import scalar_reference

METHODS = ["qss1", "qss2", "qss3", "qss4", "cqss1",
           *(family + str(order) for family in ("liqss", "eliqss", "cheqss", "mliqss")
             for order in (1, 2, 3)), "liqss-bdf"]
LEVELS = [0.005, 0.001, 0.0002]
TARGET = 0.001
PIN = "8332be4d6ac90b7c3d4c4ec8024dba969e098574"

@dataclass(frozen=True)
class Case:
    name: str
    end: float
    scales: tuple
    bdf: tuple
    run: object
    reference: object
    rhs: object
    hamiltonian: bool = False

def cases():
    # C15 switches the infusion off at 0.5. Select its one-sided RHS by interval midpoint.
    p = C15Parameters()
    def clearance_rhs(mid, t, y):
        x, z = y
        return ((5000 if mid < 0.5 else 0) - (p.k01+p.k21)*x + p.k12*z, p.k21*x-p.k12*z)
    yield Case("C15-A", 240., (2500., 2500.), (1,),
               lambda m,o: solve_c15(m, options=o),
               lambda t: np.array([c15_analytical(float(s)) for s in t]), clearance_rhs)

    def ivp_case(name, problem, scales, bdf, reference, hamiltonian=False):
        return Case(name, problem.t_bound, scales, bdf,
                    lambda m,o: solve_ivp(problem, m, options=o), reference,
                    lambda mid,t,y: problem.rhs(t,y), hamiltonian)

    yield ivp_case("C17R-ODE", c17_problem(t_bound=100.), (10000.,)*3, (1,), scalar_reference())
    yield Case("C21-ball", 5., (10., 14.), (1,),
               lambda m,o: simulate_c21_bouncing_ball_event_contact(
                   C21BouncingBallParameters(beta=0.), t_bound=5., method=m, options=o),
               None, None)

    def oscillator(damping):
        problem = cp1_task_a_ivp(damping)
        alpha = damping/900
        omega = math.sqrt(20-alpha*alpha)
        def exact(t):
            envelope = 0.1*np.exp(-alpha*t)
            return np.column_stack((envelope*(np.cos(omega*t)+alpha/omega*np.sin(omega*t)),
                                    -envelope*20/omega*np.sin(omega*t)))
        return ivp_case("CP1-A" if damping else "CP1-A-control", problem, (0.1, 0.1*math.sqrt(20)),
                        (1,), exact, not damping)
    yield oscillator(1000.)
    yield oscillator(0.)

    n = 3
    params = CP2SwingingRopeParameters(interior_points=n)
    problem = cp2_swinging_rope_problem(parameters=params)
    spacing = params.length/(n+1)
    indices = np.arange(1,n+1)
    modes = np.sqrt(2/(n+1))*np.sin(np.pi*np.outer(indices,indices)/(n+1))
    freq = 2*params.nu/spacing*np.sin(np.pi*indices/(2*(n+1)))
    initial = params.h*(1-np.abs(2*indices/(n+1)-1))
    amplitudes = modes.T @ initial
    def rope_exact(t):
        phase = np.outer(t, freq)
        return np.column_stack(((np.cos(phase)*amplitudes) @ modes.T,
                                (-np.sin(phase)*freq*amplitudes) @ modes.T))
    yield ivp_case("CP2-rope", problem, (params.h,)*n+(params.h*params.nu/params.length,)*n,
                   tuple(range(n,2*n)), rope_exact, True)

def get_options(case, method, level):
    if method == "rk45":
        return dict(rtol=1e-8, atol=tuple(1e-10*s for s in case.scales), max_step=case.end/100)
    if method == "rk4":
        return dict(step=case.end/1000)
    options = dict(quantum=tuple(level*s for s in case.scales), max_events=40000)
    if method == "liqss-bdf":
        options.update(bdf_partition=case.bdf, rtol=1e-5, atol=tuple(1e-8*s for s in case.scales),
                       max_step=case.end/50, max_steps=40000)
    return options

def score(case, result):
    times = np.asarray(result.times)
    if times[0] != 0 or times[-1] != case.end:
        raise ArithmeticError("incomplete time coverage")
    if case.name == "C21-ball":
        impacts = [float(e.time.macro) for e in result.events if e.name == "bounce"]
        expected = c21_analytical_bounce_times(2)
        if len(impacts) != len(expected) or any(e.state_after[1] <= 0 for e in result.events):
            return dict(status="event_mismatch", impacts=impacts)
        err = max(abs(x-y) for x,y in zip(impacts,expected))
        return dict(error=err, impact_times=impacts, reference_impacts=expected)

    states = np.asarray(result.states)
    grid = np.unique(np.append(np.linspace(0,case.end,201),0.5)) if case.name=="C15-A" else np.linspace(0,case.end,201)
    # Common-grid Hermite reconstruction, scored independently of solver timing.
    sampled = []
    for t in grid:
        i = bisect.bisect_right(times, t)-1
        y = states[i]
        if t != times[i]:
            a,b = times[i:i+2]
            z = states[i+1]
            h = b-a
            u = (t-a)/h
            mid = (a+b)/2
            f = np.asarray(case.rhs(mid,a,y))
            g = np.asarray(case.rhs(mid,b,z))
            y = (1+2*u)*(1-u)**2*y + u*(1-u)**2*h*f + u*u*(3-2*u)*z + u*u*(u-1)*h*g
        sampled.append(y)
    native = np.abs(states-case.reference(times))
    common = np.abs(np.asarray(sampled)-case.reference(grid))
    err = max(np.max(native/case.scales), np.max(common/case.scales))
    if not math.isfinite(err):
        raise ArithmeticError("non-finite reference error")
    return dict(error=float(err), grid_max_abs=common.max(axis=0).tolist(),
                native_max_abs=native.max(axis=0).tolist(), endpoint_abs=native[-1].tolist())

def expired(*_):
    raise TimeoutError("per-solve wall-time limit")

def experiment(case, method, level, repeat, timeout):
    row = dict(case=case.name, method=method, level=level, target=TARGET)
    if method=="cqss1" and not case.hamiltonian:
        return dict(**row, status="inapplicable")
    options = get_options(case,method,level)
    row.update(options=options, durations_ms=[])
    try:
        for rep in range(repeat+1):
            signal.setitimer(signal.ITIMER_REAL,timeout)
            try:
                start = time.perf_counter_ns()
                result = case.run(method,options)
                duration = (time.perf_counter_ns()-start)/1e6
            finally:
                signal.setitimer(signal.ITIMER_REAL,0)
            if rep == 0:
                values = score(case,result)
                row.update(values, **asdict(result.stats), endpoint=list(result.final_state))
                row["status"] = values.get("status") or ("pass" if values["error"] <= TARGET else "accuracy_miss")
            elif result.final_state != tuple(row["endpoint"]) or asdict(result.stats) != {
                key:row[key] for key in asdict(result.stats)
            }:
                raise ArithmeticError("repetition changed endpoint or solver work")
            else:
                row["durations_ms"].append(duration)
        row["median_ms"] = statistics.median(row["durations_ms"])
    except (TimeoutError, IntegrationError, ArithmeticError) as exc:
        row.update(status="timeout" if isinstance(exc,TimeoutError) else "solver_error", reason=str(exc))
    return row

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--repeat",type=int,default=3)
    parser.add_argument("--timeout",type=float,default=8.)
    args = parser.parse_args()
    if args.repeat<1 or not math.isfinite(args.timeout) or args.timeout<=0:
        parser.error("positive repeat and timeout required")
    args.output.mkdir(parents=True,exist_ok=True)
    rev = subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip()
    if rev!=PIN or subprocess.run(["git","diff","--quiet","HEAD","--","argesim_benchmarks","scripts/c17_reference.py"]).returncode:
        raise SystemExit("use a clean checkout of "+PIN)
    setup = list(cases())
    schedule = [(c,m,q) for c in setup for m in METHODS for q in LEVELS]
    schedule += [(c,m,None) for c in setup for m in ("rk4","rk45")]
    random.Random(1701).shuffle(schedule)
    meta = dict(commit=rev,python=platform.python_version(),system=platform.platform(),
                numpy=np.__version__,scipy=scipy.__version__,repeat=args.repeat,timeout_seconds=args.timeout,
                script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                cases={c.name:dict(t_end=c.end, scales=c.scales,bdf_indices=c.bdf) for c in setup})
    (args.output/"metadata.json").write_text(json.dumps(meta,indent=2)+"\n")
    signal.signal(signal.SIGALRM,expired)
    with (args.output/"results.jsonl").open("w",buffering=1) as out:
        for case,method,level in schedule:
            row = experiment(case,method,level,args.repeat,args.timeout)
            print(json.dumps(row,allow_nan=False),file=out)
    with (args.output/"results.jsonl").open() as raw, (args.output/"matrix.csv").open("w",newline="") as out:
        fields = "case method level status error target accepted_steps rejected_steps rhs_evaluations median_ms reason".split()
        writer = csv.DictWriter(out,fields,extrasaction="ignore")
        writer.writeheader()
        for row in sorted(map(json.loads,raw),key=lambda r:(r["case"],r["method"],r["level"] or 0)):
            writer.writerow(row)

if __name__ == "__main__":
    main()
