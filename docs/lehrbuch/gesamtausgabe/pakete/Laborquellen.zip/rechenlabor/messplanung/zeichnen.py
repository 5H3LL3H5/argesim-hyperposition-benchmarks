"""Draw the C19R reading counts and fixed schedules stored in the laboratory report."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import FuncFormatter, MultipleLocator  # noqa: E402
import numpy as np  # noqa: E402


def draw(source, svg, pdf):
    report = json.loads(source.read_text(encoding="utf-8"))
    c19r = next(case for case in report["cases"] if case["identifier"] == "C19R")
    well = c19r["source_enclosure"]
    replay = well["replay"]
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 8,
            "pdf.fonttype": 42,
            "svg.hashsalt": "argesim-c19r-reading-plans",
            "text.color": "#1d3240",
            "axes.labelcolor": "#1d3240",
            "axes.spines.right": False,
            "axes.spines.top": False,
        }
    )
    navy, rust, teal = "#365474", "#9e4925", "#00675e"
    fig, (counts, schedules) = plt.subplots(1, 2, figsize=(7.1, 2.17))
    fig.subplots_adjust(left=0.076, right=0.98, bottom=0.21, top=0.84, wspace=0.52)
    for key, label, color, style in (
        ("uniform", "Gleichmäßig", navy, ":"),
        ("targeted", "Fest zielgerichtet", rust, "--"),
        ("online", "Adaptiv", teal, "-"),
    ):
        histogram = replay["strategies"][key]["counts"]
        fraction = 100 * np.cumsum(histogram) / replay["histories"]
        counts.step(range(len(fraction)), fraction, where="post", color=color,
                    linestyle=style, linewidth=1.65, label=label)
    counts.set(xlim=(0, 15), ylim=(-1, 105), xlabel="Ausgeführte Ablesungen",
               ylabel="Budget erreicht (%)", title="a  Aufwand im Prüfsatz")
    counts.xaxis.set_major_locator(MultipleLocator(3))
    counts.yaxis.set_major_locator(MultipleLocator(25))
    counts.grid(axis="y", color="#dce6e6", linewidth=0.6, zorder=0)
    counts.legend(loc="upper left", frameon=False, fontsize=7)

    for level, configuration, color in (
        (1, well, teal), (0, c19r["shifted_well"], navy),
    ):
        times = configuration["targeted"]["times_days"]
        schedules.hlines(level, 3.75, 5.0, color="#bccacb", linewidth=0.9)
        schedules.vlines(times, level - 0.19, level + 0.19, color=color, linewidth=1.55)
    schedules.set(xlim=(3.72, 5.03), ylim=(-0.56, 1.56), xlabel="Zeit (Tage)",
                  title="b  Feste zielgerichtete Ablesezeiten")
    schedules.set_yticks([0, 1], ["5,25 m", "5 m"])
    schedules.set_xticks([3.75, 4, 4.25, 4.5, 4.75, 5])
    schedules.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f"{x:g}".replace(".", ",")))
    schedules.tick_params(axis="y", length=0)
    schedules.spines["left"].set_visible(False)

    fig.savefig(svg, metadata={"Date": None})
    fig.savefig(pdf, metadata={"CreationDate": None, "ModDate": None})
    plt.close(fig)


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path(__file__).parent / "messung/messplanung.json")
    options = parser.parse_args()
    draw(options.source, root / "abbildungen/mp_c19.svg", root / "druck/mp_c19.pdf")
