"""All six CP tasks with quantities tied to their original physical models."""

from itertools import product

import numpy as np
from scipy.integrate import solve_ivp

from argesim_benchmarks.models import (
    cp1_parallel as cp1,
    cp2_parallel_and_distributed as cp2,
)

from dynamik import case, probes
from planer import Probe, Quantity, Scenario
import linear


def oscillator():
    times = (0.1, 0.2, 0.35, 0.5, 0.7, 0.9, 1.1)
    rows = []
    for damping, mass in product((800.0, 930.0, 1060.0, 1200.0), (435.0, 450.0, 465.0)):
        model = cp1.cp1_task_a_ivp(damping, mass=mass, t_bound=1.6)
        result = solve_ivp(
            model.rhs,
            (model.t0, model.t_bound),
            model.y0,
            method="DOP853",
            rtol=1e-11,
            atol=1e-13,
            t_eval=(*times, 1.6),
        )
        assert result.success
        check = cp2.cp2_monte_carlo_analytical(
            1.6,
            cp2.CP2MonteCarloParameters(mass=mass, damping=damping),
            initial_position=0.1,
            initial_velocity=0,
        )
        assert abs(check - result.y[0, -1]) < 1e-11
        rows.append(
            Scenario(f"d={damping:g}, m={mass:g}", (check,), tuple(result.y[0, :-1]))
        )
    return case(
        "CP1/A",
        "Einzelläufe des gedämpften Federwagens, Masse und Dämpfung",
        "CP1 Federwagen, DOP853 und analytischer Oszillator",
        [Quantity("Position bei 1,6 s", "m", 0.0008)],
        probes("Position", "m", 0.004, times),
        rows,
    )


def populations():
    times = (0.5, 1.0, 1.8, 2.5, 3.5, 4.5, 6.0)
    rows = []
    for v1, z2 in product((0.8, 0.95, 1.10, 1.25), (0.9, 1.0, 1.1)):
        model = cp1.cp1_task_b_ivp(t_bound=10.0)
        y = list(model.y0)
        y[0], y[-1] = v1, z2
        result = solve_ivp(
            model.rhs,
            (model.t0, model.t_bound),
            y,
            method="DOP853",
            rtol=1e-10,
            atol=1e-12,
            t_eval=(*times, 10.0),
        )
        assert result.success and np.all(result.y >= 0)
        rows.append(
            Scenario(
                f"v1={v1:g}, z2={z2:g}", (result.y[-1, -1],), tuple(result.y[0, :-1])
            )
        )
    return case(
        "CP1/B",
        "Zehn gekoppelte Populationsgleichungen, Variation zweier Startwerte",
        "CP1 Räuber-Beute-System, DOP853",
        [Quantity("Population z2 bei 10 ZE", "Modellskala", 0.06)],
        probes("Population v1", "Modellskala", 0.09, times, "ZE"),
        rows,
    )


def driven_rope():
    times = (3.0, 5.0, 7.0, 9.0, 11.0, 13.0, 16.0)
    frequencies = (0.72, 1.0, 1.55, 2.6)
    profiles = linear.modal_rope(np.asarray((*times, 20.0)), frequencies)
    rows = []
    for i, amplitude in product(range(len(frequencies)), (0.8, 1.0, 1.2)):
        rows.append(
            Scenario(
                f"ω={frequencies[i]:g}, A={amplitude:g}",
                (amplitude * profiles[i, -1, 599],),
                tuple(amplitude * profiles[i, :-1, 399]),
            )
        )
    return case(
        "CP1/C",
        "Saite mit bewegtem Rand, bekannte Frequenzen und 2,6 rad/s",
        "CP1 modale Raumdiskretisierung auf 800 Intervallen",
        [Quantity("Auslenkung bei 7,5 m und 20 s", "m", 0.012)],
        probes("Auslenkung bei 5 m", "m", 0.035, times),
        rows,
    )


def monte_carlo():
    rows = []
    for shift, seed in product((0.0, 100.0, 200.0), (1729, 1730, 1731, 1732)):
        dampings = np.random.default_rng(seed).uniform(800 + shift, 1000 + shift, 28)
        values = [
            cp2.cp2_monte_carlo_analytical(1.6, cp2.CP2MonteCarloParameters(damping=d))
            for d in dampings
        ]
        rows.append(
            Scenario(
                f"Bandverschiebung {shift:g}, Ensemble {seed}",
                (float(np.mean(values)),),
                tuple(np.mean(np.asarray(values).reshape(7, 4), axis=1)),
            )
        )
    return case(
        "CP2/1",
        "Festes Monte-Carlo-Ensemble aus 28 Federwagenläufen",
        "CP2 exakte Schwingungslösung, sieben gleich große Teilstichproben",
        [Quantity("Ensemblemittel bei 1,6 s", "m", 0.00012)],
        [
            Probe(f"Mittel der vier Läufe in Block {j}", "m", 0.00035)
            for j in range(1, 8)
        ],
        rows,
        "festgelegtes Monte-Carlo-Ensemble",
    )


def cavity():
    rows = []
    for reynolds, drive in product((70.0, 100.0, 160.0, 220.0), (0.045, 0.065, 0.085)):
        run = cp2.cp2_task2_lid_driven_cavity(
            nx=19, iterations=215, reynolds=reynolds, u0_x=drive
        )
        populations = np.asarray(run.grid)
        assert np.min(populations.sum(axis=2)) > 0
        speed = np.asarray(run.relative_speed) * drive
        local = populations[9, 13]
        momentum_x = local @ np.array([0, 1, 0, -1, 0, 1, -1, -1, 1])
        momentum_y = local @ np.array([0, 0, 1, 0, -1, 1, 1, -1, -1])
        target = np.hypot(momentum_x, momentum_y) / local.sum()
        assert abs(target - speed[9, 13]) < 1e-12
        rows.append(
            Scenario(
                f"Re={reynolds:g}, Deckeltempo={drive:g}",
                (target,),
                tuple(speed[j, 9] for j in (2, 4, 6, 8, 10, 12, 15)),
            )
        )
    return case(
        "CP2/2",
        "Kavität auf 19 × 19 Knoten nach 215 Schritten",
        "CP2 D2Q9-BGK Referenz, direkte Dichte- und Impulsmomente",
        [Quantity("Geschwindigkeitsbetrag am Knoten (13,9)", "Gittereinheit", 0.0012)],
        [
            Probe(f"Geschwindigkeit in Spalte 9, Zeile {i}", "Gittereinheit", 0.003)
            for i in (2, 4, 6, 8, 10, 12, 15)
        ],
        rows,
    )


def plucked_rope():
    times = (0.8, 1.5, 2.3, 3.5, 4.4, 5.5, 6.7)
    rows = []
    for speed, height in product((0.052, 0.056, 0.06, 0.064), (0.044, 0.050, 0.056)):
        p = cp2.CP2SwingingRopeParameters(nu=speed, h=height)
        signal = tuple(
            cp2.cp2_swinging_rope_analytical(0.25, t, p, terms=800) for t in times
        )
        truth = cp2.cp2_swinging_rope_analytical(0.375, 8.0, p, terms=800)
        assert (
            abs(truth - cp2.cp2_swinging_rope_analytical(0.375, 8.0, p, terms=1600))
            < 1e-6
        )
        rows.append(
            Scenario(f"c={speed:g} m/s, Zupfhöhe={height:g} m", (truth,), signal)
        )
    return case(
        "CP2/3",
        "Feste Enden, Dreieckszupfung, Ausbreitungstempo und Amplitude",
        "CP2 Sinusreihenreferenz mit Reihenprobe",
        [Quantity("Auslenkung bei 0,375 m und 8 s", "m", 0.0015)],
        probes("Auslenkung bei 0,25 m", "m", 0.004, times),
        rows,
    )
