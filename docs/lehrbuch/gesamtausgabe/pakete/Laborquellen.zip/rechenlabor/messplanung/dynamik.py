"""Measurement contracts for ODEs, switches, contacts and identification."""

from itertools import product

import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm

from argesim_benchmarks.models import (
    c01_lithium_cluster as c01,
    c03_amplifier as c03,
    c05_two_state as c05,
    c07_constrained_pendulum as c07,
    c09_fuzzy_tanks as c09,
    c11_scara_robot as c11,
    c13_crane as c13,
    c15_clearance as c15,
    c17_sir_epidemic as c17,
    c18_nonlinear_identification as c18,
    c21_state_events as c21,
)
from argesim_benchmarks.models.c12_collision import c12_collision_processes as c12

from planer import Case, Probe, Quantity, Scenario


def probes(name, unit, quantum, times, time_unit="s"):
    return tuple(Probe(f"{name} bei {t:g} {time_unit}", unit, quantum) for t in times)


def trajectory(result, times, component):
    return tuple(
        np.interp(times, result.times, np.asarray(result.states)[:, component])
    )


def case(
    identifier,
    description,
    reference,
    targets,
    measuring,
    scenarios,
    kind="deterministisch",
    *,
    extra=(),
):
    return Case(
        identifier,
        description,
        reference,
        kind,
        tuple(targets),
        tuple(measuring),
        tuple(scenarios),
        tuple(extra),
    )


def lithium():
    times = (0.001, 0.01, 0.05, 0.15, 0.4, 1, 2)
    rows = []
    for loss, initial_factor in product(c01.C01_LOG_LOSS_VALUES, (0.97, 1.0, 1.03)):
        rhs = c01.c01_rhs(c01.C01Parameters(loss_f=loss))
        y0 = np.asarray(c01.C01_INITIAL_STATE) * initial_factor
        run = solve_ivp(
            rhs,
            (0, 10),
            y0,
            method="Radau",
            t_eval=(*times, 3, 10),
            atol=3e-11,
            rtol=3e-10,
        )
        assert run.success and np.all(run.y >= 0)
        rows.append(
            Scenario(
                f"Verlust {loss:g}, Startfaktor {initial_factor:g}",
                (run.y[1, -1],),
                tuple(run.y[2, : len(times)]),
                extra=(run.y[1, -2],),
            )
        )
    return case(
        "C01",
        "Abschaltung, vorgeschriebene Verlustwerte und gestaffelte Anfangszustände",
        "C01-Ratengleichungen, SciPy Radau",
        [Quantity("Clustergröße m bei 10 s", "Modellskala", 0.08)],
        probes("Clustergröße f", "Modellskala", 0.02, times),
        rows,
        extra=[Probe("Clustergröße m bei 3 s", "Modellskala", 0.08)],
    )


def amplifier():
    times = (2, 4, 6, 8, 11, 14, 17)
    rows = []
    for resistance, supply in product((45.0, 52.4, 60.0, 70.0), (4.9, 5.0, 5.1)):
        p = c03.C03Parameters(rl=resistance, vdc=supply, trf=0)
        run = c03.solve_c03(
            parameters=p,
            t_bound=20e-6,
            options={"max_step": 1e-7, "rtol": 1e-8, "atol": 1e-10},
        )
        rows.append(
            Scenario(
                f"R={resistance:g} Ω, U={supply:g} V",
                (run.final_state[3],),
                trajectory(run, np.asarray(times) * 1e-6, 1),
                extra=trajectory(run, (18e-6,), 3),
            )
        )
    return case(
        "C03",
        "Idealer Klasse-E-Schalter, Last und Versorgung variiert",
        "C03 phasenausgerichtetes RK45",
        [Quantity("Kondensatorspannung u4 bei 20 µs", "V", 0.10)],
        probes("Kondensatorspannung u2", "V", 0.25, times, "µs"),
        rows,
        extra=[Probe("Kondensatorspannung u4 bei 18 µs", "V", 0.10)],
    )


def hysteresis():
    times = (0.2, 0.6, 1.0, 1.4, 1.8, 2.2, 2.6)
    rows = []
    for x, y in product((4.14, 4.20, 4.26, 4.32), (0.27, 0.30, 0.33)):
        run = c05.simulate_c05(t_bound=3.0, initial_state=(x, y), output_step=0.02)
        first = run.events[0].time if run.events else 3.0
        z = np.interp(
            times,
            run.times,
            np.asarray(run.states)[:, 0] - np.asarray(run.states)[:, 1],
        )
        event = " → ".join(e.new_mode for e in run.events) or "ohne Umschaltung"
        rows.append(Scenario(f"x0={x:g}, y0={y:g}", (first,), tuple(z), event))
    return case(
        "C05",
        "Kleine Startwertvarianten, erstes Ereignis und Modi bis 3 s",
        "C05 exakter Phasenfluss mit gerichteter Schwelle",
        [Quantity("Erste Schaltzeit, 3 s ohne Übergang", "s", 0.015)],
        probes("Zustandsdifferenz x−y", "Modellskala", 0.025, times),
        rows,
    )


def pendulum():
    times = (0.1, 0.2, 0.3, 0.4, 0.5, 0.65, 0.8)
    rows = []
    for start, damping in product((0.31, 0.41, 0.51, 0.61), (0.10, 0.15, 0.20)):
        p = c07.C07Parameters(d=damping)
        run = c07.solve_c07(
            parameters=p,
            initial_state=(start, 0.0),
            t_bound=1.3,
            max_step=0.005,
            options={"rtol": 1e-10, "atol": 1e-12},
        )
        phi = np.asarray(run.states)[:, 0]
        event = "Stift erreicht" if np.any(phi <= p.phi_p) else "freier Bogen"
        rows.append(
            Scenario(
                f"φ0={start:g}, d={damping:g}",
                (run.final_state[0],),
                trajectory(run, times, 0),
                event,
            )
        )
    return case(
        "C07",
        "Winkel nach der Kontaktphase und Stiftkontakt als Kategorie",
        "C07 Winkelmodell mit Reset und RK45",
        [Quantity("Winkel bei 1,3 s", "rad", 0.018)],
        probes("Winkel", "rad", 0.022, times),
        rows,
    )


def tanks():
    times = (4, 8, 12, 16, 20, 24, 28)
    rows = []
    for initial, disturbance in product((0.46, 0.48, 0.50, 0.52), (0.025, 0.05, 0.075)):
        run = c09.simulate_c09(
            c09.C09Controller.PFC,
            t_bound=36,
            initial_state=(initial, 0.30),
            output_step=1.0,
            disturbance_time=10,
            disturbance=disturbance,
        )
        rows.append(
            Scenario(
                f"h1(0)={initial:g} m, Störung={disturbance:g}",
                (run.h1[-1], run.h2[-1]),
                tuple(np.interp(times, run.times, run.h1)),
            )
        )
    return case(
        "C09",
        "PFC-Regelkreis, kurze Störphase und zwei Endpegel",
        "C09 Sample-and-Hold-Referenz",
        [
            Quantity("Pegel 1 bei 36 s", "m", 0.004),
            Quantity("Pegel 2 bei 36 s", "m", 0.004),
        ],
        probes("Pegel 1", "m", 0.007, times),
        rows,
    )


def robot():
    times_ms = (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7)
    rows = []
    for start, payload in product((0.293, 0.295, 0.297, 0.299), (0.35, 0.5, 0.65)):
        p = c11.C11Parameters(m3L=payload)
        model = c11.c11_problem(
            parameters=p,
            initial_state=(2.0, 2.0, start, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
            t_bound=0.0009,
            task="b",
        )
        run = solve_ivp(
            model.rhs,
            (model.t0, model.t_bound),
            model.y0,
            method="Radau",
            rtol=1e-9,
            atol=1e-11,
            max_step=2e-5,
            t_eval=(*[t * 1e-3 for t in times_ms], model.t_bound),
        )
        assert run.success
        limits = np.asarray(c11._armature_current_limits(p))
        assert np.all(np.abs(run.y[6:]) < limits[:, None])
        rows.append(
            Scenario(
                f"z0={start:g} m, Nutzlast {payload:g} kg",
                (run.y[2, -1],),
                tuple(run.y[8, :-1]),
            )
        )
    return case(
        "C11",
        "SCARA, vertikale Achse im kurzen Fenster vor der Strombegrenzung",
        "C11 Neun-Zustände-Modell, Radau im ungesättigten Fenster",
        [Quantity("z-Achse bei 0,9 ms", "m", 0.00045)],
        probes("Ankerstrom I3", "A", 0.055, times_ms, "ms"),
        rows,
    )


def collisions():
    times = (0.65, 1.0, 1.4, 1.9, 2.6, 3.4, 4.5)
    rows = []
    for restitution, initial in product((0.40, 0.55, 0.7, 0.9), (0.9, 1.0, 1.1)):
        count, end, _, history = c12._simulate(
            c12.C12Parameters(e=restitution, v0=initial, max_time=6.0)
        )
        idx = np.searchsorted([r[0] for r in history], times, side="right") - 1
        measured = tuple(history[j][2][1] for j in idx)
        assert abs(sum(end) - initial) < 1e-12
        rows.append(
            Scenario(
                f"e={restitution:g}, v0={initial:g}",
                (end[-1],),
                measured,
                f"{count} Kontakte",
            )
        )
    return case(
        "C12",
        "Kugelreihe, isolierte Stöße und Kontaktzahl bis 6 s",
        "C12 freier Flug und zentraler Impulsreset",
        [Quantity("Geschwindigkeit der vierten Kugel", "m/s", 0.025)],
        probes("Geschwindigkeit der zweiten Kugel", "m/s", 0.05, times),
        rows,
    )


def crane():
    times = (2.0, 4.0, 5.0, 6.0, 7.0, 9.0, 11.0)
    rows = []
    for force, duration in product((-870.0, -800.0, -730.0, -660.0), (2.0, 3.0, 4.0)):
        p = c13.C13Parameters()
        state = np.zeros(5)
        output = {}
        for a, b, load in ((0, 4, 0), (4, 4 + duration, force), (4 + duration, 15, 0)):
            rhs = c13.c13_linear_rhs(p, fd=load, fc_desired=160.0)
            offset = np.asarray(rhs(0.0, (0.0,) * 5))
            matrix = np.zeros((6, 6))
            matrix[:5, 5] = offset
            matrix[:5, :5] = np.column_stack(
                [np.asarray(rhs(0.0, basis)) - offset for basis in np.eye(5)]
            )
            for t in (*[t for t in (*times, 12.0) if a < t < b], b):
                output[t] = (expm((t - a) * matrix) @ np.r_[state, 1.0])[:5]
            state = output[b]
        rows.append(
            Scenario(
                f"{force:g} N für {duration:g} s",
                (state[0] + p.r * state[2],),
                tuple(output[t][2] for t in times),
                extra=(output[12.0][0],),
            )
        )
    return case(
        "C13",
        "Linearer Lastpuls, Lastposition nach 15 s",
        "C13 lineare Modellfunktion, affiner Matrixfluss",
        [Quantity("Lastposition bei 15 s", "m", 0.25)],
        probes("Seilwinkel", "rad", 0.015, times),
        rows,
        extra=[Probe("Katzposition bei 12 s", "m", 0.10)],
    )


def clearance():
    times = (1, 4, 9, 17, 35, 70, 100)
    rows = []
    for removal, exchange in product(
        (0.0036, 0.0041, 0.0046, 0.0051), (0.046, 0.0498, 0.054)
    ):
        p = c15.C15Parameters(k01=removal, k21=exchange)
        concentration = [
            c15.c15_analytical(t, parameters=p)[0] / p.v1 for t in (*times, 160)
        ]
        rows.append(
            Scenario(
                f"k01={removal:g}, k21={exchange:g}",
                (concentration[-1],),
                tuple(concentration[:-1]),
            )
        )
    return case(
        "C15",
        "Zweikompartiment-Identifikation mit variiertem Abfluss und Austausch",
        "C15 analytische Bolus-Antwort",
        [Quantity("Konzentration A bei Zeiteinheit 160", "Modellskala", 0.30)],
        probes("Konzentration A", "Modellskala", 2.0, times, "ZE"),
        rows,
    )


def sir():
    times = (2, 5, 9, 14, 20, 28, 36)
    rows = []
    for initial in (200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750):
        run = c17.solve_c17(
            initial_state=(10000.0 - initial, initial, 0),
            t_bound=60.0,
            options={"rtol": 1e-9, "atol": 1e-8, "max_step": 0.25},
        )
        assert abs(sum(run.final_state) - 10000.0) < 1e-8
        rows.append(
            Scenario(
                f"I(0)={initial}", (run.final_state[2],), trajectory(run, times, 1)
            )
        )
    return case(
        "C17R",
        "Abstraktes SIR-Lehrmodell, feste Modellraten, synthetische Startgruppen",
        "C17R ODE, Bilanzkontrolle",
        [Quantity("R nach 60 Zeiteinheiten", "Modellpersonen", 8.0)],
        probes("I", "Modellpersonen", 80.0, times, "ZE"),
        rows,
    )


def identification():
    _, data = c18.c18_digitized_data()
    offsets = (0, 4, 8, 12, 16, 20, 24)
    rows = []
    for start in range(100, 1700, 80):
        predicted = data.force[start + 45]
        rows.append(
            Scenario(
                f"Kurvenfenster {start}",
                (predicted,),
                tuple(data.thickening[start + r] for r in offsets),
            )
        )
    return case(
        "C18",
        "Zwanzig getrennte Zeitfenster der rekonstruierten Prüfkurve",
        "C18 publizierte Abbildung, rekonstruierte Werte bei 100 Hz",
        [Quantity("Kraft 450 ms nach Fensterbeginn", "Datenskala", 0.04)],
        probes("Verdickung", "Datenskala", 0.05, [10 * i for i in offsets], "ms"),
        rows,
        "rekonstruierte Kurvenspur",
    )


def ball():
    times = (0.17, 0.33, 0.57, 0.74, 1.0, 1.45, 2.1)
    rows = []
    for height, restitution in product((6.0, 7.0, 8.0, 9.0), (0.72, 0.80, 0.88)):
        bounce = c21.c21_analytical_bounce_times(
            12, initial_height=height, restitution=restitution
        )
        t0 = bounce[0]
        velocities = [9.81 * t0 * restitution**k for k in range(1, 13)]
        values = []
        for t in times:
            hit = np.searchsorted(bounce, t, side="right") - 1
            tau = t if hit < 0 else t - bounce[hit]
            values.append(
                (height if hit < 0 else velocities[hit] * tau) - 9.81 / 2 * tau**2
            )
        count = int(np.searchsorted(bounce, 4.0, side="right"))
        rows.append(
            Scenario(
                f"h0={height:g}, μ={restitution:g}",
                (bounce[2],),
                tuple(values),
                f"{count} Bodenkontakte bis 4 s",
            )
        )
    return case(
        "C21",
        "Ball mit Ereigniskontakt, freier Fall und Newton-Reset",
        "C21 analytische Ballistik ohne Luftwiderstand",
        [Quantity("Zeit des dritten Bodenkontakts", "s", 0.06)],
        probes("Ballhöhe", "m", 0.4, times),
        rows,
    )
