"""Exact chronological measurement planning for finite reference catalogs."""

from dataclasses import dataclass, replace
from fractions import Fraction
from functools import cache
from itertools import combinations, pairwise
import math


@dataclass(frozen=True)
class Probe:
    label: str
    unit: str
    quantum: float


@dataclass(frozen=True)
class Quantity:
    label: str
    unit: str
    budget: float


@dataclass(frozen=True)
class Scenario:
    name: str
    values: tuple[float, ...]
    readings: tuple[float, ...]
    event: str = ""
    extra: tuple[float, ...] = ()


@dataclass(frozen=True)
class Case:
    identifier: str
    description: str
    reference: str
    trace_kind: str
    quantities: tuple[Quantity, ...]
    probes: tuple[Probe, ...]
    scenarios: tuple[Scenario, ...]
    extra_probes: tuple[Probe, ...] = ()

    def __post_init__(self):
        if not self.scenarios or not self.quantities or not self.probes:
            raise ValueError("a case has targets, candidate readings and scenarios")
        if len({s.name for s in self.scenarios}) != len(self.scenarios):
            raise ValueError("scenario identifiers must be distinct")
        if any(not math.isfinite(q.budget) or q.budget <= 0 for q in self.quantities):
            raise ValueError("numeric targets need positive absolute budgets")
        if any(
            not math.isfinite(p.quantum) or p.quantum <= 0
            for p in (*self.probes, *self.extra_probes)
        ):
            raise ValueError("candidate readings need positive quantization steps")
        for s in self.scenarios:
            if len(s.values) != len(self.quantities) or len(s.readings) != len(
                self.probes
            ):
                raise ValueError("catalog row does not match its contract")
            if len(s.extra) != len(self.extra_probes):
                raise ValueError("catalog row does not match its probe extension")
            if not all(math.isfinite(v) for v in (*s.values, *s.readings, *s.extra)):
                raise ValueError(f"nonfinite reference in {s.name}")

    def expanded(self):
        return replace(
            self,
            probes=(*self.probes, *self.extra_probes),
            scenarios=tuple(
                replace(s, readings=(*s.readings, *s.extra), extra=())
                for s in self.scenarios
            ),
            extra_probes=(),
        )


def digitize(value, quantum):
    # The finite experiment stores these exact device codes, including ties.
    return math.floor(value / quantum + 0.5)


def evenly_spaced(slots, schedule):
    """Equal spacing up to one candidate position, including virtual endpoints."""
    boundaries = (-1, *schedule, slots)
    widths = [b - a for a, b in pairwise(boundaries)]
    return max(widths) - min(widths) <= 1


def analyze(case):
    n = len(case.scenarios)
    slots = len(case.probes)
    whole = tuple(range(n))
    budgets = tuple(Fraction(str(q.budget)) for q in case.quantities)
    values = [tuple(Fraction(str(v)) for v in s.values) for s in case.scenarios]
    events = [s.event for s in case.scenarios]
    readings = [
        tuple(
            digitize(v, p.quantum) for v, p in zip(s.readings, case.probes, strict=True)
        )
        for s in case.scenarios
    ]

    @cache
    def bounds(group):
        return tuple(
            (min(values[j][i] for j in group), max(values[j][i] for j in group))
            for i in range(len(budgets))
        )

    @cache
    def certified(group):
        return len({events[j] for j in group}) == 1 and all(
            hi - lo <= 2 * tol
            for (lo, hi), tol in zip(bounds(group), budgets, strict=True)
        )

    @cache
    def read(group, slot):
        bins = {}
        for j in group:
            bins.setdefault(readings[j][slot], []).append(j)
        return tuple(tuple(indices) for indices in bins.values())

    def check(group):
        """Direct oracle for the published intervals and event labels."""
        endpoints = bounds(group)
        estimates = tuple((lo + hi) / 2 for lo, hi in endpoints)
        for j in group:
            assert events[j] == events[group[0]]
            assert all(
                abs(est - val) <= tol
                for est, val, tol in zip(estimates, values[j], budgets, strict=True)
            )
        return max(
            float((hi - lo) / (2 * tol))
            for (lo, hi), tol in zip(endpoints, budgets, strict=True)
        )

    def replay_fixed(group, schedule):
        if certified(group):
            return (0,) * len(group)
        if not schedule:
            return None
        totals = []
        for part in read(group, schedule[0]):
            counts = replay_fixed(part, schedule[1:])
            if counts is None:
                return None
            totals.extend(1 + count for count in counts)
        return tuple(totals)

    def fixed(balanced):
        for size in range(slots + 1):
            best = None
            for schedule in combinations(range(slots), size):
                if balanced and not evenly_spaced(slots, schedule):
                    continue
                counts = replay_fixed(whole, schedule)
                if counts is None:
                    continue
                candidate = (max(counts), sum(counts), schedule)
                best = candidate if best is None else min(candidate, best)
            if best is not None:
                return {"max": best[0], "mean": best[1] / n, "slots": list(best[2])}
        return None

    @cache
    def adaptive(group, start, allowance):
        if certified(group):
            return (0, None)
        if not allowance:
            return None
        best = None
        for slot in range(start, slots):
            branches = read(group, slot)
            if len(branches) == 1:
                continue
            successors = [adaptive(part, slot + 1, allowance - 1) for part in branches]
            if any(state is None for state in successors):
                continue
            candidate = (len(group) + sum(state[0] for state in successors), slot)
            best = candidate if best is None else min(candidate, best)
        return best

    def replay_adaptive(group, start, allowance, prefix=()):
        if certified(group):
            score = check(group)
            return [
                {
                    "case": case.scenarios[j].name,
                    "slots": list(prefix),
                    "max_score_in_group": score,
                }
                for j in group
            ]
        _, slot = adaptive(group, start, allowance)
        assert start <= slot < slots
        return [
            row
            for part in read(group, slot)
            for row in replay_adaptive(part, slot + 1, allowance - 1, (*prefix, slot))
        ]

    groups = [whole]
    for i in range(slots):
        groups = [leaf for branch in groups for leaf in read(branch, i)]
    unresolved = [bad for bad in groups if not certified(bad)]
    witness = None
    uniform = planned = active = None
    if unresolved:
        bad = unresolved[0]
        a, b = next((a, b) for a, b in combinations(bad, 2) if not certified((a, b)))
        assert readings[a] == readings[b]
        witness = {
            "cases": [case.scenarios[j].name for j in (a, b)],
            "readings": list(readings[a]),
            "values": [list(case.scenarios[j].values) for j in (a, b)],
            "events": [events[a], events[b]],
        }
    else:
        uniform = fixed(balanced=True)
        planned = fixed(balanced=False)
        for allowance in range(slots + 1):
            rule = adaptive(whole, 0, allowance)
            if rule is not None:
                paths = replay_adaptive(whole, 0, allowance)
                assert len(paths) == n and len({row["case"] for row in paths}) == n
                assert max(len(p["slots"]) for p in paths) == allowance
                assert sum(len(p["slots"]) for p in paths) == rule[0]
                active = {
                    "max": allowance,
                    "mean": rule[0] / n,
                    "first_slot": rule[1],
                    "paths": paths,
                }
                break
        assert active is not None and uniform is not None and planned is not None
        assert active["max"] <= planned["max"] <= uniform["max"]
        if active["max"] == planned["max"]:
            assert active["mean"] <= planned["mean"]

    return {
        "uniform": uniform,
        "planned": planned,
        "adaptive": active,
        "scenarios": n,
        "unresolved_scenarios": sum(map(len, unresolved)),
        "witness": witness,
        "device_codes": [list(row) for row in readings],
    }


def check_example():
    p = tuple(Probe(name, "–", 1) for name in ("Betriebsart", "Kanal A", "Kanal B"))
    s = (
        Scenario("A0", (0,), (0, 0, 0)),
        Scenario("A1", (1,), (0, 1, 0)),
        Scenario("B0", (2,), (1, 0, 0)),
        Scenario("B1", (3,), (1, 0, 1)),
    )
    q = (Quantity("Ziel", "–", 0.1),)
    standard = Case("probe", "Handprobe", "Beispiel", "deterministisch", q, p, s)
    result = analyze(standard)
    assert result["adaptive"]["max"] == 2
    assert result["planned"]["max"] == 3
    # A pure event conflict remains visible with two otherwise equal entries.
    s = (
        Scenario("kein Kontakt", (0,), (0, 0, 0), "aus"),
        Scenario("Kontakt", (0,), (0, 0, 0), "ein"),
    )
    result = analyze(Case("probe", "Handprobe", "Beispiel", "deterministisch", q, p, s))
    assert result["unresolved_scenarios"] == 2 and result["witness"]["events"] == [
        "aus",
        "ein",
    ]
