"""C19R: certify the well error and plan chronological cumulative-mass readings."""

import argparse
from dataclasses import dataclass
from decimal import Context, Decimal, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
from functools import lru_cache
from itertools import combinations
import json
from pathlib import Path
import sys

import numpy as np
from scipy.integrate import quad
from scipy.optimize import linprog

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "fno_benchmarks"))
import c19r  # noqa: E402


CELLS = 20
TIME_STEP = 5400
SOURCE_START = 324000  # seconds since the beginning of the 10-day experiment
DOSE = 4
RATE_TICKS = 4096
WEIGHT_SCALE = 10**6
BUDGET = Fraction(1, 100)
PI_LO = Decimal("3.14159265358979323846264338327950288419716939937510")
PI_HI = Decimal("3.14159265358979323846264338327950288419716939937511")
INF = 1 << 58


def weights(well, *, with_reference=True):
    """Enclose the Green integrals with directed arithmetic and trapezoid error."""
    down = Context(prec=60, rounding=ROUND_FLOOR)
    up = Context(prec=60, rounding=ROUND_CEILING)
    velocity = Decimal(str(c19r.VELOCITY))
    diffusion4 = 4 * Decimal(str(c19r.DIFFUSION))
    water = Decimal(str(c19r.WATER_COLUMN))
    x = Decimal(str(well))
    steps = 128
    h = Decimal(TIME_STEP) / steps
    low, high, reference = [], [], []

    for i in range(CELLS):
        older_age = Decimal(int(c19r.HORIZON) - SOURCE_START - i * TIME_STEP)
        younger_age = older_age - TIME_STEP
        a = younger_age
        # G'' = G ((log G)'^2 + (log G)''). Bound each term on this interval.
        slope = up.add(
            up.add(up.divide(1, a), up.divide(x * x, diffusion4 * a * a)),
            up.divide(velocity * velocity, diffusion4),
        )
        curvature = up.add(
            up.divide(1, a * a), up.divide(2 * x * x, diffusion4 * a * a * a)
        )
        max_green = up.divide(1, down.multiply(PI_LO, diffusion4 * water * a))
        second = up.multiply(max_green, up.add(up.multiply(slope, slope), curvature))
        error = up.multiply(up.divide(Decimal(TIME_STEP) * h * h, 12), second)
        lo = hi = Decimal(0)
        for j in range(steps + 1):
            age = a + j * h
            dist = x - velocity * age
            term = -(dist * dist)
            spread = diffusion4 * age
            # Decimal.exp is correctly rounded to nearest. The adjacent values
            # enclose the exact exponential of each directed exponent.
            e_lo = down.next_minus(down.exp(down.divide(term, spread)))
            e_hi = up.next_plus(up.exp(up.divide(term, spread)))
            f_lo = down.divide(e_lo, up.multiply(PI_HI, spread * water))
            f_hi = up.divide(e_hi, down.multiply(PI_LO, spread * water))
            trapezoid_weight = Decimal("0.5") if j in (0, steps) else Decimal(1)
            lo = down.add(lo, down.multiply(f_lo, trapezoid_weight))
            hi = up.add(hi, up.multiply(f_hi, trapezoid_weight))
        lo = down.subtract(down.multiply(lo, h), error)
        hi = up.add(up.multiply(hi, h), error)
        low.append(int(down.multiply(lo, WEIGHT_SCALE).to_integral_value(context=down)))
        high.append(int(up.multiply(hi, WEIGHT_SCALE).to_integral_value(context=up)))

        def kernel(age):
            scale = 4 * c19r.DIFFUSION * age
            return np.exp(-((well - c19r.VELOCITY * age) ** 2) / scale) / (
                np.pi * scale * c19r.WATER_COLUMN
            )

        if with_reference:
            reference.append(quad(kernel, float(a), float(older_age), epsabs=1e-11)[0])

    lo = np.asarray(low, dtype=np.int64)
    hi = np.asarray(high, dtype=np.int64)
    ref = None
    if with_reference:
        ref = np.asarray(reference)
        assert np.all(lo / WEIGHT_SCALE <= ref) and np.all(ref <= hi / WEIGHT_SCALE)
        if well == 5.0:
            np.testing.assert_allclose(ref.sum(), c19r.point_basis()[3], rtol=3e-15)
    return lo, hi, ref


@dataclass(frozen=True)
class Plan:
    cuts: tuple[int, ...]
    margin: int


class Planner:
    def __init__(self, lower, upper):
        self.n = len(lower)
        self.sum_lo = {}
        self.sum_hi = {}
        self.sorted_lo = {}
        self.sorted_hi = {}
        marginals = {}
        below = BUDGET.denominator - BUDGET.numerator
        above = BUDGET.denominator + BUDGET.numerator
        self.below, self.above = below, above
        for a in range(self.n):
            for b in range(a + 1, self.n + 1):
                key = a, b
                lo = np.sort(lower[a:b])
                hi = np.sort(upper[a:b])[::-1]
                self.sorted_lo[key], self.sorted_hi[key] = lo, hi
                self.sum_lo[key] = np.r_[0, np.cumsum(lo)]
                self.sum_hi[key] = np.r_[0, np.cumsum(hi)]
                marginals[key] = below * hi - above * lo
        self.thresholds = np.unique(np.concatenate(list(marginals.values())))
        self.interval_cost = np.zeros(
            (len(self.thresholds), self.n + 1, self.n + 1), dtype=np.int64
        )
        for (a, b), terms in marginals.items():
            difference = terms[None, :] - self.thresholds[:, None]
            self.interval_cost[:, a, b] = np.maximum(difference, 0).sum(axis=1)
        maximum = int(np.max(np.abs(self.thresholds)))
        if 4 * self.n * maximum * RATE_TICKS >= np.iinfo(np.int64).max:
            raise OverflowError("outside the exact int64 range of this study")
        self.dp, self.split = self.partitions(self.n, range(1, self.n + 1))

    def partitions(self, groups, widths):
        """For each threshold, minimize additive cost over contiguous groups."""
        n = self.n
        length = len(self.thresholds)
        cost = np.full((groups + 1, length, n + 1), INF, dtype=np.int64)
        split = np.zeros(cost.shape, dtype=np.int16)
        cost[0, :, n] = 0
        for count in range(1, groups + 1):
            for start in range(n - count + 1):
                ends = [
                    start + size for size in widths if start + size <= n - count + 1
                ]
                if not ends:
                    continue
                options = self.interval_cost[:, start, ends] + cost[count - 1][:, ends]
                best = np.argmin(options, axis=1)
                cost[count, :, start] = options[np.arange(length), best]
                split[count, :, start] = np.asarray(ends)[best]
        return cost, split

    def group_bounds(self, start, end, mass):
        full, rem = divmod(mass, RATE_TICKS)
        key = start, end
        lo = int(self.sum_lo[key][full]) * RATE_TICKS
        hi = int(self.sum_hi[key][full]) * RATE_TICKS
        if rem:
            lo += int(self.sorted_lo[key][full]) * rem
            hi += int(self.sorted_hi[key][full]) * rem
        return lo, hi

    def candidate(self, dp, split, start, groups, mass, past_margin=0):
        # Here all queried states have a valid timetable with these group sizes.
        values = dp[groups, :, start]
        assert np.max(values) < INF
        excess = mass * self.thresholds + RATE_TICKS * values + past_margin
        best = int(np.argmin(excess))
        cuts = []
        current = start
        for count in range(groups, 1, -1):
            current = int(split[count, best, current])
            cuts.append(current)
        return Plan(tuple(cuts), int(excess[best]))

    @lru_cache(maxsize=16384)
    def targeted(self, start, mass, past_lo, past_hi):
        margin = self.below * past_hi - self.above * past_lo
        for groups in range(1, self.n - start + 1):
            plan = self.candidate(self.dp, self.split, start, groups, mass, margin)
            if plan.margin <= 0:
                return plan
        raise ArithmeticError("the observations cannot certify the budget")

    def uniform(self, mass):
        """Best timetable among partitions with group sizes differing by at most one."""
        for groups in range(1, self.n + 1):
            step, remainder = divmod(self.n, groups)
            lengths = (step, step + 1) if remainder else (step,)
            dp, split = self.partitions(groups, lengths)
            plan = self.candidate(dp, split, 0, groups, mass)
            if plan.margin <= 0:
                return plan
        raise ArithmeticError("the complete timetable cannot certify the budget")


def ratio(lower, upper):
    return Fraction(upper - lower, upper + lower)


def feasible_allocations(widths, mass):
    if len(widths) == 1:
        if 0 <= mass <= widths[0]:
            yield (mass,)
        return
    for first in range(max(0, mass - sum(widths[1:])), min(widths[0], mass) + 1):
        for tail in feasible_allocations(widths[1:], mass - first):
            yield (first, *tail)


def worst_radius(model, cuts, dose):
    """Exact extremum for a fixed partition and an integer total mass."""
    edges = (0, *cuts, model.n)
    groups = list(zip(edges[:-1], edges[1:], strict=True))
    widths = [b - a for a, b in groups]
    worst = Fraction(-1)
    for distribution in feasible_allocations(widths, dose):
        lower = sum(
            int(model.sum_lo[group][m])
            for group, m in zip(groups, distribution, strict=True)
        )
        upper = sum(
            int(model.sum_hi[group][m])
            for group, m in zip(groups, distribution, strict=True)
        )
        worst = max(worst, ratio(lower, upper))
    return worst


def choose_readings(model, read_counter, fixed=None):
    """Commit to the next timestamp using only the already read counter values."""
    mass = DOSE * RATE_TICKS
    start = past_lo = past_hi = 0
    observations = [0]
    cuts = []
    for _ in range(model.n):
        tail_lo, tail_hi = model.group_bounds(start, model.n, mass)
        lower, upper = past_lo + tail_lo, past_hi + tail_hi
        if ratio(lower, upper) <= BUDGET:
            center = Fraction(2 * lower * upper, lower + upper)
            return (
                cuts,
                observations,
                lower,
                upper,
                float(center) / (RATE_TICKS * WEIGHT_SCALE),
            )
        choices = (
            fixed[len(cuts) :]
            if fixed is not None
            else model.targeted(start, mass, past_lo, past_hi).cuts
        )
        if not choices:
            raise ArithmeticError("no reading is available to meet the budget")
        end = choices[0]
        assert start < end < model.n
        counter = read_counter(end)
        amount = counter - observations[-1]
        if not 0 <= amount <= (end - start) * RATE_TICKS:
            raise ValueError("inconsistent cumulative measurement")
        if not 0 <= mass - amount <= (model.n - end) * RATE_TICKS:
            raise ValueError("cumulative measurement conflicts with the known dose")
        group_lo, group_hi = model.group_bounds(start, end, amount)
        past_lo += group_lo
        past_hi += group_hi
        mass -= amount
        start = end
        cuts.append(end)
        observations.append(counter)
    raise ArithmeticError("the finite sequence of readings did not terminate")


def dose_histories():
    for active in combinations(range(CELLS), DOSE):
        rate = np.zeros(CELLS, dtype=np.int64)
        rate[list(active)] = RATE_TICKS
        yield rate
    generator = np.random.default_rng(1932026)
    for _ in range(256):
        rate = np.full(CELLS, DOSE * RATE_TICKS // CELLS, dtype=np.int64)
        rate[: (DOSE * RATE_TICKS) % CELLS] += 1
        for _ in range(64):
            i, j = generator.choice(CELLS, 2, replace=False)
            transfer = generator.integers(
                max(-rate[i], rate[j] - RATE_TICKS),
                min(RATE_TICKS - rate[i], rate[j]) + 1,
            )
            rate[i] += transfer
            rate[j] -= transfer
        yield rate


def compare_lp(steps, observations, reference, lower, upper, prediction):
    """Independent LP check using the exact observed group totals."""
    edges = (0, *steps, CELLS)
    matrix = np.zeros((len(edges) - 1, CELLS))
    for row, (left, right) in enumerate(zip(edges[:-1], edges[1:], strict=True)):
        matrix[row, left:right] = 1.0
    right_hand = np.diff([*observations, DOSE * RATE_TICKS]) / RATE_TICKS
    for sign in (1, -1):
        result = linprog(
            sign * reference,
            A_eq=matrix,
            b_eq=right_hand,
            bounds=(0, 1),
            method="highs",
        )
        assert result.success
        value = sign * result.fun
        assert (
            lower / (RATE_TICKS * WEIGHT_SCALE)
            <= value
            <= upper / (RATE_TICKS * WEIGHT_SCALE)
        )
        assert abs(prediction - value) / value <= float(BUDGET)


def check_planner():
    """Exhaustively verify the dynamic program against small direct searches."""
    kernel = (
        np.array([741, 750, 650, 730, 760, 748, 740, 705], dtype=np.int64)
        * WEIGHT_SCALE
    )
    model = Planner(kernel, kernel)
    for g in range(1, model.n + 1):
        exact_margin = None
        for cuts in combinations(range(1, model.n), g - 1):
            edges = (0, *cuts, model.n)
            groups = list(zip(edges[:-1], edges[1:], strict=True))
            worst = max(
                sum(
                    int(99 * model.sum_hi[key][m] - 101 * model.sum_lo[key][m])
                    for key, m in zip(groups, allocation, strict=True)
                )
                for allocation in feasible_allocations([b - a for a, b in groups], 3)
            )
            exact_margin = worst if exact_margin is None else min(exact_margin, worst)
        assert (
            model.candidate(model.dp, model.split, 0, g, 3 * RATE_TICKS).margin
            == exact_margin * RATE_TICKS
        )


def verify_one_fewer(lower, upper, uniform_count, targeted_count):
    """Rule out one fewer fixed reading by direct enumeration at the main well."""
    marginal = {
        (a, b): 99 * np.sort(lower[a:b])[::-1] - 101 * np.sort(upper[a:b])
        for a in range(CELLS)
        for b in range(a + 1, CELLS + 1)
    }

    def minimum_excess(schedules):
        best = INF
        count = 0
        for cuts in schedules:
            edges = (0, *cuts, CELLS)
            terms = np.concatenate(
                [marginal[group] for group in zip(edges[:-1], edges[1:], strict=True)]
            )
            value = int(np.partition(terms, -DOSE)[-DOSE:].sum())
            best = min(best, value)
            count += 1
        assert count and best > 0
        return {
            "schedules": count,
            "min_excess_lower_mg_m3": best / (100 * WEIGHT_SCALE),
        }

    def balanced():
        # With one fewer reading, the number of groups equals uniform_count.
        width, extra = divmod(CELLS, uniform_count)
        for long_groups in combinations(range(uniform_count), extra):
            sizes = np.full(uniform_count, width)
            sizes[list(long_groups)] += 1
            yield tuple(np.cumsum(sizes)[:-1])

    return {
        "uniform_count_checked": uniform_count - 1,
        "uniform": minimum_excess(balanced()),
        "targeted_count_checked": targeted_count - 1,
        "targeted": minimum_excess(combinations(range(1, CELLS), targeted_count - 1)),
    }


def times_days(cuts):
    return [(SOURCE_START + c * TIME_STEP) / c19r.DAY for c in cuts]


def encode_fixed(plan, upper):
    intervals = np.diff((0, *plan.cuts, CELLS))
    return {
        "cuts": list(plan.cuts),
        "count": len(plan.cuts),
        "times_days": times_days(plan.cuts),
        "widths_in_cells": intervals.tolist(),
        "worst_relative_upper": float(worst_radius(upper, plan.cuts, DOSE)),
    }


def replay(upper, known, uniform, targeted):
    configurations = {
        "uniform": uniform.cuts,
        "targeted": targeted.cuts,
        "online": None,
    }
    counts = {key: [] for key in configurations}
    maximum_error = dict.fromkeys(configurations, 0.0)
    witness = {}
    lp_checks = 0
    for i, rate in enumerate(dose_histories()):
        cumulative = np.r_[0, np.cumsum(rate)]
        reference = (known @ rate) / RATE_TICKS

        def read_counter(index):
            return int(cumulative[index])

        for name, fixed in configurations.items():
            steps, observations, lo, hi, prediction = choose_readings(
                upper, read_counter, fixed
            )
            assert (
                lo / (RATE_TICKS * WEIGHT_SCALE)
                <= reference
                <= hi / (RATE_TICKS * WEIGHT_SCALE)
            )
            error = abs(prediction - reference) / reference
            assert error <= float(BUDGET)
            cap = len(uniform.cuts) if name == "uniform" else len(targeted.cuts)
            assert len(steps) <= cap
            counts[name].append(len(steps))
            maximum_error[name] = max(maximum_error[name], error)
            if name == "online" and i in (0, 27, 488, 1600, 3291, 4845, 5100):
                compare_lp(steps, observations, known, lo, hi, prediction)
                lp_checks += 1
            if name == "online" and (
                "sparse" not in witness or len(steps) < witness["sparse"]["count"]
            ):
                witness["sparse"] = {
                    "count": len(steps),
                    "cuts": steps,
                    "times_days": times_days(steps),
                    "rate_mg_s": (rate / RATE_TICKS).tolist(),
                    "relative_certified": float(ratio(lo, hi)),
                }
        if i + 1 == 4845:
            corner_counts = {key: tuple(value) for key, value in counts.items()}
    table = {}
    for label, cases in counts.items():
        hist = np.bincount(cases, minlength=CELLS)
        table[label] = {
            "minimum": int(min(cases)),
            "maximum": int(max(cases)),
            "mean": float(np.mean(cases)),
            "median": float(np.median(cases)),
            "max_observed_relative_error": maximum_error[label],
            "counts": hist.tolist(),
            "corner_maximum": int(max(corner_counts[label])),
        }
    assert table["online"]["maximum"] == len(targeted.cuts)
    return table, witness, lp_checks


def run(well, simulate):
    lower, upper_bound, known = weights(well)
    upper = Planner(lower, upper_bound)
    lower_check = Planner(upper_bound, lower)
    total = DOSE * RATE_TICKS
    uniform, targeted = upper.uniform(total), upper.targeted(0, total, 0, 0)
    assert len(lower_check.uniform(total).cuts) == len(uniform.cuts)
    assert len(lower_check.targeted(0, total, 0, 0).cuts) == len(targeted.cuts)
    best_one = min((worst_radius(upper, (c,), DOSE), c) for c in range(1, CELLS))
    assert all(
        worst_radius(lower_check, (c,), DOSE) > best_one[0]
        for c in range(1, CELLS)
        if c != best_one[1]
    )
    output = {
        "well_x_m": well,
        "no_readings_worst_relative_upper": float(worst_radius(upper, (), DOSE)),
        "best_single_reading": {
            "cut": best_one[1],
            "time_days": times_days([best_one[1]])[0],
            "worst_relative_upper": float(best_one[0]),
        },
        "uniform": encode_fixed(uniform, upper),
        "targeted": encode_fixed(targeted, upper),
        "quadrature_interval_max_width_mg_m3_per_mg_s": float(
            np.max(upper_bound - lower) / WEIGHT_SCALE
        ),
        "objective_minimum_certified": True,
    }
    if simulate:
        output["independent_fixed_minimum_check"] = verify_one_fewer(
            lower, upper_bound, len(uniform.cuts), len(targeted.cuts)
        )
        table, witness, lp_checks = replay(upper, known, uniform, targeted)
        output["replay"] = {
            "histories": 4845 + 256,
            "binwise_endpoint_histories": 4845,
            "fractional_histories": 256,
            "strategies": table,
            "example": witness,
            "independent_lp_checks": lp_checks,
        }
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("auswertung"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    check_planner()
    results = {
        "budget_relative": float(BUDGET),
        "source_bins": CELLS,
        "source_start_days": SOURCE_START / c19r.DAY,
        "source_end_days": (SOURCE_START + CELLS * TIME_STEP) / c19r.DAY,
        "total_mg": DOSE * TIME_STEP,
        "max_rate_mg_s": 1,
        "main_well": run(5.0, simulate=True),
        "shifted_well": run(5.25, simulate=False),
    }
    (args.out / "messplanung.json").write_text(
        json.dumps(results, indent=2, allow_nan=False) + "\n"
    )
    preferred = results["main_well"]
    print(
        f"C19R certificate: {preferred['uniform']['count']} balanced, "
        f"{preferred['targeted']['count']} targeted readings."
    )


if __name__ == "__main__":
    main()
