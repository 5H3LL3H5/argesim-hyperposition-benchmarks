"""Measurement contracts for DES, stochastic trajectories and agent models."""

from itertools import product

from argesim_benchmarks.models import (
    c02_flexible_assembly as c02,
    c04_dining_philosophers as c04,
    c06_emergency_department as c06,
    c08_canal_and_lock as c08,
    c10_dining_philosophers as c10,
    c14_supply_chain as c14,
    c16_restaurant_business as c16,
    c20_complex_production as c20,
    c22_queuing_policies as c22,
)
from nsa_devs import HyperTime

from dynamik import case, probes
from planer import Probe, Quantity, Scenario


DES = "festgelegte stochastische Ereignisspur"


def assembly():
    measurements = (
        Probe("Anfangsplätze auf B1", "Paletten", 3),
        Probe("Vollständige Zulassung", "s", 20),
        Probe("Mittlere Zeit von Beladung bis Entladung", "s", 25),
    )
    rows = []
    for pallets, mode in product(
        (8, 11, 14, 17, 20, 23), ("exclusive", "service-only")
    ):
        run = c02.solve_c02(pallets, unit_timing=mode)
        rows.append(
            Scenario(
                f"{pallets} Paletten, {mode}",
                (run["throughput"],),
                (
                    run["initial_on_b1"],
                    run["fully_admitted_at_seconds"] or 0,
                    run["average_throughput_time"] or 0,
                ),
                "Stillstand" if run["deadlock"] else "reguläres Ende",
                extra=(int(mode == "service-only"),),
            )
        )
    return case(
        "C02",
        "Montageanlage, Palettenzahl und Zuordnung der Transportzeiten",
        "C02 Transportmodell, Standardmessfenster 120–600 min",
        [Quantity("Ausgebrachte Teile", "Teile", 12.0)],
        measurements,
        rows,
        extra=[
            Probe(
                "Zuordnung der An- und Ausfahrt im Steuerprotokoll",
                "Betriebsartcode",
                1,
            )
        ],
    )


def dining():
    measurements = (
        Probe("Anteil Denken aller Plätze", "Anteil", 0.05),
        Probe("Anteil Warten aller Plätze", "Anteil", 0.05),
        Probe("Anteil Essen aller Plätze", "Anteil", 0.05),
        *(Probe(f"Mahlzeiten an Platz {i}", "Mahlzeiten", 3) for i in range(1, 5)),
    )
    rows = []
    for strategy, seed in product(
        ("atomic", "unprotected", "waiter"), (21, 22, 23, 24)
    ):
        run = c04.run_c04(strategy, seed=seed, horizon=100.0)
        rows.append(
            Scenario(
                f"{strategy}, Spur {seed}",
                (run.meals,),
                (
                    run.thinking_fraction,
                    run.waiting_fraction,
                    run.eating_fraction,
                    *run.philosopher_meals[:4],
                ),
                "Verklemmung" if run.deadlocked else "lebendiger Ablauf",
            )
        )
    return case(
        "C04",
        "Philosophen, drei Zugriffsregeln und Verklemmungsmerkmal",
        "C04 Ereignismodell bis 100 Modellzeiteinheiten",
        [Quantity("Gesamtzahl Mahlzeiten", "Mahlzeiten", 2.0)],
        measurements,
        rows,
        DES,
    )


def emergency():
    measurements = (
        *(Probe(f"Aufenthaltsmittel Klasse {i}", "min", 10) for i in range(1, 5)),
        Probe("Schließzeit", "min", 8),
        Probe("Streuung Aufenthaltszeit", "min", 4),
    )
    rows = []
    for follow, seed in product((False, True), range(41, 49)):
        run = c06.solve_c06(task_b_active=follow, seed=seed, num_patients=60)
        rows.append(
            Scenario(
                f"Variante {int(follow)}, Spur {seed}",
                (run["overall"],),
                (
                    *(run[f"type_{i}"] for i in range(1, 5)),
                    run["closing_minutes"],
                    run["std_dev"],
                ),
            )
        )
    return case(
        "C06",
        "Simulierte Notaufnahme mit 60 Vorgängen, Varianten A und B",
        "C06 FIFO und definierte Folgenutzung von Ressourcen",
        [Quantity("Mittlere gesamte Aufenthaltszeit", "min", 3.0)],
        measurements,
        rows,
        DES,
    )


def lock():
    measurements = (
        Probe("Ostankünfte bis Minute 20", "Schiffe", 4),
        Probe("Westankünfte bis Minute 20", "Schiffe", 4),
        Probe("Ost abgefertigt", "Schiffe", 5),
        Probe("West abgefertigt", "Schiffe", 5),
        Probe("Ost mittlere Transitzeit", "s", 90),
        Probe("West mittlere Transitzeit", "s", 90),
    )
    rows = []
    for capacity, seed in product(((2, 2), (4, 2), (2, 4)), range(50, 54)):
        horizon = 3600.0
        arrivals = c08._stochastic_arrivals(seed=seed, duration=horizon)
        model = c08.CanalAndLock(*capacity)
        count = 0
        for direction, stream in zip(
            (c08.Direction.EASTBOUND, c08.Direction.WESTBOUND), arrivals, strict=True
        ):
            for t in stream:
                model.schedule_arrival(c08.Barge(count, direction, HyperTime.at(t)))
                count += 1
        model.run(horizon)
        stats = model.average_transit_times()
        tally = tuple(
            sum(barge.direction == d for barge, _ in model.completed_barges)
            for d in (c08.Direction.EASTBOUND, c08.Direction.WESTBOUND)
        )
        rows.append(
            Scenario(
                f"Kapazität {capacity}, Spur {seed}",
                (stats["pooled"],),
                (
                    *(sum(t <= 1200 for t in stream) for stream in arrivals),
                    *tally,
                    stats["eastbound"],
                    stats["westbound"],
                ),
            )
        )
    return case(
        "C08",
        "Kanalschleuse, beidseitige Ankünfte über eine Stunde",
        "C08 Ankunftsgenerator und CanalAndLock",
        [Quantity("Mittlere Transitzeit abgefertigter Schiffe", "s", 25.0)],
        measurements,
        rows,
        DES,
    )


def chopsticks():
    states = c10.PhilosopherState
    index = {s: i for i, s in enumerate(states)}
    measurements = (
        Probe("Anzahl freier Stäbchen", "Stäbchen", 1),
        *(Probe(f"Anforderungszustand Platz {i}", "Zustandscode", 1) for i in range(5)),
    )
    rows = []
    for contended, extra, eating in product(range(5), (False, True), (False, True)):
        start = [states.THINKING] * 5
        free = [True] * 5
        left = (contended - 1) % 5
        start[left] = states.WAITING_RIGHT
        free[left] = False
        start[contended] = states.WAITING_LEFT
        if extra:
            start[(contended + 1) % 5] = states.WAITING_LEFT
        if eating:
            k = (contended + 2) % 5
            start[k] = states.EATING
            free[k] = free[(k + 1) % 5] = False
        _, _, started, conflicts = c10.resolve_chopstick_requests(start, free)
        assert conflicts and conflicts[0].winner_id == contended
        label = ",".join(f"{t.chopstick_id}→{t.winner_id}" for t in conflicts)
        rows.append(
            Scenario(
                f"Stäbchen {contended}, Zusatz {int(extra)}, Essen {int(eating)}",
                (len(started),),
                (sum(free), *(index[s] for s in start)),
                label,
            )
        )
    return case(
        "C10",
        "Gleichzeitiger Zugriff in legal belegten Anfangszuständen",
        "C10 Konfliktauflösung der Ereignisroutine",
        [Quantity("Neu begonnene Mahlzeiten", "Mahlzeiten", 0.25)],
        measurements,
        rows,
    )


def supply():
    days = (9, 12, 15, 18, 21, 24, 27)
    rows = []
    for seed in range(42, 58):
        run = c14.c14_task_a1(seed=seed)
        stock = {t // 86400: sum(products.values()) for t, products in run}
        rows.append(
            Scenario(
                f"Nachfragespur {seed}", (stock[30],), tuple(stock[i] for i in days)
            )
        )
    return case(
        "C14",
        "Lager D1 mit festgelegten Nachfragespuren",
        "C14 Bestands- und Nachbestellrechnung A1",
        [Quantity("Gesamtbestand D1 an Tag 30", "Produkte", 6.0)],
        probes("Gesamtbestand D1", "Produkte", 10.0, days, "d"),
        rows,
        DES,
    )


def restaurants():
    weeks = (26, 52, 78, 104, 130, 156, 208)
    rows = []
    for rate, seed in product((0.16, 0.20, 0.24), (32, 33, 34)):
        params = c16.C16Parameters(
            total_people=600,
            initial_restaurants=6,
            running_cost=30.0,
            profit_threshold=70.0,
            initial_tax_rate=rate,
        )
        counts = c16._weekly_restaurant_counts(params, seed, weeks=260)
        rows.append(
            Scenario(
                f"Steuersatz {rate:g}, Spur {seed}",
                (counts[-1],),
                tuple(counts[w - 1] for w in weeks),
            )
        )
    return case(
        "C16",
        "Restaurantdynamik bis Jahr fünf im verkleinerten Markt mit 600 Personen",
        "C16 Agentenmodell, wöchentliche Beobachtung",
        [Quantity("Restaurantzahl nach fünf Jahren", "Restaurants", 1.0)],
        probes("Restaurantzahl", "Restaurants", 4, weeks, "Wochen"),
        rows,
        DES,
    )


def production():
    measurements = tuple(
        Probe(f"Durchlaufzeit fertiggestellter Auftrag Nr. {i}", "s", 100.0)
        for i in (1, 2, 3, 4, 6, 8, 10)
    )
    rows = []
    for kind, seed in product(
        (c20.C20OrderScenario.OSC1, c20.C20OrderScenario.OSC2), range(20, 26)
    ):
        run = c20.run_c20_replication(
            kind, c20.C20PlantScenario.PSC1, seed=seed, order_seed=seed, order_count=24
        )
        finished = sorted(
            run.orders, key=lambda order: (order.completion_date, order.identifier)
        )
        assert len(finished) == 24
        rows.append(
            Scenario(
                f"{kind.value}, Spur {seed}",
                (run.median_throughput_time,),
                tuple(finished[i - 1].throughput_time for i in (1, 2, 3, 4, 6, 8, 10)),
            )
        )
    return case(
        "C20",
        "Produktionsanlage, 24 Aufträge und zwei Auftragsprofile",
        "C20 Fertigung und Transporte PSc1",
        [Quantity("Median der Durchlaufzeit", "s", 65.0)],
        measurements,
        rows,
        DES,
    )


def queuing():
    measurements = (
        Probe("Maximale Warteschlangenlänge", "Aufträge", 3),
        Probe("Mittlere Warteschlangenlänge", "Aufträge", 1),
        Probe("Größte Wartezeit", "Modellzeit", 2),
        Probe("Bearbeitete Ereignisse", "Ereignisse", 100),
    )
    rows = []
    for system, seed in product(
        (c22.BaseDevsSystem, c22.RenegingSystem), range(42, 50)
    ):
        run = c22.run_model(system, True, False, seed=seed)
        assert (
            run["entities_created"] == run["entities_terminated"]
            and run["active_entities"] == 0
        )
        rows.append(
            Scenario(
                f"{system.__name__}, Spur {seed}",
                (run["tq_avg"],),
                tuple(
                    run[key]
                    for key in ("lqt_max", "lqt_avg", "tq_max", "processed_events")
                ),
                "Abbruch beobachtet" if run.get("renege_events", 0) else "ohne Abbruch",
            )
        )
    return case(
        "C22",
        "Warteschlange mit und ohne Abbruch, stochastische kleine Instanz",
        "C22 NS-DEVS, abgeschlossene Lebenszyklen",
        [Quantity("Mittlere Wartezeit", "Modellzeit", 0.4)],
        measurements,
        rows,
        DES,
    )
