"""Reproduce the catalogue of 28 distinct ARGESIM measurement tasks."""

import argparse
import csv
from dataclasses import asdict
import json
from pathlib import Path
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE / "projekt"), str(HERE.parent / "fno_transfer")]

import dynamik  # noqa: E402
import diskret  # noqa: E402
import parallelfaelle  # noqa: E402
from planer import analyze, check_example  # noqa: E402
import c19r_plan  # noqa: E402


PROJECT = "16f0f2528fcf77f16898ecd74ad952be2c09eac2"
REGISTRY = {
    "C01": dynamik.lithium,
    "C02": diskret.assembly,
    "C03": dynamik.amplifier,
    "C04": diskret.dining,
    "C05": dynamik.hysteresis,
    "C06": diskret.emergency,
    "C07": dynamik.pendulum,
    "C08": diskret.lock,
    "C09": dynamik.tanks,
    "C10": diskret.chopsticks,
    "C11": dynamik.robot,
    "C12": dynamik.collisions,
    "C13": dynamik.crane,
    "C14": diskret.supply,
    "C15": dynamik.clearance,
    "C16": diskret.restaurants,
    "C17R": dynamik.sir,
    "C18": dynamik.identification,
    "C19R": None,
    "C20": diskret.production,
    "C21": dynamik.ball,
    "C22": diskret.queuing,
    "CP1/A": parallelfaelle.oscillator,
    "CP1/B": parallelfaelle.populations,
    "CP1/C": parallelfaelle.driven_rope,
    "CP2/1": parallelfaelle.monte_carlo,
    "CP2/2": parallelfaelle.cavity,
    "CP2/3": parallelfaelle.plucked_rope,
}


def groundwater():
    c19r_plan.check_planner()
    main = c19r_plan.run(5.0, simulate=True)
    replay = main["replay"]
    stages = {"uniform": "uniform", "planned": "targeted", "adaptive": "online"}
    plans = {
        name: {
            "max": replay["strategies"][key]["maximum"],
            "mean": replay["strategies"][key]["mean"],
        }
        for name, key in stages.items()
    }
    return {
        "identifier": "C19R",
        "description": "Konzentration am Brunnen bei 5 m, garantierte Quellzeitplanung bei bekanntem Eintrag",
        "reference": "Positiver Green-Kern, gerichtete Quadratur und vollständiger Vergleich fester Pläne",
        "trace_kind": "kontinuierliche Ratenbox mit Massenbedingung",
        "quantities": [
            {"label": "Brunnenwert nach 10 Tagen", "unit": "relativ", "budget": 0.01}
        ],
        "probes": [
            {
                "label": f"Freigesetzte Masse bis Tag {time:g}",
                "unit": "mg",
                "quantum": None,
            }
            for time in c19r_plan.times_days(range(1, c19r_plan.CELLS))
        ],
        "result": plans
        | {
            "scenarios": replay["histories"],
            "unresolved_scenarios": 0,
            "witness": None,
        },
        "source_enclosure": main,
        "shifted_well": c19r_plan.run(5.25, simulate=False),
    }


def run(selected=None):
    check_example()
    registry = REGISTRY if selected is None else {selected: REGISTRY[selected]}
    cases = []
    for key, evaluate in registry.items():
        if evaluate is None:
            record = groundwater()
        else:
            case = evaluate()
            assert case.identifier == key
            record = asdict(case) | {"result": analyze(case)}
            if case.extra_probes:
                record["with_extra"] = analyze(case.expanded())
        cases.append(record)
        result = record["result"]
        if result["adaptive"] is not None:
            costs = "/".join(
                str(result[name]["max"]) for name in ("uniform", "planned", "adaptive")
            )
        else:
            costs = f"offen für {result['unresolved_scenarios']}"
        if "with_extra" in record:
            after = record["with_extra"]["adaptive"]
            costs += (
                f" → {after['max']} mit Zusatzkanal"
                if after
                else " → offen mit Zusatzkanal"
            )
        print(f"{key}: {result['scenarios']} Verläufe, {costs}", flush=True)
    return {"project_commit": PROJECT, "cases": cases}


def to_csv(report, path):
    header = (
        "Aufgabe",
        "Prüfverläufe",
        "Zielgrößen",
        "Messmöglichkeiten",
        "gleichmäßig_max",
        "fest_max",
        "adaptiv_max",
        "gleichmäßig_mittel",
        "fest_mittel",
        "adaptiv_mittel",
        "unentscheidbare_Verläufe",
        "Zusatzkanal",
        "adaptiv_max_mit_Zusatzkanal",
        "unentscheidbar_mit_Zusatzkanal",
    )
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(header)
        for case in report["cases"]:
            result = case["result"]
            plans = [result[k] for k in ("uniform", "planned", "adaptive")]
            extra = case.get("with_extra", {})
            adapted = extra.get("adaptive")
            writer.writerow(
                [
                    case["identifier"],
                    result["scenarios"],
                    " / ".join(q["label"] for q in case["quantities"]),
                    len(case["probes"]),
                    *(p["max"] if p else "" for p in plans),
                    *(f"{p['mean']:.4f}" if p else "" for p in plans),
                    result["unresolved_scenarios"],
                    " / ".join(p["label"] for p in case.get("extra_probes", ())),
                    adapted["max"] if adapted is not None else "",
                    extra.get("unresolved_scenarios", ""),
                ]
            )


def numpy_value(value):
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(f"unsupported report value {type(value).__name__}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=tuple(REGISTRY))
    parser.add_argument("--out", type=Path, default=HERE / "messung")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    report = run(args.case)
    assert args.case is not None or len(report["cases"]) == 28
    (args.out / "messplanung.json").write_text(
        json.dumps(
            report, ensure_ascii=False, allow_nan=False, default=numpy_value, indent=2
        )
        + "\n",
        encoding="utf-8",
    )
    to_csv(report, args.out / "messplanung.csv")


if __name__ == "__main__":
    main()
