"""Short Fourier corrections around the original C05, C07 and C09 models."""

import math
from time import perf_counter

import numpy as np
from scipy.integrate import solve_ivp

from c05_referenz import (
    C05_C1, C05_C3, C05_INITIAL_STATE, C05_MODE_1, C05_MODE_2,
    C05_REFERENCE_EVENT_TIMES, C05_TASK_D_MODE_2, C05_TASK_D_REFERENCE_EVENT_TIMES,
    C05_TASK_D_REFERENCE_LAST_EVENT_TIMES, c05_exact_step, _event_delay,
)
from c09_referenz import C09PlantParameters, c09_pfc_control, c09_plant_rhs, _c09_rk4_step
from fourier_layer import WindowFNO, max_normalized, median_ms, scores, window_features


def base_path(rhs, initial, duration, midpoint=False):
    ends = [np.asarray(initial,dtype=float)]
    step = duration / 4
    for _ in range(4):
        y = ends[-1]
        slope = rhs(y)
        if midpoint:
            slope = rhs(y + step*slope/2)
        ends.append(y + step*slope)
    return np.stack(ends,axis=1)


def dopri_many(rhs, initial, duration):
    shape = initial.shape
    sol = solve_ivp(lambda _t, packed: rhs(packed.reshape(shape)).ravel(),
                    (0,duration), initial.ravel(), method="DOP853", rtol=2e-12, atol=2e-13)
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.y[:,-1].reshape(shape)


def rk4(rhs, state, step):
    a=rhs(state)
    b=rhs(state+step*a/2)
    c=rhs(state+step*b/2)
    d=rhs(state+step*c)
    return state + step*(a+2*b+2*c+d)/6


def pump_reference(states, voltage):
    return np.array([c09_plant_rhs(a,b,u) for (a,b),u in zip(states,voltage,strict=True)])


def pump_features(path, voltage):
    forcing = np.broadcast_to(np.asarray(voltage)[:,None,None], (len(path),5,1))
    return np.concatenate((path,forcing),axis=2)


def tank_run(states, setpoint, burst, mode, model):
    states = np.array(states,dtype=float,copy=True)
    saved = [states.copy()]
    pump = []
    predicted = np.zeros(len(states), dtype=int)
    at_fallback = np.zeros_like(predicted)
    for tick in range(16):
        voltage = np.clip([c09_pfc_control(wanted-level,level)
                           for wanted,level in zip(setpoint,states[:,1],strict=True)],0,.3)
        if tick >= 4:
            voltage += burst
        rhs = lambda y: pump_reference(y,voltage)
        pump.append(voltage.copy())
        if mode == "reference":
            states = dopri_many(rhs,states,1.)
        elif mode == "rk4":
            params = C09PlantParameters()
            states = np.array([_c09_rk4_step(a,b,u,1.,params) for (a,b),u in zip(states,voltage,strict=True)])
        else:
            path = base_path(rhs,states,1.)
            possible = path[:,-1].copy()
            if mode == "hybrid_fno":
                usable = ((path[:,:,0].min(axis=1)>=.37) & (path[:,:,0].max(axis=1)<=.69) &
                          (path[:,:,1].min(axis=1)>=.21) & (path[:,:,1].max(axis=1)<=.45) &
                          ((path[:,:,0]-path[:,:,1]).min(axis=1)>=.044) & (voltage<=.43))
                indices = np.flatnonzero(usable)
                if len(indices):
                    estimate = possible[indices]+model.predict(pump_features(path[indices],voltage[indices]))
                    admissible = np.isfinite(estimate).all(axis=1) & (estimate[:,1]>.18) & (estimate[:,0]>0)
                    usable[indices] = admissible
                    possible[indices[admissible]] = estimate[admissible]
                fallback = np.flatnonzero(~usable)
                if len(fallback):
                    possible[fallback] = dopri_many(lambda s:pump_reference(s,voltage[fallback]),states[fallback],1.)
                predicted += usable
                at_fallback += ~usable
            states = possible
        saved.append(states.copy())
    return np.stack(saved,axis=1), np.stack(pump,axis=1), predicted, at_fallback


def c09(destination):
    setup_started = perf_counter()
    rng=np.random.default_rng(905)
    train=rng.uniform([.37,.21],[.69,.45],size=(1200,2))
    train=train[train[:,0]-train[:,1]>=.045]
    voltage=rng.uniform(0,.43,len(train))
    rhs=lambda s:pump_reference(s,voltage)
    classical=base_path(rhs,train,1.)
    exact=dopri_many(rhs,train,1.)
    fit_started = perf_counter()
    model,fit=WindowFNO.fit(pump_features(classical,voltage),exact-classical[:,-1],905)
    fit_seconds = perf_counter() - fit_started
    # 8 in-domain scenarios and two guards outside the training box.
    initial=np.array([[.503,.3],[.44,.26],[.55,.31],[.50,.30],[.62,.34],[.47,.35],
                      [.64,.38],[.50,.39],[.73,.40],[.34,.19]])
    setpoint=np.array([.30,.32,.34,.31,.30,.29,.42,.34,.42,.34])
    burst=np.array([.10,.08,.02,.10,.12,.0,.09,.04,.12,.08])
    expected,reference_pump,_,_=tank_run(initial,setpoint,burst,"reference",None)
    assert np.allclose(expected[0,1],[.500398,.301913],atol=1e-6)
    budget=np.array([.0005,.0005])
    arrays,results={},{}
    for name in ("euler","rk4","hybrid_fno"):
        call=lambda:tank_run(initial,setpoint,burst,name,model)
        fields,applied,active,fallback=call()
        assert np.isfinite(fields).all()
        states=max_normalized(fields,expected,budget)
        controls=np.max(np.abs(applied-reference_pump)/.005,axis=1)
        result=scores(np.maximum(states,controls))
        assert applied.shape==(10,16)
        results[name]=result | {"batch_ms":median_ms(call,3),"learned_steps":active.tolist(),
                                "fallback_steps":fallback.tolist(),
                                "level_max_mm":float(np.max(np.abs(fields-expected))*1000)}
        arrays[name]=fields
    assert sum(results["hybrid_fno"]["learned_steps"]) > 0
    assert sum(results["hybrid_fno"]["fallback_steps"][-2:]) > 0
    assert np.all(np.array(results["hybrid_fno"]["learned_steps"])+results["hybrid_fno"]["fallback_steps"]==16)
    np.savez_compressed(destination/"c09.npz",reference=expected, reference_voltage=reference_pump,
                        initial=initial, setpoint=setpoint, burst=burst, **arrays, **vars(model))
    return {"methods":results,"fit":fit,"budget_m":.0005,"budget_v":.005,"tacts":16,
            "data_seconds":fit_started - setup_started,"fit_seconds":fit_seconds,
            "initial":initial.tolist(),"scope":"16-tact PFC short window with an imposed fluctuation from 4 s"}


PIN=-np.pi/12
LENGTHS=(1., .3)
C07_H=.04


def pendulum(length,damping):
    def rhs(state):
        phi,omega=state.T
        return np.column_stack((omega,-9.81/length*np.sin(phi)-damping/1.02*omega))
    return rhs


def timed_arc(start,length,damping,duration,direction=None):
    field=pendulum(length,damping)
    event=None
    if direction is not None:
        def event(_t,z):
            return z[0]-PIN
        event.direction=direction
        event.terminal=True
    sol=solve_ivp(lambda _t,y:field(y[None])[0],(0.,duration),start,method="DOP853",
                  events=event,rtol=8e-13,atol=8e-14,max_step=.02)
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.y[:,-1],float(sol.t[-1]),(event is not None and len(sol.t_events[0])>0)


def c07_run(initial,damping,method,models):
    state=np.array(initial,dtype=float)
    side=int(state[0]<PIN)
    history=[state.copy()]
    events=[]
    active,fallback,reset_error=0,0,0.
    for i in range(250):
        left=C07_H
        for j in range(12):
            elapsed=C07_H-left
            length=LENGTHS[side]
            field=pendulum(length,damping)
            # The damping cannot increase |omega|. Bound travel by integrating g/L.
            swept=left*abs(state[1])+9.81/(2*length)*left**2
            safe=abs(state[0]-PIN)>swept+1e-12
            known=(abs(state[0])<=.90 and abs(state[1])<=6. and .05<=damping<=.28)
            if safe and method!="reference":
                start=state[None]
                if method=="rk4":
                    state=rk4(field,start,left)[0]
                    break
                if method=="midpoint" and j==0:
                    state=base_path(field,start,left,midpoint=True)[0,-1]
                    break
                if method in ("fno_euler","hybrid_fno") and known and j==0:
                    path=base_path(field,start,left,midpoint=method=="hybrid_fno")
                    encoding=np.concatenate((path,np.full((1,5,1),damping)),axis=2)
                    proposal=path[0,-1]+models[method][side].predict(encoding)[0]
                    if np.isfinite(proposal).all() and (proposal[0]-PIN)*(state[0]-PIN)>0:
                        state=proposal
                        active+=1
                        break
            # The same classical root localisation and arc update is used by both step policies.
            direction=(-1,1)[side]
            state,used,hit=timed_arc(state,length,damping,left,direction)
            fallback+=1
            if not hit:
                break
            after=LENGTHS[1-side]
            speed=length*state[1]
            state=np.array([PIN,speed/after])
            reset_error=max(reset_error,abs(speed-after*state[1]))
            events.append((i*C07_H+elapsed+used,direction))
            left-=used
            side=1-side
            if left <= 1e-13:
                break
        else:
            raise RuntimeError("too many C07 events in one window")
        history.append(state.copy())
    return np.array(history),events,active,fallback,reset_error


def hybrid_score(states,expected,events,reference,states_budget,time_budget):
    wave=max_normalized(states,expected,np.asarray(states_budget))
    timing=[]
    verified=[]
    for a,b in zip(events,reference,strict=True):
        if [i[1] for i in a]!=[i[1] for i in b]:
            timing.append(None)
            continue
        err=max((abs(x[0]-y[0]) for x,y in zip(a,b,strict=True)),default=0.)
        timing.append(float(err))
    factor=[]
    for gap,relative in zip(timing,wave,strict=True):
        factor.append(float(max(gap/time_budget,relative)) if gap is not None else None)
        verified.append(gap is not None and factor[-1]<=1.)
    return {"scores":factor,"accepted":int(sum(verified)),"count":len(factor),
            "maximum":max((v for v in factor if v is not None),default=None),
            "event_mismatch":sum(t is None for t in timing),"event_errors_s":timing,
            "states_max":wave.tolist()}


def constraint_defects(states, events, schedule, grid):
    modes = np.empty(states.shape[:2], dtype=int)
    for i, (initial, marks) in enumerate(zip(schedule,events,strict=True)):
        crossed = np.searchsorted([time for time,_ in marks],grid,side="right")
        modes[i] = (int(initial[0]<PIN)+crossed)%2
    radius = np.take(LENGTHS,modes)
    angle, angular_rate = states[:,:,0], states[:,:,1]
    position = np.stack((radius*np.sin(angle),-radius*np.cos(angle)),axis=-1)
    velocity = np.stack((radius*angular_rate*np.cos(angle),radius*angular_rate*np.sin(angle)),axis=-1)
    length_residual = float(np.max(np.abs(np.linalg.norm(position,axis=-1)-radius)))
    tangency = float(np.max(np.abs(np.sum(position*velocity,axis=-1))))
    assert max(length_residual,tangency) < 1e-12
    return {"length_residual_m":length_residual,"tangency_residual_m2_s":tangency}


def c07(destination):
    setup_started = perf_counter()
    rng=np.random.default_rng(705)
    start=rng.uniform([-.90,-6.],[.90,6.],size=(1250,2))
    damping=rng.uniform(.05,.28,size=len(start))
    models,fit={},{}
    fit_seconds = 0.0
    for name in ("fno_euler","hybrid_fno"):
        models[name],fit[name]=[],[]
        for side,length in enumerate(LENGTHS):
            field=lambda z: np.column_stack((z[:,1],-9.81/length*np.sin(z[:,0])-damping/1.02*z[:,1]))
            path=base_path(field,start,C07_H,midpoint=name=="hybrid_fno")
            exact=dopri_many(field,start,C07_H)
            encoding=np.concatenate((path,np.broadcast_to(damping[:,None,None],(len(path),5,1))),axis=2)
            fit_started = perf_counter()
            model,record=WindowFNO.fit(encoding,exact-path[:,-1],705+side)
            fit_seconds += perf_counter() - fit_started
            models[name].append(model)
            fit[name].append(record)
    data_seconds = perf_counter() - setup_started - fit_seconds
    specs=[(np.pi/6,0,.2),(-np.pi/6,0,.1),(.42,-.1,.17),(.36,.20,.21),(.65,0,.11),
           (-.44,.0,.18),(.48,-.3,.15),(-.49,-.1,.23),(.58,-.11,.14),(.31,-.08,.19),
           (-.54,.15,.16),(.46,.16,.245)]

    def run(method):
        runs=[c07_run([angle,speed],friction,method,models) for angle,speed,friction in specs]
        states,events,accepted,fallback,errors=zip(*runs,strict=True)
        return np.stack(states),events,list(accepted),list(fallback),max(errors)

    expected,reference,_,_,_=run("reference")
    example_times = [.703459,1.151780,2.590418,2.990529,4.542741,4.867488,6.648707,6.720384]
    assert np.allclose([t for t,_ in reference[0]],example_times,rtol=0,atol=6e-7)
    assert len(reference[1])>=4
    wave_budget=[.001,.005]
    timing_budget=.001
    results={}
    arrays={}
    grid=np.arange(251)*C07_H
    for variant in ("rk4","midpoint","fno_euler","hybrid_fno"):
        states,events,active,fallback,reset=run(variant)
        assert reset < 1e-12
        r=hybrid_score(states,expected,events,reference,wave_budget,timing_budget)
        results[variant]=r | {"batch_ms":median_ms(lambda:run(variant),3),"events":events,
                             "learned_steps":active,"arc_solves":fallback,"reset_error_m_s":reset}
        results[variant].update(constraint_defects(states, events, specs, grid))
        arrays[variant]=states
    assert min(results["hybrid_fno"]["learned_steps"])>0
    defects=constraint_defects(expected,reference,specs,grid)
    trained={f"{name}_mode{typ}_{key}":value for name,pair in models.items()
             for typ,mdl in enumerate(pair) for key,value in vars(mdl).items()}
    np.savez_compressed(destination/"c07.npz",time=grid,reference=expected, **arrays,**trained)
    return {"methods":results,"fit":fit,"specs":specs,"reference_events":reference,
            "data_seconds":data_seconds,"fit_seconds":fit_seconds,
            "reference_constraints":defects,"h":C07_H,"event_budget_s":timing_budget,"state_budget":wave_budget,
            "scope":"C07 A pendulum angle formulation; hybrid events with pin reset"}


def fno_lag_fit():
    rng=np.random.default_rng(505)
    differences=rng.uniform(-5.5,3.,size=96)
    elapsed=rng.uniform(.015,1.6,size=len(differences))
    mode=C05_MODE_1
    feature_path=np.exp(-C05_C3*(elapsed[:,None]-np.linspace(.006,0,5))) * differences[:,None]
    target=[]
    for d,t in zip(differences,elapsed,strict=True):
        x,y=c05_exact_step((4.2,mode.c4+d),t,mode)
        target.append(x-y-mode.c2)
    weights=np.linalg.lstsq(window_features(feature_path[:,:,None]),target,rcond=1e-10)[0]
    one=np.exp(C05_C3*np.linspace(.006,0,5))[None,:,None]
    ratio=float((window_features(one)@weights)[0])
    assert abs(ratio-C05_C3/(C05_C1-C05_C3)) < 1e-10
    return weights,ratio


def candidate_event(state,mode,t_bound,lag,certify):
    warm=40/C05_C1
    d=state[1]-mode.c4
    eq=mode.c4+mode.c2
    warm_values=(state[0],eq+d,eq+d*math.exp(-C05_C3*warm))
    # x(t) follows y+c2 with a stable first-order lag, hence stays in this hull.
    if t_bound<=warm or min(warm_values)<=mode.threshold<=max(warm_values):
        return _event_delay(state,mode,t_bound),True
    target=(mode.threshold-eq)/(d*(1+lag)) if d else -1.
    if not 0 < target <= 1:
        return _event_delay(state,mode,t_bound),True
    trial=-math.log(target)/C05_C3
    if not certify:
        return (trial if trial<=t_bound else None),False
    lower,upper=trial-2e-8,trial+2e-8
    if (lower < warm or upper>t_bound or
            mode.direction*(c05_exact_step(state,lower,mode)[0]-mode.threshold)>=0 or
            mode.direction*(c05_exact_step(state,upper,mode)[0]-mode.threshold)<0):
        return _event_delay(state,mode,t_bound),True
    return trial,False


def c05_simulate(initial,fast_task,method,learned):
    state=initial
    now=0.
    mode=0
    counter=0
    modes=(C05_MODE_1,C05_TASK_D_MODE_2 if fast_task else C05_MODE_2)
    observed=[]
    for _ in range(128):
        left=5.-now
        if left<=0:
            return state,observed,counter
        if method=="closed":
            dt=_event_delay(state,modes[mode],left)
        else:
            if method=="slow":
                lag=0.
            elif method=="lag_formula":
                lag=C05_C3/(C05_C1-C05_C3)
            else:
                lag=learned
            dt,fallback=candidate_event(state,modes[mode],left,lag,method!="slow")
            counter+=int(fallback)
        if dt is None:
            return c05_exact_step(state,left,modes[mode]),observed,counter
        now+=dt
        observed.append((now,modes[mode].direction))
        state=c05_exact_step(state,dt,modes[mode])
        mode=1-mode
    raise RuntimeError("unexpected C05 event count")


def c05(destination):
    start=perf_counter()
    weights,lag=fno_lag_fit()
    elapsed=perf_counter()-start
    cases=[(C05_INITIAL_STATE,False),(C05_INITIAL_STATE,True),((4.15,.29),False),
           ((4.50,.32),True),((4.80,.27),False),((4.30,.39),True),((5.79,5.57),False),
           ((4.10,.32),False)]

    def run(method):
        return tuple(zip(*(c05_simulate(initial,fast,method,lag) for initial,fast in cases),strict=True))

    expected,events,_=run("closed")
    assert np.allclose([t for t,_ in events[0]],C05_REFERENCE_EVENT_TIMES,rtol=0,atol=4e-12)
    assert len(events[1])==62
    assert np.allclose([t for t,_ in events[1][:4]],C05_TASK_D_REFERENCE_EVENT_TIMES,rtol=0,atol=4e-12)
    assert np.allclose([t for t,_ in events[1][-4:]],C05_TASK_D_REFERENCE_LAST_EVENT_TIMES,rtol=0,atol=4e-12)
    results={}
    for variant in ("closed","slow","lag_formula","fno_event"):
        states,times,fallback=run(variant)
        results[variant]=hybrid_score(np.array(states),np.array(expected),times,events,[1e-6,1e-6],5e-8)
        results[variant].update({"analytic_fallback":list(fallback),"batch_ms":median_ms(lambda:run(variant),3),
                                 "events":times})
    assert results["fno_event"]["accepted"] == len(cases)
    assert results["fno_event"]["analytic_fallback"][6] > 0
    np.savez_compressed(destination/"c05.npz",weights=weights,effective_lag=lag)
    return {"methods":results,"references":events,"case_inputs":cases,"fit_seconds":elapsed,
            "fit_count":96,"learned_lag":lag,"event_budget_s":5e-8,"state_budget":[1e-6,1e-6],
            "scope":"C05 default and D with a certified candidate for each slow crossing"}
