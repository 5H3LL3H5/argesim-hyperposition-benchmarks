"""Unchanged C09 plant and PFC functions from project blob d210a75bfcc34862c0287bc5465b133af95ff121."""

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class C09PlantParameters:
    v1: float = 0.4
    v2: float = 0.3
    c1: float = 0.067
    c2: float = 0.0605
    c3: float = 0.06624

    def __post_init__(self) -> None:
        if any(
            not math.isfinite(value) or value <= 0.0
            for value in (self.v1, self.v2, self.c1, self.c2, self.c3)
        ):
            raise ValueError("C09 plant parameters must be positive and finite")


def _triangle(value: float, left: float, peak: float, right: float) -> float:
    if value <= left or value >= right:
        return 0.0
    if value == peak:
        return 1.0
    if value < peak:
        return (value - left) / (peak - left)
    return (right - value) / (right - peak)


def _left_shoulder(value: float, full_until: float, zero_at: float) -> float:
    if value <= full_until:
        return 1.0
    if value >= zero_at:
        return 0.0
    return (zero_at - value) / (zero_at - full_until)


def _right_shoulder(value: float, zero_until: float, full_at: float) -> float:
    if value <= zero_until:
        return 0.0
    if value >= full_at:
        return 1.0
    return (value - zero_until) / (full_at - zero_until)


def _pfc_error_memberships(error_cm: float) -> tuple[float, float, float]:
    """Return the wider Figure-5 (high, good, low) partition."""

    return (
        _left_shoulder(error_cm, -30.0, 0.0),
        _triangle(error_cm, -30.0, 0.0, 30.0),
        _right_shoulder(error_cm, 0.0, 30.0),
    )


def _sum_aggregate_centroid(
    strengths: tuple[float, ...],
    areas: tuple[float, ...],
    centroids: tuple[float, ...],
) -> float:
    """Exact COG for product implication and sum aggregation."""

    denominator = sum(weight * area for weight, area in zip(strengths, areas))
    if denominator == 0.0:
        return 0.0
    return sum(
        weight * area * centroid
        for weight, area, centroid in zip(strengths, areas, centroids)
    ) / denominator


def c09_pfc_control(error: float, h2: float) -> float:
    """Evaluate the proportional Mamdani controller in physical volts."""

    high_error, good_error, low_error = _pfc_error_memberships(100.0 * error)
    level_cm = 100.0 * h2
    low_level = _left_shoulder(level_cm, 30.0, 40.0)
    middle_level = _triangle(level_cm, 30.0, 40.0, 60.0)
    high_level = _right_shoulder(level_cm, 40.0, 60.0)
    strengths = (
        high_error,
        good_error * low_level,
        good_error * middle_level,
        good_error * high_level,
        low_error,
    )
    # Map the 0..3 ordinate in Figure 5 to this plant's 0..0.3 V convention.
    # Exact areas and moments avoid a 301-point scan every second.
    p1_area = 0.12
    p1_centroid = (0.1 * 0.05 + 0.02 * (0.1 + 0.1 + 0.14) / 3.0) / p1_area
    p5_area = 0.07
    p5_centroid = (0.02 * (0.21 + 0.25 + 0.25) / 3.0 + 0.05 * 0.275) / p5_area
    return _sum_aggregate_centroid(
        strengths,
        (p1_area, 0.0375, 0.035, 0.0375, p5_area),
        (
            p1_centroid,
            (0.10 + 0.14 + 0.175) / 3.0,
            0.175,
            (0.175 + 0.21 + 0.25) / 3.0,
            p5_centroid,
        ),
    )


def c09_plant_rhs(
    h1: float,
    h2: float,
    voltage: float,
    parameters: C09PlantParameters = C09PlantParameters(),
) -> tuple[float, float]:
    """Evaluate the revised nonlinear plant, including its h2 regime switch."""

    difference = h1 - h2
    coupling = (
        parameters.c3
        * parameters.v1
        * math.sqrt(abs(difference))
        * (1.0 if difference >= 0.0 else -1.0)
    )
    outlet_factor = 1.2 if h2 < 0.16 else 1.0
    outlet = (
        outlet_factor
        * parameters.c2
        * parameters.v2
        * math.sqrt(max(0.0, h2))
    )
    return parameters.c1 * voltage - coupling, coupling - outlet


def _c09_rk4_step(
    h1: float,
    h2: float,
    voltage: float,
    step: float,
    parameters: C09PlantParameters,
) -> tuple[float, float]:
    k1 = c09_plant_rhs(h1, h2, voltage, parameters)
    k2 = c09_plant_rhs(
        h1 + 0.5 * step * k1[0], h2 + 0.5 * step * k1[1], voltage, parameters
    )
    k3 = c09_plant_rhs(
        h1 + 0.5 * step * k2[0], h2 + 0.5 * step * k2[1], voltage, parameters
    )
    k4 = c09_plant_rhs(h1 + step * k3[0], h2 + step * k3[1], voltage, parameters)
    return (
        max(0.0, h1 + step * (k1[0] + 2.0 * k2[0] + 2.0 * k3[0] + k4[0]) / 6.0),
        max(0.0, h2 + step * (k1[1] + 2.0 * k2[1] + 2.0 * k3[1] + k4[1]) / 6.0),
    )
