"""Reproduce the six benchmark transfers and verify the catalog's 24 families."""

import argparse
import json
import os
from pathlib import Path
import platform
from tempfile import TemporaryDirectory

import numpy as np
import scipy

import ereignisse
import linear
from fourier_layer import check_window


CASES = {"c05": ereignisse.c05, "c07": ereignisse.c07, "c09": ereignisse.c09,
         "c13": linear.c13, "c15": linear.c15, "cp1": linear.cp1}
HERE = Path(__file__).resolve().parent
REFERENCE_BLOBS = {
    "c05_two_state.py": "e529183b650224e5394c53d25109e7b9970cd86e",
    "c07_constrained_pendulum.py": "7b9fead82df1397fe7cbcca17cd77d095b6c5c98",
    "c09_fuzzy_tanks.py": "d210a75bfcc34862c0287bc5465b133af95ff121",
    "c13_crane.py": "5433fcb6415085742bae1fdcfa5d243ff9ab17f9",
    "c15_clearance.py": "18f5e8803685f838c6f88c1624444754f47c7b72",
    "cp1_parallel.py": "f456f556ab520af1bffa283d37119e9b176e8787",
}


def read_catalog():
    catalog = json.loads((HERE / "katalog.json").read_text(encoding="utf-8"))
    assert {row["family"] for row in catalog} == {
        *(f"C{i:02d}" for i in range(1,23) if i not in (17,19)),
        "C17R","C19R","CP1","CP2",
    }
    assert len(catalog)==28 and len({row["task"] for row in catalog})==28
    assert {row["case"] for row in catalog if row["result"]=="neu"}==set(CASES)
    return catalog


def display(case, metrics):
    for name,row in metrics["methods"].items():
        value=row["maximum"]
        limit="unbewertet" if value is None else f"{value:.6g}"
        print(f"{case.upper():4s} {name:14s} {row['accepted']}/{row['count']} | Smax {limit}",flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case",choices=(*CASES,"all"),default="all")
    parser.add_argument("--out",type=Path,required=True)
    args=parser.parse_args()
    catalog=read_catalog()
    check_window()
    selection=CASES if args.case=="all" else {args.case:CASES[args.case]}
    args.out.mkdir(exist_ok=True,parents=True)
    manifest={"catalog_families":len({row["family"] for row in catalog}),"catalog_tasks":len(catalog),
              "reference_blobs": REFERENCE_BLOBS,
              "environment":{"python":platform.python_version(),"numpy":np.__version__,"scipy":scipy.__version__,
                             "machine":platform.machine(),"blas_threads":os.environ.get("OPENBLAS_NUM_THREADS"),
                             "omp_threads":os.environ.get("OMP_NUM_THREADS")}, "cases":{}}
    with TemporaryDirectory(dir=args.out,prefix=".transfer-") as temporary:
        stage=Path(temporary)
        for label,operation in selection.items():
            manifest["cases"][label]=operation(stage)
            display(label,manifest["cases"][label])
        result=stage/"transfer.json"
        result.write_text(json.dumps(manifest,indent=2,ensure_ascii=False,allow_nan=False)+"\n",encoding="utf-8")
        for file in sorted(stage.glob("*.npz")):
            file.replace(args.out/file.name)
        result.replace(args.out/result.name)


if __name__=="__main__":
    main()
