"""Fourier layers for sampled, causal histories and short residual windows."""

from dataclasses import dataclass
from statistics import median
from time import perf_counter_ns

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from scipy.linalg import lstsq
from scipy.optimize import minimize


def median_ms(call, repeats=5):
    call()
    times = []
    for _ in range(repeats):
        start = perf_counter_ns()
        call()
        times.append((perf_counter_ns() - start) / 1e6)
    return median(times)


def scores(sample_errors):
    values = np.asarray(sample_errors, dtype=float)
    assert np.isfinite(values).all() and (values >= 0).all()
    return {"scores": values.tolist(), "accepted": int(np.count_nonzero(values <= 1)),
            "maximum": float(values.max()), "count": len(values)}


def max_normalized(predicted, expected, budget):
    difference = np.abs(predicted - expected) / budget
    return difference.reshape(len(difference), -1).max(axis=1)


@dataclass(frozen=True)
class HistoryFNO:
    """One Fourier layer representing a channel-valued finite causal response."""

    kernel: np.ndarray

    @classmethod
    def fit(cls, forcing, targets):
        steps = forcing.shape[1]
        histories = sliding_window_view(np.pad(forcing, ((0, 0), (steps-1, 0))), steps, axis=1)
        design = histories[:, :, ::-1].reshape(-1, steps).copy()
        weights, _, rank, _ = lstsq(design, targets.reshape(len(design), -1), lapack_driver="gelsy")
        if rank != steps:
            raise ValueError("inputs do not identify the causal history kernel")
        return cls(weights)

    def spectrum(self):
        return np.fft.rfft(self.kernel, n=2*len(self.kernel), axis=0)

    def limited(self, modes):
        # Project a smoothed impulse response back onto causal support.
        spectrum = self.spectrum()
        spectrum[modes+1:] = 0
        causal = np.fft.irfft(spectrum, n=2*len(self.kernel), axis=0)[:len(self.kernel)]
        return HistoryFNO(causal)

    def predict(self, forcing, weights=None):
        steps = forcing.shape[1]
        if steps != len(self.kernel):
            raise ValueError("forcing length must match the trained time grid")
        if weights is None:
            weights = self.spectrum()
        spectrum = np.fft.rfft(forcing, n=2*steps, axis=1)
        return np.fft.irfft(spectrum[:, :, None] * weights, n=2*steps, axis=1)[:, :steps]


def window_features(path):
    """Latest-sample readout of DC and one positive Fourier mode, by channel."""
    if path.ndim != 3 or path.shape[1] != 5:
        raise ValueError("expected a batch of five uniformly spaced state vectors")
    spectrum = np.fft.rfft(path, axis=1)[:, :2] / 5
    last = spectrum[:, 1] * np.exp(2j*np.pi*4/5)
    return np.concatenate((spectrum[:, 0].real, 2*last.real, -2*last.imag, path[:, -1]), axis=1)


def forward(weights, features, channels, width):
    n_in = features.shape[1] * width
    hidden = np.tanh(features @ weights[:n_in].reshape(-1, width))
    w_out = weights[n_in:-channels].reshape(width, channels)
    return hidden @ w_out + weights[-channels:], hidden, w_out


def objective(weights, features, targets, width, penalty):
    output, hidden, w_out = forward(weights, features, targets.shape[1], width)
    residual = output - targets
    error = residual / len(features)
    delta = (error @ w_out.T) * (1 - hidden**2)
    gradient = np.r_[(features.T @ delta).ravel(), (hidden.T @ error).ravel(), error.sum(axis=0)]
    return (0.5*np.sum(error*residual) + 0.5*penalty*(weights @ weights), gradient + penalty*weights)


@dataclass(frozen=True)
class WindowFNO:
    """Nonlinear one-layer FNO correction for one fixed, already known segment."""

    mean: np.ndarray
    scale: np.ndarray
    target_mean: np.ndarray
    target_scale: np.ndarray
    weights: np.ndarray
    width: int

    @classmethod
    def fit(cls, paths, defects, seed):
        raw = window_features(paths)
        mean = raw.mean(axis=0)
        scale = np.maximum(raw.std(axis=0), 1e-12)
        normalized = np.column_stack(((raw - mean) / scale, np.ones(len(raw))))
        center = defects.mean(axis=0)
        width = 10
        target_scale = np.maximum(defects.std(axis=0), 1e-12)
        target = (defects - center) / target_scale
        rng = np.random.default_rng(seed)
        count = width * (normalized.shape[1] + target.shape[1]) + target.shape[1]
        results = [minimize(objective, rng.normal(0, .15, count),
                            args=(normalized, target, width, 2e-5), jac=True,
                            method="L-BFGS-B", options={"maxiter": 600, "ftol": 1e-11})
                   for _ in range(2)]
        remaining = [r for r in results if np.isfinite(r.fun) and np.isfinite(r.x).all()]
        if not remaining:
            raise RuntimeError("no finite Fourier-window fit")
        best = min(remaining, key=lambda r: r.fun)
        return cls(mean, scale, center, target_scale, best.x, width), {
            "train_loss": float(best.fun), "iterations": int(best.nit), "converged": bool(best.success),
            "training_windows": len(paths),
        }

    def predict(self, paths):
        encoded = (window_features(paths) - self.mean) / self.scale
        features = np.column_stack((encoded, np.ones(len(encoded))))
        output, _, _ = forward(self.weights, features, len(self.target_mean), self.width)
        return self.target_mean + self.target_scale * output


def check_window():
    rng = np.random.default_rng(40)
    paths = rng.normal(size=(9, 5, 2))
    complex_weights = rng.normal(size=(2, 2)) + 1j*rng.normal(size=(2, 2))
    complex_weights[0] = complex_weights[0].real
    spectrum = np.zeros((3, 2), dtype=complex)
    spectrum[:2] = complex_weights
    expected = np.fft.irfft(np.fft.rfft(paths, axis=1)*spectrum, n=5, axis=1)[:, -1].sum(axis=1)
    encoded = window_features(paths)
    multipliers = np.r_[complex_weights[0].real, complex_weights[1].real,
                        complex_weights[1].imag, np.zeros(2)]
    assert np.allclose(encoded @ multipliers, expected, rtol=0, atol=1e-13)
    features = np.column_stack((encoded, np.ones(len(encoded))))
    targets = rng.normal(size=(len(encoded), 2))
    theta = rng.normal(0, .1, 3*(features.shape[1]+2)+2)
    direction = rng.normal(size=len(theta))
    _, gradient = objective(theta, features, targets, 3, 2e-5)
    eps = 1e-6
    hi = objective(theta+eps*direction, features, targets, 3, 2e-5)[0]
    lo = objective(theta-eps*direction, features, targets, 3, 2e-5)[0]
    assert abs((hi-lo)/(2*eps) - gradient @ direction) < 1e-7
