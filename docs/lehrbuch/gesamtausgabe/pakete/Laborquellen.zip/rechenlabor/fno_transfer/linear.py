"""C13, C15 and CP1-C have linear subproblems with independent references."""

from time import perf_counter

import numpy as np
from scipy.fft import dst, idst
from scipy.integrate import solve_ivp
from scipy.linalg import expm, lstsq

from fourier_layer import HistoryFNO, max_normalized, median_ms, scores


def hold_transition(matrix, inputs, step):
    dim, channels = inputs.shape
    augmented = np.zeros((dim+channels, dim+channels))
    augmented[:dim, :dim] = matrix
    augmented[:dim, dim:] = inputs
    advance = expm(step*augmented)
    return advance[:dim, :dim], advance[:dim, dim:]


def rollout(transition, response, forcing):
    states = np.zeros((len(forcing), transition.shape[0]))
    history = np.empty((len(forcing), forcing.shape[1], states.shape[1]))
    for n, u in enumerate(forcing.T):
        states = states @ transition.T + u[:, None] * response
        history[:, n] = states
    return history


def history_study(train, tests, expected, direct, offset, budget, keep):
    start = perf_counter()
    target = direct(train)
    data_seconds = perf_counter() - start
    start = perf_counter()
    full = HistoryFNO.fit(train, target)
    restricted = full.limited(keep)
    full_weight, reduced_weight = full.spectrum(), restricted.spectrum()
    fit_seconds = perf_counter() - start
    impulse = np.zeros_like(train[:1])
    impulse[0,0] = 1.
    analytical_kernel = direct(impulse)[0]
    assert np.allclose(analytical_kernel, full.kernel, rtol=1e-8, atol=1e-9)
    analytical = HistoryFNO(analytical_kernel)
    analytical_weight = analytical.spectrum()
    methods = {
        "matrix_step": lambda u: offset + direct(u),
        "physics_fft": lambda u: offset + analytical.predict(u, analytical_weight),
        "fno_full": lambda u: offset + full.predict(u, full_weight),
        "fno_cut": lambda u: offset + restricted.predict(u, reduced_weight),
    }
    outputs, report = {}, {}
    cut = tests.shape[1] // 2
    changed = tests.copy()
    changed[:, cut:] += .17
    for name, call in methods.items():
        prediction = call(tests)
        assert np.allclose(call(changed)[:, :cut], prediction[:, :cut], rtol=1e-10, atol=1e-9)
        outputs[name] = prediction
        report[name] = scores(max_normalized(prediction, expected, budget))
        report[name]["batch_ms"] = median_ms(lambda: call(tests))
    assert report["fno_full"]["maximum"] < 1e-5
    return ({"methods": report, "data_seconds": data_seconds, "fit_seconds": fit_seconds,
             "training_count": len(train), "cut_before_causal_projection": keep,
             "budget": np.asarray(budget).tolist(), "causality_check": True},
            outputs, full.kernel, restricted.kernel)


def c13_problem():
    # Linear Task A of revised C13. Second input is the normalized load force.
    mc, ml, length, g, dc, dl = 10., 100., 5., 9.81, .5, .001
    matrix = np.array([
        [0, 1, 0, 0, 0], [0, -dc/mc, g*ml/mc, 0, 1/mc], [0, 0, 0, 1, 0],
        [0, (dc/mc-dl/ml)/length, -g*(1+ml/mc)/length, -dl/ml, -1/(mc*length)],
        [0, 0, 0, 0, -4],
    ])
    inputs = np.zeros((5, 2))
    inputs[4, 0] = 640.  # 4 * 160 N fixed desired carriage force
    inputs[3, 1] = 800./(ml*length)
    step, n = .25, 60
    advance, response = hold_transition(matrix, inputs, step)
    q = np.zeros((8, n))
    events = [(4, 7, -800), (4, 7, -750), (4, 7, -850), (2, 5, -650),
              (5, 6.5, -410), (1.5, 7.5, -700), (8, 9.25, -490), (3.25, 4.5, 550)]
    for u, (start, stop, force) in zip(q, events, strict=True):
        u[round(start/step):round(stop/step)] = force/800
    base = rollout(advance, response[:, 0], np.ones((1, n)))
    expected = np.empty((len(q), n, 5))
    for index, (a, b, value) in enumerate(events):
        start = np.zeros(5)
        for left, right, force in ((0, a, 0), (a, b, value/800), (b, 15, 0)):
            requested = np.arange(round(left/step)+1, round(right/step)+1)*step
            forcing = inputs[:, 0] + force*inputs[:, 1]
            sol = solve_ivp(lambda _t, y: matrix@y + forcing, (left, right), start,
                            t_eval=requested, method="DOP853", rtol=3e-12, atol=3e-13)
            assert sol.success and len(sol.t) == len(requested)
            assert np.allclose(sol.t, requested)
            expected[index, round(left/step):round(right/step)] = sol.y.T
            start = sol.y[:, -1]
    rng = np.random.default_rng(1305)
    train = rng.uniform(-1.1, 1.1, size=(24, n))
    budget = np.array([.002, .002, .0002, .0002, .02])
    terminal = expm((2000-15)*matrix)
    return train, q, expected, base, budget, advance, response[:, 1], step, events, terminal


def c13(destination):
    train, q, expected, base, budget, advance, response, step, events, end_at_2000 = c13_problem()
    n = q.shape[1]
    length = 5.
    report, output, kernel, cut = history_study(
        train, q, expected, lambda u: rollout(advance, response, u), base, budget, 12)
    terminal = (expected[:, -1] @ end_at_2000.T)
    nominal_load = float(terminal[0, 0] + length*terminal[0, 2])
    assert abs(nominal_load - (-0.0057068688)) < 2e-7
    for name, fields in output.items():
        terminal_prediction = (fields[:, -1] @ end_at_2000.T)
        assert name != "fno_full" or np.max(np.abs(terminal_prediction-terminal)) < 1e-8
        report["methods"][name]["terminal_load_max_m"] = float(
            np.max(np.abs((terminal_prediction-terminal) @ np.array([1, 0, length, 0, 0]))))
    np.savez_compressed(destination / "c13.npz", times=np.arange(1,n+1)*step,
                        forcing=q, reference=expected, kernel=kernel, cut_kernel=cut, **output)
    return report | {"force_events": events, "dt": step, "horizon": 15.,
                     "nominal_terminal_load_m": nominal_load, "propagated_to_s": 2000.,
                     "scope": "C13R Linear Task A and unseen known pulses"}


def c15_problem():
    k01, k21, k12 = .0041, .0498, .0585
    matrix = np.array([[-(k01+k21), k12], [k21, -k12]])
    inputs = np.array([[5000.], [0.]])
    step, n = .5, 480
    times = np.arange(1,n+1)*step
    # State units and bolus magnitudes are values of the benchmark definition.
    doses = [(2500.,.5), (2500.,3.), (2500.,240.), (1800.,1.), (2900.,5.), (2100.,24.)]
    q = np.zeros((len(doses), n))
    exact = np.zeros((len(q), n, 2))
    for i, (amount, span) in enumerate(doses):
        q[i, :round(span/step)] = amount / (span*5000)
        equilibrium = np.linalg.solve(-matrix, np.array([amount/span, 0.]))
        at_switch = equilibrium - expm(span*matrix) @ equilibrium
        for j, time in enumerate(times):
            if time <= span:
                exact[i, j] = equilibrium - expm(time*matrix) @ equilibrium
            else:
                exact[i, j] = expm((time-span)*matrix) @ at_switch
    advance, response = hold_transition(matrix, inputs, step)
    rng = np.random.default_rng(1505)
    train = rng.uniform(0, .9, size=(12, n))
    train[rng.random(train.shape)<.68] = 0.0
    assert np.allclose(step*5000*q.sum(axis=1), [d[0] for d in doses], rtol=1e-13)
    return train, q, exact, np.zeros((1,n,2)), np.array([2.5, 2.5]), advance, response[:, 0], step, doses


def c15(destination):
    train, q, exact, base, budget, advance, response, step, doses = c15_problem()
    n = q.shape[1]
    times = np.arange(1,n+1)*step
    report, output, kernel, cut = history_study(
        train, q, exact, lambda u: rollout(advance, response, u), base, budget, 22)
    for label, values in output.items():
        report["methods"][label]["minimum_state"] = float(np.min(values))
        report["methods"][label]["concentration_max_abs"] = float(np.max(np.abs(values[:,:,0]-exact[:,:,0]))/7.3)
    np.savez_compressed(destination / "c15.npz", times=times, forcing=q, reference=exact,
                        kernel=kernel, cut_kernel=cut, **output)
    return report | {"input_durations_and_doses": doses, "dt": step, "horizon": 240.,
                     "scope": "C15 A; fixed rates, not the inverse problem"}


ROPE_N = 800
ROPE_LENGTH = 10.
ROPE_DAMPING = .2  # prescribed boundary envelope, not material damping
ROPE_COEFFICIENT = 1/(2*(ROPE_LENGTH/ROPE_N)**2)


def modal_rope(times, frequencies, intervals=ROPE_N):
    """Exact-in-time interior solution of the CP1-C finite differences."""
    if intervals < 2:
        raise ValueError("the rope needs at least two spatial intervals")
    coefficient = 1/(2*(ROPE_LENGTH/intervals)**2)
    j = np.arange(1, intervals)
    frequencies_natural = 2*np.sqrt(coefficient)*np.sin(np.pi*j/(2*intervals))
    source = np.zeros(intervals-1)
    source[-1] = coefficient
    coupling = dst(source, type=1, norm="ortho")
    freq = frequencies_natural[None, None, :]
    time = times[None, :, None]
    pole = (-ROPE_DAMPING+1j*np.asarray(frequencies))[:, None, None]
    evolution = (np.exp(pole*time)-np.cos(freq*time)-(pole/freq)*np.sin(freq*time))/(freq**2+pole**2)
    return idst(coupling*evolution.imag, type=1, norm="ortho", axis=-1)


def rope_rk4(times, step=.005):
    """Nominal CP1-C with the existing five-point observation convention."""
    state = np.zeros((2, ROPE_N-1))
    stride = round(times[1]/step)
    history = np.zeros((len(times), ROPE_N-1))

    def derivative(t, y):
        padded = np.r_[0, y[0], np.exp(-ROPE_DAMPING*t)*np.sin(t)]
        return np.stack((y[1], ROPE_COEFFICIENT*np.diff(padded, n=2)))

    for i in range(1, stride*(len(times)-1)+1):
        t = (i-1)*step
        a = derivative(t, state)
        b = derivative(t+step/2, state+step*a/2)
        c = derivative(t+step/2, state+step*b/2)
        d = derivative(t+step, state+step*c)
        state += step*(a+2*b+2*c+d)/6
        if i % stride == 0:
            history[i//stride] = state[0]
    return history


def mixing(controls, data):
    return (controls @ data.reshape(len(data), -1)).reshape(-1, *data.shape[1:])


def cp1(destination):
    data_started = perf_counter()
    times = np.arange(121)*.25
    frequencies = np.array([.55, .72, 1., 1.25, 1.55, 1.9])
    rng = np.random.default_rng(105)
    train = rng.uniform(-1., 1., size=(32,len(frequencies)))
    q = rng.uniform(-.65, .65, size=(8,len(frequencies)))
    q[0] = [0., 0., 1., 0., 0., 0.]
    classical = modal_rope(times, frequencies)
    trained_fields = mixing(train, classical)
    target = np.fft.rfft(trained_fields, axis=-1)
    source = np.zeros(ROPE_N-1)
    source[-1] = 1.
    origin = np.fft.rfft(source)
    fit_started = perf_counter()
    weights, _, rank, _ = lstsq(train, target.reshape(len(train),-1), lapack_driver="gelsy")
    assert rank == len(frequencies)
    weights = weights.reshape(len(frequencies),*target.shape[1:]) / origin
    fit_seconds = perf_counter() - fit_started
    limited = weights.copy()
    limited[:,:,13:] = 0

    def learned(coeff, spectrum):
        return np.fft.irfft(mixing(coeff, spectrum*origin), n=ROPE_N-1, axis=-1)

    refined = modal_rope(times, frequencies[::-1])[::-1]
    expected = mixing(q, refined)
    probes = np.rint(np.array([.1,.25,.5,.75,.9])*ROPE_N).astype(int)-1
    lengths = np.linalg.norm(expected.reshape(len(q),-1), axis=1)

    def compare(fields, reference, sizes):
        difference = fields-reference
        relative = np.linalg.norm(difference.reshape(len(fields),-1), axis=1)/sizes
        probe_error = np.abs(difference[:,:,probes]).max(axis=(1,2))
        report = scores(np.maximum(relative/.01, probe_error/.001))
        return report | {"field_relative_max": float(relative.max()),
                         "probe_abs_max": float(probe_error.max())}

    outputs, report = {}, {}
    for name, call in {"modal_sum": lambda: mixing(q,classical), "fno_full": lambda: learned(q,weights),
                       "fno_cut": lambda: learned(q,limited)}.items():
        output = call()
        report[name] = compare(output, expected, lengths) | {"batch_ms":median_ms(call,3)}
        outputs[name] = output
    numerical = rope_rk4(times)
    rk4 = compare(numerical[None], expected[:1], lengths[:1])
    fine = compare(rope_rk4(times,.0025)[None], expected[:1], lengths[:1])
    assert fine["maximum"] < rk4["maximum"] < 1
    assert report["fno_full"]["maximum"] < 1e-7
    assert report["fno_cut"]["accepted"] < 8

    novel = 2.6
    actual_boundary = np.exp(-ROPE_DAMPING*times)*np.sin(novel*times)
    boundary_basis = np.exp(-ROPE_DAMPING*times[:,None])*np.sin(times[:,None]*frequencies)
    projection = np.linalg.lstsq(boundary_basis,actual_boundary,rcond=None)[0]
    projection_error = np.linalg.norm(boundary_basis @ projection-actual_boundary)/np.linalg.norm(actual_boundary)
    true_novel = modal_rope(times,[novel])
    trial = learned(projection[None],weights)
    extrapolation = compare(trial,true_novel,np.array([np.linalg.norm(true_novel)]))
    assert extrapolation["maximum"] > 1
    np.savez_compressed(destination / "cp1.npz", times=times, x=np.arange(1,ROPE_N)*ROPE_LENGTH/ROPE_N,
                        drive=q, frequencies=frequencies, weights=weights,
                        nominal_reference=expected[0], nominal_full=outputs["fno_full"][0],
                        nominal_cut=outputs["fno_cut"][0], nominal_rk4=numerical,
                        novel_reference=true_novel[0], novel_fno=trial[0], probes=probes)
    return {"methods":report, "rk4_nominal":rk4, "rk4_half_step":fine, "novel_drive":extrapolation,
            "novel_boundary_projection_error":float(projection_error), "novel_omega":novel,
            "training_count":len(train), "intervals":ROPE_N, "horizon":30., "dt_output":.25,
            "data_seconds":fit_started - data_started, "fit_seconds":fit_seconds,
            "frequencies":frequencies.tolist(), "budget":[.01,.001],
            "scope":"CP1-C forced string, known boundary histories, sequential field comparison"}
