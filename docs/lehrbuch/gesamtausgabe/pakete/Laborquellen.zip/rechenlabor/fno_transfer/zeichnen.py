"""Rebuild the appendix D figures from the measured arrays."""

import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MEASURE = HERE / "messung"
INK, RED, BLUE, TEAL = "#1d3240", "#b74732", "#2c5e8b", "#00796b"


def save(fig, name):
    fig.savefig(ROOT / "abbildungen" / (name + ".svg"), metadata={"Date": None}, dpi=150)
    fig.savefig(ROOT / "druck" / (name + ".pdf"), metadata={"CreationDate": None}, dpi=150)
    plt.close(fig)


def histories():
    fig, axes = plt.subplots(1, 2, figsize=(7.35, 2.7), layout="constrained")
    for ax, case, title, channel, end, unit in (
        (axes[0], "c13", "A   C13 · Lastpuls", 2, 15, "Winkel [rad]"),
        (axes[1], "c15", "B   C15 · Kurzer Bolus", 0, 25, "Konzentration (Vergleichsskala)"),
    ):
        with np.load(MEASURE / f"{case}.npz") as record:
            times = np.r_[0.,record["times"]]
            scale = 7.3 if case == "c15" else 1.
            baseline = np.r_[0.,record["reference"][0,:,channel]] / scale
            filtered = np.r_[0.,record["fno_cut"][0,:,channel]] / scale
        ax.plot(times,baseline,color=INK,linewidth=1.7,label="Referenz und volles FNO")
        ax.plot(times,filtered,color=RED,linestyle="--",linewidth=1.2,label="FNO mit geglättetem Kern")
        if case=="c13":
            ax.axvspan(4,7,color="#d2e1e7",alpha=.55,linewidth=0)
        else:
            ax.axvline(.5,color=BLUE,linewidth=.8)
        ax.set_xlim(0,end)
        ax.set_xlabel("Zeit [s]" if case == "c13" else "Zeit (Modellskala)")
        ax.set_ylabel(unit)
        ax.set_title(title,loc="left")
    axes[0].legend(loc="upper center",fontsize=7.25,frameon=False)
    save(fig,"fno_transfer_zeit")


def rope():
    fig, (field, line) = plt.subplots(1,2,figsize=(7.35,2.7),layout="constrained")
    with np.load(MEASURE / "cp1.npz") as record:
        times, positions = record["times"], record["x"]
        sample = record["nominal_reference"]
        center = record["probes"][2]
        known = record["novel_reference"][:,center]
        estimate = record["novel_fno"][:,center]
    limit = np.max(abs(sample))
    image = field.pcolormesh(times,positions,sample.T,shading="nearest",cmap="RdBu_r",
                             rasterized=True,vmin=-limit,vmax=limit)
    fig.colorbar(image,ax=field,pad=.02,label="Auslenkung [m]",shrink=.94)
    field.set_title("A   Nominelle Anregung · Feld",loc="left")
    field.set_xlabel("Zeit [s]")
    field.set_ylabel("Ort auf der Saite [m]")
    field.axhline(5,color=INK,linewidth=.7,linestyle=":")
    line.plot(times,known,color=INK,linewidth=1.7,label="Modalreferenz")
    line.plot(times,estimate,color=RED,linestyle="--",linewidth=1.2,label="FNO nach Projektion")
    line.set_title("B   Neue Frequenz · Sensor",loc="left")
    line.set_xlabel("Zeit [s]")
    line.set_ylabel("Auslenkung bei 5 m [m]")
    line.legend(loc="upper right",frameon=False,fontsize=7.4)
    save(fig,"fno_transfer_saite")


def pendulum():
    report = json.loads((MEASURE / "transfer.json").read_text())["cases"]["c07"]
    fig,ax = plt.subplots(figsize=(7.35,2.55),layout="constrained")
    variants = (("rk4","RK4",INK,"o"),("midpoint","Mittelpunkt",BLUE,"s"),
                ("fno_euler","Euler mit FNO",RED,"x"),("hybrid_fno","Mittelpunkt mit FNO",TEAL,"D"))
    for name,title,color,marker in variants:
        records = np.asarray(report["methods"][name]["scores"],dtype=float)
        ax.plot(np.arange(1,len(records)+1),records,label=title,color=color,marker=marker,markersize=3,linewidth=1.)
    ax.set_yscale("log")
    ax.axhline(1,color="#8b9292",linestyle="--",linewidth=.9)
    ax.set_xticks(range(1,13))
    ax.set_xlabel("Prüffall")
    ax.set_ylabel("Größter normierter Fehler S")
    ax.legend(loc="lower left",ncols=2,fontsize=7.5,frameon=False)
    save(fig,"fno_transfer_pendel")


if __name__ == "__main__":
    plt.rcParams.update({"font.size":9.4,"font.family":"DejaVu Sans","axes.spines.top":False,
                         "axes.spines.right":False,"text.color":INK,"pdf.fonttype":42,
                         "svg.hashsalt":"argesim-transfer-2026"})
    histories()
    rope()
    pendulum()
