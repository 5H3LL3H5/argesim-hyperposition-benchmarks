"""Rechenproben zu den Ergänzungen der Revision v9.1."""
import json
import math
import sys
from fractions import Fraction as Q
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "beispiele"))

from ereignis import brent, rk4_dense
from fourier_operator import fft
from rk_adaptiv import DP54, interpolate, proposal


def quadratic_event_candidates(a, b, c):
    """Isolierte positive Wurzeln eines quadratischen Lehrpolynoms."""
    scale = max(abs(a), abs(b), abs(c))
    if not math.isfinite(scale):
        raise ValueError("Koeffizienten müssen endlich sein")
    if scale == 0:
        return ()
    _, exponent = math.frexp(scale)
    a = math.ldexp(a, -exponent)
    b = math.ldexp(b, -exponent)
    c = math.ldexp(c, -exponent)
    if a == 0:
        roots = (-c / b,) if b != 0 else ()
    else:
        disc = b * b - 4 * a * c
        if disc < 0:
            return ()
        if disc == 0:
            roots = (-b / (2 * a),)
        else:
            w = -0.5 * (b + math.copysign(math.sqrt(disc), b))
            roots = (w / a, c / w)
    return tuple(sorted(root for root in roots if math.isfinite(root) and root > 0))


def rk_probes():
    def rhs(_time, y):
        return (-y[0],)

    one, _ = rk4_dense(rhs, 0.0, (1.0,), 0.5)
    midway, _ = rk4_dense(rhs, 0.0, (1.0,), 0.25)
    two, _ = rk4_dense(rhs, 0.25, midway, 0.5)
    assert abs(one[0] - float(Q(233, 384))) < 2 * math.ulp(1.0)
    error = two[0] - math.exp(-0.5)
    assert 1.216e-5 < error < 1.217e-5
    for start, value, h in ((0.0, (1.0,), 0.5), (0.5, one, 0.25)):
        high, _, _, last = proposal(rhs, start, value, h, DP54)
        assert last == rhs(start + h, high)
    p_left = interpolate(1 / 3, 1, (0,), (1,), (4,), (4,))[0]
    p_right = interpolate(2 / 3, 1, (0,), (1,), (4,), (4,))[0]
    assert abs(p_left - 5 / 9) < 2 * math.ulp(1.0)
    assert abs(p_right - 4 / 9) < 2 * math.ulp(1.0)
    assert interpolate(0.5, 1, (0,), (1,), (8,), (0,)) == (1.5,)
    print(f"RK4: y(0.5)={one[0]:.10f}, Fehler mit zwei Schritten {error:.8g}")


def qss_probe():
    h, = quadratic_event_candidates(0.5, 0.0, -0.25)
    q = 1 - h
    x = q + h * h / 2
    assert abs(x - q - 0.25) <= math.ulp(1.0)
    small, = quadratic_event_candidates(1e-12, 1.0, -1e-12)
    naive = (-1.0 + math.sqrt(1.0 + 4e-24)) / (2e-12)
    assert naive == 0 and abs(small - 1e-12) <= math.ulp(1e-12)
    assert quadratic_event_candidates(0, 2, -1) == (0.5,)
    assert quadratic_event_candidates(1, -2, 1) == (1.0,)
    assert quadratic_event_candidates(1, -3, 2) == (1.0, 2.0)
    assert quadratic_event_candidates(1, 0, 1) == ()
    assert quadratic_event_candidates(1, -1, 0) == (1.0,)
    print(f"QSS2: erster Termin {h:.8f} s, x={x:.8f}, q={q:.8f}")


def physics_probes():
    capacitance, resistance = Q(1, 1000), 1000
    voltage, source = 1, 5
    current = Q(source - voltage, resistance)
    rate = current / capacitance
    assert current == Q(4, 1000) and rate == 4
    assert voltage + resistance * current - source == 0

    z = Q(1, 4)
    full = z - (z * z - 1) / (2 * z)
    half = (z + full) / 2
    assert full == Q(17, 8) and half == Q(19, 16)
    assert abs(full * full - 1) > abs(z * z - 1) > abs(half * half - 1)

    consistent = (4, -2)
    assert ((2 * consistent[0] + consistent[1]) / 6,
            (consistent[0] + 2 * consistent[1]) / 6) == (1, 0)
    assert (2 * Q(1, 2), 0 * Q(1, 2)) == (1, 0)

    velocity, length, viscosity = Q(1, 100), Q(1, 100), Q(1, 10**6)
    dx = length / 100
    lattice_velocity = Q(1, 20)
    dt = lattice_velocity * dx / velocity
    lattice_viscosity = viscosity * dt / dx**2
    tau = Q(1, 2) + 3 * lattice_viscosity
    assert dt == Q(1, 2000) and tau == Q(13, 20)
    assert velocity * length / viscosity == lattice_velocity * 100 / lattice_viscosity == 100
    spectrum = fft([0, 1, 0, -1])
    expected = [0, -2j, 0, 2j]
    assert all(abs(got - want) <= 4 * math.ulp(1.0)
               for got, want in zip(spectrum, expected, strict=True))
    print(f"D2Q9: Zeitschritt {float(dt):.6f} s, tau={float(tau):.2f}; Saiten-DFT geprüft")


def benchmark_probes():
    def linear_test(z):
        end, *_ = proposal(lambda _t, y: (z * y[0],), 0.0, (1.0,), 1.0, DP54)
        return end[0]

    for z in (-4.0, -0.3, 0.0, 0.25):
        polynomial = sum(z**k / math.factorial(k) for k in range(6)) + z**6 / 600
        assert abs(linear_test(z) - polynomial) <= 8 * math.ulp(4.0)
    dp_limit = brent(lambda x: linear_test(-x) - 1, 3.0, 4.0, 1e-13)
    assert abs(dp_limit - 3.306567892635) < 1e-12
    assert math.ceil(3.5 * 2.7e6 / dp_limit) == 2_857_949

    t1 = math.sqrt(20.0 / 9.81)
    assert abs(t1 * (1 + 2 * 0.9 / (1 - 0.9)) - 27.1290193356) < 1e-10
    assert tuple(dx / Q(1, 20) for dx in (Q(1), Q(1, 2), Q(1, 4))) == (20, 10, 5)
    pe = 4
    central = Q(1, 2) * (1 - Q(pe, 2))
    upwind = Q(1, 2 + pe)
    assert (central, upwind) == (Q(-1, 2), Q(1, 6))

    metrics_path = ROOT / "rechenlabor/cp2_feldlabor/rope/rope-metrics.json"
    metrics = json.loads(metrics_path.read_text())
    at_five = metrics["canonical"]["501"][0]
    assert at_five["time_s"] == 5.0
    assert round(100 * at_five["fno_relative_l2"], 3) == 3.001
    assert round(100 * at_five["newmark_relative_l2"], 3) == 0.374
    assert round(metrics["seconds"]["training"], 3) == 3.354
    assert round(1000 * metrics["seconds"]["cpu_inference_test_batch"], 3) == 4.339
    print(f"DP5(4): reelle Stabilitätsgrenze {-dp_limit:.11f}; Zeno-, Péclet- und CP2-Probe bestanden")


if __name__ == "__main__":
    rk_probes()
    qss_probe()
    physics_probes()
    benchmark_probes()
