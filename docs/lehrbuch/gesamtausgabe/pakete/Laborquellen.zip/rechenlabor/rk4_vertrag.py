"""Zeit- und Zustandsvertrag an einem analytisch lösbaren skalaren Anfangswertproblem."""
from math import exp, ulp


def integrate(rhs, t0, state, t1, steps):
    h = (t1 - t0) / steps
    y = state
    for n in range(steps):
        t = t0 + n*h
        k1 = rhs(t, y)
        k2 = rhs(t + h/2, y + h*k1/2)
        k3 = rhs(t + h/2, y + h*k2/2)
        k4 = rhs(t + h, y + h*k3)
        y += h*(k1 + 2*k2 + 2*k3 + k4)/6
    return y


def main():
    steps = 100
    h = 1.0 / steps
    reference = exp(-2.0)
    y = integrate(lambda t, value: -2*value, 0.0, 1.0, 1.0, steps)
    # 0 < R(-2h), exp(-2h) < 1. Das Teleskopieren über N Faktoren
    # beschränkt den globalen Verfahrensfehler durch N*(2h)^5/5!.
    discretization = steps*(2*h)**5/120
    # Operationsreserve für diese kontraktive skalare Rechnung in binär64.
    rounding = 32*steps*ulp(1.0)
    assert abs(y-reference) <= discretization+rounding
    print(f"RK4-Endfehler {abs(y-reference):.4g}, Budget {discretization+rounding:.4g}")


if __name__ == "__main__":
    main()
