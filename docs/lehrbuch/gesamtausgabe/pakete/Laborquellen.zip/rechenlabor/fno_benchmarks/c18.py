"""C18: predict force from thickening with a causal Fourier operator and ARX."""

from dataclasses import dataclass
import hashlib
import io
from pathlib import Path
from time import perf_counter

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from scipy.optimize import minimize


HERE = Path(__file__).resolve().parent
CURVES_SHA = "36ca0ab924cb98d34cd285a2147b358cc941452c6c5c7fafbeb7ae6dd1c75a42"
PUBLISHED_ARX = np.array([1.586, -0.5985, 0.5289, -0.5206])
WINDOW = 64
MODES = 12
HIDDEN = 8
SEEDS = (18, 19, 20)
RIDGE = 5e-4
MAX_ITERATIONS = 450


def csv_data(path, expected_columns):
    raw = path.read_bytes()
    checksum = hashlib.sha256(raw).hexdigest()
    data = np.genfromtxt(io.BytesIO(raw), names=True, delimiter=",", encoding="utf-8", dtype=float)
    if (data.ndim != 1 or len(data) < WINDOW or set(data.dtype.names or ()) != expected_columns or
            not all(np.isfinite(data[key]).all() for key in expected_columns)):
        raise ValueError(f"{path}: expected finite numeric CSV columns {sorted(expected_columns)}")
    if not np.allclose(np.diff(data["time_s"]), 0.01, rtol=0, atol=1e-9):
        raise ValueError(f"{path}: expected increasing time_s at 100 Hz")
    return data, checksum


def load_sequences(train_path, test_path):
    if train_path is None:
        path = HERE / "daten/c18_figure_traces.csv"
        columns = {f"{part}_{key}" for part in ("training", "validation")
                   for key in ("thickening", "force")}
        data, sha = csv_data(path, columns | {"time_s"})
        if sha != CURVES_SHA or len(data) != 2000:
            raise ValueError("C18 reconstructed curves differ from the pinned input")
        train = tuple(data[key] for key in ("time_s", "training_thickening", "training_force"))
        test = tuple(data[key] for key in ("time_s", "validation_thickening", "validation_force"))
        return train, test, {"kind": "published_figure_reconstruction", "csv_sha256": sha}

    cols = {"time_s", "thickening", "force"}
    train, train_sha = csv_data(train_path, cols)
    test, test_sha = csv_data(test_path, cols)
    if train_sha == test_sha:
        raise ValueError("C18 requires independent training and validation recordings")
    keys = ("time_s", "thickening", "force")
    return tuple(train[key] for key in keys), tuple(test[key] for key in keys), {
        "kind": "supplied_recordings", "training_sha256": train_sha, "validation_sha256": test_sha}


def fit_arx(thickening, force):
    rows = np.column_stack((force[1:-1], force[:-2], thickening[2:], thickening[1:-1]))
    return np.linalg.solve(rows.T @ rows + 1e-10 * np.eye(4), rows.T @ force[2:])


def rollout_arx(u, initial, coefficients):
    a1, a2, b0, b1 = coefficients
    predicted = np.empty(len(u))
    predicted[:2] = initial
    for i in range(2, len(u)):
        predicted[i] = a1 * predicted[i-1] + a2 * predicted[i-2] + b0 * u[i] + b1 * u[i-1]
    if not np.isfinite(predicted).all():
        raise ValueError("ARX rollout did not remain finite")
    return predicted


def history_features(u):
    """Real and imaginary modal contributions to inverse FFT at the latest sample."""
    history = sliding_window_view(np.pad(u, (WINDOW - 1, 0), mode="edge"), WINDOW)
    kept = np.fft.rfft(history, axis=-1)[:, :MODES+1]
    phase = np.exp(2j * np.pi * np.arange(MODES+1) * (WINDOW-1) / WINDOW)
    readout = kept * phase / WINDOW
    return np.column_stack((readout[:, 0].real, 2 * readout[:, 1:].real,
                            -2 * readout[:, 1:].imag, u))


def network(parameters, features):
    weights = parameters[:-HIDDEN-1].reshape(features.shape[1], HIDDEN)
    hidden = np.tanh(features @ weights)
    return hidden @ parameters[-HIDDEN-1:-1] + parameters[-1], hidden


def objective(parameters, features, expected):
    output, hidden = network(parameters, features)
    residual = output - expected
    unscaled = residual / len(expected)
    output_weights = parameters[-HIDDEN-1:-1]
    delta = (unscaled[:, None] * output_weights) * (1 - hidden**2)
    derivative = np.r_[(features.T @ delta).ravel(), hidden.T @ unscaled, unscaled.sum()]
    loss = 0.5 * np.mean(residual**2) + (RIDGE / 2) * (parameters @ parameters)
    return loss, derivative + RIDGE * parameters


@dataclass(frozen=True)
class CausalFNO:
    feature_mean: np.ndarray
    feature_scale: np.ndarray
    target_mean: float
    target_scale: float
    parameters: np.ndarray

    def predict(self, u):
        features = transform_features(u, self.feature_mean, self.feature_scale)
        output, _ = network(self.parameters, features)
        return self.target_mean + self.target_scale * output


def transform_features(u, mean, scale):
    features = (history_features(u) - mean) / scale
    return np.column_stack((features, np.ones(len(u))))


def fit_fno(u, y):
    training_features = history_features(u)[2:]
    mean = training_features.mean(axis=0)
    spread = training_features.std(axis=0)
    spread = np.where(spread > 1e-12, spread, 1.0)
    features = transform_features(u, mean, spread)[2:]
    target_mean = float(np.mean(y[2:]))
    target_scale = max(float(np.std(y[2:])), 1e-12)
    target = (y[2:] - target_mean) / target_scale
    training = []
    for seed in SEEDS:
        rng = np.random.default_rng(seed)
        guess = rng.normal(0, 0.15, HIDDEN * (features.shape[1]+1) + 1)
        result = minimize(objective, guess, args=(features, target), jac=True,
                          method="L-BFGS-B", options={"maxiter": MAX_ITERATIONS, "ftol": 1e-10})
        if not np.isfinite(result.fun) or not np.isfinite(result.x).all():
            raise ValueError(f"nonfinite optimization for seed {seed}")
        model = CausalFNO(mean, spread, target_mean, target_scale, result.x)
        training.append((model, {"seed": seed, "train_loss": float(result.fun),
                                 "iterations": int(result.nit), "converged": bool(result.success)}))
    selected = min(range(len(training)), key=lambda i: training[i][1]["train_loss"])
    return training[selected][0], training[selected][1]["seed"], training


def metrics(predicted, measured):
    residual = predicted[2:] - measured[2:]
    actual = measured[2:]
    forecast = predicted[2:]
    correlation = None
    if np.ptp(actual) > 0 and np.ptp(forecast) > 0:
        correlation = float(np.corrcoef(forecast, actual)[0, 1])
    return {
        "rmse": float(np.sqrt(np.mean(residual**2))),
        "mae": float(np.mean(np.abs(residual))),
        "max_abs": float(np.max(np.abs(residual))),
        "correlation": correlation,
    }


def check_layer():
    rng = np.random.default_rng(101)
    u = rng.normal(size=97)
    coeff = rng.normal(size=MODES+1) + 1j * rng.normal(size=MODES+1)
    coeff[0] = coeff[0].real
    features = history_features(u)
    weights = np.r_[coeff[0].real, coeff[1:].real, coeff[1:].imag, 0.0]
    windows = sliding_window_view(np.pad(u, (WINDOW-1, 0), mode="edge"), WINDOW)
    fft_filter = np.pad(coeff, (0, WINDOW//2 - MODES))
    explicit = np.fft.irfft(np.fft.rfft(windows) * fft_filter, n=WINDOW)[:, -1]
    assert np.allclose(features @ weights, explicit, rtol=0, atol=1e-12)
    features = np.column_stack((features, np.ones(len(u))))
    parameters = rng.normal(0, 0.1, HIDDEN * (features.shape[1]+1) + 1)
    direction = rng.normal(size=len(parameters))
    eps = 1e-6
    _, analytic = objective(parameters, features, u)
    high = objective(parameters + eps*direction, features, u)[0]
    low = objective(parameters - eps*direction, features, u)[0]
    assert np.isclose(analytic @ direction, (high-low)/(2*eps), rtol=1e-6, atol=1e-8)


def run(output, median_ms, train_path=None, test_path=None):
    check_layer()
    start = perf_counter()
    (train_t, train_u, train_y), (test_t, test_u, test_y), provenance = load_sequences(train_path, test_path)
    input_seconds = perf_counter() - start
    start = perf_counter()
    arx = fit_arx(train_u, train_y)
    train_arx = rollout_arx(train_u, train_y[:2], arx)
    arx_seconds = perf_counter() - start
    start = perf_counter()
    direct, direct_seed, direct_runs = fit_fno(train_u, train_y)
    direct_seconds = perf_counter() - start
    start = perf_counter()
    residual, residual_seed, residual_runs = fit_fno(train_u, train_y - train_arx)
    residual_seconds = perf_counter() - start

    test_start = test_y[:2].copy()
    methods = {
        "published_arx": lambda u, y0: rollout_arx(u, y0, PUBLISHED_ARX),
        "refit_arx": lambda u, y0: rollout_arx(u, y0, arx),
        "fno": lambda u, _y0: direct.predict(u),
        "arx_fno": lambda u, y0: rollout_arx(u, y0, arx) + residual.predict(u),
    }
    sliced = len(test_u) // 2
    changed_suffix = test_u.copy()
    changed_suffix[sliced:] += 1.5
    predictions = {}
    scores = {}
    for label, method in methods.items():
        training = method(train_u, train_y[:2])
        forecast = method(test_u, test_start)
        assert np.allclose(method(changed_suffix, test_start)[:sliced], forecast[:sliced], rtol=0, atol=1e-12)
        predictions[f"training_{label}"] = training
        predictions[f"validation_{label}"] = forecast
        scores[label] = {
            "training": metrics(training, train_y), "validation": metrics(forecast, test_y),
            "validation_sequence_ms": median_ms(lambda: method(test_u, test_start)),
        }
    if provenance["kind"] == "published_figure_reconstruction":
        assert np.allclose(arx, [1.760091, -0.769501, 0.308333, -0.301893], atol=5e-6)
        original_convention = float(np.corrcoef(predictions["validation_published_arx"], test_y)[0, 1])
        assert abs(original_convention - 0.94231) < 1e-5

    model_arrays = {"arx_coefficients": arx}
    for name, model in (("direct", direct), ("residual", residual)):
        model_arrays.update({f"{name}_{key}": val for key, val in vars(model).items()})
    np.savez_compressed(output / "c18_modelle.npz", training_time=train_t, training_force=train_y,
                        training_thickening=train_u, validation_time=test_t, validation_force=test_y,
                        validation_thickening=test_u, **predictions, **model_arrays)
    test_arx = predictions["validation_refit_arx"]
    return {
        "provenance": provenance, "sampling_hz": 100, "samples": [len(train_y), len(test_y)],
        "first_scored_index": 2, "window_samples": WINDOW, "positive_modes": MODES,
        "hidden_units": HIDDEN, "penalty": RIDGE, "max_training_iterations": MAX_ITERATIONS,
        "inputs_seconds": input_seconds, "arx_fit_seconds": arx_seconds,
        "fno_fit_seconds": direct_seconds, "residual_fit_seconds": residual_seconds,
        "seeds_selected": {"fno": direct_seed, "arx_fno": residual_seed},
        "arx_coefficients": arx.tolist(), "methods": scores,
        "direct_candidates": [{**rec, "validation": metrics(model.predict(test_u), test_y)}
                              for model, rec in direct_runs],
        "residual_candidates": [{**rec, "validation": metrics(test_arx + model.predict(test_u), test_y)}
                                for model, rec in residual_runs],
        "checks": ["Fourier readout equals inverse FFT", "finite-difference gradient",
                   "prediction prefix unchanged when future input changes"],
    }
