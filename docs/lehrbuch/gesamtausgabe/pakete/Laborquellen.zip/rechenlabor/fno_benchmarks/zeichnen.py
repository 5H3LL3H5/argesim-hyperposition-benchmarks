"""Regenerate the two scientific figures in appendix C from the saved run."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
BOOK = HERE.parents[1]
INK = "#1d3240"
TEAL = "#00796b"
BLUE = "#285e8e"
RED = "#b74732"


def save(fig, name):
    fig.savefig(BOOK / "abbildungen" / (name + ".svg"), metadata={"Date": None})
    fig.savefig(BOOK / "druck" / (name + ".pdf"), metadata={"CreationDate": None})
    plt.close(fig)


def groundwater():
    with np.load(HERE / "messung/c19r_modelle.npz") as data:
        profiles = data["x"]
        row = np.flatnonzero(data["y"] == 0)[0]
        reference = data["reference"][4, row] / 1000
        rk4 = data["rk4"][4, row] / 1000
        limited = data["fno_limited"][4, row] / 1000
        well_point = data["point_reference"][4] / 1000

    fig, axes = plt.subplots(1, 2, figsize=(7.3, 2.8), layout="constrained")
    for ax in axes:
        ax.axhline(0, color="#b0bbbb", linewidth=.65)
        ax.plot(profiles, reference, color=INK, label="Green und FNO mit allen Moden", linewidth=1.7)
        ax.plot(profiles, limited, color=RED, linestyle="--", label="FNO mit begrenzten Moden", linewidth=1.2)
        ax.plot(profiles, rk4, color=BLUE, linestyle=":", label="Finite Volumen + RK4", linewidth=1.4)
        ax.set_xlabel("Längskoordinate $x$ [m]")
    axes[0].set_title("In der Nähe der Quelle", loc="left")
    axes[0].set_xlim(-1.25, 1.5)
    axes[0].set_ylabel("Konzentration bei $y=0$ [g/m³]")
    axes[1].set_title("Im Bereich des Brunnens", loc="left")
    axes[1].set_xlim(2.5, 9.5)
    local = (profiles >= 2.5) & (profiles <= 9.5)
    axes[1].set_ylim(min(-2, 1.2 * np.min(limited[local])),
                     1.14 * max(np.max(profile[local]) for profile in (reference, rk4, limited)))
    axes[1].axvline(5, color="#778888", linewidth=.8)
    axes[1].scatter(5, well_point, color=TEAL, marker="D", s=15, zorder=5,
                    label="Exakte Punktreferenz am Brunnen")
    axes[1].legend(loc="upper right", fontsize=7.2, frameon=False)
    save(fig, "fno_c19r_vergleich")


def identification():
    with np.load(HERE / "messung/c18_modelle.npz") as data:
        time, input_signal, reference, arx, fno, hybrid = (
            data["validation_" + k] for k in ("time", "thickening", "force", "refit_arx", "fno", "arx_fno"))

    fig, (ax, err) = plt.subplots(2, 1, figsize=(7.3, 3.25), sharex=True,
                                  gridspec_kw={"height_ratios": [2.4, 1]}, layout="constrained")
    ax.plot(time, input_signal, color="#829899", linewidth=1.0, label="Eingabe (Verdickung)", alpha=.8)
    ax.plot(time, reference, color=INK, linewidth=1.8, label="Kraft (Bildkurve)")
    ax.plot(time[2:], arx[2:], color=RED, linestyle=":", linewidth=1.3, label="ARX")
    ax.plot(time[2:], fno[2:], color=TEAL, linestyle="--", linewidth=1.2, label="Kausales FNO")
    ax.set_ylabel("Normierte Werte")
    ax.legend(loc="lower left", bbox_to_anchor=(0, 1, 1, .1), mode="expand",
              ncols=4, fontsize=7.6, frameon=False, borderaxespad=0)
    err.plot(time[2:], np.abs(arx[2:] - reference[2:]), color=RED, linestyle=":", linewidth=1.1, label="ARX")
    err.plot(time[2:], np.abs(hybrid[2:] - reference[2:]), color=BLUE, linewidth=.95, label="ARX mit FNO")
    err.plot(time[2:], np.abs(fno[2:] - reference[2:]), color=TEAL, linewidth=1.15, label="Kausales FNO")
    err.set_ylabel("Absoluter Fehler")
    err.set_xlabel("Zeit [s]")
    err.legend(loc="upper right", ncols=3, fontsize=7.2, frameon=False)
    err.set_xlim(0, 20)
    save(fig, "fno_c18_vergleich")


if __name__ == "__main__":
    plt.rcParams.update({"font.size": 9.5, "font.family": "DejaVu Sans", "axes.spines.top": False,
                         "axes.spines.right": False, "text.color": INK, "svg.hashsalt": "argesim-fno-2026"})
    groundwater()
    identification()
