"""Run the separate C19R and C18 operator experiments from the book."""

import argparse
import json
import os
from pathlib import Path
import platform
from statistics import median
from tempfile import TemporaryDirectory
from time import perf_counter_ns

import numpy as np
import scipy

import c18
import c19r


def median_ms(operation):
    operation()
    runs = []
    for _ in range(7):
        start = perf_counter_ns()
        operation()
        runs.append((perf_counter_ns() - start) / 1e6)
    return median(runs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--case", choices=("c19r", "c18", "all"), default="all")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--training", type=Path, help="Optional C18 training recording (CSV)")
    parser.add_argument("--validation", type=Path, help="Optional C18 independent recording (CSV)")
    args = parser.parse_args()
    if (args.training is None) != (args.validation is None):
        parser.error("--training and --validation must be provided together")
    if args.case == "c19r" and args.training is not None:
        parser.error("recording arguments are only applicable to C18")
    args.out.mkdir(parents=True, exist_ok=True)
    manifest = {
        "python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
        "machine": platform.machine(), "timing": "median of seven warmed executions",
        "thread_environment": {name: os.environ.get(name) for name in
                               ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS")},
    }
    with TemporaryDirectory(dir=args.out, prefix=".fno-") as directory:
        stage = Path(directory)
        if args.case in ("c19r", "all"):
            manifest["c19r"] = c19r.run(stage, median_ms)
            for name, metrics in manifest["c19r"]["methods"].items():
                print(f"C19R {name:15s} {sum(metrics['pass'])}/8  max. S={max(metrics['score']):.5f}")
        if args.case in ("c18", "all"):
            manifest["c18"] = c18.run(stage, median_ms, args.training, args.validation)
            for name, metrics in manifest["c18"]["methods"].items():
                val = metrics["validation"]
                correlation = val["correlation"]
                corr_text = f"{correlation:.6f}" if correlation is not None else "undefined"
                print(f"C18  {name:15s} RMSE={val['rmse']:.6f}  r={corr_text}")
        (stage / "vergleich.json").write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
        for path in sorted(stage.glob("*.npz")):
            path.replace(args.out / path.name)
        (stage / "vergleich.json").replace(args.out / "vergleich.json")


if __name__ == "__main__":
    main()
