"""C19R task-A extension with time-dependent release on a homogeneous aquifer."""

from time import perf_counter

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import quad
from scipy.special import ndtr


DAY = 86_400.0
HORIZON = 10 * DAY
WATER_COLUMN = 2.5  # layer thickness times water-filled porosity, in m
VELOCITY = 1e-5  # m/s
DIFFUSION = 5e-7  # m²/s, isotropic task-A setting
DX = 0.25
X = np.arange(-3.0, 13.0 + DX, DX)
Y = np.arange(-4.0, 4.0 + DX, DX)
SOURCE = (16, 12)
WELL = (16, 32)
SEGMENTS = 8
DT = 7200.0
CELL_WATER = WATER_COLUMN * DX**2
BUDGETS = {"field_relative": 0.01, "well_relative": 0.01, "mass_fraction": 0.001}


def axis_probabilities(edges, mean, sigma):
    return np.diff(ndtr((edges - mean[:, None]) / sigma[:, None]), axis=1)


def green_basis(nodes=96):
    """Cell-average concentration per mg/s in each time bin, on the open plane."""
    abscissas, weights = leggauss(nodes)
    duration = HORIZON / SEGMENTS
    shifts = (1 + abscissas) * duration / 2
    x_edges = np.r_[X - DX / 2, X[-1] + DX / 2]
    y_edges = np.r_[Y - DX / 2, Y[-1] + DX / 2]
    kernels = []
    for age_bin in reversed(range(SEGMENTS)):
        age = age_bin * duration + shifts
        sigma = np.sqrt(2 * DIFFUSION * age)
        along = axis_probabilities(x_edges, VELOCITY * age, sigma)
        across = axis_probabilities(y_edges, np.zeros_like(age), sigma)
        cell_integrals = (across * weights[:, None]).T @ along
        kernels.append(cell_integrals * (duration / (2 * CELL_WATER)))
    return np.stack(kernels)


def point_basis():
    """Independent continuous point reference c(5 m, 0, T), without a cell average."""
    duration = HORIZON / SEGMENTS

    def concentration(age):
        distance = 5.0 - VELOCITY * age
        scale = 4 * DIFFUSION * age
        return np.exp(-(distance**2) / scale) / (np.pi * scale * WATER_COLUMN)

    return np.array([
        quad(concentration, j * duration, (j + 1) * duration, epsabs=1e-11, epsrel=1e-11)[0]
        for j in reversed(range(SEGMENTS))
    ])


def observation_field(rates, kernels):
    return (rates @ kernels.reshape(SEGMENTS, -1)).reshape(-1, Y.size, X.size)


def source_spectrum():
    source = np.zeros((Y.size, X.size))
    source[SOURCE] = 1.0
    return np.fft.rfft2(source)


def fit_fourier(rates, fields):
    """One learned spectral layer with identity activation and eight source channels."""
    targets = np.fft.rfft2(fields)
    weights, _, rank, _ = np.linalg.lstsq(rates, targets.reshape(len(rates), -1), rcond=None)
    if rank != SEGMENTS:
        raise ValueError("training rates must span the eight release bins")
    return weights.reshape(SEGMENTS, *targets.shape[1:]) / source_spectrum()


def predict_fourier(rates, weights, phase):
    learned_basis = weights * phase
    spectrum = (rates @ learned_basis.reshape(SEGMENTS, -1)).reshape(-1, *phase.shape)
    return np.fft.irfft2(spectrum, s=(Y.size, X.size), axes=(-2, -1))


def limited_modes():
    mx = np.arange(X.size // 2 + 1)
    my = np.abs(np.rint(np.fft.fftfreq(Y.size) * Y.size))
    return (mx[None, :] <= 12) & (my[:, None] <= 8)


def flux_derivative(field, release):
    """Upwind advection, centered diffusion, zero normal dispersive boundary flux."""
    derivative = np.zeros_like(field)
    x_flux = VELOCITY * field[:, :, :-1] - (DIFFUSION / DX) * np.diff(field, axis=2)
    y_flux = -(DIFFUSION / DX) * np.diff(field, axis=1)
    derivative[:, :, :-1] -= x_flux / DX
    derivative[:, :, 1:] += x_flux / DX
    derivative[:, :-1, :] -= y_flux / DX
    derivative[:, 1:, :] += y_flux / DX
    derivative[:, :, -1] -= (VELOCITY / DX) * field[:, :, -1]
    derivative[:, SOURCE[0], SOURCE[1]] += release / CELL_WATER
    outflow = VELOCITY * DX * WATER_COLUMN * field[:, :, -1].sum(axis=1)
    return derivative, outflow


def finite_volume(rates, step=DT, *, with_history=False):
    """RK4 with steps ending at the known release changes and a mass-flux integral."""
    if not 0 < step <= HORIZON / SEGMENTS:
        raise ValueError("RK4 step must be positive and within a release bin")
    count = int(HORIZON / (SEGMENTS * step))
    if count * SEGMENTS * step != HORIZON:
        raise ValueError("RK4 step must divide each release bin")
    result = np.zeros((len(rates), Y.size, X.size))
    outflow = np.zeros(len(rates))
    history = [result.copy()] if with_history else None
    for release in rates.T:
        for _ in range(count):
            k1, f1 = flux_derivative(result, release)
            k2, f2 = flux_derivative(result + step * k1 / 2, release)
            k3, f3 = flux_derivative(result + step * k2 / 2, release)
            k4, f4 = flux_derivative(result + step * k3, release)
            result += (step / 6) * (k1 + 2 * k2 + 2 * k3 + k4)
            outflow += (step / 6) * (f1 + 2 * f2 + 2 * f3 + f4)
        if history is not None:
            history.append(result.copy())
    if with_history:
        return result, outflow, np.stack(history, axis=1)
    return result, outflow


def mass(fields):
    return CELL_WATER * fields.sum(axis=(1, 2))


def report_scores(predictions, reference, points, injected):
    field_error = np.linalg.norm((predictions - reference).reshape(len(points), -1), axis=1)
    field_error /= np.linalg.norm(reference.reshape(len(points), -1), axis=1)
    well_error = np.abs(predictions[:, WELL[0], WELL[1]] - points) / points
    mass_error = np.abs(mass(predictions) - mass(reference)) / injected
    errors = dict(zip(BUDGETS, (field_error, well_error, mass_error), strict=True))
    score = np.max([errors[key] / value for key, value in BUDGETS.items()], axis=0)
    min_value = np.min(predictions, axis=(1, 2))
    roundoff_budget = 1e-10 * np.max(reference, axis=(1, 2))
    accepted = (score <= 1) & (min_value >= -roundoff_budget)
    return {
        **{key: values.tolist() for key, values in errors.items()},
        "score": score.tolist(), "min_mg_m3": min_value.tolist(), "pass": accepted.tolist(),
    }


def run(output, median_ms):
    rng = np.random.default_rng(1904)
    train = rng.uniform(0.3, 3.7, size=(80, SEGMENTS))
    tests = np.array([
        [2, 2, 2, 2, 2, 2, 2, 2],
        [0.4, 0.4, 3.8, 3.8, 0.4, 0.4, 0.6, 0.6],
        [0.3, 0.3, 0.3, 0.3, 3.8, 3.8, 3.8, 3.8],
        [3.8, 3.8, 3.8, 3.8, 0.3, 0.3, 0.3, 0.3],
        [0.3, 3.6, 0.3, 0.3, 0.3, 3.6, 0.3, 0.3],
        [3.0, 2.7, 2.4, 2.1, 1.8, 1.5, 1.2, 0.9],
        [0.9, 1.2, 1.5, 1.8, 2.1, 2.4, 2.7, 3.0],
        [1.0, 2.4, 1.0, 2.4, 1.0, 2.4, 1.0, 2.4],
    ])
    names = ("konstant", "frueher Puls", "spaete Erhoehung", "spaete Absenkung",
             "Doppelpuls", "fallend", "steigend", "abwechselnd")

    start = perf_counter()
    kernels = green_basis()
    train_fields = observation_field(train, kernels)
    data_seconds = perf_counter() - start
    independent = green_basis(144)
    reference = observation_field(tests, independent)
    points = tests @ point_basis()
    assert abs(points[0] - 45021.6231) < 1e-3
    relative_quadrature_gap = np.linalg.norm(kernels - independent) / np.linalg.norm(independent)
    assert relative_quadrature_gap < 1e-7, relative_quadrature_gap

    phase = source_spectrum()
    start = perf_counter()
    weights = fit_fourier(train, train_fields)
    fit_seconds = perf_counter() - start
    mask = limited_modes()
    short_weights = weights * mask
    learned = predict_fourier(tests, weights, phase)
    band_limited = predict_fourier(tests, short_weights, phase)
    classical = observation_field(tests, kernels)
    rk, out = finite_volume(tests)
    rk_half_step, _ = finite_volume(tests, DT / 2)
    time_refinement = np.linalg.norm((rk - rk_half_step).reshape(len(tests), -1), axis=1)
    time_refinement /= np.linalg.norm(reference.reshape(len(tests), -1), axis=1)
    injected = tests.sum(axis=1) * HORIZON / SEGMENTS
    balance_gap = np.abs(mass(rk) + out - injected) / injected
    assert np.max(balance_gap) < 1e-12
    assert (rk >= 0).all()
    assert np.allclose(learned, classical, rtol=1e-10, atol=3e-9)

    methods = {
        "green": (classical, lambda: observation_field(tests, kernels)),
        "rk4": (rk, lambda: finite_volume(tests)),
        "fno_limited": (band_limited, lambda: predict_fourier(tests, short_weights, phase)),
        "fno_full": (learned, lambda: predict_fourier(tests, weights, phase)),
    }
    scored = {}
    for label, (values, operation) in methods.items():
        scored[label] = report_scores(values, reference, points, injected)
        scored[label]["batch_ms"] = median_ms(operation)
    np.savez_compressed(
        output / "c19r_modelle.npz", weights=weights, limited_modes=mask,
        kernels=kernels, x=X, y=Y, train_rates=train, test_rates=tests,
        reference=reference, point_reference=points, mass_injected=injected,
        **{key: fields for key, (fields, _) in methods.items()},
    )
    return {
        "test_names": names, "test_rates_mg_s": tests.tolist(), "training_seed": 1904,
        "training_count": len(train), "roundoff_nonnegative_budget": "1e-10 * max(reference)",
        "budgets": BUDGETS, "methods": scored, "data_seconds": data_seconds,
        "fit_seconds": fit_seconds, "rk4_mass_balance_max": float(np.max(balance_gap)),
        "rk4_time_refinement_max": float(np.max(time_refinement)),
        "quad_relative_difference": float(relative_quadrature_gap),
        "nominal_well_mg_m3": {key: float(value[0, WELL[0], WELL[1]])
                               for key, (value, _) in methods.items()} | {"point": float(points[0])},
        "outer_mass_fraction": ((injected - mass(reference)) / injected).tolist(),
    }
