// CP2 D2Q9 BGK, double precision. Arrays have nine planes of padded rows.
// Arguments: N Re threads output-directory checkpoint-file. Stored fields: rho,u/U,v/U.
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include <omp.h>
namespace fs=std::filesystem;
using Clock=std::chrono::steady_clock;
constexpr double lid=.1;
constexpr std::array<int,9> cx{0,1,0,-1,0,1,-1,-1,1},cy{0,0,1,0,-1,1,1,-1,-1},op{0,3,4,1,2,7,8,5,6};
constexpr std::array<double,9> weight{4./9,1./9,1./9,1./9,1./9,1./36,1./36,1./36,1./36};
inline void edge(const double *a,double *b,int n,int stride,int planes,int y,int x){
    int pos=y*stride+x;
    double rho=0; for(int j=0;j<9;++j) rho+=a[j*planes+pos];
    for(int j=0;j<9;++j){
        double z=a[op[j]*planes+pos];
        if(y==n-1){double ux=lid*cx[j];z=weight[j]*rho*(1+3*ux+4.5*ux*ux-1.5*lid*lid);}
        int yy=y+cy[j],xx=x+cx[j];
        if(yy>=0 && yy<n && xx>=0 && xx<n)b[j*planes+yy*stride+xx]=z;
        yy=y-cy[j];xx=x-cx[j];
        if(yy<0||yy>=n||xx<0||xx>=n)b[j*planes+pos]=z;
    }
}
inline void row(const double *__restrict a,double *__restrict b,int n,int st,int pl,int y,double rate){
    const double *f[9]; double *g[9];int base=y*st;
    for(int j=0;j<9;++j){f[j]=a+j*pl+base;g[j]=b+j*pl+base+cy[j]*st+cx[j];}
    #pragma omp simd
    for(int x=1;x<n-1;++x){
        double f0=f[0][x],f1=f[1][x],f2=f[2][x],f3=f[3][x],f4=f[4][x],f5=f[5][x],f6=f[6][x],f7=f[7][x],f8=f[8][x];
        double rho=f0+f1+f2+f3+f4+f5+f6+f7+f8, inv=1./rho;
        double u=(f1+f5+f8-f3-f6-f7)*inv,v=(f2+f5+f6-f4-f7-f8)*inv;
        double k=1.-1.5*(u*u+v*v), uv=u+v, vu=v-u;
        double eu=k+4.5*u*u,ev=k+4.5*v*v, ep=k+4.5*uv*uv, em=k+4.5*vu*vu;
        double r0=weight[0]*rho,r1=weight[1]*rho,r5=weight[5]*rho;
        g[0][x]=f0+rate*(r0*k-f0);
        g[1][x]=f1+rate*(r1*(eu+3*u)-f1);g[3][x]=f3+rate*(r1*(eu-3*u)-f3);
        g[2][x]=f2+rate*(r1*(ev+3*v)-f2);g[4][x]=f4+rate*(r1*(ev-3*v)-f4);
        g[5][x]=f5+rate*(r5*(ep+3*uv)-f5);g[7][x]=f7+rate*(r5*(ep-3*uv)-f7);
        g[6][x]=f6+rate*(r5*(em+3*vu)-f6);g[8][x]=f8+rate*(r5*(em-3*vu)-f8);
    }
    edge(a,b,n,st,pl,y,0);edge(a,b,n,st,pl,y,n-1);
}
int main(int argc,char**argv){
    if(argc!=6){std::cerr<<"N Re threads out checkpoint-file\n";return 2;}
    int n=std::stoi(argv[1]),threads=std::stoi(argv[3]),st=(n+15)/16*16,pl=n*st;
    double re=std::stod(argv[2]),rate=1./(.5+3*(n-1)*lid/re);
    if(n<5||threads<1||re<=0)return 2;
    fs::path out=argv[4];fs::create_directories(out);
    std::ifstream requested(argv[5]);std::vector<int> checkpoints;
    for(int k;requested>>k;)checkpoints.push_back(k);
    if(checkpoints.empty()||!std::is_sorted(checkpoints.begin(),checkpoints.end())||checkpoints[0]<1)return 2;
    std::array<std::vector<double>,2> buf{std::vector<double>(9*pl),std::vector<double>(9*pl)};
    for(int j=0;j<9;++j)std::fill_n(buf[0].data()+j*pl,pl,weight[j]);
    std::ofstream log(out/"zeiten.csv");log<<"step,t_star,wall_s,cpu_s,min_rho,max_rho,mean_rho\n"<<std::setprecision(17);
    omp_set_dynamic(0);omp_set_num_threads(threads);
    int last=0;double wall=0,cpu=0;
    for(int end:checkpoints){
        auto start=Clock::now();auto tc=std::clock();
        #pragma omp parallel
        {
            for(int k=last;k<end;++k){
                const auto *a=buf[k%2].data();auto *b=buf[(k+1)%2].data();
                #pragma omp for schedule(static)
                for(int y=0;y<n;++y){
                    if(y==0||y==n-1){for(int x=0;x<n;++x)edge(a,b,n,st,pl,y,x);}
                    else row(a,b,n,st,pl,y,rate);
                }
            }
        }
        wall+=std::chrono::duration<double>(Clock::now()-start).count();cpu+=double(std::clock()-tc)/CLOCKS_PER_SEC;
        const auto *a=buf[end%2].data();std::vector<double> field(3*n*n);
        double mn=1e300,mx=-1e300,mass=0;
        for(int y=0;y<n;++y)for(int x=0;x<n;++x){
            int p=y*st+x,i=y*n+x;double f[9],rho=0;
            for(int j=0;j<9;++j){f[j]=a[j*pl+p];rho+=f[j];}
            if(!(rho>0)||!std::isfinite(rho)){std::cerr<<"invalid density "<<end<<" "<<x<<" "<<y<<"\n";return 3;}
            mn=std::min(mn,rho);mx=std::max(mx,rho);mass+=rho;
            field[i]=rho;
            field[n*n+i]=(f[1]+f[5]+f[8]-f[3]-f[6]-f[7])/(rho*lid);
            field[2*n*n+i]=(f[2]+f[5]+f[6]-f[4]-f[7]-f[8])/(rho*lid);
        }
        fs::path name=out/("feld_"+std::to_string(end)+".bin");
        std::ofstream f(name,std::ios::binary);f.write(reinterpret_cast<const char*>(field.data()),field.size()*sizeof(double));f.close();
        if(!f){std::cerr<<"write failed\n";return 4;}
        log<<end<<','<<double(end)*lid/(n-1)<<','<<wall<<','<<cpu<<','<<mn<<','<<mx<<','<<mass/(n*n)<<'\n'<<std::flush;
        last=end;
    }
}
