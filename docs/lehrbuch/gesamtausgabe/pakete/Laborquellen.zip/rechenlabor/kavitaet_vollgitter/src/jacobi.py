"""Exact diagonal and adjoint rows of the full five-point/Thom vorticity Jacobian."""
from functools import cached_property,lru_cache
from gemeinsam import *

class IndexedRow:
    def __init__(self,matrix,i): self.matrix,self.i=matrix,i
    def __getitem__(self,j):
        if self.i==j:return self.matrix.diagonal[self.i]
        if j<0 or j>=len(self.matrix.diagonal):raise IndexError(j)
        return self.matrix.row(self.i)[j]
    def __iter__(self):return iter(self.matrix.row(self.i))
    def __len__(self):return len(self.matrix.diagonal)

class Jacobian:
    def __init__(self,cavity,z,geo):
        self.c=cavity;h=cavity.h;m=cavity.m
        _,u,v,zx,zy=cavity.quantities(z)
        self.u,self.v,self.zx,self.zy=u,v,zx,zy
        diff,du,dv,dx,dy=geo
        self.diagonal=diff-du*zx-dv*zy-u*dx-v*dy
        self.row=lru_cache(maxsize=5)(self._row)
    def __getitem__(self,i):
        if i<0 or i>=self.c.dim:raise IndexError(i)
        return IndexedRow(self,i)
    def __len__(self): return self.c.dim
    def _row(self,i):
        c=self.c;h=c.h;m=c.m;y,x=divmod(i,m)
        source=np.zeros((m,m));local=np.zeros_like(source)
        # Adjoints of node differences and the Thom boundary relation z_wall=-2 psi_adj/h+constant.
        local[y,x]=-4/(c.re*h*h)
        for dy,dx in ((0,1),(0,-1),(1,0),(-1,0)):
            yy,xx=y+dy,x+dx
            coeff=1/(c.re*h*h)-(self.u[i]*dx+self.v[i]*dy)/(2*h)
            if 0<=yy<m and 0<=xx<m:
                local[yy,xx]+=coeff
                source[yy,xx]+=(-self.zx[i]*dy+self.zy[i]*dx)/(2*h)
            else:source[y,x]-=2*coeff/h
        field=idstn(dstn(source,type=1,norm='ortho')/c.eigen,type=1,norm='ortho')/h
        return (local+field).ravel()
def geometry(c):
    m=c.m;h=c.h
    wave=np.sqrt(2*h)*np.sin(np.pi*h*np.arange(1,m+1)[:,None]*np.arange(1,m+1)[None,:])
    sq=wave**2;inv=1/c.eigen
    up=np.vstack((wave[1:],np.zeros((1,m))))*wave
    down=np.vstack((np.zeros((1,m)),wave[:-1]))*wave
    green=sq@inv@sq.T
    du=((up-down)@inv@sq.T)/(2*h*h);dv=-du.T
    shadow=-2*green/(h*h)
    diff=np.full_like(green,-4);dx=np.zeros_like(green);dy=np.zeros_like(green)
    for s in (0,-1): diff[s]+=shadow[s];diff[:,s]+=shadow[:,s]
    dx[:,0]-=shadow[:,0]/(2*h);dx[:,-1]+=shadow[:,-1]/(2*h)
    dy[0]-=shadow[0]/(2*h);dy[-1]+=shadow[-1]/(2*h)
    return [v.ravel() for v in (diff/(c.re*h*h),du,dv,dx,dy)]

def mount(c):
    from argesim_benchmarks.solvers import advanced_qss as adv,mixed_qss as mix
    geo=geometry(c)
    def jac(t,state):return Jacobian(c,state,geo)
    def validate(problem,t,state,cb,step):return cb(t,state),0
    adv.validated_jacobian=validate
    mix._validated_full_jacobian=lambda cb,t,state,dim:cb(t,state)
    # The reduced LIQSS2 block needs the principal diagonal only.
    def reduced(cb,problem,t,h,start,bdf_end,iq,ib):
        indices=np.array(iq,dtype=int);bi=np.array(ib,dtype=int);y0=np.asarray(start)
        def jr(tt,sub):
            full=y0.copy();full[indices]=sub;theta=(tt-t)/h
            full[bi]=y0[bi]+theta*(np.asarray(bdf_end)[bi]-y0[bi])
            fulljac=cb(tt,full)
            class Principal:
                diagonal=fulljac.diagonal[indices]
                def __getitem__(self,i):return IndexedRow(self,i)
                def row(self,i):return fulljac.row(indices[i])[indices]
            return Principal()
        return jr
    mix._reduced_jacobian=reduced
    return jac
if __name__=='__main__':
    rng=np.random.default_rng(917);errors=[]
    for n in (7,9,17):
        c=Cavity(n,1000);z=rng.normal(0,.1,c.dim);m=Jacobian(c,z,geometry(c));exact=c.jac(0,z)
        err=max(abs(m.diagonal-exact.diagonal()).max(),max(abs(m.row(i)-exact[i]).max() for i in range(c.dim)))
        assert err<1e-11,err
        # The BDF endpoint is a full state. Verify the interpolated principal matrix.
        from argesim_benchmarks.solvers import mixed_qss as mix
        cb=mount(c);indices=np.arange(c.dim-c.m);ib=np.arange(c.dim-c.m,c.dim)
        x1=z+rng.normal(0,.001,c.dim);x2=z[indices]+.01;full=z.copy();full[indices]=x2;full[ib]=.5*(x1[ib]+z[ib])
        principal=mix._reduced_jacobian(cb,None,0,1,z,x1,indices,ib)(.5,x2)
        reference=c.jac(.5,full)[np.ix_(indices,indices)]
        e2=max(np.max(abs(principal.diagonal-reference.diagonal())),np.max(abs(principal.row(0)-reference[0])))
        assert e2<1e-11,e2
        errors.append(dict(n=n,max_abs=err,reduced_block_abs=e2))
    savecsv(DATA/'jacobi_kontrolle.csv',errors)
