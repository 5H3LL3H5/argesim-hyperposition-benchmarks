"""Offline verification of all archived outputs; no raw training simulation required."""
from gemeinsam import *
from operatoren import KINDS, infer
import hashlib
r=readcsv(DATA/'methodenmatrix_voll.csv')
def by(f):return [q for q in r if q['familie']==f]
for typ in ('QSS Komponente','QSS POD','QSS Korrektur'):
    assert set(a['verfahren'].split()[0] for a in by(typ))==set(METHODS)
for typ in ('Operator direkt','Operator korrektur'):
    assert set(a['verfahren'] for a in by(typ))==set(KINDS)
for row in r:
    assert float(row['cpu_s'])>=0 and float(row['wand_s'])>=0
    for name in ('lbm_rel_max','lbm_lokal_max_U','ns_rel_max','ns_lokal_max_U','zeit_rel_max','zeit_lokal_max_U'):
        if row[name]:assert np.isfinite(float(row[name])),(row['verfahren'],name)
    if int(row['zeitpunkte'])<7:assert not row['budget_d2q9'] and not row['amortisation_anfragen']
refs=np.load(DATA/'testreferenzen.npz');assert np.array_equal(refs['steps'],TEST);target=refs['lbm']
assert target.shape==(7,257,257,2) and np.min(refs['rho'])>0
assert np.all(target[:,-1,:,0]==1.) and np.all(target[:,-1,:,1]==0.)
c=Cavity(N,RE);sn=[c.field(z) for z in refs['ns_z']];co=np.load(DATA/'operatoren/feld_physik_D2Q9_65.npz')['u']
checks=0
for rec in by('QSS Gruppe'):
    a,b=rec['verfahren'].split();order=int(a[-1]);q=float(b.split('=')[1]);xs=np.load(DATA/f'gruppe_{order}_{q}.npz')['z']
    v=[c.field(z) for z in xs]
    for field,key in ((sn,'ns'),(target,'lbm')):
        rel,mx=np.max([compare(vi,ri) for vi,ri in zip(v,field)],axis=0)
        assert abs(rel-float(rec[key+'_rel_max']))<2e-12 and abs(mx-float(rec[key+'_lokal_max_U']))<2e-12;checks+=1
for t in ('direkt','korrektur'):
    v=np.load(DATA/f'operatoren/basis_{t}.npy',mmap_mode='r')
    for kind in KINDS:
        e=next(a for a in by('Operator '+t) if a['verfahren']==kind)
        p=dict(np.load(DATA/f'operatoren/{t}_{kind}.npz'));pred=infer(kind,p,[(RE,k) for k in TEST],v)
        if t=='korrektur':pred+=co
        else:pred[:,-1,:,:]=[1,0]
        sample=np.load(DATA/f'operatoren/feld_{t}_{kind}.npz')['u']
        assert np.max(abs(pred-sample))<2e-7
        mx=np.max([compare(a,b) for a,b in zip(pred,target)],axis=0)
        assert np.max(abs(mx-np.array([float(e['lbm_rel_max']),float(e['lbm_lokal_max_U'])])))<3e-7;checks+=1
from galerkin import Model
model=Model(dict(np.load(DATA/'galerkin_basis.npz')),RE);ref=np.load(DATA/'galerkin_zeitreferenz.npz')['a']
lift=np.load(DATA/'qss_korrektur/modell.npz')
for typ in ('QSS POD','QSS Korrektur'):
    for e in by(typ):
        m=e['verfahren'].split()[0]
        if not int(e['zeitpunkte']):continue
        if typ=='QSS POD':
            a=np.load(DATA/f'rom_qss/{m}_q0.003.npz')['a']
            vf=[model.field(q) for q in a]
        else:
            ob=json.loads((DATA/f'qss_korrektur/{m}.json').read_text())['observations']
            vf=[c.field(b+z['a']*lift['phi']) for b,z in zip(lift['bases'],ob)]
        val=np.max([compare(v,t) for v,t in zip(vf,target)],axis=0)
        assert np.allclose(val,[float(e['lbm_rel_max']),float(e['lbm_lokal_max_U'])],rtol=2e-13,atol=1e-12);checks+=1
for mode in ('direkt','korrektur'):
    item=by('2D-Fourieroperator '+mode)[0]
    a=np.load(DATA/'raum_fourier'/(mode+'_felder.npz'))['u']
    import raum_fourier as spatial
    params=np.load(DATA/'raum_fourier'/(mode+'.npz'))
    assert np.array_equal(params['lift'],spatial.w) and np.array_equal(params['bias'],spatial.bias)
    for j,k in enumerate(TEST):
        z,b=spatial.datafeatures(RE,k,mode=='korrektur',base_field=co[j])
        reconstructed=spatial.reconstruct(params['weights'],z,b)
        assert np.max(np.abs(reconstructed-a[j]))<3e-5
    mm=np.max([compare(x,y) for x,y in zip(a,target)],axis=0)
    assert np.max(abs(mm-[float(item['lbm_rel_max']),float(item['lbm_lokal_max_U'])]))<4e-7;checks+=1
for mode in ('direkt','korrektur'):
    basis=np.load(DATA/f'operatoren/basis_{mode}.npy',mmap_mode='r')
    for row in by('Zeitblind '+mode):
        kind=row['verfahren'];weights=dict(np.load(DATA/f'zeitblind/{mode}_{kind}.npz'))
        pred=infer(kind,weights,[(RE,k) for k in TEST],basis)
        if mode=='korrektur':pred+=co
        else:pred[:,-1]=[1,0]
        mx=np.max([compare(a,b) for a,b in zip(pred,target)],axis=0)
        assert np.allclose(mx,[float(row['lbm_rel_max']),float(row['lbm_lokal_max_U'])],atol=3e-7,rtol=1e-10);checks+=1
print(f'{len(r)} Methoden-Konfigurationen kontrolliert. {checks} gespeicherte Feld- oder Rekonstruktionsvergleiche bestanden.')
