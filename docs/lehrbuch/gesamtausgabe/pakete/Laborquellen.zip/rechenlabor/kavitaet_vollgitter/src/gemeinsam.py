import os
for name in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"): os.environ[name]="1"
import csv,json,time,sys
from pathlib import Path
import numpy as np
from scipy.fft import dstn,idstn
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'daten';DATA.mkdir(exist_ok=True)
RAW=Path(os.environ.get('KAV_RAW',str(ROOT/'rohdaten')))
BASIS=ROOT/'basis'
sys.path.insert(0,str(BASIS));sys.path.insert(0,str(BASIS/'original'))
from kavitaet import Cavity
from argesim_benchmarks import InitialValueProblem,solve_ivp
from argesim_benchmarks.runtime import _QUANTISED_SOLVERS
METHODS=('qss1','qss2','qss3','qss4','cqss1','bqss1',*(f'{f}{s}' for f in ('liqss','mliqss','eliqss','cheqss') for s in (1,2,3)),'liqss-bdf')
assert set(METHODS)==set(_QUANTISED_SOLVERS)
N=257; RE=1000;U=.1; END=350000;DT=U/(N-1)
K=np.loadtxt(ROOT/'src'/'zeitpunkte.txt',dtype=int)
TEST=np.asarray([256,4096,16384,65536,131072,262144,350000])
def savecsv(path,rows):
    path=Path(path);path.parent.mkdir(exist_ok=True,parents=True)
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=tuple(dict.fromkeys(k for r in rows for k in r)));w.writeheader();w.writerows(rows)
def readcsv(path):
    with Path(path).open() as f:return list(csv.DictReader(f))
def lb(k,re=1000,n=N):
    a=np.fromfile(RAW/f're{re}'/f'feld_{k}.bin',dtype='f8').reshape(3,n,n)
    v=a[1:].transpose(1,2,0).copy()
    v[-1,:,:]=[1,0]
    return v
def ns(k,re=1000,stride=2,n=N):
    return np.fromfile(RAW/f'ns_{re}_{stride}'/f'z_{k}.bin',dtype='f8')
def compare(v,ref):
    a=v[1:-1,1:-1]-ref[1:-1,1:-1];b=ref[1:-1,1:-1]
    return float(np.linalg.norm(a)/np.linalg.norm(b)),float(np.linalg.norm(a,axis=-1).max())
