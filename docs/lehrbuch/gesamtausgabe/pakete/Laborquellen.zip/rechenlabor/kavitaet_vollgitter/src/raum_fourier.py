"""One trained 2-D Fourier layer, directly or as correction to the 65² physics.
Frozen nonlinear lifting, learned frequency-by-frequency complex channel mixing, physical output at 257².
"""
from gemeinsam import *
from operatoren import TRAIN,VAL,KT,coarse
from scipy.fft import rfft2,irfft2
OUT=DATA/'raum_fourier';OUT.mkdir(exist_ok=True)
MODES=16;YD=np.r_[0:MODES+1,N-MODES:N];XD=np.arange(MODES+1);D=9
x=np.linspace(-1,1,N,dtype=np.float32);Y,X=np.meshgrid(x,x,indexing='ij');lid=(Y==1).astype('f4')
w=np.random.default_rng(917).normal(0,1.25,(6,D));bias=np.random.default_rng(918).normal(0,.45,D)
def datafeatures(re,k,h,base_field=None):
    r=(re-1000)/350;t=np.log1p(k*DT)/np.log1p(END*DT)
    base=(coarse(k,re) if base_field is None else base_field) if h else None
    # The two signal channels carry the current baseline or the prescribed lid and its history.
    a,b=(base[:,:,0],base[:,:,1]) if h else (lid,t*lid)
    F=np.empty((N,N,D),dtype='f4')
    for j in range(D):F[:,:,j]=np.tanh(w[0,j]*X+w[1,j]*Y+w[2,j]*r+w[3,j]*t+w[4,j]*a+w[5,j]*b+bias[j])
    hats=rfft2(F,axes=(0,1),norm='forward')[np.ix_(YD,XD,np.arange(D))]
    return hats,base
def project(U):return rfft2(U,axes=(0,1),norm='forward')[np.ix_(YD,XD,np.arange(2))]
def reconstruct(co,z,base):
    hat=np.zeros((N,N//2+1,2),dtype='c8')
    hat[np.ix_(YD,XD,np.arange(2))]=np.einsum('ijk,ijkl->ijl',z,co)
    v=irfft2(hat,s=(N,N),axes=(0,1),norm='forward')
    if base is not None:v=v+base
    v[-1,:,:]=[1,0]
    return v
def run(h):
    from operatoren import error_records
    tag='korrektur' if h else 'direkt'
    start=time.process_time();wall=time.perf_counter()
    xx=[];yy=[]
    for re in TRAIN:
        for k in KT:
            z,b=datafeatures(re,k,h);y=lb(k,re)
            if b is not None:y-=b
            else:y[-1]=0
            xx.append(z);yy.append(project(y))
    xx=np.asarray(xx,dtype='c16');yy=np.asarray(yy,dtype='c16')
    gram=np.einsum('nija,nijb->ijab',xx.conj(),xx,optimize=True)
    cross=np.einsum('nija,nijc->ijac',xx.conj(),yy,optimize=True)
    scale=np.maximum(gram.trace(axis1=-2,axis2=-1).real/D,1e-11)
    val=[]
    for re in VAL:
        for k in TEST:
            z,b=datafeatures(re,k,h);val.append((z,b,lb(k,re)))
    best=None
    for reg in (1e-6,1e-4,1e-2):
        co=np.linalg.solve(gram+reg*scale[:,:,None,None]*np.eye(D),cross)
        score=max(max(compare(reconstruct(co,z,b),ref)) for z,b,ref in val)
        if best is None or score<best[0]:best=(score,reg,co)
    score,reg,co=best;tc=time.process_time()-start;tw=time.perf_counter()-wall
    np.savez_compressed(OUT/(tag+'.npz'),weights=co,lift=w,bias=bias,xmodes=XD,ymodes=YD,reg=reg)
    cs=[];ws=[]
    for rep in range(6):
        c=time.process_time();wt=time.perf_counter()
        out=np.stack([reconstruct(co,*datafeatures(RE,k,h)) for k in TEST])
        if rep:cs.append(time.process_time()-c);ws.append(time.perf_counter()-wt)
    cb=readcsv(RAW/'g65_re1000'/'zeiten.csv')[-1]
    ct=float(np.median(cs))+(float(cb['cpu_s']) if h else 0.);wt=float(np.median(ws))+(float(cb['wall_s']) if h else 0.)
    obs=error_records('raum_'+tag,'Fourier2D',out,dict(cpu_s=ct,wall_s=wt,net_cpu_s=float(np.median(cs)),clock_repeats=5),False)
    savecsv(OUT/(tag+'_test.csv'),obs);np.savez_compressed(OUT/(tag+'_felder.npz'),u=out.astype('f4'),steps=TEST)
    (OUT/(tag+'_fit.json')).write_text(json.dumps(dict(cpu_s=tc,wall_s=tw,validation_score=score,ridge=reg,
            spectral_modes_per_axis=MODES,nonlinear_lift=D,train_re=TRAIN,validation_re=VAL,test_re=RE),indent=2))
if __name__=='__main__':
    for mode in (False,True):run(mode)
