from gemeinsam import *
from collections import defaultdict
rows=readcsv(DATA/'klassisch_gruppen.csv');names=[r['verfahren'] for r in rows if int(r['step'])==END and not r['verfahren'].startswith('D2Q9')]
table=defaultdict(list);ratios=[]
for name in names:
    table[name]=[r for r in rows if r['verfahren']==name]
for i,k in enumerate(TEST):
    eligible={name:float(table[name][i]['cpu_s']) for name in names
              if all(float(r['ns_rel'])<=.01 and float(r['ns_max_U'])<=.01 for r in table[name][:i+1])}
    best=min(eligible.values())
    for name in names:ratios.append(dict(verfahren=name,k=int(k),referenz='NS AB2, zwei Gittertakte',eligible=name in eligible,quotient=eligible[name]/best if name in eligible else ''))
for method in METHODS:
    name='Einzelkalender '+method
    recorded=json.loads((DATA/'voll_qss'/(method+'.json')).read_text())
    assert recorded['last_time'] < TEST[0]*DT, (method,recorded['last_time'])
    for k in TEST:
        ratios.append(dict(verfahren=name,k=int(k),referenz='NS AB2, zwei Gittertakte',eligible=False,quotient=''))
    names.append(name)
savecsv(DATA/'dolan_more_ns_quotienten.csv',ratios)
savecsv(DATA/'dolan_more_ns_profil.csv',[dict(verfahren=name,tau=tau,erfuellte_praefixe=sum(x['quotient']!='' and float(x['quotient'])<=tau for x in ratios if x['verfahren']==name),nenner=len(TEST)) for name in names for tau in (1,1.25,1.5,2,4,8,16)])
