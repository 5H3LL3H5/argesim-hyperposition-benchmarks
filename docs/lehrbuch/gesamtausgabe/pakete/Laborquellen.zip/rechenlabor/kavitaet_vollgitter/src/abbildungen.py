"""Two book plates from scored full-resolution fields. Lettered panels share explicit scales."""
from gemeinsam import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator
from matplotlib.colors import Normalize
import matplotlib.patheffects as pe
plt.rcParams.update({'font.size':9.5,'axes.labelsize':9,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
O=ROOT/'grafiken';O.mkdir(exist_ok=True)
def save(fig,stem):
    for ext in ('pdf','svg'):fig.savefig(O/(stem+'.'+ext),bbox_inches='tight',pad_inches=.045,dpi=165)
    plt.close(fig)
def fields():
    c=Cavity(N,RE);a=np.load(DATA/'testreferenzen.npz');v=a['lbm'][-1];ns_v=c.field(a['ns_z'][-1])
    fig,axes=plt.subplots(1,2,figsize=(7.5,3.48),layout='constrained')
    for ax,title,data,cm,limits,legend in zip(axes,('A   Geschwindigkeit','B   Abstand zur Wirbelrechnung'),(np.linalg.norm(v,axis=-1),np.linalg.norm(v-ns_v,axis=-1)),('viridis','magma'),((0,1),(0,.10)),(r'$|u|/U$',r'$|u_{\rm D2Q9}-u_{\rm NS}|/U$')):
        im=ax.imshow(data,origin='lower',extent=[0,1,0,1],cmap=cm,norm=Normalize(*limits),interpolation='none',rasterized=True)
        ax.set(xlabel='$x/L$',ylabel='$y/L$',xticks=[0,.5,1],yticks=[0,.5,1]);ax.set_title(title,loc='left',fontsize=10,weight='bold')
        cb=fig.colorbar(im,ax=ax,orientation='horizontal',fraction=.08,pad=.15,extend='max' if limits[1]<1 else 'neither')
        cb.set_label(legend)
    x=np.linspace(0,1,N);ax=axes[0];ax.streamplot(x,x,v[:,:,0],v[:,:,1],density=.72,color='white',linewidth=.46,arrowsize=.64)
    for ax in axes: ax.set(xlim=(0,1),ylim=(0,1),aspect='equal')
    save(fig,'cp2_voll_feld')
def errors():
    rows=readcsv(DATA/'klassisch_gruppen.csv');fig,axes=plt.subplots(1,2,figsize=(7.5,3.0),layout='constrained')
    lookup={'NS AB2 (2 Takte)':('NS gegen D2Q9','#362b61','lbm_rel'),'Gruppen-QSS1 q=0.001':('QSS1 gegen NS','#af5d15','ns_rel'),'Gruppen-QSS2 q=0.001':('QSS2 gegen NS','#147773','ns_rel')}
    ax=axes[0]
    for name,(label,color,col) in lookup.items():
        rr=[r for r in rows if r['verfahren']==name];ax.loglog([float(r['t_star']) for r in rr],[100*float(r[col]) for r in rr],'-o',ms=3,linewidth=1.5,label=label,color=color)
    ax.set(xlabel='Zeit $tU/L$',ylabel='Relativer Feldfehler [%]');ax.grid(True,alpha=.2);ax.legend(fontsize=7,loc='best')
    ax.set_title('A   Fehler entlang der Bahn',loc='left',fontsize=10,weight='bold')
    ax=axes[1];op=readcsv(DATA/'methodenmatrix_voll.csv')
    groups=(('Operator direkt','direkt','#146f78','o'),('Operator korrektur','65² + Korrektur','#b15d12','s'),('interpolation','Interpolation','#452b67','d'),('physik','D2Q9 auf 65²','#49565c','^'))
    for tag,label,color,marker in groups:
        s=[r for r in op if r['familie']==tag]
        ax.scatter([float(r['cpu_s']) for r in s],[100*float(r['lbm_rel_max']) for r in s],color=color,alpha=.8,s=29,marker=marker,label=label)
    ax.axhline(1,color='gray',ls='--',lw=.85);ax.set(xscale='log',yscale='log',xlabel='CPU-Zeit für sieben Felder [s]',ylabel='Größter Feldfehler gegen D2Q9 [%]')
    ax.grid(True,alpha=.2);ax.legend(fontsize=7,loc='best');ax.set_title('B   Aufwand einer Anfrage',loc='left',fontsize=10,weight='bold')
    save(fig,'cp2_voll_fehler')
if __name__=='__main__':fields();errors()
