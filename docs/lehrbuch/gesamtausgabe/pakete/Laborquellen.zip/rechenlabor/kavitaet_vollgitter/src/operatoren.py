"""Matched 257² operators. Learning is on other Reynolds numbers, followed by frozen full-field prediction."""
from gemeinsam import *
from scipy.ndimage import map_coordinates
import hashlib
TRAIN=(650,750,850,950,1050,1150,1250,1350)
VAL=(900,1100)
HIDDEN_TIMES=(4096,65536,262144)
KT=np.array([k for k in K if k not in HIDDEN_TIMES])
KINDS=('fourier','laplace','wavelet','hankel','radon','wavelet_laplace','fourier_mellin')
DICTS=dict(np.load(BASIS/'zeitkerne.npz')); RANK=24; WIDTH=96
OUT=DATA/'operatoren';OUT.mkdir(exist_ok=True)
GRID=np.indices((N,N),dtype=float)/4
def coarse(k,re):
    a=np.fromfile(RAW/f'g65_re{re}'/f'feld_{k//4}.bin',dtype='f8').reshape(3,65,65)[1:].copy()
    a[0,-1]=1;a[1,-1]=0
    return np.stack([map_coordinates(v,GRID,order=1,mode='nearest',prefilter=False) for v in a],axis=-1)
def signature(re,k,kind):
    edges=np.expm1(np.linspace(0,np.log1p(END),65))
    hist=np.clip((k-edges[:-1])/np.diff(edges),0,1)
    z=hist@DICTS[kind]
    r=(re-1000)/350
    return np.r_[r,r*r,np.log1p(k*DT),z,z*r]
def dictionary(X):
    n,dim=X.shape
    norms=np.sqrt(np.einsum('ij,ij->i',X,X,dtype=float));w=1/np.maximum(norms,1e-12)
    G=np.zeros((n,n))
    for s in range(0,dim,8192):
        a=X[:,s:s+8192].astype(float)*w[:,None];G+=a@a.T
    vals,vec=np.linalg.eigh(G);ii=np.argsort(vals)[::-1][:RANK]
    coef=(w[:,None]*vec[:,ii])/np.sqrt(np.maximum(vals[ii],1e-15))
    V=np.empty((RANK,dim));Y=np.zeros((n,RANK))
    for s in range(0,dim,8192):
        j=slice(s,s+8192);block=X[:,j].astype(float)
        V[:,j]=coef.T@block;Y+=block@V[:,j].T
    return V,Y
def fit_head(kind,train,val,Y,Yval,Xval,ridge_vals):
    code=np.array([signature(re,k,kind) for re,k in train]);cv=np.array([signature(re,k,kind) for re,k in val])
    shift=code.mean(axis=0);scale=code.std(axis=0);scale[scale<1e-10]=1.
    rng=np.random.default_rng(917)
    W=rng.normal(0,1/np.sqrt(code.shape[1]),(code.shape[1],WIDTH));b=rng.normal(0,.35,WIDTH)
    def design(x):
        s=(x-shift)/scale
        return np.column_stack((np.ones(len(s)),s,np.tanh(s@W+b)))
    A=design(code);B=design(cv);u,s,vt=np.linalg.svd(A,full_matrices=False)
    # Orthogonal unreconstructed energy is common to the ridge candidates.
    best=None
    for ridge in ridge_vals:
        out=(vt.T*(s/(s*s+ridge)))@(u.T@Y);res=B@out-Yval
        score=float(np.max(np.linalg.norm(res,axis=1)/Xval))
        if best is None or score<best[0]:best=(score,ridge,out)
    return dict(shift=shift,scale=scale,W=W,b=b,out=best[2],ridge=best[1],validation_coeff_score=best[0])
def infer(kind,params,coords,V):
    x=np.array([signature(re,k,kind) for re,k in coords])
    s=(x-params['shift'])/params['scale']
    A=np.column_stack((np.ones(len(s)),s,np.tanh(s@params['W']+params['b'])))
    v=((A@params['out'])@V).reshape(len(s),N,N,2)
    return v
def train_group(hybrid):
    train=[(re,int(k)) for re in TRAIN for k in KT];val=[(re,int(k)) for re in VAL for k in TEST]
    tag='korrektur' if hybrid else 'direkt';twall=time.perf_counter();tcpu=time.process_time()
    def targets(coords):
        a=np.empty((len(coords),2*N*N),dtype=np.float32)
        fullnorm=[]
        for i,(re,k) in enumerate(coords):
            ref=lb(k,re);fullnorm.append(np.linalg.norm(ref[1:-1,1:-1]))
            if hybrid: ref-=coarse(k,re)
            else:ref[-1,:,:]=0
            a[i]=ref.ravel()
        return a,np.asarray(fullnorm)
    X,_=targets(train);V,Y=dictionary(X);del X
    xval,norm=targets(val);Yval=xval@V.T;del xval
    np.save(OUT/f'basis_{tag}.npy',V)
    info=dict(train_re=TRAIN,validation_re=VAL,test_re=1000,training_steps=KT.tolist(),val_steps=TEST.tolist(),
              heldout_steps=HIDDEN_TIMES,rank=RANK,width=WIDTH,shared_pod_cpu_s=time.process_time()-tcpu,shared_pod_wall_s=time.perf_counter()-twall)
    fitrows=[]
    for kind in KINDS:
        t=time.process_time();w=time.perf_counter()
        params=fit_head(kind,train,val,Y,Yval,norm,(1e-9,1e-7,1e-5,1e-3,1e-1,1))
        rt=time.process_time()-t;wt=time.perf_counter()-w
        path=OUT/f'{tag}_{kind}.npz';np.savez_compressed(path,**params)
        fitrows.append(dict(art=tag,kern=kind,fit_cpu_s=rt,fit_wall_s=wt,ridge=params['ridge'],validierungswert=params['validation_coeff_score'],
                            frozen_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    (OUT/f'aufbau_{tag}.json').write_text(json.dumps(info,indent=2));savecsv(OUT/f'fit_{tag}.csv',fitrows)
def error_records(name,kind,fields,timing,fields_out):
    rows=[]
    for k,v in zip(TEST,fields):
        truth=lb(k);er,mx=compare(v,truth);diff=np.linalg.norm(v-truth,axis=-1)
        where=np.unravel_index(np.argmax(diff[1:-1,1:-1]),(N-2,N-2))
        wall=np.vstack((v[0],v[1:-1,0],v[1:-1,-1]))
        rows.append(dict(art=name,kern=kind,step=int(k),t_star=float(k*DT),rel=er,max_U=mx,
                     max_yL=(where[0]+1)/(N-1),max_xL=(where[1]+1)/(N-1),wall_U=np.linalg.norm(wall,axis=1).max(),**timing))
    if fields_out:np.savez_compressed(OUT/f'feld_{name}_{kind}.npz',u=fields.astype('f4'),steps=TEST)
    return rows
def baseline(typ,cache):
    # Nearest training times bracketing each test time. Only training-grid data are indexed.
    fields=[]
    for k in TEST:
        high=min(x for x in KT if x>=k);low=max(x for x in KT if x<=k)
        w=0 if low==high else (k-low)/(high-low)
        subset=(950,1050) if typ=='linear' else (850,950,1050)
        out=np.zeros((N,N,2))
        for re in subset:
            l=np.prod([(1000-other)/(re-other) for other in subset if other!=re])
            out+=l*((1-w)*cache[(re,low)]+w*cache[(re,high)])
        fields.append(out)
    return np.stack(fields)
def evaluate():
    records=[]; coords=[(1000,int(k)) for k in TEST]
    cstart=time.process_time();cw=time.perf_counter();cgroup=np.array([coarse(k,1000) for k in TEST]);cpost=time.process_time()-cstart;cwpost=time.perf_counter()-cw
    c0=readcsv(RAW/'g65_re1000'/'zeiten.csv')[-1]
    coarse_cpu=float(c0['cpu_s'])+cpost;coarse_wall=float(c0['wall_s'])+cwpost
    records+=error_records('physik','D2Q9_65',cgroup,dict(cpu_s=coarse_cpu,wall_s=coarse_wall,clock_repeats=1,net_cpu_s=0),True)
    for tag in ('direkt','korrektur'):
        V=np.load(OUT/f'basis_{tag}.npy')
        for kind in KINDS:
            p=dict(np.load(OUT/f'{tag}_{kind}.npz'));cs=[];ws=[]
            for rep in range(6):
                t=time.process_time();w=time.perf_counter()
                v=infer(kind,p,coords,V)
                if tag=='korrektur':v+=cgroup
                else:v[:,-1,:,0]=1;v[:,-1,:,1]=0
                if rep:cs.append(time.process_time()-t);ws.append(time.perf_counter()-w)
            cost=float(np.median(cs));wc=float(np.median(ws))
            records+=error_records(tag,kind,v,dict(cpu_s=cost+(coarse_cpu if tag=='korrektur' else 0),
                       wall_s=wc+(coarse_wall if tag=='korrektur' else 0),clock_repeats=5,net_cpu_s=cost),True)
    cache={(r,k):lb(k,r) for r in (850,950,1050) for k in KT}
    for typ in ('linear','quadratisch'):
        cs=[];ws=[]
        for rep in range(6):
            t=time.process_time();w=time.perf_counter();v=baseline(typ,cache)
            if rep:cs.append(time.process_time()-t);ws.append(time.perf_counter()-w)
        records+=error_records('interpolation',typ,v,dict(cpu_s=np.median(cs),wall_s=np.median(ws),clock_repeats=5,net_cpu_s=0),False)
    savecsv(OUT/'test.csv',records)
if __name__=='__main__':train_group(False);train_group(True);evaluate()
