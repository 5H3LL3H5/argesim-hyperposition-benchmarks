"""Independent time-split sensitivity; the three additional test times are absent from both fit and tuning."""
from gemeinsam import *
import operatoren as op
dst=DATA/'zeitblind';dst.mkdir(exist_ok=True)
VSTEPS=(256,3072,16384,57344,131072,245760,350000)
assert not set(VSTEPS)&set(op.HIDDEN_TIMES)
rows=[];coords=[(RE,int(k)) for k in TEST]
for tag in ('direkt','korrektur'):
    h=tag=='korrektur';tic=time.process_time();setup=json.loads((op.OUT/f'aufbau_{tag}.json').read_text());V=np.load(op.OUT/f'basis_{tag}.npy')
    train=[(re,int(k)) for re in op.TRAIN for k in op.KT];val=[(re,k) for re in op.VAL for k in VSTEPS]
    def projection(records):
        ys=[];norm=[]
        for re,k in records:
            truth=lb(k,re);norm.append(np.linalg.norm(truth[1:-1,1:-1]))
            if h:truth-=op.coarse(k,re)
            else:truth[-1]=0
            ys.append(V@truth.astype('f4').ravel().astype('f8'))
        return np.stack(ys),np.array(norm)
    Y,_=projection(train);Yv,norm=projection(val);co=[op.coarse(k,RE) for k in TEST] if h else None
    shared=time.process_time()-tic
    coarse_record=readcsv(RAW/'g65_re1000'/'zeiten.csv')[-1]
    t0=time.process_time();w0=time.perf_counter();cg=np.stack([op.coarse(k,RE) for k in TEST]) if h else None
    coarse_cpu=(float(coarse_record['cpu_s'])+time.process_time()-t0) if h else 0;coarse_wall=(float(coarse_record['wall_s'])+time.perf_counter()-w0) if h else 0
    for kind in op.KINDS:
        fit=time.process_time();params=op.fit_head(kind,train,val,Y,Yv,norm,(1e-9,1e-7,1e-5,1e-3,1e-1,1))
        fit=time.process_time()-fit;cs=[];ws=[]
        for i in range(6):
            t=time.process_time();w=time.perf_counter()
            out=op.infer(kind,params,coords,V)
            if h:out+=cg
            else:out[:,-1]=[1,0]
            if i:cs.append(time.process_time()-t);ws.append(time.perf_counter()-w)
        rt=float(np.median(cs));rw=float(np.median(ws))
        vals=np.array([compare(v,lb(k)) for v,k in zip(out,TEST)])
        np.savez_compressed(dst/f'{tag}_{kind}.npz',**params)
        for k,(a,b) in zip(TEST,vals):rows.append(dict(art=tag,kern=kind,step=int(k),rel=a,max_U=b,ridge=params['ridge'],cpu_s=rt+coarse_cpu,wall_s=rw+coarse_wall,net_cpu_s=rt,fit_cpu_s=fit,additional_projection_cpu_s=shared,validation_re='900/1100',validation_steps='/'.join(map(str,VSTEPS))))
    savecsv(dst/'test.csv',rows)
