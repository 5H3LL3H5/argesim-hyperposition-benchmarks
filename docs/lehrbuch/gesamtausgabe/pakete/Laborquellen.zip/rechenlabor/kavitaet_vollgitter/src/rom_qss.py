from gemeinsam import *
from galerkin import Model
import argparse,signal,resource
def run(method,q,limit):
    model=Model(dict(np.load(DATA/'galerkin_basis.npz')),1000)
    ref=np.load(DATA/'galerkin_zeitreferenz.npz')['a']
    sub=DATA/'rom_qss';sub.mkdir(exist_ok=True)
    shift=q/2 if method=='cqss1' else 0.
    curr=np.zeros(model.r);obs=[];cnt=0;rhs=0;out=[];ts=[0.,*(TEST*DT)]
    totals={'cpu_s':0.,'wall_s':0.};outcpu=0.;outwall=0.
    def field_rhs(t,x):return model.rhs(t,np.asarray(x)-shift)
    def jac(t,x):return model.jac(t,np.asarray(x)-shift)
    def stop(*unused):raise TimeoutError('process CPU limit for seven successive output intervals')
    signal.signal(signal.SIGPROF,stop);stats={'last_native_time':0.}
    def track(a,xx,b,yy):
        stats['last_native_time']=max(stats['last_native_time'],b)
        return False
    options=dict(quantum=q,max_events=1500000)
    if method.startswith(('liqss','mliqss','eliqss','cheqss')):options['jacobian']=jac
    if method=='liqss-bdf':
        # Put the most rapidly damped modal coordinates in the classical partition.
        J=model.jac(0,np.zeros(model.r));indices=np.argsort(J.diagonal())[:max(1,model.r//3)]
        options.update(bdf_partition=tuple(int(i) for i in np.sort(indices)),rtol=3e-4,
                       atol=max(q*.03,1e-6),max_step=1.0,max_steps=500000)
    status='Ziel erreicht';detail=''
    try:
        for j,(lo,hi) in enumerate(zip(ts,ts[1:])):
            cpu=time.process_time();wall=time.perf_counter()
            signal.setitimer(signal.ITIMER_PROF,max(.01,limit-totals['cpu_s']))
            try:
                p=InitialValueProblem(field_rhs,lo,curr+shift,hi,autonomous=True,_stop_after_step=track)
                res=solve_ivp(p,method=method,options=options)
                if abs(res.final_time-hi)>1e-9:raise RuntimeError('incomplete interval')
                curr=np.array(res.final_state)-shift
                cnt+=res.stats.accepted_steps;rhs+=res.stats.rhs_evaluations
                out.append(curr.copy());v=model.field(curr)
            finally:
                signal.setitimer(signal.ITIMER_PROF,0.)
                totals['cpu_s']+=time.process_time()-cpu;totals['wall_s']+=time.perf_counter()-wall
            local=compare(v,model.field(ref[j]));sp=compare(v,model.c.field(ns(TEST[j])));lbm=compare(v,lb(TEST[j]))
            obs.append(dict(step=int(TEST[j]),t_star=hi,zeit_rel=local[0],zeit_max_U=local[1],ns_rel=sp[0],ns_max_U=sp[1],lbm_rel=lbm[0],lbm_max_U=lbm[1],**totals))
    except (TimeoutError,ArithmeticError,RuntimeError,ValueError) as exc:status=type(exc).__name__;detail=str(exc)
    tag=f'{method}_q{q:g}'
    if out:np.savez_compressed(sub/(tag+'.npz'),a=np.array(out),steps=TEST[:len(out)])
    row=dict(method=method,n=N,rank=model.r,quantum=q,cpu_limit=limit,completed_outputs=len(out),**totals,**stats,count_completed=cnt,rhs_completed=rhs,
                 status=status,detail=detail,observations=obs)
    (sub/(tag+'.json')).write_text(json.dumps(row,indent=2))
    print(method,q,status,len(out),totals['cpu_s'],flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('method',choices=METHODS);p.add_argument('--quantum',type=float,default=.003);p.add_argument('--limit',type=float,default=180)
    a=p.parse_args();run(a.method,a.quantum,a.limit)
