"""On 257² nodes, distinguish the exact discrete map from its continuous secant embedding."""
from gemeinsam import *
from populationen import MapODE
from scipy.integrate import solve_ivp as integrate
from kavitaet import lattice_fields
m=MapODE(N,RE);z=np.zeros(m.dim);ks=(1,2,4);ts=np.asarray(ks)*m.dt
target,_,_=lattice_fields(N,RE,ts,retain_populations=True)
rows=[]
sol=integrate(m.rhs,(0,ts[-1]),z,atol=2e-10,rtol=2e-8,t_eval=ts,method='DOP853')
assert sol.success and np.all(np.isfinite(sol.y))
idx=0
for k in range(1,max(ks)+1):
    z+=m.dt*m.rhs((k-1)*m.dt,z)
    if k not in ks:continue
    ref=target[idx];e=compare(m.field(z),ref);smooth=compare(m.field(sol.y[:,idx]),ref)
    rows.append(dict(k=k,t_star=k*m.dt,states=m.dim,euler_map_rel=e[0],euler_map_max_U=e[1],
                     continuous_rel=smooth[0],continuous_max_U=smooth[1],reference_rhs_calls=sol.nfev));idx+=1
assert max(r['euler_map_max_U'] for r in rows)<1e-12
savecsv(DATA/'populationsprobe.csv',rows);print(rows)
