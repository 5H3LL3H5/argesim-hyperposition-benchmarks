"""Independent full state attempts. Preserve at most the last two output states and first."""
from gemeinsam import *
from jacobi import mount
import resource,signal,argparse
def run(method,limit):
    dest=DATA/'voll_qss';dest.mkdir(exist_ok=True)
    c=Cavity(N,1000);q=.001;offset=q/2 if method=='cqss1' else 0
    stats={'last_time':0.,'accepted_output_steps':0,'rhs_actual':0};last=[None]
    class IVP(InitialValueProblem):
        def _record_step(self,times,states,t,state):
            stats['last_time']=float(t);stats['accepted_output_steps']+=1;last[0]=state
            if len(times)>=3: del times[1:-1];del states[1:-1]
            return super()._record_step(times,states,t,state)
    def f(t,x):
        stats['rhs_actual']+=1
        return c.rhs(t,np.asarray(x)-offset)
    def expire(*unused):raise TimeoutError('declared per-method process CPU budget reached')
    signal.signal(signal.SIGPROF,expire)
    # Same bound for all full-state runs, well above the actual memory footprint with lazy rows.
    rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    opts=dict(quantum=q,max_events=1200000)
    t_cpu=time.process_time();t_wall=time.perf_counter()
    signal.setitimer(signal.ITIMER_PROF,limit)
    try:
        if method.startswith(('liqss','mliqss','eliqss','cheqss')):opts['jacobian']=mount(c)
        if method=='liqss-bdf': opts.update(bdf_partition=tuple(range(c.dim-c.m,c.dim)),rtol=1e-3,atol=5e-5,max_step=.5,max_steps=1000000)
        res=solve_ivp(IVP(f,0.,(offset,)*c.dim,DT*END,autonomous=True),method=method,options=opts)
        status='Ziel erreicht';detail='';stats['events_or_macrosteps']=res.stats.accepted_steps
        last[0]=res.final_state
    except (RuntimeError,TimeoutError,MemoryError,ValueError,ArithmeticError) as exc:
        status=type(exc).__name__;detail=str(exc)
    finally:signal.setitimer(signal.ITIMER_PROF,0.)
    wall=time.perf_counter()-t_wall;cpu=time.process_time()-t_cpu
    if last[0] is not None:
        np.savez_compressed(dest/(method+'.npz'),z=np.asarray(last[0])-offset,t=stats['last_time'])
    log=dict(method=method,n=N,states=c.dim,quantum=q,cpu_limit=limit,wall_s=wall,cpu_s=cpu,peak_RSS_KiB=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
             target_time=DT*END,**stats,status=status,detail=detail)
    (dest/(method+'.json')).write_text(json.dumps(log,indent=2))
    print(method,status,stats['last_time'],cpu,flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('method',choices=METHODS);p.add_argument('--limit',type=int,default=240)
    a=p.parse_args();run(a.method,a.limit)
