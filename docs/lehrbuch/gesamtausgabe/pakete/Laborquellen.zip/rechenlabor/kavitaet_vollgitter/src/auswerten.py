"""Regenerate all scored rows from fields and run logs. Relative errors are ratios."""
from gemeinsam import *
from scipy.integrate import solve_ivp as scipy_ivp
import argparse, hashlib
from collections import defaultdict
GHIA=dict(u=([.9766,.8516,.6172,.5,.2813,.1016],[.65928,.33304,.05702,-.06080,-.27805,-.29730]),
          v=([.9688,.9063,.8047,.5,.2344,.0938],[-.21388,-.51500,-.31966,.02526,.32235,.32627]))
def rows_at(d):
    return {int(r['step']):r for r in readcsv(d/'zeiten.csv')}
def velocity_z(d,k,c):
    return c.field(np.fromfile(d/f'z_{k}.bin',dtype='f8'))
def diagnostic(v):
    a=np.vstack((v[0],v[1:-1,0],v[1:-1,-1]))
    div=(v[1:-1,2:,0]-v[1:-1,:-2,0]+v[2:,1:-1,1]-v[:-2,1:-1,1])*(N-1)/2
    return dict(wall_U=float(np.linalg.norm(a,axis=1).max()),div_rms_UL=float(np.sqrt(np.mean(div**2))))
def scores(v,ref,prefix):
    r,m=compare(v,ref)
    return {prefix+'_rel':r,prefix+'_max_U':m}
def ghia(v,method):
    coords=np.linspace(0,1,N);rows=[]
    for part,(loc,ref) in GHIA.items():
        val=np.interp(loc,coords,v[:,N//2,0] if part=='u' else v[N//2,:,1])
        for xi,f,g in zip(loc,val,ref):rows.append(dict(method=method,component=part,coordinate=xi,measured=f,ghia=g,error_U=f-g))
    return rows
def reference():
    c=Cavity(N,RE);out=[];profiles=[];extras={};vel=[];dens=[]
    runs={'D2Q9 seriell':RAW/'re1000','D2Q9 OpenMP-4':RAW/'pruef4','NS AB2 (2 Takte)':RAW/'ns_1000_2','NS AB2 (4 Takte)':RAW/'ns_1000_4'}
    for order in (1,2):
        for q in (.001,.0002):runs[f'Gruppen-QSS{order} q={q:g}']=RAW/f'gruppe_{order}_{q}'
    for name,d in runs.items():
        tm=rows_at(d)
        assert END in tm,(name,tm.keys())
        for k in TEST:
            ref=lb(k);space=c.field(ns(k));rr=tm[k]
            if name.startswith('D2Q9'):
                a=np.fromfile(d/f'feld_{k}.bin',dtype='f8').reshape(3,N,N)
                v=a[1:].transpose(1,2,0).copy();v[-1]=[1,0]
                if name=='D2Q9 seriell':vel.append(v);dens.append(a[0])
            else:v=velocity_z(d,k,c)
            row=dict(verfahren=name,step=k,t_star=k*DT,cpu_s=rr['cpu_s'],wall_s=rr['wall_s'],**scores(v,ref,'lbm'),**scores(v,space,'ns'),**diagnostic(v))
            for i in ('segments','max_state_defect','mean_rho','min_rho','max_rho'):
                if i in rr:row[i]=rr[i]
            out.append(row)
            if k==END:profiles+=ghia(v,name)
    for k in K:
        a=np.fromfile(RAW/'re1000'/f'feld_{k}.bin',dtype='f8').reshape(3,-1)
        b=np.fromfile(RAW/'pruef4'/f'feld_{k}.bin',dtype='f8').reshape(3,-1)
        extras[str(k)]=np.max(abs(a-b),axis=1).tolist()
    d=lb(END)-lb(340000);base=lb(END)[1:-1,1:-1]
    info=dict(serial_parallel_raw_max=np.max(list(extras.values()),axis=0).tolist(),serial_parallel_steps=len(extras),
              last_10000_relative=float(np.linalg.norm(d[1:-1,1:-1])/np.linalg.norm(base)),
              ghia_note='Sechs je Komponente explizit hinterlegte Koordinaten aus Tabellen I/II, linear interpoliert.',
              n=N,interior=(N-2)**2,re=RE,umax=U)
    for name in runs:
        info[name]={p:float(np.sqrt(np.mean([r['error_U']**2 for r in profiles if r['method']==name and r['component']==p]))) for p in GHIA}
    (DATA/'referenz.json').write_text(json.dumps(info,indent=2))
    savecsv(DATA/'klassisch_gruppen.csv',out);savecsv(DATA/'ghia.csv',profiles)
    np.savez_compressed(DATA/'testreferenzen.npz',steps=TEST,lbm=np.stack(vel),rho=np.stack(dens),ns_z=np.stack([ns(k) for k in TEST]))
    for name,d in runs.items():
        if name.startswith('Gruppen'):
            np.savez_compressed(DATA/(d.name+'.npz'),steps=TEST,z=np.stack([np.fromfile(d/f'z_{k}.bin',dtype='f8') for k in TEST]))
def partial():
    run=[json.loads((DATA/'voll_qss'/(m+'.json')).read_text()) for m in METHODS];c=Cavity(N,RE)
    times=sorted(set(r['last_time'] for r in run if r['last_time']>0))
    ref={}
    if times:
        sol=scipy_ivp(c.rhs,(0,max(times)),np.zeros(c.dim),t_eval=times,method='DOP853',atol=3e-12,rtol=1e-10)
        assert sol.success
        ref={t:c.field(z) for t,z in zip(sol.t,sol.y.T)}
    result=[]
    for r in run:
        row={k:v for k,v in r.items() if k!='observations'};t=r['last_time']
        if t>0:
            a=np.load(DATA/'voll_qss'/(r['method']+'.npz'));assert a['t']==t
            row.update(scores(c.field(a['z']),ref[t],'partial_ns'))
        result.append(row)
    savecsv(DATA/'voll_komponenten.csv',result)
def maxs(rr,col):return max(float(r[col]) for r in rr)
def combine():
    records=[];ref=readcsv(DATA/'klassisch_gruppen.csv')
    def add(family,name,status,n,tc,tw,vals=None,off=None,note='',tlast=None,etime=None,emax=None):
        e,a,z,b=(vals if vals is not None else ('',)*4)
        verdict='' if vals is None or n!=7 else ('ja' if e<=.01 and a<=.01 else 'nein')
        records.append(dict(familie=family,verfahren=name,status=status,netz=N,zeitpunkte=n,t_letzte=tlast,
             cpu_s=tc,wand_s=tw,lbm_rel_max=e,lbm_lokal_max_U=a,ns_rel_max=z,ns_lokal_max_U=b,zeit_rel_max=etime,zeit_lokal_max_U=emax,
             budget_d2q9=verdict,offline_cpu_s=off,amortisation_anfragen='',hinweis=note))
        return records[-1]
    grouped=defaultdict(list)
    for r in ref:grouped[r['verfahren']].append(r)
    for name,rr in grouped.items():
        r=rr[-1]; add('QSS Gruppe' if name.startswith('Gruppen') else 'Referenz',name,'Ziel erreicht',7,float(r['cpu_s']),float(r['wall_s']),
        tuple(maxs(rr,x) for x in ('lbm_rel','lbm_max_U','ns_rel','ns_max_U')),note='gleicher Raumoperator für NS und Gruppen-QSS',tlast=DT*END)
    for r in readcsv(DATA/'voll_komponenten.csv'):
        add('QSS Komponente',r['method'],r['status'],0,float(r['cpu_s']),float(r['wall_s']),note=r['detail'],tlast=float(r['last_time']),
            etime=r.get('partial_ns_rel'),emax=r.get('partial_ns_max_U'))
    gal=json.loads((DATA/'galerkin_modell.json').read_text())
    rom_off=gal['basis_cpu_s']+sum(float(rows_at(RAW/f'ns_{re}_2')[END]['cpu_s']) for re in (850,1150,950))
    for p in sorted((DATA/'rom_qss').glob('*.json')):
        r=json.loads(p.read_text());rr=r['observations'];n=len(rr)
        vals=tuple(maxs(rr,x) for x in ('lbm_rel','lbm_max_U','ns_rel','ns_max_U')) if n else None
        add('QSS POD',r['method']+' q='+format(r['quantum'],'g'),r['status'],n,r['cpu_s'],r['wall_s'],vals,rom_off,
        r['detail'] or f"Galerkin-Rang {r['rank']}",r['last_native_time'],maxs(rr,'zeit_rel') if n else None,maxs(rr,'zeit_max_U') if n else None)
    from operatoren import TRAIN,VAL
    def training(grid,seq):
        return sum(float(readcsv(RAW/(('' if grid==N else 'g65_')+'re'+str(re))/'zeiten.csv')[-1]['cpu_s']) for re in seq)
    costs={};grouped=defaultdict(list);op=DATA/'operatoren'
    for r in readcsv(op/'test.csv'):grouped[(r['art'],r['kern'])].append(r)
    cpu_lbm=float(rows_at(RAW/'re1000')[END]['cpu_s'])
    for (tag,kind),rr in grouped.items():
        r=rr[-1];tc=float(r['cpu_s']);tw=float(r['wall_s']);off=0.
        if tag in ('direkt','korrektur'):
            setup=json.loads((op/f'aufbau_{tag}.json').read_text());fit=next(x for x in readcsv(op/f'fit_{tag}.csv') if x['kern']==kind)
            off=training(N,TRAIN+VAL)+setup['shared_pod_cpu_s']+float(fit['fit_cpu_s'])
            if tag=='korrektur':off+=training(65,TRAIN+VAL)
        if tag=='interpolation':off=training(N,(950,1050) if kind=='linear' else (850,950,1050))
        pair=(maxs(rr,'rel'),maxs(rr,'max_U'))
        rec=add('Operator '+tag if tag in ('direkt','korrektur') else tag,kind,'Ziel erreicht',7,tc,tw,(*pair,'',''),off,
                '7 volle Felder, bei Korrektur einschließlich eigenem 65²-Physiklauf',DT*END)
        if rec['budget_d2q9']=='ja' and tc<cpu_lbm:rec['amortisation_anfragen']=int(np.floor(off/(cpu_lbm-tc))+1)
        costs[f'{tag}/{kind}']=off
    equal=readcsv(DATA/'interpolation_zusatzzeiten.csv');x=equal[-1];tc=float(x['cpu_s'])
    rr=add('Interpolation Zusatzzeiten','linear_zeitgleich','Ziel erreicht',7,tc,float(x['wall_s']),
           (maxs(equal,'rel'),maxs(equal,'max_U'),'',''),training(N,(950,1050)),'Zusatzinformation: zwei Trainings-Re auch an drei verborgenen Zeiten ausgewertet',DT*END)
    if rr['budget_d2q9']=='ja' and tc<cpu_lbm:rr['amortisation_anfragen']=int(np.floor(rr['offline_cpu_s']/(cpu_lbm-tc))+1)
    lift_off=sum(float(rows_at(RAW/f'ns_{re}_2')[END]['cpu_s']) for re in (850,1150))+float(np.load(DATA/'qss_korrektur/modell.npz')['cpu_s'])
    for m in METHODS:
        r=json.loads((DATA/'qss_korrektur'/(m+'.json')).read_text());obs=r['observations'];n=len(obs)
        v=tuple(maxs(obs,x) for x in ('lbm_rel','lbm_max_U','ns_rel','ns_max_U')) if n else None
        add('QSS Korrektur',m,r['status'],n,r['cpu_s'],r['wall_s'],v,lift_off,r['detail'] or '1 glatte räumliche Korrekturmode und 1 Phasenzustand über zeitgleicher NS-Interpolation',r['last_time'],maxs(obs,'zeit_rel') if n else None,maxs(obs,'zeit_max_U') if n else None)
    for path in sorted((DATA/'qss_korrektur').glob('cqss1_offset*.json')):
        r=json.loads(path.read_text());obs=r['observations'];n=len(obs)
        vals=tuple(maxs(obs,x) for x in ('lbm_rel','lbm_max_U','ns_rel','ns_max_U')) if n else None
        add('QSS Korrektur Zelllage','cqss1 offset='+str(r['cell_shift']),r['status'],n,r['cpu_s'],r['wall_s'],vals,lift_off,r['detail'] or 'Gegenprobe mit anderer Gitterlage',r['last_time'],maxs(obs,'zeit_rel') if n else None,maxs(obs,'zeit_max_U') if n else None)
    for mode in ('direkt','korrektur'):
        obs=readcsv(DATA/'raum_fourier'/(mode+'_test.csv'));setup=json.loads((DATA/'raum_fourier'/(mode+'_fit.json')).read_text());o=obs[-1]
        expense=training(N,TRAIN+VAL)+setup['cpu_s']+(training(65,TRAIN+VAL) if mode=='korrektur' else 0.)
        rec=add('2D-Fourieroperator '+mode,'2D-Fourierschicht','Ziel erreicht',7,float(o['cpu_s']),float(o['wall_s']),(maxs(obs,'rel'),maxs(obs,'max_U'),'',''),expense,'gelernte komplexe 2D-Faltung, 9 nichtlineare räumliche Kanäle, 16 Moden je Achsenrichtung',DT*END)
        if rec['budget_d2q9']=='ja' and rec['cpu_s']<cpu_lbm:rec['amortisation_anfragen']=int(np.floor(expense/(cpu_lbm-rec['cpu_s']))+1)
    time_rows=defaultdict(list)
    for row in readcsv(DATA/'zeitblind/test.csv'):time_rows[(row['art'],row['kern'])].append(row)
    for (mode,kind),obs in time_rows.items():
        r=obs[-1];setup=json.loads((DATA/'operatoren'/f'aufbau_{mode}.json').read_text())
        data_cost=training(N,TRAIN+VAL)+(training(65,TRAIN+VAL) if mode=='korrektur' else 0.)
        off=data_cost+setup['shared_pod_cpu_s']+float(r['additional_projection_cpu_s'])+float(r['fit_cpu_s'])
        add('Zeitblind '+mode,kind,'Ziel erreicht',7,float(r['cpu_s']),float(r['wall_s']),
          (maxs(obs,'rel'),maxs(obs,'max_U'),'',''),off,'Drei Testzeiten aus Training und Hyperparameterwahl ausgeschlossen; vorbereitete POD-Basis wie Hauptvergleich.',DT*END)
    savecsv(DATA/'methodenmatrix_voll.csv',records)
    (DATA/'kosten.json').write_text(json.dumps(costs,indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=['referenz','teil','matrix','alle']);a=p.parse_args()
    if a.phase in ('referenz','alle'):reference()
    if a.phase in ('teil','alle'):partial()
    if a.phase in ('matrix','alle'):combine()
