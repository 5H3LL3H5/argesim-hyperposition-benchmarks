"""A separate information contract: two external reference runs also save the three hidden times."""
from gemeinsam import *
from operatoren import error_records
cached={re:np.stack([lb(k,re) for k in TEST]) for re in (950,1050)}
cs=[];ws=[]
for i in range(6):
    t=time.process_time();w=time.perf_counter();v=.5*(cached[950]+cached[1050])
    if i:cs.append(time.process_time()-t);ws.append(time.perf_counter()-w)
savecsv(DATA/'interpolation_zusatzzeiten.csv',error_records('Zusatzzeiten','linear_zeitgleich',v,dict(cpu_s=np.median(cs),wall_s=np.median(ws),clock_repeats=5,net_cpu_s=0),True))
