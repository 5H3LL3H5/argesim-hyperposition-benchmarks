"""A separate low-dimensional physical correction to two stored NS trajectories.
Every original QSS solver evolves a smooth correction and a phase coordinate per interval.
The target field at Re=1000 is used only for scoring.
"""
from gemeinsam import *
from scipy.integrate import solve_ivp as ode
import argparse,signal
DIR=DATA/'qss_korrektur';DIR.mkdir(exist_ok=True)
TRAIN=(850,1150);CLOCK=.05;Q=.001
def fit():
    c=Cavity(N,RE);h=c.h
    x=np.linspace(0,1,N);p=(np.outer((x*(1-x))**2,(x*(1-x))**2))
    phi=(-(p[2:,1:-1]+p[:-2,1:-1]+p[1:-1,2:]+p[1:-1,:-2]-4*p[1:-1,1:-1])/h).ravel()
    phi=phi/np.max(np.linalg.norm(c.field(phi)[1:-1,1:-1],axis=-1))
    cov=phi@phi
    knots=np.r_[0,K];prev=np.zeros(c.dim);starts=[prev];coefs=[];tic=time.process_time()
    for left,right in zip(knots,knots[1:]):
        now=(ns(right,TRAIN[0])+ns(right,TRAIN[1]))*.5;delta=now-prev;dt=(right-left)*DT
        def scalar(s,a):return (phi@(dt*c.rhs(0,prev+s*delta+a*phi)-delta))/cov
        y0=scalar(0,0);ym=scalar(.5,0);ye=scalar(1,0)
        dd=2*(ye+y0-2*ym);d=ye-y0-dd
        b0=(scalar(0,1)-scalar(0,-1))*.5;b1=(scalar(1,1)-scalar(1,-1))*.5-b0
        gamma=(scalar(0,1)+scalar(0,-1))*.5-y0
        v=np.array([y0,d,dd,b0,b1,gamma])
        check=abs(scalar(.37,-.021)-ev(v,.37,-.021));assert check<1e-10,check
        starts.append(now);coefs.append(v);prev=now
    np.savez_compressed(DIR/'modell.npz',knots=knots,coef=coefs,phi=phi,bases=np.array(starts)[np.searchsorted(knots,TEST)],cpu_s=time.process_time()-tic)
def ev(b,s,a):return b[0]+s*(b[1]+s*b[2])+a*(b[3]+s*b[4]+a*b[5])
def run(method,origin=.5):
    f=np.load(DIR/'modell.npz');knots=f['knots'];bb=f['coef'];phi=f['phi'];bases=f['bases'];c=Cavity(N,RE)
    goal=0.;a=0.;shift=Q*origin if method=='cqss1' else 0.;obs=[];states=[];cpu_total=wall_total=0.;last_t=0.;status='Ziel erreicht';detail='';active=0.
    def stop(*args):raise TimeoutError('60 CPU seconds for correction')
    signal.signal(signal.SIGPROF,stop)
    def track(ta,xa,tb,xb):
        nonlocal active
        active=max(active,(lo+(hi-lo)*tb)*DT);return False
    try:
        for block,(lo,hi,co) in enumerate(zip(knots,knots[1:],bb)):
            goal=ode(lambda t,x:ev(co,t,x[0]),(0.,1.),[goal],method='DOP853',rtol=3e-11,atol=2e-13).y[0,-1]
            def rhs(t,x):
                phase=(x[0]-shift)/CLOCK;am=x[1]-shift
                return (CLOCK,ev(co,phase,am))
            def jac(t,x):
                s=(x[0]-shift)/CLOCK;a=x[1]-shift
                return ((0.,0.),((co[1]+2*s*co[2]+a*co[4])/CLOCK,co[3]+s*co[4]+2*a*co[5]))
            opts={'quantum':Q,'max_events':150000}
            if method.startswith(('liqss','mliqss','eliqss','cheqss')):opts['jacobian']=jac
            if method=='liqss-bdf':opts.update(bdf_partition=(1,),rtol=1e-4,atol=2e-6,max_step=.15,max_steps=10000)
            t=time.process_time();w=time.perf_counter();signal.setitimer(signal.ITIMER_PROF,max(.01,60-cpu_total))
            try:
                sol=solve_ivp(InitialValueProblem(rhs,0.,(shift,a+shift),1.,autonomous=True,_stop_after_step=track),method=method,options=opts)
                assert abs(sol.final_time-1)<1e-9;a=sol.final_state[1]-shift;last_t=hi*DT
                if hi in TEST:
                    j=len(obs);z=bases[j]+a*phi;v=c.field(z);states.append(a)
            finally:
                signal.setitimer(signal.ITIMER_PROF,0);cpu_total+=time.process_time()-t;wall_total+=time.perf_counter()-w
            if hi in TEST:
                b0=c.field(bases[j]);qt=compare(v,c.field(bases[j]+goal*phi));qn=compare(v,c.field(ns(hi)));ql=compare(v,lb(hi));qb=compare(b0,c.field(ns(hi)))
                obs.append(dict(step=int(hi),zeit_rel=qt[0],zeit_max_U=qt[1],ns_rel=qn[0],ns_max_U=qn[1],lbm_rel=ql[0],lbm_max_U=ql[1],grund_rel=qb[0],grund_max_U=qb[1],a=float(a),reference_a=goal))
    except (ArithmeticError,ValueError,RuntimeError,TimeoutError) as ex:status=type(ex).__name__;detail=str(ex)
    record=dict(method=method,cell_shift=origin if method=='cqss1' else 0,status=status,detail=detail,last_time=max(last_t,active),cpu_s=cpu_total,wall_s=wall_total,observations=obs)
    tag=method if origin==.5 else f'{method}_offset{origin:g}'
    (DIR/f'{tag}.json').write_text(json.dumps(record,indent=2));print(method,len(obs),status,flush=True)
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['aufbau',*METHODS]);ap.add_argument('--offset',type=float,default=.5);a=ap.parse_args()
    if a.action=='aufbau':fit()
    else:run(a.action,a.offset)
