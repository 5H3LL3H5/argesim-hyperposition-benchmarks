"""Full-grid projected vorticity transport. The target Re=1000 is held out of fitting and rank selection."""
from gemeinsam import *
from scipy.integrate import solve_ivp as ode
import hashlib
FIT_RE=(850,1150);CHECK_RE=950
def reduced_rom(modes,scales,r):
    c=Cavity(N,1.);V=modes[:,:r];S=scales[:r]
    zero=c.quantities(np.zeros(c.dim))
    vals=[tuple(a-b for a,b in zip(c.quantities(V[:,k]*S[k]),zero)) for k in range(r)]
    diff,u,v,dx,dy=[np.ascontiguousarray(np.array(k)) for k in zip(*vals)]
    project=V.T/S[:,None]
    const=project@zero[0];linD=project@diff.T
    linC=-(project@(u*zero[3]+v*zero[4]).T)
    H=np.empty((r,r,r))
    for i in range(r):H[:,i,:]=-project@(u[i]*dx+v[i]*dy).T
    return dict(V=V,S=S,const=const,linD=linD,linC=linC,H=H)
class Model:
    def __init__(self,data,re):
        self.V=data['V'];self.s=data['S'];self.r=len(self.s);self.re=re
        self.b=data['const']/re;self.a=data['linD']/re+data['linC']
        self.h=data['H'].reshape(self.r,-1)
        self.sym=data['H']+data['H'].transpose(0,2,1);self.c=Cavity(N,re)
    def rhs(self,t,x):
        x=np.asarray(x);return self.b+self.a@x+self.h@np.outer(x,x).ravel()
    def jac(self,t,x):return self.a+self.sym@x
    def field(self,x):return self.c.field(self.V@(self.s*np.asarray(x)))
    def solution(self):
        s=ode(self.rhs,(0,DT*END),np.zeros(self.r),method='Radau',jac=self.jac,t_eval=TEST*DT,rtol=2e-9,atol=1e-11)
        if not s.success or len(s.t)!=len(TEST):raise RuntimeError(s.message)
        return s.y.T
def train():
    tic=time.process_time();c=Cavity(N,CHECK_RE)
    raw=np.stack([ns(k,re) for re in FIT_RE for k in K])
    scaled=raw/np.linalg.norm(raw,axis=1)[:,None]
    g=scaled@scaled.T;w,q=np.linalg.eigh(g);order=np.argsort(w)[::-1][:24]
    V=(scaled.T@q[:,order])/np.sqrt(np.maximum(w[order],1e-30))[None,:]
    V,_=np.linalg.qr(V)
    scales=np.max(abs(raw@V),axis=0);records=[];available={}
    for r in (6,10,14,18,24):
        data=reduced_rom(V,scales,r);mo=Model(data,CHECK_RE);xx=mo.solution()
        scores=[compare(mo.field(x),c.field(ns(k,CHECK_RE))) for k,x in zip(TEST,xx)]
        rel,absmax=np.max(scores,axis=0);score=max(rel/.01,absmax/.01)
        records.append(dict(rank=r,validation_re=CHECK_RE,worst_rel=rel,worst_max_U=absmax,score=score));available[r]=data
    # Choose the least expensive dimension passing two validation budgets, otherwise smallest worst budget factor.
    selected=next((rec for rec in records if rec['score']<=1),min(records,key=lambda a:a['score']))
    data=available[selected['rank']];np.savez_compressed(DATA/'galerkin_basis.npz',**data)
    savecsv(DATA/'galerkin_validierung.csv',records)
    m=Model(data,1000);rng=np.random.default_rng(917);x=rng.normal(0,.15,m.r);y=rng.normal(size=m.r)
    exact=(m.V.T@Cavity(N,1000).rhs(0,m.V@(m.s*x)))/m.s
    lhs=m.rhs(0,x);err=float(np.max(abs(exact-lhs)))
    fd=(m.rhs(0,x+1e-6*y)-m.rhs(0,x-1e-6*y))/(2e-6)
    assert err<1e-7
    meta=dict(train_re=FIT_RE,validation_re=CHECK_RE,target_re=1000,rank=m.r,
              projection_check_abs=err,jacobian_check_rel=float(np.linalg.norm(fd-m.jac(0,x)@y)/np.linalg.norm(fd)),
              basis_cpu_s=time.process_time()-tic,weights_sha256=hashlib.sha256((DATA/'galerkin_basis.npz').read_bytes()).hexdigest())
    (DATA/'galerkin_modell.json').write_text(json.dumps(meta,indent=2))
def test():
    m=Model(np.load(DATA/'galerkin_basis.npz'),1000);tic=time.process_time();s=m.solution();wall=time.process_time()-tic
    rows=[]
    for k,x in zip(TEST,s):
        spatial=m.c.field(ns(k));v=m.field(x);a,b=compare(v,spatial);d,e=compare(v,lb(k))
        rows.append(dict(step=k,t_star=k*DT,relative_ns=a,max_ns_U=b,relative_lbm=d,max_lbm_U=e))
    savecsv(DATA/'galerkin_referenz.csv',rows);np.savez_compressed(DATA/'galerkin_zeitreferenz.npz',steps=TEST,a=s,cpu_s=wall)
if __name__=='__main__':train();test()
