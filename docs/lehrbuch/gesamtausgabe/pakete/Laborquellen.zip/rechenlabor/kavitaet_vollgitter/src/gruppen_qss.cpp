// One vector-valued QSS quantizer for every vorticity node together.
// F is quadratic. Along an affine q the integral of F(q) is exactly cubic.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <vector>
extern "C"{using plan=void*;plan fftw_plan_r2r_2d(int,int,double*,double*,int,int,unsigned);void fftw_execute(const plan);void fftw_destroy_plan(plan);}
namespace fs=std::filesystem;
using V=std::vector<double>;
using W=std::chrono::steady_clock;
struct Grid{
    int n,m;double re,ih,h;V spec,eigen;plan fft;
    Grid(int size,double reynolds):n(size),m(n-2),re(reynolds),ih(n-1),h(1/ih),spec(m*m),eigen(m*m){
        fft=fftw_plan_r2r_2d(m,m,spec.data(),spec.data(),7,7,64U);
        if(!fft)throw std::runtime_error("DST plan failed");
        for(int i=0;i<m;++i)for(int j=0;j<m;++j){
            double a=std::sin((i+1)*std::acos(-1.)/(2*ih)),b=std::sin((j+1)*std::acos(-1.)/(2*ih));
            eigen[i*m+j]=1./(4*ih*ih*h*(4*ih*ih*(a*a+b*b)));}
    }
    ~Grid(){fftw_destroy_plan(fft);}
    void geometry(V &z,V &p,double lid){
        for(int y=1;y<n-1;++y)std::copy_n(z.data()+y*n+1,m,spec.data()+(y-1)*m);
        fftw_execute(fft);for(int i=0;i<m*m;++i)spec[i]*=eigen[i];fftw_execute(fft);
        for(int y=1;y<n-1;++y)std::copy_n(spec.data()+(y-1)*m,m,p.data()+y*n+1);
        for(int a=1;a<n-1;++a){z[a]=-2*ih*p[n+a];z[(n-1)*n+a]=-2*ih*p[(n-2)*n+a]-2*lid;
            z[a*n]=-2*ih*p[a*n+1];z[a*n+n-1]=-2*ih*p[a*n+n-2];}
    }
    double diffus(const V& z,int i)const{return (z[i+n]+z[i-n]+z[i+1]+z[i-1]-4*z[i])*(ih*ih/re);}
    double dx(const V& z,int i)const{return (z[i+1]-z[i-1])*(.5*ih);}
    double dy(const V& z,int i)const{return (z[i+n]-z[i-n])*(.5*ih);}
};
inline double defect(double a,double b,double s){return s*s*(.5*a+(s/3)*b);}
inline double first_hit(double a,double b,double q,double end){
    if(end*end*(.5*std::abs(a)+end*std::abs(b)/3)<q)return end;
    double cut=(b==0?0:-a/b),lo=0,hi=end;
    if(cut>0&&cut<end){
        if(std::abs(defect(a,b,cut))>=q)hi=cut;
        else {if(std::abs(defect(a,b,end))<q)return end;lo=cut;}
    } else if(std::abs(defect(a,b,end))<q)return end;
    for(int k=0;k<43;++k){double s=.5*(lo+hi);if(std::abs(defect(a,b,s))>=q)hi=s;else lo=s;}
    return hi;
}
int main(int argc,char**argv){
    if(argc!=7){std::cerr<<"N Re order quantum output checkpoint-file\n";return 2;}
    int n=std::stoi(argv[1]),ord=std::stoi(argv[3]);double re=std::stod(argv[2]),q=std::stod(argv[4]);
    if((ord!=1&&ord!=2)||q<=0||n<5)return 2;
    fs::path out=argv[5];fs::create_directories(out);std::ifstream file(argv[6]);std::vector<int> marks;
    for(int k;file>>k;)marks.push_back(k);
    if(marks.empty())return 2;
    Grid g(n,re);V z(n*n),p(n*n),f(n*n),pf(n*n),a(n*n),b(n*n);
    auto w0=W::now();auto c0=std::clock();
    std::ofstream log(out/"zeiten.csv");log<<"step,t_star,wall_s,cpu_s,segments,quantum,last_dt,max_state_defect\n"<<std::setprecision(17);
    double t=0,T=marks.back()*.1/(n-1),global_defect=0,io_wall=0,io_cpu=0;size_t target=0;long count=0;
    while(t<T){
        g.geometry(z,p,1);double maxf=0;
        for(int y=1;y<n-1;++y)for(int x=1;x<n-1;++x){int i=y*n+x;
            f[i]=g.diffus(z,i)-g.dy(p,i)*g.dx(z,i)+g.dx(p,i)*g.dy(z,i);maxf=std::max(maxf,std::abs(f[i]));}
        double s=T-t;
        if(ord==1){if(maxf>0)s=std::min(s,q/maxf);}
        else{
            g.geometry(f,pf,0);int peak=0;double largest=0;
            for(int y=1;y<n-1;++y)for(int x=1;x<n-1;++x){int i=y*n+x;
                double u=g.dy(p,i),v=-g.dx(p,i),du=g.dy(pf,i),dv=-g.dx(pf,i);
                a[i]=g.diffus(f,i)-du*g.dx(z,i)-dv*g.dy(z,i)-u*g.dx(f,i)-v*g.dy(f,i);
                b[i]=-du*g.dx(f,i)-dv*g.dy(f,i);
                if(std::abs(a[i])>largest){largest=std::abs(a[i]);peak=i;}}
            s=first_hit(a[peak],b[peak],q,s);
            for(int y=1;y<n-1;++y)for(int x=1;x<n-1;++x){int i=y*n+x;s=first_hit(a[i],b[i],q,s);}
        }
        if(!(s>0)||!std::isfinite(s)||t+s==t)return 3;
        ++count;
        while(target<marks.size()&&marks[target]*.1/(n-1)<=t+s+1e-13){
            double obs=marks[target]*.1/(n-1),d=std::clamp(obs-t,0.,s);
            double wc=std::chrono::duration<double>(W::now()-w0).count()-io_wall;
            double cc=double(std::clock()-c0)/CLOCKS_PER_SEC-io_cpu;
            auto iw=W::now();auto ic=std::clock();V zz(g.m*g.m);
            for(int y=1;y<n-1;++y)for(int x=1;x<n-1;++x){int i=y*n+x;
                zz[(y-1)*g.m+x-1]=z[i]+d*f[i]+(ord==2?defect(a[i],b[i],d):0.);}
            std::ofstream o(out/("z_"+std::to_string(marks[target])+".bin"),std::ios::binary);
            o.write(reinterpret_cast<char*>(zz.data()),zz.size()*sizeof(double));o.close();if(!o)return 4;
            log<<marks[target]<<','<<obs<<','<<wc<<','<<cc<<','<<count<<','<<q<<','<<s<<','<<global_defect<<'\n'<<std::flush;
            io_wall+=std::chrono::duration<double>(W::now()-iw).count();io_cpu+=double(std::clock()-ic)/CLOCKS_PER_SEC;++target;
        }
        double local=0;
        for(int y=1;y<n-1;++y)for(int x=1;x<n-1;++x){int i=y*n+x;double e=(ord==2?defect(a[i],b[i],s):s*f[i]);
            local=std::max(local,std::abs(e));z[i]+=s*f[i]+(ord==2?e:0.);}
        if(!std::isfinite(local)||local>q*(1+1e-7)){std::cerr<<"quantum violation "<<t<<" "<<local<<"\n";return 5;}
        global_defect=std::max(global_defect,local);t+=s;
    }
    return target==marks.size()?0:6;
}
