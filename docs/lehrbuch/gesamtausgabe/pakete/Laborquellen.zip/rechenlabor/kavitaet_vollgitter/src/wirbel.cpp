// Centred vorticity transport with Thom wall data, discrete Poisson via FFTW DST-I.
// Single-threaded Adams-Bashforth 2; first step explicit Euler, zero initial state.
#include <algorithm>
#include <chrono>
#include <cmath>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <vector>
extern "C" {using plan=void*;plan fftw_plan_r2r_2d(int,int,double*,double*,int,int,unsigned);void fftw_execute(const plan);void fftw_destroy_plan(plan);}
namespace fs=std::filesystem;
int main(int argc,char**argv){
    if(argc!=6){std::cerr<<"N Re lattice_ticks_per_step out steps\n";return 2;}
    int n=std::stoi(argv[1]),m=n-2,stride=std::stoi(argv[3]);
    double re=std::stod(argv[2]),ih=n-1,h=1/ih,dt=stride*.1/ih;
    if(n<5||stride<1||re<=0)return 2;
    fs::path out=argv[4];fs::create_directories(out);std::ifstream file(argv[5]);std::vector<int> checkpoints;
    for(int t;file>>t;){if(t%stride){std::cerr<<"unaligned checkpoint "<<t<<"\n";return 2;}checkpoints.push_back(t);}
    if(checkpoints.empty())return 2;
    std::vector<double> z(n*n),p(n*n),spec(m*m),eigen(m*m),old(m*m),current(m*m);
    constexpr int dst1=7; auto transform=fftw_plan_r2r_2d(m,m,spec.data(),spec.data(),dst1,dst1,64U);
    if(!transform)return 2;
    const double pi=std::acos(-1.),normal=4*ih*ih;
    for(int i=0;i<m;++i)for(int j=0;j<m;++j){
        double a=std::sin((i+1)*pi/(2*ih)),b=std::sin((j+1)*pi/(2*ih));
        eigen[i*m+j]=1./(normal*h*(4*ih*ih*(a*a+b*b)));
    }
    auto poisson=[&](){
        for(int y=1;y<n-1;++y)std::copy_n(z.data()+y*n+1,m,spec.data()+(y-1)*m);
        fftw_execute(transform);for(int k=0;k<m*m;++k)spec[k]*=eigen[k];fftw_execute(transform);
        for(int y=1;y<n-1;++y)std::copy_n(spec.data()+(y-1)*m,m,p.data()+y*n+1);
    };
    auto rhs=[&](){
        for(int a=1;a<n-1;++a){
            z[a]=-2*ih*p[n+a];z[(n-1)*n+a]=-2*ih*p[(n-2)*n+a]-2;
            z[a*n]=-2*ih*p[a*n+1];z[a*n+n-1]=-2*ih*p[a*n+n-2];
        }
        for(int y=1;y<n-1;++y)for(int x=1;x<n-1;++x){int i=y*n+x,k=(y-1)*m+x-1;
            double u=(p[i+n]-p[i-n])*(.5*ih),v=(p[i-1]-p[i+1])*(.5*ih);
            current[k]=(z[i+n]+z[i-n]+z[i+1]+z[i-1]-4*z[i])*(ih*ih/re)
                      -(u*(z[i+1]-z[i-1])+v*(z[i+n]-z[i-n]))*(.5*ih);
        }
    };
    std::ofstream log(out/"zeiten.csv");log<<"step,t_star,wall_s,cpu_s,max_z,max_change_rate\n"<<std::setprecision(17);
    int last=0;double wall=0,cpu=0;
    for(int end:checkpoints){
        auto tic=std::chrono::steady_clock::now();auto ct=std::clock();
        for(int t=last;t<end;t+=stride){poisson();rhs();
            for(int y=1;y<n-1;++y)for(int x=1;x<n-1;++x){int k=(y-1)*m+x-1;
                z[y*n+x]+=dt*(t==0?current[k]:1.5*current[k]-.5*old[k]);}
            old.swap(current);
        }
        wall+=std::chrono::duration<double>(std::chrono::steady_clock::now()-tic).count();cpu+=double(std::clock()-ct)/CLOCKS_PER_SEC;
        double mx=0,rate=0;std::vector<double> out_z(m*m);
        for(int y=1;y<n-1;++y)for(int x=1;x<n-1;++x){int k=(y-1)*m+x-1;
            double value=z[y*n+x];if(!std::isfinite(value)){std::cerr<<"nonfinite at "<<end<<"\n";return 3;}
            mx=std::max(mx,std::abs(value));rate=std::max(rate,std::abs(old[k]));out_z[k]=value;}
        std::ofstream f(out/("z_"+std::to_string(end)+".bin"),std::ios::binary);
        f.write(reinterpret_cast<char*>(out_z.data()),out_z.size()*sizeof(double));f.close();if(!f)return 4;
        log<<end<<','<<double(end)*.1/ih<<','<<wall<<','<<cpu<<','<<mx<<','<<rate<<'\n'<<std::flush;
        last=end;
    }
    fftw_destroy_plan(transform);
}
