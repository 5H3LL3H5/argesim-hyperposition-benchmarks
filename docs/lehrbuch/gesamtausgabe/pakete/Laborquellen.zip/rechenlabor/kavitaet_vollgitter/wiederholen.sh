#!/usr/bin/env bash
# Complete regeneration. Run from any directory. CPU limits are per method.
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
export KAV_RAW="${KAV_RAW:-$root/rohdaten}"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
src="$root/src"
bin="${KAV_BIN:-$root/bin}"
mkdir -p "$bin" "$KAV_RAW" "$root/daten"
flags=(-std=c++20 -O3 -march=native -ffp-contract=off -Wall -Wextra -Werror)
g++ "${flags[@]}" -fopenmp "$src/d2q9.cpp" -o "$bin/d2q9"
g++ "${flags[@]}" "$src/wirbel.cpp" -Wl,-l:libfftw3.so.3 -o "$bin/wirbel"
g++ "${flags[@]}" "$src/gruppen_qss.cpp" -Wl,-l:libfftw3.so.3 -o "$bin/gruppen_qss"
for re in 1000 650 750 850 950 1050 1150 1250 1350 900 1100; do
    "$bin/d2q9" 257 "$re" 1 "$KAV_RAW/re$re" "$src/zeitpunkte.txt"
    "$bin/d2q9" 65 "$re" 1 "$KAV_RAW/g65_re$re" "$src/zeitpunkte65.txt"
done
"$bin/d2q9" 257 1000 4 "$KAV_RAW/pruef4" "$src/zeitpunkte.txt"
for re in 1000 850 1150 950; do "$bin/wirbel" 257 "$re" 2 "$KAV_RAW/ns_${re}_2" "$src/zeitpunkte.txt"; done
"$bin/wirbel" 257 1000 4 "$KAV_RAW/ns_1000_4" "$src/zeitpunkte.txt"
for order in 1 2; do
    for q in 0.001 0.0002; do "$bin/gruppen_qss" 257 1000 "$order" "$q" "$KAV_RAW/gruppe_${order}_$q" "$src/zeitpunkte.txt"; done
done
python "$src/prozesszeit.py" "$bin/d2q9"
python "$src/jacobi.py"
python "$src/gruppentest.py" "$bin/gruppen_qss"
python "$src/populationsprobe.py"
python "$src/galerkin.py"
python "$src/operatoren.py"
python "$src/zusatzzeiten.py"
python "$src/raum_fourier.py"
python "$src/zeitblind.py"
python "$src/korrektur_qss.py" aufbau
mapfile -t methods < <(PYTHONPATH="$src" python -c 'from gemeinsam import METHODS;print(*METHODS,sep="\n")')
for m in "${methods[@]}"; do
    python "$src/voll_qss.py" "$m" --limit 240
    python "$src/rom_qss.py" "$m" --limit 180 --quantum .003
    python "$src/korrektur_qss.py" "$m"
done
for off in .25 .75 0 -.25; do python "$src/korrektur_qss.py" cqss1 --offset "$off"; done
python "$src/auswerten.py" alle
python "$src/profil.py"
python "$src/abbildungen.py"
python "$src/pruefen.py"
