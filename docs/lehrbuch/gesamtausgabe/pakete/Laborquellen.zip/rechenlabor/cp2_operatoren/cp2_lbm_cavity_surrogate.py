"""Affine and hybrid PyTorch benchmarks for low-Mach lid-driven cavity fields."""

from __future__ import annotations

import argparse
from pathlib import Path
from time import perf_counter

import numpy as np
import torch
import torch.nn.functional as F

from hybrid_operator import HybridNeuralOperator, TRANSFORMS
from labor_common import (
    amortized,
    configure_device,
    environment,
    fit_operator,
    measure,
    relative_error,
    tensor,
    write_report,
)
from referenzen import (
    CALIBRATION,
    TRAIN,
    VALIDATION,
    build_cpp,
    cavity_case,
    resize_centers,
)


VECTOR_BUDGET = 0.03
DIVERGENCE_BUDGET = 0.045
PROFILE_BUDGET = 0.025
PHYSICS_WEIGHT = 0.006
HISTORY = np.array([0.0, 0.4, 1.2, 3.5, 26.0]) / 26.0

# Ghia et al. Re=100. Interior samples from Tables I and II; also reproduced in
# the Sandia SIERRA/Fuego Verification Manual, Table 22.1, OSTI report 2547076.
GHIA_U = np.array(
    [
        [0.1016, -0.06434],
        [0.1719, -0.10150],
        [0.2813, -0.15662],
        [0.4531, -0.21090],
        [0.5000, -0.20581],
        [0.6172, -0.13641],
        [0.7344, 0.00332],
        [0.8516, 0.23151],
        [0.9688, 0.78871],
    ]
)
GHIA_V = np.array(
    [
        [0.0625, 0.09233],
        [0.1563, 0.16077],
        [0.2344, 0.17527],
        [0.5000, 0.05454],
        [0.8047, -0.24533],
        [0.8594, -0.22445],
        [0.9063, -0.16914],
        [0.9453, -0.10313],
        [0.9688, -0.05906],
    ]
)


def polynomial(cases):
    re = np.array([(reynolds - 90) / 30 for _, reynolds, _ in cases])
    a = np.array([amplitude / 0.3 for _, _, amplitude in cases])
    return np.column_stack((np.ones(len(re)), re, a, re * a, re**2, a**2))


def on_grid(field, size, device):
    shape = field.shape
    if shape[-1] == size:
        return field
    values = F.interpolate(
        field.reshape(-1, 1, *shape[-2:]),
        size=(size, size),
        mode="bilinear",
        align_corners=False,
    )
    return values.reshape(*shape[:-2], size, size).to(device)


def data_query(cases, basis_grid, device):
    controls = tensor(polynomial(cases), device)
    history = torch.einsum("ba,atcij->btcij", controls[:, :3], basis_grid)
    history = torch.cat((torch.zeros_like(history[:, :1]), history), dim=1)
    size = history.shape[-1]
    coordinate = (torch.arange(size, dtype=history.dtype, device=device) + 0.5) / size
    edge = (4 * coordinate * (1 - coordinate)) ** 0.5
    envelope = (edge[:, None] * edge[None, :])[None, None]
    return history, tensor(HISTORY, device), controls, history[:, -1], envelope


def divergence(field):
    n = field.shape[-1]
    ux, uy = field[:, 0], field[:, 1]
    return (
        0.5
        * n
        * (ux[:, 1:-1, 2:] - ux[:, 1:-1, :-2] + uy[:, 2:, 1:-1] - uy[:, :-2, 1:-1])
    )


class FluxProjection:
    """Discrete L2 projection with zero outward normal flux at the four faces."""

    def __init__(self, size, device):
        difference = torch.zeros((size, size), dtype=torch.float64, device=device)
        interior = torch.arange(1, size - 1, device=device)
        difference[interior, interior + 1] = 0.5 * size
        difference[interior, interior - 1] = -0.5 * size
        difference[0, :2] = 0.5 * size
        difference[-1, -2:] = -0.5 * size
        spectrum, basis = torch.linalg.eigh(difference @ difference.T)
        sums = spectrum[:, None] + spectrum[None, :]
        self.inverse = torch.where(sums > 1e-9, sums.reciprocal(), 0.0)
        self.basis = basis
        self.difference = difference

    def apply(self, field):
        u, v = field.unbind(dim=1)
        derivative = self.difference
        source = u @ derivative.T + derivative @ v
        basis = self.basis
        potential = basis @ ((basis.T @ source @ basis) * self.inverse) @ basis.T
        return torch.stack(
            (u - potential @ derivative, v - derivative.T @ potential), dim=1
        )


def anchor_offset(cases, discrepancy, tests, device):
    """Fit a local constant or affine field offset as a function of the lid amplitude."""
    if len(cases) == 1:
        return discrepancy[:1].expand(len(tests), *discrepancy.shape[1:])

    def query(values):
        return tensor([[1.0, case[2]] for case in values], device)

    anchors = query(cases)
    rhs = discrepancy.reshape(len(cases), -1)
    weights = torch.linalg.solve(anchors.T @ anchors, anchors.T @ rhs)
    return (query(tests) @ weights).reshape(len(tests), *discrepancy.shape[1:])


def stationarity_constraint(features, base, stride):
    size = features.shape[-1]
    horizontal = 0.5 * size * (features[..., 1:-1, 2:] - features[..., 1:-1, :-2])
    vertical = 0.5 * size * (features[..., 2:, 1:-1] - features[..., :-2, 1:-1])
    # Corners have a discontinuity in the imposed tangential boundary data.
    edge = max(1, int(0.055 * size)) - 1
    core = slice(edge, -edge or None, stride)
    design = torch.cat((horizontal[..., core, core], vertical[..., core, core]), dim=1)
    return design, -divergence(base)[..., core, core]


def fit(model, config, label, prior=None):
    history, times, conditions, base, envelope = config
    features = model.features(history, times, conditions, envelope)
    stride = max(1, label.shape[-1] // 100)
    condition = stationarity_constraint(features, base, stride)
    return fit_operator(
        model,
        features[..., ::stride, ::stride],
        (label - base)[..., ::stride, ::stride],
        condition,
        PHYSICS_WEIGHT,
        prior=prior,
        ridge=3e-3 if prior is not None else 8e-7,
    )


def profiles(field):
    size = field.shape[-1]
    coordinate = np.r_[0.0, (np.arange(size) + 0.5) / size, 1.0]
    mid = size // 2
    u = np.interp(GHIA_U[:, 0], coordinate, np.r_[0.0, field[0, :, mid], 1.0])
    v = np.interp(GHIA_V[:, 0], coordinate, np.r_[0.0, field[1, mid, :], 0.0])
    error = (
        np.sqrt(np.mean((u - GHIA_U[:, 1]) ** 2)),
        np.sqrt(np.mean((v - GHIA_V[:, 1]) ** 2)),
    )
    return np.stack((u, v)), list(error)


def summarize(estimated, truth, cases):
    n = truth.shape[-1]
    border = max(2, int(0.055 * n))
    core = slice(border, -border)
    rel = relative_error(estimated[..., core, core], truth[..., core, core])
    wall = slice(-max(2, round(0.04 * n)), None)
    shear_error = relative_error(estimated[..., wall, core], truth[..., wall, core])
    div = np.sqrt(
        np.mean(
            divergence(estimated)[:, border - 1 : 1 - border, border - 1 : 1 - border]
            ** 2,
            axis=(1, 2),
        )
    )
    per_case = []
    for index, (size, reynolds, amplitude) in enumerate(cases):
        benchmark = reynolds == 100 and amplitude == 0.0
        profile = profiles(estimated[index])[1] if benchmark else None
        score = max(
            rel[index] / VECTOR_BUDGET,
            div[index] / DIVERGENCE_BUDGET,
            max(profile) / PROFILE_BUDGET if profile is not None else 0.0,
        )
        per_case.append(
            {
                "n": size,
                "re": reynolds,
                "amplitude": amplitude,
                "field_relative": float(rel[index]),
                "near_lid_relative": float(shear_error[index]),
                "divergence_rms": float(div[index]),
                "ghia_rms_UV": profile,
                "score": float(score),
            }
        )
    return {
        "cases": per_case,
        "score_max": max(row["score"] for row in per_case),
        "accepted": sum(row["score"] <= 1 for row in per_case),
    }


def final_prediction(model, config):
    return model(*config[:3], physics=config[3], envelope=config[4])


@torch.no_grad()
def run(output, device, coarse=False, reference=None):
    output.mkdir(parents=True, exist_ok=True)
    directory = (reference or output) / "lbm_cache"
    binary = build_cpp(output)
    groups = {
        name: case
        for name, case in VALIDATION.items()
        if not coarse or case[0][0] == 65
    }
    calibration = {
        name: values for name, values in CALIBRATION.items() if name in groups
    }

    def load(cases):
        return [cavity_case(*case, directory, binary) for case in cases]

    train = load(TRAIN)
    fields = np.stack([data for data, _ in train])
    train_clock = sum(report["seconds"] for _, report in train)
    ready = perf_counter()
    base, _, rank, _ = np.linalg.lstsq(
        polynomial(TRAIN)[:, :3], fields.reshape(len(TRAIN), -1), rcond=None
    )
    assert rank == 3
    basis65 = tensor(base.reshape(3, *fields.shape[1:]), device)
    affine_fit = perf_counter() - ready
    train_config = data_query(TRAIN, basis65, device)
    train_label = tensor(fields[:, -1], device)
    references = {name: load(cases) for name, cases in groups.items()}
    shot_sets = {name: load(cases) for name, cases in calibration.items()}
    sizes = {cases[0][0] for cases in groups.values()}
    weights_at_size = {n: on_grid(basis65, n, device) for n in sizes}
    cases_at = {
        name: data_query(cases, weights_at_size[cases[0][0]], device)
        for name, cases in groups.items()
    }
    truth = {
        name: np.stack([field[-1] for field, _ in values])
        for name, values in references.items()
    }
    tests = {name: tuple(group) for name, group in groups.items()}
    for name, cases in calibration.items():
        assert not set(cases) & (set(TRAIN) | set(groups[name]))
    nominal = ("Re100", 0)
    probe_reference = {}
    base_results = {}
    pics = {"ghia_u": GHIA_U, "ghia_v": GHIA_V, "affine_weights": basis65.cpu().numpy()}
    timing_targets = [name for name in ("Re100", "421") if name in groups]
    for name, group in groups.items():
        nominal_field = truth[name]
        base_results[name] = summarize(
            cases_at[name][3].cpu().numpy(), nominal_field, group
        )
        probe_reference[name] = summarize(nominal_field, nominal_field, group)
    affine_performance = {}
    for name in timing_targets:
        basis_grid = weights_at_size[groups[name][0][0]]
        affine_performance[name] = measure(
            lambda: data_query(groups[name][:1], basis_grid, device)[3], device
        )
    projectors, projection_setup = {}, {}
    for name in calibration:
        started = perf_counter()
        projectors[name] = FluxProjection(groups[name][0][0], device)
        projection_setup[name] = perf_counter() - started
    print(
        "Affine maximum scores:",
        {key: round(val["score_max"], 3) for key, val in base_results.items()},
        flush=True,
    )
    pics["reference_Re100"] = truth[nominal[0]][nominal[1]]
    pics["affine_Re100"] = cases_at[nominal[0]][3][nominal[1]].cpu().numpy()
    if "421" in tests:
        pics["reference_n421"] = truth["421"][0]
        pics["affine_n421"] = cases_at["421"][3][0].cpu().numpy()
    changes = {}
    for name in ("129", "257", "421"):
        if name in truth:
            projected = resize_centers(truth["Re100"][0], truth[name].shape[-1])
            changes[name] = float(
                relative_error(
                    projected[:, 4:-4, 4:-4][None], truth[name][[0], :, 4:-4, 4:-4]
                )[0]
            )
    book = {
        "population_count": len(TRAIN),
        "data_seconds": train_clock,
        "affine_fit_seconds": affine_fit,
        "environment": environment(device),
        "physics_weight": PHYSICS_WEIGHT,
        "training_conditions": TRAIN,
        "train_reference_runs": [report for _, report in train],
        "validation_reference_runs": {
            name: [report for _, report in values]
            for name, values in references.items()
        },
        "calibration_reference_runs": {
            name: [report for _, report in values] for name, values in shot_sets.items()
        },
        "calibration_conditions": calibration,
        "classical": probe_reference,
        "affine": base_results,
        "affine_performance": affine_performance,
        "affine_parameter_count": int(basis65.numel()),
        "affine_parameter_bytes": int(basis65.numel() * basis65.element_size()),
        "lbm_sensitivity_to_grid": changes,
        "methods": {},
        "projection_setup_seconds": projection_setup,
        "affine_anchor": {},
        "budgets": {
            "velocity_relative": VECTOR_BUDGET,
            "continuity_rms": DIVERGENCE_BUDGET,
            "ghia_profile_rms": PROFILE_BUDGET,
        },
    }
    for name, cases in calibration.items():
        counts = (1, 2, 4) if len(cases) == 4 else (1, 2)
        projected = projectors[name]
        reference = tensor(
            np.stack([field[-1] for field, _ in shot_sets[name]]), device
        )
        affine_anchor = data_query(cases, weights_at_size[cases[0][0]], device)[3]
        base_field = cases_at[name][3]
        trials = []
        for number in counts:
            offset = anchor_offset(
                cases[:number],
                (reference - affine_anchor)[:number],
                tests[name],
                device,
            )
            value = projected.apply(base_field + offset).cpu().numpy()
            trials.append(
                {"shots": number, **summarize(value, truth[name], groups[name])}
            )
        book["affine_anchor"][name] = trials
    for kind in TRANSFORMS:
        model = HybridNeuralOperator(kind, 2, 2, conditioning_terms=6).to(device)
        now = perf_counter()
        fit(model, train_config, train_label)
        elapsed = perf_counter() - now
        saved = model.mixing.clone()
        comparisons = {}
        inference = {}
        needed = {}
        for name, group in tests.items():
            value = final_prediction(model, cases_at[name]).cpu().numpy()
            comparisons[name] = summarize(value, truth[name], group)
            if name in timing_targets:
                basis_grid = weights_at_size[group[0][0]]

                def call():
                    return final_prediction(
                        model, data_query(group[:1], basis_grid, device)
                    )

                inference[name] = measure(call, device, repeats=7)
                solver_time = (
                    references[name][0][1]["seconds"]
                    + references[name][0][1]["warm_reference_seconds"]
                )
                needed[name] = amortized(
                    train_clock + affine_fit + elapsed,
                    inference[name]["seconds"],
                    solver_time,
                )
                pics[f"prediction_{name}_{kind}"] = value[0].copy()
        few_shot = {}
        for name, cases in calibration.items():
            history = [{"shots": 0, "calibration_seconds": 0.0, **comparisons[name]}]
            counts = (1, 2, 4) if len(cases) == 4 else (1, 2)
            grid = weights_at_size[cases[0][0]]
            raw_prediction = final_prediction(model, cases_at[name])
            installed_anchor_prediction = final_prediction(
                model, data_query(cases, grid, device)
            )
            anchor_reference = tensor(
                np.stack([field[-1] for field, _ in shot_sets[name]]), device
            )
            offsets = anchor_reference - installed_anchor_prediction
            anchor_trials = []
            for number in counts:
                start = perf_counter()
                training = data_query(cases[:number], grid, device)
                label = tensor(
                    np.stack([field[-1] for field, _ in shot_sets[name][:number]]),
                    device,
                )
                fit(model, training, label, prior=saved)
                fitting = perf_counter() - start
                prediction = final_prediction(model, cases_at[name]).cpu().numpy()
                extra = sum(
                    report["seconds"] + report["warm_reference_seconds"]
                    for _, report in shot_sets[name][:number]
                )
                history.append(
                    {
                        "shots": number,
                        "calibration_seconds": extra + fitting,
                        **summarize(prediction, truth[name], groups[name]),
                    }
                )
                model.mixing.copy_(saved)
                started = perf_counter()
                offset = anchor_offset(
                    cases[:number], offsets[:number], tests[name], device
                )
                setup = perf_counter() - started + projection_setup[name]
                projector = projectors[name]
                anchored = projector.apply(raw_prediction + offset).cpu().numpy()
                acceptance = summarize(anchored, truth[name], groups[name])
                kernel_cost = None
                if acceptance["accepted"] == len(tests[name]):

                    def projected_query():
                        field = final_prediction(
                            model, data_query(tests[name][:1], grid, device)
                        )
                        return projector.apply(field + offset[:1])

                    kernel_cost = measure(projected_query, device, repeats=5)
                    solver = references[name][0][1]
                    kernel_cost["amortization_arithmetic"] = amortized(
                        train_clock + affine_fit + elapsed + extra + setup,
                        kernel_cost["seconds"],
                        solver["seconds"] + solver["warm_reference_seconds"],
                    )
                anchor_trials.append(
                    {
                        "shots": number,
                        "calibration_seconds": extra + setup,
                        "inference_calibrated": kernel_cost,
                        **acceptance,
                    }
                )
                if number == 1 and kind == "fourier":
                    pics[f"projected_anchor_{name}"] = anchored[0]
            few_shot[name] = {
                "trials": history,
                "fewest_passing": next(
                    (x["shots"] for x in history if x["accepted"] == len(tests[name])),
                    None,
                ),
                "anchor_trials": anchor_trials,
                "fewest_anchored_passing": next(
                    (
                        x["shots"]
                        for x in anchor_trials
                        if x["accepted"] == len(tests[name])
                    ),
                    None,
                ),
            }
        pics[f"weights_{kind}"] = model.mixing.cpu().numpy().copy()
        book["methods"][kind] = {
            "head_parameters": model.mixing.numel(),
            "head_bytes": model.mixing.numel() * model.mixing.element_size(),
            "seconds_fit": elapsed,
            "comparisons": comparisons,
            "inference": inference,
            "amortization_arithmetic": needed,
            "few_shot": few_shot,
        }
        print(
            kind,
            {key: round(val["score_max"], 3) for key, val in comparisons.items()},
            {key: val["fewest_passing"] for key, val in few_shot.items()},
            flush=True,
        )
    np.savez_compressed(output / "kavitaet_felder.npz", **pics)
    write_report(output / "kavitaet_operatoren.json", book)
    return book


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--reference", type=Path, help="optional existing reference-run directory"
    )
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument(
        "--coarse", action="store_true", help="only the 65×65 Reynolds experiments"
    )
    args = parser.parse_args()
    run(args.out, configure_device(args.device), args.coarse, args.reference)


if __name__ == "__main__":
    main()
