"""CP2/3, a dispersive control experiment and localized non-smoothness tests."""

from __future__ import annotations

import argparse
from pathlib import Path
from statistics import median
from time import perf_counter

import numpy as np
from scipy.fft import dst, idst
import torch

from hybrid_operator import HybridNeuralOperator, TRANSFORMS
from labor_common import (
    amortized,
    configure_device,
    correction_matrix,
    environment,
    fit_operator,
    measure,
    relative_error,
    tensor,
    write_report,
)
from referenzen import build_cpp, string_case


LENGTH = 0.5
SPEED = 0.06
TIMES = np.array([5.0, 8.0])
GAMMA = 1.2e-8
SIZE = 501
HISTORY = np.linspace(0, 1, 5)
HARD_BUDGET = 0.01


def tents(position, amplitude):
    return ("tent", position, amplitude)


def shape_at(spec, x):
    reflected = x % 2
    sign = np.where(reflected <= 1, 1.0, -1.0)
    inside = np.where(reflected <= 1, reflected, 2 - reflected)
    if spec[0] == "tent":
        _, position, amplitude = spec
        return (
            sign
            * amplitude
            * np.minimum(inside / position, (1 - inside) / (1 - position))
        )
    harmonics = np.arange(1, len(spec[1]) + 1)
    return np.sin(np.pi * x[..., None] * harmonics) @ spec[1]


def wave_field(spec, times, x):
    shift = np.asarray(times)[..., None] * SPEED / LENGTH
    return 0.5 * (shape_at(spec, x - shift) + shape_at(spec, x + shift))


def sine_coefficients(spec, modes):
    if spec[0] == "tent":
        _, position, amplitude = spec
        return (
            2
            * amplitude
            * np.sin(np.pi * modes * position)
            / (np.pi**2 * modes**2 * position * (1 - position))
        )
    return np.pad(spec[1], (0, len(modes) - len(spec[1])))


def dispersive(spec, times, x, gamma, count=4096):
    mode = np.arange(1, count + 1)
    k = np.pi * mode / LENGTH
    frequency = np.sqrt((SPEED * k) ** 2 + gamma * k**4)
    weights = sine_coefficients(spec, mode) * np.cos(
        np.asarray(times)[..., None] * frequency
    )
    return weights @ np.sin(np.pi * mode[:, None] * x)


def dispersion_sensitivity(spec, times, x, gamma, first_mode, last_mode):
    """First-order frequency perturbation, used as input rather than as the label."""
    all_modes = np.arange(1, last_mode + 1)
    modes = all_modes[first_mode - 1 :]
    wave_numbers = np.pi * modes / LENGTH
    omega = SPEED * wave_numbers
    clock = np.asarray(times)[..., None]
    frequency = omega + gamma * wave_numbers**4 / (2 * omega)
    coefficients = sine_coefficients(spec, all_modes)[first_mode - 1 :]
    return (
        coefficients * (np.cos(clock * frequency) - np.cos(clock * omega))
    ) @ np.sin(np.pi * modes[:, None] * x)


def query(specs, frames, x, device, gamma):
    time_grid = np.asarray(frames)[:, None] * HISTORY
    base = np.stack([wave_field(spec, time_grid, x) for spec in specs])
    sensitivity = [
        np.stack(
            [
                dispersion_sensitivity(spec, time_grid, x, gamma, low, high)
                for spec in specs
            ]
        )
        if gamma
        else np.zeros_like(base)
        for low, high in ((1, 12), (13, 40))
    ]
    data = np.stack((base, *sensitivity), axis=3)
    history = tensor(data.reshape(-1, len(HISTORY), 3, len(x)), device)
    physics = history[:, -1, :1]
    condition = torch.ones((len(history), 1), dtype=history.dtype, device=device)
    envelope = torch.ones((1, 1, len(x)), dtype=history.dtype, device=device)
    envelope[..., (0, -1)] = 0
    return history, tensor(HISTORY, device), condition, physics, envelope


def training_specs():
    rng = np.random.default_rng(2813)
    smooth = [
        ("sine", rng.normal(0, 0.032, 8) / (np.arange(1, 9) ** 1.28)) for _ in range(12)
    ]
    sharp = [
        tents(p, a)
        for p, a in zip(
            np.linspace(0.24, 0.76, 10), np.linspace(0.035, 0.062, 10), strict=True
        )
    ]
    return smooth + sharp, len(smooth)


def wave_residual(minus, center, plus, spatial_step, time_step, gamma):
    d2 = (
        center[..., 1:-3] - 2 * center[..., 2:-2] + center[..., 3:-1]
    ) / spatial_step**2
    d4 = (
        center[..., :-4]
        - 4 * center[..., 1:-3]
        + 6 * center[..., 2:-2]
        - 4 * center[..., 3:-1]
        + center[..., 4:]
    ) / spatial_step**4
    dtt = (minus[..., 2:-2] - 2 * center[..., 2:-2] + plus[..., 2:-2]) / time_step**2
    return dtt - SPEED**2 * d2 + gamma * d4


def bending_energy(minus, center, plus, step, time_step, gamma):
    rate = (plus - minus) / (2 * time_step)
    gradient = np.diff(center, axis=-1) / step
    curvature = np.diff(center, n=2, axis=-1) / step**2
    terms = (
        np.sum(rate**2, axis=-1)
        + SPEED**2 * np.sum(gradient**2, axis=-1)
        + gamma * np.sum(curvature**2, axis=-1)
    )
    return 0.5 * step * terms


def analytic_controls(binary, output, x):
    profile = tents(0.5, 0.05)
    initial = shape_at(profile, x)
    truth = wave_field(profile, TIMES, x)
    mode = np.arange(1, len(x) - 1)
    omega = (
        2 * SPEED * (len(x) - 1) / LENGTH * np.sin(np.pi * mode / (2 * (len(x) - 1)))
    )
    spectrum = dst(initial[1:-1], type=1)

    def pad(values):
        return np.pad(idst(values, type=1, axis=-1), ((0, 0), (1, 1)))

    exact_in_space = pad(spectrum * np.cos(TIMES[:, None] * omega))
    result = {"spatial_relative": relative_error(exact_in_space, truth).tolist()}
    for method in ("newmark", "verlet"):
        repeated = [string_case(binary, output, method, len(x)) for _ in range(3)]
        values, run = repeated[-1]
        angle = 2 * (
            np.arctan(0.01 * omega / 2)
            if method == "newmark"
            else np.arcsin(0.01 * omega / 2)
        )
        fully_discrete = pad(spectrum * np.cos(TIMES[:, None] / 0.01 * angle))
        implementation_error = relative_error(values, fully_discrete)
        assert max(implementation_error) < 2e-11 and run["linear_residual_max"] < 5e-16
        result[method] = {
            "total_relative": relative_error(values, truth).tolist(),
            "time_relative": relative_error(fully_discrete, exact_in_space).tolist(),
            "inner_relative": implementation_error.tolist(),
            "linear_residual_max": run["linear_residual_max"],
            "seconds": median(report["seconds"] for _, report in repeated),
            "workspace_payload_bytes": 7 * len(x) * np.dtype("float64").itemsize,
        }
    return result


def shock_fields(grid_size, cases):
    axis = np.linspace(-1, 1, grid_size)
    yy, xx = np.meshgrid(axis, axis, indexing="ij")
    signed = np.stack(
        [
            np.cos(angle) * xx + np.sin(angle) * yy - (origin + 0.12)
            for angle, origin in cases
        ]
    )
    field = np.where(signed < 0, 1.0, 0.2)
    strip = (np.abs(signed) < 0.10) & (np.abs(xx) < 0.81) & (np.abs(yy) < 0.81)
    return field, strip


def transform_controls(kind, x, device, picture):
    """Fit standalone reconstruction of known profiles to isolate transform ringing."""
    sharp_train = [tents(p, 0.05) for p in np.linspace(0.24, 0.76, 12)]
    sharp_test = [tents(0.5, 0.05), tents(0.33, 0.05), tents(0.67, 0.05)]

    def reconstruction(target, evaluate):
        def sequence(data):
            return tensor(data[:, None, None], device).repeat(
                1, 3, 1, *([1] * (data.ndim - 1))
            )

        duration = tensor([0.0, 0.5, 1.0], device)

        def condition(number):
            return tensor(np.ones((number, 1)), device)

        operator = HybridNeuralOperator(kind, 1, 1).to(device)
        values = sequence(target)
        features = operator.features(values, duration, condition(len(target)))
        fit_operator(operator, features, values[:, -1])
        with torch.no_grad():
            return (
                operator(sequence(evaluate), duration, condition(len(evaluate)))[:, 0]
                .cpu()
                .numpy()
            )

    truth = np.concatenate([wave_field(spec, TIMES, x) for spec in sharp_test])
    training = np.concatenate([wave_field(spec, TIMES, x) for spec in sharp_train])
    predicted = reconstruction(training, truth)
    amplitude = np.max(abs(truth), axis=1)
    excess = np.maximum(
        predicted.max(axis=1) - truth.max(axis=1),
        truth.min(axis=1) - predicted.min(axis=1),
    ).clip(min=0)
    picture[f"rope_projection_{kind}"] = predicted[0]
    train = [
        (angle, origin)
        for angle in (0.0, 0.48, 0.97, 1.37)
        for origin in (-0.37, -0.13, 0.14)
    ]
    test = [
        (angle, origin)
        for angle, origin in ((0.25, -0.24), (0.68, -0.09), (1.20, 0.06))
    ]
    shock_train, _ = shock_fields(97, train)
    shocks, fronts = shock_fields(129, test)
    shock_pred = reconstruction(shock_train, shocks)
    outside = np.maximum(shock_pred - 1.0, 0.2 - shock_pred).clip(min=0)
    picture[f"burgers_{kind}"] = shock_pred[1]
    picture["burgers_reference"] = shocks[1]
    return {
        "tent_relative_max": float(relative_error(predicted, truth).max()),
        "tent_overshoot": float(np.max(excess / amplitude)),
        "burgers_relative_max": float(relative_error(shock_pred, shocks).max()),
        "burgers_overshoot": float(outside[fronts].max() / 0.8),
        "burgers_front_max": float(np.abs(shock_pred - shocks)[fronts].max() / 0.8),
    }


@torch.no_grad()
def run(output, device):
    output.mkdir(parents=True, exist_ok=True)
    binary = build_cpp(output)
    x = np.linspace(0, 1, SIZE)
    controls = analytic_controls(binary, output, x)
    started = perf_counter()
    specs, smooth_count = training_specs()
    targets = np.stack([dispersive(spec, TIMES, x, GAMMA) for spec in specs]).reshape(
        -1, 1, SIZE
    )
    train = query(specs, TIMES, x, device, GAMMA)
    smooth = slice(0, 2 * smooth_count)
    time_step = 0.02
    intervals = [
        query(specs[:smooth_count], TIMES + sign * time_step, x, device, GAMMA)
        for sign in (-1, 1)
    ]
    training_seconds = perf_counter() - started
    test_specs = [
        tents(0.5, 0.05),
        tents(0.29, 0.053),
        tents(0.71, 0.053),
        tents(0.42, 0.044),
        tents(0.58, 0.044),
    ]
    nominal = wave_field(test_specs[0], TIMES, x)
    ideal = np.stack([wave_field(spec, TIMES, x) for spec in test_specs])
    extension = np.stack([dispersive(spec, TIMES, x, GAMMA) for spec in test_specs])
    fine = np.stack([dispersive(spec, TIMES, x, GAMMA, 8192) for spec in test_specs])
    series_diff = float(
        relative_error(extension.reshape(-1, SIZE), fine.reshape(-1, SIZE)).max()
    )
    assert series_diff < 0.001
    assert np.max(abs(ideal[1] - ideal[2, :, ::-1])) < 1e-14
    assert np.max(abs(extension[1] - extension[2, :, ::-1])) < 1e-13
    pictures = {
        "x": x * LENGTH,
        "rope_reference": nominal[0],
        "dispersive_reference": extension[0],
        "dispersive_physics": nominal,
        "ideal_reference": ideal,
    }
    result = {
        "classical": controls,
        "physics_extension_relative": relative_error(
            ideal.reshape(-1, SIZE), extension.reshape(-1, SIZE)
        )
        .reshape(-1, 2)
        .tolist(),
        "continuum_series_change": series_diff,
        "gamma_m4_s2": GAMMA,
        "data_seconds": training_seconds,
        "environment": environment(device),
        "methods": {},
    }
    result["analytic"] = measure(lambda: wave_field(test_specs[0], TIMES, x), device)
    train_target = tensor(targets, device)
    eval_ext = query(test_specs, TIMES, x, device, GAMMA)
    eval_ideal = query(test_specs, TIMES, x, device, 0.0)
    energy_spec = [
        ("sine", np.array([0.041, -0.016, 0.007, -0.003, 0.001, 0.002, -0.002, 0.0015]))
    ]
    energy_queries = [
        query(energy_spec, TIMES + sign * time_step, x, device, GAMMA)
        for sign in (-1, 0, 1)
    ]
    energy_reference = bending_energy(
        *[
            dispersive(energy_spec[0], TIMES + sign * time_step, x, GAMMA)
            for sign in (-1, 0, 1)
        ],
        LENGTH / (SIZE - 1),
        time_step,
        GAMMA,
    )
    for kind in TRANSFORMS:
        ideal_operator = HybridNeuralOperator(kind, 3, 1).to(device)
        extension_operator = HybridNeuralOperator(kind, 3, 1).to(device)

        def feature_args(config):
            return (*config[:3], config[4])

        def evaluate(module, config):
            return module(*config[:3], physics=config[3], envelope=config[4])

        started = perf_counter()
        # Negative control for CP2. For this exact model the residual target is identically zero.
        exact_train = query(specs, TIMES, x, device, 0.0)
        fit_operator(
            ideal_operator,
            ideal_operator.features(*feature_args(exact_train)),
            torch.zeros_like(exact_train[3]),
        )
        data_feature = extension_operator.features(*feature_args(train))
        sides = [
            extension_operator.features(*feature_args(neighbor))
            for neighbor in intervals
        ]
        grid = LENGTH / (SIZE - 1)
        gain = (LENGTH / SPEED) ** 2
        pde_features = gain * wave_residual(
            sides[0], data_feature[smooth], sides[1], grid, time_step, GAMMA
        )
        pde_base = gain * wave_residual(
            intervals[0][3], train[3][smooth], intervals[1][3], grid, time_step, GAMMA
        )
        fit_operator(
            extension_operator,
            data_feature,
            train_target - train[3],
            (pde_features, -pde_base),
            5e-7,
        )
        fit_time = perf_counter() - started
        data_only = HybridNeuralOperator(kind, 3, 1).to(device)
        fit_operator(data_only, data_feature, train_target - train[3])
        ideal_prediction = (
            evaluate(ideal_operator, eval_ideal).cpu().numpy().reshape(-1, 2, SIZE)
        )
        extension_prediction = (
            evaluate(extension_operator, eval_ext).cpu().numpy().reshape(-1, 2, SIZE)
        )
        ideal_err = relative_error(
            ideal_prediction.reshape(-1, SIZE), ideal.reshape(-1, SIZE)
        ).reshape(-1, 2)
        extension_err = relative_error(
            extension_prediction.reshape(-1, SIZE), extension.reshape(-1, SIZE)
        ).reshape(-1, 2)
        assert ideal_err.max() <= HARD_BUDGET
        assert np.max(abs(ideal_operator.mixing.cpu().numpy())) == 0.0

        def mirror(field):
            return float(relative_error(field[1], field[2, :, ::-1]).max())

        symmetric_image = (
            evaluate(extension_operator, eval_ext)
            .reshape(-1, 2, 1, SIZE)[:, :, 0]
            .cpu()
            .numpy()
        )
        sym_average = (symmetric_image[1] + symmetric_image[2, :, ::-1]) / 2
        # The same group average is used in both directions, giving a reproducible parity control.
        assert np.array_equal(
            sym_average,
            ((symmetric_image[2] + symmetric_image[1, :, ::-1]) / 2)[:, ::-1],
        )
        pde_fit = pde_base + correction_matrix(extension_operator.mixing, pde_features)
        pde_data_only = pde_base + correction_matrix(data_only.mixing, pde_features)
        energy = bending_energy(
            *[
                evaluate(extension_operator, cfg)[:, 0].cpu().numpy()
                for cfg in energy_queries
            ],
            grid,
            time_step,
            GAMMA,
        )
        pictures[f"extension_{kind}"] = extension_prediction[0]
        pictures[f"weights_ideal_{kind}"] = ideal_operator.mixing.cpu().numpy().copy()
        pictures[f"weights_extension_{kind}"] = (
            extension_operator.mixing.cpu().numpy().copy()
        )
        # Query preparation belongs to inference. It uses only initial data and the specified law.
        inference = measure(
            lambda: evaluate(
                ideal_operator, query(test_specs[:1], TIMES, x, device, 0.0)
            ),
            device,
        )
        solver_seconds = min(
            controls[name]["seconds"] for name in ("newmark", "verlet")
        )
        result["methods"][kind] = {
            "parameter_count": ideal_operator.mixing.numel(),
            "parameter_bytes": ideal_operator.mixing.numel()
            * ideal_operator.mixing.element_size(),
            "ideal_error": ideal_err.tolist(),
            "ideal_accepted": int(np.sum(ideal_err.max(axis=1) <= HARD_BUDGET)),
            "dispersion_error": extension_err.tolist(),
            "dispersion_accepted": int(
                np.sum(extension_err.max(axis=1) <= HARD_BUDGET)
            ),
            "ideal_mirror": mirror(ideal_prediction),
            "dispersive_mirror": mirror(extension_prediction),
            "train_pde_rms": float(pde_fit.square().mean().sqrt()),
            "train_pde_data_only_rms": float(pde_data_only.square().mean().sqrt()),
            "train_pde_base_rms": float(pde_base.square().mean().sqrt()),
            "pde_weight": 5e-7,
            "energy_relative_error_smooth": (
                np.abs(energy - energy_reference) / energy_reference
            ).tolist(),
            "fit_seconds": fit_time,
            "inference": inference,
            "amortization_verlet_or_newmark": amortized(
                training_seconds + fit_time, inference["seconds"], solver_seconds
            ),
            "amortization_dalembert": amortized(
                training_seconds + fit_time,
                inference["seconds"],
                result["analytic"]["seconds"],
            ),
            "non_smooth": transform_controls(kind, x, device, pictures),
        }
        print(
            kind,
            f"CP2 {100 * ideal_err.max():.4f} %, dispersiv {100 * extension_err.max():.3f} %",
            flush=True,
        )
    np.savez_compressed(output / "saite_felder.npz", **pictures)
    write_report(output / "saite_operatoren.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--device", default="cpu", choices=("cpu", "cuda"))
    args = parser.parse_args()
    run(args.out, configure_device(args.device))


if __name__ == "__main__":
    main()
