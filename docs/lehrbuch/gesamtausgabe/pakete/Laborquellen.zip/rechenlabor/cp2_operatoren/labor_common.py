"""Training, accuracy and resource metrics shared by both CP2 experiments."""

from __future__ import annotations

import json
import math
from pathlib import Path
from statistics import median
from threading import Event, Thread
from time import perf_counter

import numpy as np
import psutil
import torch


def environment(device):
    import platform

    return {
        "python": platform.python_version(),
        "torch": torch.__version__,
        "numpy": np.__version__,
        "platform": platform.machine(),
        "threads": torch.get_num_threads(),
        "device": str(device),
        "cuda_available": torch.cuda.is_available(),
        "cpu_count": psutil.cpu_count(logical=True),
    }


def configure_device(name):
    torch.set_num_threads(1)
    device = torch.device(name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA was requested, but a supported CUDA device is unavailable"
        )
    return device


def tensor(values, device):
    return torch.as_tensor(values, dtype=torch.float64, device=device)


def correction_matrix(mixing, features):
    return torch.einsum("of,bf...->bo...", mixing, features)


def rows(field):
    return field.movedim(1, -1).reshape(-1, field.shape[1])


def regression_terms(features, target):
    """Sufficient statistics for the pointwise quadratic field loss."""
    design, values = rows(features), rows(target)
    gram = design.T @ design / len(design)
    cross = values.T @ design / len(design)
    output_count = cross.shape[0]
    joint = torch.kron(
        torch.eye(output_count, dtype=gram.dtype, device=gram.device), gram.contiguous()
    )
    return joint, cross.flatten()


def constraint_terms(design, forcing):
    """Quadratic residual of a linear physical constraint in the same parameters."""
    design_rows = rows(design)
    target = forcing.reshape(-1)
    if len(design_rows) != len(target):
        raise ValueError("constraint and forcing must cover the same grid")
    return design_rows.T @ design_rows / len(target), design_rows.T @ target / len(
        target
    )


def fit_operator(
    model, features, target, constraint=None, strength=0.0, prior=None, ridge=1e-8
):
    normal, rhs = regression_terms(features, target)
    if constraint is not None and strength:
        physics_normal, physics_rhs = constraint_terms(*constraint)
        normal = normal + strength * physics_normal
        rhs = rhs + strength * physics_rhs
    scale = normal.diag().clamp_min(1e-20).sqrt()
    equilibrated = normal / (scale[:, None] * scale[None])
    regularization = ridge * torch.eye(len(rhs), dtype=rhs.dtype, device=rhs.device)
    prior_term = 0.0 if prior is None else ridge * scale * prior.flatten()
    optimum = (
        torch.linalg.solve(equilibrated + regularization, rhs / scale + prior_term)
        / scale
    )
    with torch.no_grad():
        model.mixing.copy_(optimum.reshape_as(model.mixing))
    return model


def relative_error(prediction, truth):
    values = (prediction - truth).reshape(len(truth), -1)
    reference = truth.reshape(len(truth), -1)
    return np.linalg.norm(values, axis=1) / np.maximum(
        np.linalg.norm(reference, axis=1), 1e-30
    )


def measure(call, device, repeats=9):
    """Median end-to-end latency and sampled process RSS or allocator high-water mark."""
    process = psutil.Process()
    gpu = device.type == "cuda"
    synchronize = (lambda: torch.cuda.synchronize(device)) if gpu else (lambda: None)
    call()
    synchronize()
    elapsed = []
    for _ in range(repeats):
        started = perf_counter()
        call()
        synchronize()
        elapsed.append(perf_counter() - started)
    rss_before = process.memory_info().rss
    sampled_peak = [rss_before]
    finished = Event()

    def poll_memory():
        while not finished.is_set():
            sampled_peak[0] = max(sampled_peak[0], process.memory_info().rss)
            finished.wait(0.0005)

    if gpu:
        torch.cuda.reset_peak_memory_stats(device)
    thread = Thread(target=poll_memory)
    thread.start()
    try:
        for _ in range(3):
            answer = call()
            synchronize()
            sampled_peak[0] = max(sampled_peak[0], process.memory_info().rss)
            del answer
    finally:
        finished.set()
        thread.join()
    return {
        "seconds": median(elapsed),
        "timing_samples_s": elapsed,
        "cpu_rss_bytes": sampled_peak[0],
        "cpu_rss_before_bytes": rss_before,
        "cuda_allocated_peak_bytes": torch.cuda.max_memory_allocated(device)
        if gpu
        else None,
    }


def amortized(training_seconds, operator_seconds, solver_seconds):
    saving = solver_seconds - operator_seconds
    return math.floor(training_seconds / saving) + 1 if saving > 0 else None


def write_report(file: Path, report):
    file.parent.mkdir(parents=True, exist_ok=True)
    file.write_text(
        json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
