"""Render the two chapter figures using the stored benchmark fields."""

from argparse import ArgumentParser
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


INK, TEAL, ORANGE, BLUE = "#173549", "#00796b", "#b94c35", "#3a6796"


def save(fig, name, root):
    for directory, suffix, metadata in (
        ("abbildungen", "svg", {"Date": None}),
        ("druck", "pdf", {"CreationDate": None}),
    ):
        fig.savefig(root / directory / f"{name}.{suffix}", metadata=metadata)
    plt.close(fig)


def knick(measurements, root):
    with np.load(measurements / "saite_felder.npz", allow_pickle=False) as data:
        fig, (rope, shock) = plt.subplots(
            2, 1, figsize=(7.0, 3.85), layout="constrained"
        )
        x = data["x"]
        rope.plot(x, data["rope_reference"], color=INK, label="d’Alembert", lw=1.65)
        for key, color, label, style in (
            ("fourier", ORANGE, "Fourier", "--"),
            ("wavelet", TEAL, "Haar", ":"),
        ):
            rope.plot(
                x, data[f"rope_projection_{key}"], color=color, label=label, ls=style
            )
        rope.set(xlim=(0.018, 0.100), xlabel="Ort [m]", ylabel="Auslenkung [m]")
        rope.set_title("Knick der Saite bei 5 s", loc="left")
        rope.legend(loc="lower right", frameon=False, fontsize=8)
        ref = data["burgers_reference"]
        mid = len(ref) // 2
        coordinate = np.linspace(-1, 1, len(ref))
        shock.plot(coordinate, ref[mid], color=INK, lw=1.55, label="Entropiefront")
        for key, color, label in (
            ("fourier", ORANGE, "Fourier"),
            ("hankel", BLUE, "Hankel"),
        ):
            shock.plot(
                coordinate,
                data[f"burgers_{key}"][mid],
                color=color,
                ls="--",
                label=label,
            )
        for level in (0.2, 1.0):
            shock.axhline(level, color="#98a5af", linewidth=0.65, linestyle=":")
        shock.set(
            xlim=(-0.23, 0.32),
            xlabel="Ort beim Schnitt y = 0",
            ylabel="Burgers-Zustand",
        )
        shock.set_title("Schnitt durch die schräge Front", loc="left")
        shock.legend(loc="upper right", frameon=False, fontsize=8)
    save(fig, "cp2_operator_knick", root)


def ghia(measurements, root):
    with np.load(measurements / "kavitaet_felder.npz", allow_pickle=False) as data:
        fig, panels = plt.subplots(1, 2, figsize=(7.0, 2.65), layout="constrained")
        for name, color, linestyle, legend in (
            ("reference_n421", INK, "-", "D2Q9"),
            ("affine_n421", ORANGE, "--", "Affin"),
            ("prediction_421_fourier", TEAL, ":", "Affin + Fourier"),
        ):
            field = data[name]
            size = field.shape[-1]
            axis = (np.arange(size) + 0.5) / size
            panels[0].plot(
                field[0, :, size // 2], axis, color=color, ls=linestyle, label=legend
            )
            panels[1].plot(
                axis, field[1, size // 2, :], color=color, ls=linestyle, label=legend
            )
        for panel, key, xlabel, ylabel in zip(
            panels,
            ("ghia_u", "ghia_v"),
            ("Horizontalkomponente u/U", "Breite x/L"),
            ("Höhe y/L", "Vertikalkomponente v/U"),
            strict=True,
        ):
            x, y = data[key].T
            panel.scatter(
                y if key == "ghia_u" else x,
                x if key == "ghia_u" else y,
                facecolors="white",
                edgecolors=INK,
                linewidth=0.9,
                s=14,
                label="Ghia et al.",
                zorder=4,
            )
            panel.set(xlabel=xlabel, ylabel=ylabel)
        panels[0].set_ylim(0, 1)
        panels[1].set_xlim(0, 1)
        panels[0].set_title("A   Vertikale Mittellinie", loc="left")
        panels[1].set_title("B   Horizontale Mittellinie", loc="left")
        panels[0].legend(loc="lower right", frameon=False, fontsize=7.6)
    save(fig, "cp2_operator_ghia", root)


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--messung", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "font.size": 9.3,
            "text.color": INK,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "pdf.fonttype": 42,
            "svg.hashsalt": "cp2-operatoren-v96",
        }
    )
    knick(args.messung, root)
    ghia(args.messung, root)


if __name__ == "__main__":
    main()
