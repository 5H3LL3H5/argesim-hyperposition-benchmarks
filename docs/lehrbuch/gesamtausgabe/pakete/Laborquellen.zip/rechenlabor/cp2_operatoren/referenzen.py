"""CP2 reference solvers and deterministic benchmark cohorts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory

import numpy as np
from scipy.ndimage import map_coordinates


HERE = Path(__file__).resolve().parent
LID_SPEED = 0.055
TRAIN = [
    (65, reynolds, amplitude)
    for reynolds in (70, 90, 110)
    for amplitude in (-0.32, -0.11, 0.11, 0.32)
]
VALIDATION = {
    "Re100": [(65, 100, 0.0), (65, 100, 0.23)],
    "Re140": [(65, 140, 0.14), (65, 140, -0.16), (65, 140, 0.18), (65, 140, -0.13)],
    "129": [(129, 100, 0.0)],
    "257": [(257, 100, 0.0)],
    "421": [(421, 100, 0.0), (421, 100, 0.23)],
}
CALIBRATION = {
    "Re140": [(65, 140, amplitude) for amplitude in (0.0, -0.24, 0.27, 0.06)],
    "421": [(421, 100, amplitude) for amplitude in (-0.19, 0.12)],
}


def build_cpp(destination: Path) -> Path:
    """Build once into the separate run directory, leaving the source tree clean."""
    destination.mkdir(parents=True, exist_ok=True)
    binary = destination.resolve() / "cp2_referenz"
    source = HERE / "cp2_referenz.cpp"
    if not binary.is_file() or binary.stat().st_mtime_ns < source.stat().st_mtime_ns:
        with TemporaryDirectory(dir=destination) as temporary:
            candidate = Path(temporary) / "cp2_referenz"
            subprocess.run(
                [
                    "c++",
                    "-std=c++20",
                    "-O3",
                    "-Wall",
                    "-Wextra",
                    "-Werror",
                    "-pedantic",
                    str(source),
                    "-o",
                    str(candidate),
                ],
                check=True,
            )
            candidate.replace(binary)
    return binary


def resize_centers(field: np.ndarray, size: int) -> np.ndarray:
    old = field.shape[-1]
    if size == old:
        return field.copy()
    coordinate = (np.arange(size) + 0.5) * old / size - 0.5
    grid = np.meshgrid(coordinate, coordinate, indexing="ij")
    flat = field.reshape(-1, old, old)
    result = np.stack(
        [map_coordinates(row, grid, order=1, mode="nearest") for row in flat]
    )
    return result.reshape(*field.shape[:-2], size, size)


def load_result(path: Path):
    with np.load(path, allow_pickle=False) as record:
        return record["fields"], json.loads(str(record["report"]))


def cavity_case(
    size: int, reynolds: int, amplitude: float, directory: Path, binary: Path
):
    identifier = f"n{size}_re{reynolds}_a{amplitude:+.3f}"
    path = directory / (identifier + ".npz")
    if path.is_file():
        return load_result(path)
    directory.mkdir(parents=True, exist_ok=True)
    with TemporaryDirectory(dir=directory) as temporary:
        stage = Path(temporary)
        raw = stage / "field.bin"
        warm = stage / "warm.bin"
        warm_seconds = 0.0
        if size > 65:
            seed, cost = cavity_case(65, reynolds, amplitude, directory, binary)
            resize_centers(seed[-1], size).transpose(1, 2, 0).tofile(warm)
            warm_seconds = cost["seconds"]
        limits = ("8", "1.5") if size > 65 else ("26", "7")
        cmd = [
            str(binary),
            "cavity",
            str(size),
            str(reynolds),
            str(amplitude),
            str(LID_SPEED),
            *limits,
            str(raw),
        ]
        if warm.is_file():
            cmd.append(str(warm))
        result = subprocess.run(cmd, check=True, text=True, capture_output=True)
        report = json.loads(result.stdout)
        report["warm_reference_seconds"] = warm_seconds
        report["quasisteady"] = report["relative_change"] <= 1.0e-4
        fields = np.fromfile(raw).reshape(4, size, size, 2).transpose(0, 3, 1, 2).copy()
        if not np.isfinite(fields).all() or abs(report["mass_ratio"] - 1.0) > 1e-9:
            raise ArithmeticError(f"invalid field or mass drift, {identifier}")
        candidate = stage / "record.npz"
        np.savez_compressed(
            candidate, fields=fields, report=json.dumps(report, allow_nan=False)
        )
        candidate.replace(path)
    print(
        identifier,
        report["steps"],
        f"{report['relative_change']:.3g}",
        f"{report['seconds']:.3f} s",
        flush=True,
    )
    return fields, report


def string_case(
    binary: Path,
    scratch: Path,
    method: str,
    size: int,
    pluck: float = 0.5,
    amplitude: float = 0.05,
    step: float = 0.01,
):
    with TemporaryDirectory(dir=scratch) as temporary:
        output = Path(temporary) / "reference.bin"
        process = subprocess.run(
            [
                str(binary),
                "string",
                method,
                str(size),
                str(pluck),
                str(amplitude),
                str(step),
                str(output),
            ],
            text=True,
            capture_output=True,
            check=True,
        )
        return np.fromfile(output).reshape(2, size), json.loads(process.stdout)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--group", choices=("all", "coarse", "fine"), default="all")
    args = parser.parse_args()
    binary = build_cpp(args.out)
    cases = dict.fromkeys(
        TRAIN + sum(VALIDATION.values(), []) + sum(CALIBRATION.values(), [])
    )
    for case in cases:
        if args.group == "all" or (args.group == "coarse") == (case[0] == 65):
            cavity_case(*case, args.out / "lbm_cache", binary)


if __name__ == "__main__":
    main()
