"""Comparable, small spectral neural operators built with differentiable PyTorch layers."""

from __future__ import annotations

import math

import torch
from torch import nn
import torch.nn.functional as F


TRANSFORMS = (
    "fourier",
    "laplace",
    "wavelet",
    "hankel",
    "radon",
    "wavelet_laplace",
    "fourier_mellin",
)


def fourier_bands(field):
    """Three disjoint bands below a common truncation of the rectangular FFT."""
    shape = field.shape[2:]
    axes = tuple(range(2, field.ndim))
    spectrum = torch.fft.rfftn(field.contiguous(), dim=axes)
    frequencies = [
        torch.fft.fftfreq(
            size, d=1 / size, device=field.device, dtype=field.dtype
        ).abs()
        for size in shape[:-1]
    ]
    frequencies.append(
        torch.arange(spectrum.shape[-1], device=field.device, dtype=field.dtype)
    )
    grids = torch.meshgrid(*frequencies, indexing="ij")
    order = torch.stack(grids).amax(dim=0)
    return [
        torch.fft.irfftn(
            spectrum * ((order > lower) & (order <= upper)), s=shape, dim=axes
        )
        for lower, upper in ((-1, 4), (4, 12), (12, 32))
    ]


def haar_bands(field):
    """Synthesis of groups of separable Haar subbands on a replicate-padded grid."""
    dimensions = field.ndim - 2
    shape = field.shape[2:]
    pads = tuple(value for size in reversed(shape) for value in (0, (-size) % 8))
    padded = F.pad(field, pads, mode="replicate")
    average = F.avg_pool1d if dimensions == 1 else F.avg_pool2d
    region = (slice(None), slice(None), *(slice(0, size) for size in shape))
    approximations = [
        F.interpolate(
            average(padded, factor, stride=factor), scale_factor=factor, mode="nearest"
        )[region]
        for factor in (2, 8)
    ]
    fine, coarse = approximations
    return [coarse, fine - coarse, field - fine]


def laplace_channels(history, times):
    """End-time readouts of a fixed stable conjugate pole pair, by trapezoidal quadrature."""
    lag = 1.0 - times
    decay = torch.exp(-2.0 * lag)
    real = decay * torch.cos(5.0 * lag)
    imag = decay * torch.sin(5.0 * lag)
    outputs = []
    for coefficients in (real, imag):
        weights = coefficients.reshape(1, -1, *([1] * (history.ndim - 2)))
        outputs.append(torch.trapezoid(history * weights, times, dim=1))
    return outputs


def odd_extension(field):
    for axis in range(2, field.ndim):
        count = field.shape[axis]
        boundary = torch.zeros_like(field.narrow(axis, 0, 1))
        interior = field.narrow(axis, 1, count - 2)
        field = torch.cat(
            (boundary, interior, boundary, -interior.flip((axis,))), dim=axis
        )
    return field


def hankel_bands(field):
    """Three Toeplitz minus reflected Hankel Green operators for Dirichlet ends."""
    extended = odd_extension(field)
    axes = tuple(range(2, field.ndim))
    spectrum = torch.fft.rfftn(extended.contiguous(), dim=axes)
    modes = [
        torch.fft.fftfreq(count, d=1 / count, device=field.device)
        if axis != axes[-1]
        else torch.arange(spectrum.shape[-1], device=field.device)
        for axis, count in zip(axes, extended.shape[2:], strict=True)
    ]
    symbols = [
        (size - 1) ** 2 * 4 * torch.sin(math.pi * mode / length) ** 2
        for size, length, mode in zip(
            field.shape[2:], extended.shape[2:], modes, strict=True
        )
    ]
    stiffness = sum(torch.meshgrid(*symbols, indexing="ij"))
    region = (slice(None), slice(None), *(slice(0, size) for size in field.shape[2:]))
    return [
        torch.fft.irfftn(
            spectrum / (1 + stiffness / pole**2), s=extended.shape[2:], dim=axes
        )[region]
        for pole in (8.0, 32.0, 128.0)
    ]


def sample(field, grid, padding="zeros"):
    return F.grid_sample(
        field,
        grid[None].expand(len(field), *grid.shape),
        mode="bilinear",
        align_corners=True,
        padding_mode=padding,
    )


def coordinate(size, field):
    return torch.linspace(-1, 1, size, dtype=field.dtype, device=field.device)


def radon_bands(field):
    if field.ndim == 3:
        # The two 1D normals are +1 and -1. Orient their backprojections alike.
        return [
            0.5
            * (
                F.avg_pool1d(
                    F.pad(field, (width // 2, width // 2), mode="replicate"),
                    width,
                    stride=1,
                )
                + F.avg_pool1d(
                    F.pad(
                        field.flip((-1,)), (width // 2, width // 2), mode="replicate"
                    ),
                    width,
                    stride=1,
                ).flip((-1,))
            )
            for width in (1, 5, 13)
        ]
    if field.shape[-1] != field.shape[-2]:
        raise ValueError("the Radon lab uses a square spatial domain")
    size = field.shape[-1]
    pad = math.ceil(size * (math.sqrt(2) - 1) / 2)
    wide = F.pad(field, (pad,) * 4)
    extent = wide.shape[-1]
    full = coordinate(extent, field)
    yy, xx = torch.meshgrid(full, full, indexing="ij")
    yy_core = yy[pad : pad + size, pad : pad + size]
    xx_core = xx[pad : pad + size, pad : pad + size]
    frequencies = torch.fft.rfftfreq(extent, device=field.device).to(field.dtype)
    ramp = frequencies * (frequencies <= 0.38)
    groups = [torch.zeros_like(field) for _ in range(3)]
    for angle in range(8):
        theta = math.pi * angle / 8
        cosine, sine = math.cos(theta), math.sin(theta)
        rotated = sample(
            wide,
            torch.stack((cosine * xx - sine * yy, sine * xx + cosine * yy), dim=-1),
        )
        sinogram = rotated.sum(dim=-2)
        filtered = torch.fft.irfft(torch.fft.rfft(sinogram) * ramp, n=extent)
        offset = cosine * xx_core + sine * yy_core
        view = sample(
            filtered[:, :, None],
            torch.stack((offset, torch.zeros_like(offset)), dim=-1),
        )
        group = 0 if angle % 4 == 0 else 1 if angle % 2 == 0 else 2
        groups[group] = groups[group] + (math.pi / 8) * view
    return groups


def mellin_bands(field):
    """FFT bands in log-radius and angle, with explicit finite-grid interpolation."""
    size = field.shape[-1]
    radial_points = min(size, 128)
    cartesian = coordinate(size, field)
    log_min = math.log(max(1 / (size - 1), 0.008))
    if field.ndim == 3:
        radii = torch.linspace(
            log_min, 0.0, radial_points, device=field.device, dtype=field.dtype
        ).exp()
        grids = [
            torch.stack((direction * radii, torch.zeros_like(radii)), dim=-1)[None]
            for direction in (-1.0, 1.0)
        ]
        lifted = [
            sample(field[:, :, None], grid, "border").squeeze(-2) for grid in grids
        ]
        log_radius = (cartesian.abs().clamp_min(math.exp(log_min)).log() - log_min) * (
            2 / -log_min
        ) - 1
        grid = torch.stack((log_radius, torch.zeros_like(log_radius)), dim=-1)[None]
        branch_bands = [
            [
                sample(band[:, :, None], grid, "border").squeeze(-2)
                for band in fourier_bands(side)
            ]
            for side in lifted
        ]
        return [
            torch.where(cartesian < 0, left, right)
            for left, right in zip(*branch_bands, strict=True)
        ]
    size_y = field.shape[-2]
    angular_points = 64
    log_max = math.log(math.sqrt(2))
    log_radial = torch.linspace(
        log_min, log_max, radial_points, device=field.device, dtype=field.dtype
    )
    angle = torch.arange(angular_points, device=field.device, dtype=field.dtype) * (
        2 * math.pi / angular_points
    )
    theta, radius = torch.meshgrid(angle, log_radial.exp(), indexing="ij")
    polar = sample(
        field, torch.stack((radius * theta.cos(), radius * theta.sin()), dim=-1)
    )
    yy, xx = torch.meshgrid(coordinate(size_y, field), cartesian, indexing="ij")
    azimuth = torch.remainder(torch.atan2(yy, xx), 2 * math.pi) / math.pi - 1
    log_radius = (torch.hypot(xx, yy).clamp_min(math.exp(log_min)).log() - log_min) * (
        2 / (log_max - log_min)
    ) - 1
    grid = torch.stack((log_radius, azimuth), dim=-1)
    return [
        sample(torch.cat((band, band[:, :, :1]), dim=2), grid, "border")
        for band in fourier_bands(polar)
    ]


class HybridNeuralOperator(nn.Module):
    """One transform block plus learned band/field mixing and an optional physics field.

    history is [batch, time, input_channels, ...]. Times are common and normalized to [0,1].
    conditioning is [batch, conditioning_terms], with a constant one if no controls are used.
    An envelope can enforce a homogeneous correction on the physical boundary.
    """

    def __init__(
        self,
        transform_type,
        in_channels,
        out_channels,
        conditioning_terms=1,
        *,
        dtype=torch.float64,
    ):
        super().__init__()
        if transform_type not in TRANSFORMS:
            raise ValueError(f"unknown transform {transform_type!r}")
        if min(in_channels, out_channels, conditioning_terms) < 1:
            raise ValueError("channel and conditioning counts must be positive")
        self.transform_type = transform_type
        self.in_channels = in_channels
        self.conditioning_terms = conditioning_terms
        self.mixing = nn.Parameter(
            torch.zeros(out_channels, 3 * in_channels * conditioning_terms, dtype=dtype)
        )

    def features(self, history, times, conditioning, envelope=None):
        if history.ndim not in (4, 5) or history.shape[2] != self.in_channels:
            raise ValueError(
                "expected [batch, time, channels, x] or [batch, time, channels, y, x]"
            )
        if times.shape != (history.shape[1],) or conditioning.shape != (
            len(history),
            self.conditioning_terms,
        ):
            raise ValueError("history, time and conditioning shapes disagree")
        last = history[:, -1]
        kind = self.transform_type
        if kind == "laplace":
            bands = [last, *laplace_channels(history, times)]
        elif kind == "wavelet_laplace":
            wav = haar_bands(last)
            real, imag = laplace_channels(history, times)
            bands = [wav[0], wav[1] + haar_bands(real)[0], wav[2] + haar_bands(imag)[0]]
        else:
            operators = {
                "fourier": fourier_bands,
                "wavelet": haar_bands,
                "hankel": hankel_bands,
                "radon": radon_bands,
                "fourier_mellin": mellin_bands,
            }
            bands = operators[kind](last)
        spatial_ones = [1] * (last.ndim - 2)
        base = torch.cat(bands, dim=1)
        features = base[:, None] * conditioning.reshape(len(last), -1, 1, *spatial_ones)
        features = features.flatten(1, 2)
        return features if envelope is None else features * envelope

    def forward(self, history, times, conditioning, physics=None, envelope=None):
        design = self.features(history, times, conditioning, envelope)
        correction = torch.einsum("of,bf...->bo...", self.mixing, design)
        return correction if physics is None else physics + correction
