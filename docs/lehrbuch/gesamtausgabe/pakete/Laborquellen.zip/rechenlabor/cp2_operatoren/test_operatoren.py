"""Cross-check the numerical reference and the shared learned-operator interfaces."""

from pathlib import Path
import json
import subprocess
import sys
from tempfile import TemporaryDirectory

import numpy as np
import torch

from cp2_lbm_cavity_surrogate import FluxProjection, divergence
from cp2_saite_benchmark import analytic_controls, shape_at, tents, wave_field
from hybrid_operator import (
    HybridNeuralOperator,
    TRANSFORMS,
    haar_bands,
    hankel_bands,
    mellin_bands,
    radon_bands,
)
from labor_common import configure_device, fit_operator, tensor
from referenzen import build_cpp, LID_SPEED


def check_transforms(device):
    generator = torch.Generator().manual_seed(22319)
    for shape in ((51,), (27, 27)):
        state = torch.randn(
            (2, 5, 2, *shape), generator=generator, dtype=torch.float64
        ).to(device)
        times = tensor(np.linspace(0, 1, 5), device)
        factors = tensor(np.ones((2, 1)), device)
        field = state[:, -1]
        assert torch.allclose(sum(haar_bands(field)), field, rtol=0, atol=6e-16)
        for method in TRANSFORMS:
            module = HybridNeuralOperator(method, 2, 2).to(device)
            assert torch.equal(module(state, times, factors, physics=field), field)
            packed = module.features(state, times, factors)
            expected = packed[:, [0, 1]] + 0.2 * packed[:, [2, 3]]
            fit_operator(module, packed, expected)
            correction = module(state, times, factors)
            assert (
                torch.linalg.vector_norm(expected - correction)
                / torch.linalg.vector_norm(expected)
                < 5e-7
            )
            correction.square().mean().backward()
            assert torch.isfinite(module.mixing.grad).all()
            state_dict = module.state_dict()
            clone = HybridNeuralOperator(method, 2, 2).to(device)
            clone.load_state_dict(state_dict)
            assert torch.equal(clone(state, times, factors), correction)
        for encoded in hankel_bands(field):
            assert (
                encoded[..., 0].abs().max() < 5e-15
                and encoded[..., -1].abs().max() < 5e-15
            )
    line = tensor(np.sin(np.linspace(0, np.pi, 501))[None, None], device)
    assert torch.equal(radon_bands(line)[0], line)
    coarse = tents(0.29, 0.053)
    fine = tents(0.71, 0.053)
    x = np.linspace(0, 1, 501)
    assert (
        np.max(
            abs(
                wave_field(coarse, [5.0, 8.0], x)
                - wave_field(fine, [5.0, 8.0], x)[:, ::-1]
            )
        )
        < 1e-15
    )
    assert np.max(abs(shape_at(coarse, np.array([0.0, 1.0])))) == 0.0


def check_flux(device):
    rng = np.random.default_rng(42)
    value = tensor(rng.normal(size=(3, 2, 17, 17)), device)
    operator = FluxProjection(17, device)
    projected = operator.apply(value)
    derivative = operator.difference
    flux = projected[:, 0] @ derivative.T + derivative @ projected[:, 1]
    assert flux.abs().max() < 2e-12
    assert divergence(projected).abs().max() < 2e-12
    assert torch.allclose(projected, operator.apply(projected), rtol=0, atol=2e-13)


def mellin_witness(device):
    axis = np.linspace(-1, 1, 129)
    yy, xx = np.meshgrid(axis, axis, indexing="ij")
    radius = np.hypot(xx, yy)
    mask = (radius > 0.12) & (radius < 0.78)

    def annulus(r):
        return np.exp(-((np.log(np.maximum(r, 1e-12) / 0.4) / 0.26) ** 2))

    pairs = np.stack((annulus(radius), annulus(radius / 1.19)))
    reconstructed = (
        sum(mellin_bands(tensor(pairs[:, None], device)))[:, 0].cpu().numpy()
    )
    relative = np.linalg.norm((reconstructed - pairs)[:, mask]) / np.linalg.norm(
        pairs[:, mask]
    )
    assert relative < 0.035
    return relative


def check_cpp(output, binary):
    # Independent scalar collision/streaming code already in the book.
    sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "beispiele"))
    from lbm_d2q9 import D2Q9

    size = 9
    omega = 0.5 + 3 * LID_SPEED * size / 100
    old = D2Q9(size, size, omega, lid=LID_SPEED, boundary="halbweg")
    worst = 0.0
    last = 0
    for steps in (1, 7, 16):
        for _ in range(steps - last):
            old.step()
        last = steps
        expected = np.asarray(old.field())[:, 1:].reshape(size, size, 2) / LID_SPEED
        raw = output / "check.bin"
        line = subprocess.check_output(
            [
                binary,
                "cavity",
                str(size),
                "100",
                "0",
                str(LID_SPEED),
                str(steps * LID_SPEED / size),
                "0",
                raw,
            ],
            text=True,
        )
        assert json.loads(line)["steps"] == steps
        actual = np.fromfile(raw).reshape(4, size, size, 2)[-1]
        worst = max(worst, np.max(abs(actual - expected)))
    assert worst < 1e-13
    analytic_controls(binary, output, np.linspace(0, 1, 501))
    return worst


def main():
    device = configure_device("cpu")
    check_transforms(device)
    check_flux(device)
    radius_defect = mellin_witness(device)
    with TemporaryDirectory() as scratch:
        output = Path(scratch)
        worst = check_cpp(output, build_cpp(output))
    print(
        "7 PyTorch-Varianten auf zwei Rasterdimensionen, Trainingslösung und Zustandsübernahme geprüft."
    )
    print(
        f"Diskrete Flussprojektion und ihre Idempotenz geprüft. Mellin-Ring, relativer Defekt {radius_defect:.5g}."
    )
    print(
        f"D2Q9 nach 1, 7 und 16 Schritten gegen Python. Größter Defekt gegenüber dem Deckeltempo {worst:.5g}."
    )
    print(
        "C++20-Saitenintegratoren und Newmark-Residual gegen exakt diskrete Moden geprüft."
    )


if __name__ == "__main__":
    main()
