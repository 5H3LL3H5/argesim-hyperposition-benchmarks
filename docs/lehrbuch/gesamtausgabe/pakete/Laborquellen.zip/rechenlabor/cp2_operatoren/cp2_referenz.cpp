// Independent double-precision references for the CP2 operator lab (C++20).
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numbers>
#include <span>
#include <stdexcept>
#include <string>
#include <vector>

using Clock = std::chrono::steady_clock;
constexpr double pi = std::numbers::pi_v<double>;

double seconds(Clock::time_point start) {
    return std::chrono::duration<double>(Clock::now() - start).count();
}

void write_values(std::ofstream& stream, std::span<const double> values) {
    stream.write(reinterpret_cast<const char*>(values.data()),
                 static_cast<std::streamsize>(values.size_bytes()));
    if (!stream) {
        throw std::runtime_error("could not write double-precision reference");
    }
}

void string_reference(int size, double pluck, double amplitude, double dt, bool newmark,
                      const std::string& output_path) {
    constexpr double length = 0.5, speed = 0.06;
    if (size < 3 || !(0.0 < pluck && pluck < 1.0) || !(dt > 0.0)) {
        throw std::invalid_argument("invalid string parameters");
    }
    const double ratio = speed * dt * (size - 1) / length;
    if (!newmark && ratio > 1.0) {
        throw std::invalid_argument("Verlet violates the wave CFL condition");
    }
    const double q = ratio * ratio;
    const int last_step = static_cast<int>(std::llround(8.0 / dt));
    const int first_save = static_cast<int>(std::llround(5.0 / dt));
    if (std::abs(last_step * dt - 8.0) > 1e-12 || std::abs(first_save * dt - 5.0) > 1e-12) {
        throw std::invalid_argument("selected time step must reach 5 and 8 s exactly");
    }
    std::vector<double> previous(size), current(size), next(size), rhs(size), upper(size);
    std::array<std::vector<double>, 2> snapshots{std::vector<double>(size), std::vector<double>(size)};
    const double diagonal = 1 + q / 2, off_diagonal = -q / 4;
    const auto started = Clock::now();
    for (int i = 1; i < size - 1; ++i) {
        const double x = static_cast<double>(i) / (size - 1);
        current[i] = amplitude * std::min(x / pluck, (1 - x) / (1 - pluck));
    }
    // At initial rest, u^{-1}=u^1. The first step applies half the recurrence.
    previous = current;
    double max_residual = 0;
    for (int step = 1; step <= last_step; ++step) {
        for (int i = 1; i < size - 1; ++i) {
            const double laplace = current[i - 1] - 2 * current[i] + current[i + 1];
            if (newmark) {
                const double prev_lap = previous[i - 1] - 2 * previous[i] + previous[i + 1];
                rhs[i] = step == 1 ? current[i] + q * laplace / 4
                                  : 2 * current[i] + q * laplace / 2 - previous[i] + q * prev_lap / 4;
            } else {
                next[i] = step == 1 ? current[i] + q * laplace / 2
                                   : 2 * current[i] - previous[i] + q * laplace;
            }
        }
        if (newmark) {
            for (int i = 1; i < size - 1; ++i) {
                const double denominator = diagonal - off_diagonal * upper[i - 1];
                upper[i] = off_diagonal / denominator;
                next[i] = (rhs[i] - off_diagonal * next[i - 1]) / denominator;
            }
            for (int i = size - 2; i >= 1; --i) {
                next[i] -= upper[i] * next[i + 1];
            }
            for (int i = 1; i < size - 1; ++i) {
                const double residual = diagonal * next[i] + off_diagonal * (next[i - 1] + next[i + 1]) - rhs[i];
                max_residual = std::max(max_residual, std::abs(residual));
            }
        }
        previous.swap(current);
        current.swap(next);
        if (step == first_save || step == last_step) {
            snapshots[step == first_save ? 0 : 1] = current;
        }
    }
    const double elapsed = seconds(started);
    std::ofstream output(output_path, std::ios::binary);
    for (const auto& values : snapshots) {
        write_values(output, values);
    }
    std::cout << "{\"seconds\":" << elapsed << ",\"linear_residual_max\":" << max_residual
              << ",\"steps\":" << last_step << "}\n";
}

constexpr std::array dx{0, 1, 0, -1, 0, 1, -1, -1, 1};
constexpr std::array dy{0, 0, 1, 0, -1, 1, 1, -1, -1};
constexpr std::array opposite{0, 3, 4, 1, 2, 7, 8, 5, 6};
constexpr std::array weights{4./9, 1./9, 1./9, 1./9, 1./9, 1./36, 1./36, 1./36, 1./36};
using Site = std::array<double, 9>;

std::array<double, 3> moments(const Site& f) {
    const double density = f[0] + f[1] + f[2] + f[3] + f[4] + f[5] + f[6] + f[7] + f[8];
    const double inv = 1 / density;
    return {density, (f[1] - f[3] + f[5] - f[6] - f[7] + f[8]) * inv,
            (f[2] - f[4] + f[5] + f[6] - f[7] - f[8]) * inv};
}

Site equilibrium(double rho, double ux, double uy) {
    const double base = 1 - 1.5 * (ux * ux + uy * uy);
    const std::array dot{0., ux, uy, -ux, -uy, ux + uy, -ux + uy, -ux - uy, ux - uy};
    Site f{};
    for (unsigned i = 0; i < f.size(); ++i) {
        f[i] = (rho * weights[i]) * (base + dot[i] * (3 + 4.5 * dot[i]));
    }
    return f;
}

double velocity_change(std::span<const double> a, std::span<const double> b) {
    double difference = 0.0, energy = 0.0;
    for (std::size_t i = 0; i < a.size(); ++i) {
        difference += (a[i] - b[i]) * (a[i] - b[i]);
        energy += a[i] * a[i];
    }
    return std::sqrt(difference / std::max(energy, 1e-200));
}

// Pull streaming and halfway bounce-back. The lid takes priority at the top corners.
void advance_cavity(int n, double omega, std::span<const double> lid,
                    std::vector<Site>& f, std::vector<Site>& post) {
    const std::array offset{0, -1, -n, 1, n, -1-n, 1-n, 1+n, -1+n};
    // Both arrays hold post-collision populations. At step zero they are
    // at equilibrium. Pull, then collide locally; collision preserves moments.
    auto collide = [&](int k, const Site& arrived) {
        const auto [rho, ux, uy] = moments(arrived);
        const auto eq = equilibrium(rho, ux, uy);
        for (unsigned j = 0; j < eq.size(); ++j) {
            post[k][j] = arrived[j] + omega * (eq[j] - arrived[j]);
        }
    };
    for (int y = 0; y < n; ++y) {
        auto wall_site = [&](int x) {
            const int k = y * n + x;
            Site arrived{};
            for (unsigned j = 0; j < arrived.size(); ++j) {
                const int source_x = x - dx[j], source_y = y - dy[j];
                if (source_x < 0 || source_x >= n || source_y < 0 || source_y >= n) {
                    const double correction = source_y >= n ? 6 * weights[j] * dx[j] * lid[x] : 0.0;
                    arrived[j] = f[k][opposite[j]] + correction;
                } else {
                    arrived[j] = f[k + offset[j]][j];
                }
            }
            collide(k, arrived);
        };
        if (y == 0 || y == n - 1) {
            for (int x = 0; x < n; ++x) {
                wall_site(x);
            }
        } else {
            wall_site(0);
            for (int x = 1; x < n - 1; ++x) {
                const int k = y * n + x;
                Site arrived{};
                for (unsigned j = 0; j < arrived.size(); ++j) {
                    arrived[j] = f[k + offset[j]][j];
                }
                collide(k, arrived);
            }
            wall_site(n - 1);
        }
    }
    f.swap(post);
}

void cavity_reference(int n, double reynolds, double amplitude, double speed, double max_time,
                      double min_time, const std::string& output_path, const std::string& warm_path) {
    if (n < 5 || n > 2001 || !(reynolds > 0.0) || !(speed > 0.0) || !(max_time > 0.0)
        || !(min_time >= 0.0 && min_time <= max_time) || !std::isfinite(amplitude)) {
        throw std::invalid_argument("invalid cavity parameters");
    }
    const auto elapsed = Clock::now();
    const int cells = n * n;
    const double omega = 1 / (0.5 + 3 * speed * n / reynolds);
    std::vector<Site> f(cells, weights), post(cells);
    std::vector<double> old_field(2 * cells), field(2 * cells);
    if (!warm_path.empty()) {
        std::ifstream warm(warm_path, std::ios::binary);
        warm.read(reinterpret_cast<char*>(field.data()), static_cast<std::streamsize>(field.size() * sizeof(double)));
        if (!warm || warm.peek() != std::ifstream::traits_type::eof()) {
            throw std::runtime_error("warm-start field has wrong size");
        }
        for (int k = 0; k < cells; ++k) {
            f[k] = equilibrium(1.0, speed * field[2 * k], speed * field[2 * k + 1]);
        }
        old_field = field;
    }
    std::vector<double> lid(n);
    for (int x = 0; x < n; ++x) {
        const double shape = std::sin(pi * (x + 0.5) / n);
        lid[x] = speed * (1.0 + amplitude * shape * shape);
    }
    const auto steps_for = [&](double time) { return std::max(1, static_cast<int>(std::llround(time * n / speed))); };
    const int spacing = steps_for(0.5);
    const int minimum_steps = steps_for(min_time);
    // Compare full monitor intervals even when the rounded final time misses a check.
    const int windows = static_cast<int>(std::floor(max_time / 0.5));
    const int maximum_steps = windows == 0 ? steps_for(max_time) : windows * spacing;
    const std::array capture{steps_for(0.4), steps_for(1.2), steps_for(3.5)};
    std::array<std::vector<double>, 3> snapshots;
    double change = 1.0, mass = 1.0;
    int steps = 0;
    auto observe = [&]() {
        double total_mass = 0.0;
        for (int k = 0; k < cells; ++k) {
            const auto [rho, ux, uy] = moments(f[k]);
            if (!std::isfinite(rho) || !(rho > 0.0)) {
                throw std::runtime_error("nonphysical density");
            }
            total_mass += rho;
            field[2 * k] = ux / speed;
            field[2 * k + 1] = uy / speed;
        }
        mass = total_mass / cells;
    };
    for (int step = 1; step <= maximum_steps; ++step) {
        advance_cavity(n, omega, lid, f, post);
        steps = step;
        const auto hit = std::find(capture.begin(), capture.end(), step);
        const bool monitor = step % spacing == 0 || step == maximum_steps;
        if (monitor || hit != capture.end()) {
            observe();
            if (hit != capture.end()) {
                snapshots[static_cast<std::size_t>(hit - capture.begin())] = field;
            }
            if (monitor) {
                change = velocity_change(field, old_field);
                old_field = field;
                if (step >= minimum_steps && change <= 1.0e-4) {
                    break;
                }
            }
        }
    }
    const double duration = seconds(elapsed);
    std::ofstream output(output_path, std::ios::binary);
    for (const auto& snapshot : snapshots) {
        write_values(output, snapshot.empty() ? field : snapshot);
    }
    write_values(output, field);
    std::cout << "{\"seconds\":" << duration << ",\"steps\":" << steps
              << ",\"relative_change\":" << change << ",\"mass_ratio\":" << mass
              << ",\"time_star\":" << steps * speed / n << "}\n";
}

// Output every completed interval in unit U_ref. Viscosity remains fixed over the history.
void cavity_history(int n, double reynolds, double reference_speed, int block_steps,
                    std::span<const double> history, const std::string& output_path) {
    if (n < 5 || n > 2001 || !std::isfinite(reynolds) || reynolds <= 0 ||
        !std::isfinite(reference_speed) || reference_speed <= 0 ||
        block_steps < 1 || history.empty()) {
        throw std::invalid_argument("invalid cavity history");
    }
    const int cells = n * n;
    const double omega = 1.0 / (0.5 + 3.0 * reference_speed * n / reynolds);
    std::vector<Site> f(cells, weights), post(cells);
    std::vector<double> lid(n), velocity(2 * cells);
    std::ofstream output(output_path, std::ios::binary);
    double worst_mass_drift = 0.0;
    double integration_time = 0.0;
    for (const double factor : history) {
        if (!std::isfinite(factor)) throw std::invalid_argument("nonfinite lid input");
        const auto start = Clock::now();
        std::fill(lid.begin(), lid.end(), reference_speed * factor);
        for (int step = 0; step < block_steps; ++step) advance_cavity(n, omega, lid, f, post);
        double mass = 0.0;
        for (int k = 0; k < cells; ++k) {
            const auto [rho, ux, uy] = moments(f[k]);
            if (!(rho > 0.0) || !std::isfinite(rho + ux + uy)) {
                throw std::runtime_error("invalid population moments");
            }
            mass += rho;
            velocity[2 * k] = ux / reference_speed;
            velocity[2 * k + 1] = uy / reference_speed;
        }
        worst_mass_drift = std::max(worst_mass_drift, std::abs(mass / cells - 1.0));
        integration_time += seconds(start);
        write_values(output, velocity);
    }
    std::cout << "{\"seconds\":" << integration_time << ",\"max_mass_drift\":" << worst_mass_drift
              << ",\"blocks\":" << history.size() << "}\n";
}

int main(int argc, char** argv) {
    try {
        std::cout << std::setprecision(16);
        if (argc == 8 && std::string(argv[1]) == "string") {
            const std::string method(argv[2]);
            if (method != "verlet" && method != "newmark") {
                throw std::invalid_argument("unknown string integrator");
            }
            string_reference(std::stoi(argv[3]), std::stod(argv[4]), std::stod(argv[5]),
                             std::stod(argv[6]), method == "newmark", argv[7]);
        } else if (argc >= 8 && std::string(argv[1]) == "history") {
            std::vector<double> factors;
            for (int i = 7; i < argc; ++i) factors.push_back(std::stod(argv[i]));
            cavity_history(std::stoi(argv[2]), std::stod(argv[3]), std::stod(argv[4]),
                           std::stoi(argv[5]), factors, argv[6]);
        } else if ((argc == 9 || argc == 10) && std::string(argv[1]) == "cavity") {
            cavity_reference(std::stoi(argv[2]), std::stod(argv[3]), std::stod(argv[4]), std::stod(argv[5]),
                             std::stod(argv[6]), std::stod(argv[7]), argv[8], argc == 10 ? argv[9] : "");
        } else {
            throw std::invalid_argument("use string METHOD N PLUCK A H OUT or cavity N RE A U MAX MIN OUT [WARM] or history N RE U BLOCK OUT FACTOR...");
        }
    } catch (const std::exception& problem) {
        std::cerr << problem.what() << '\n';
        return 1;
    }
}
