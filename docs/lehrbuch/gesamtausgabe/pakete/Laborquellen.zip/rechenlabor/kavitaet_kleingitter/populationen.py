"""Continuous fixed-step-map embedding. This algebraic ODE is not a continuous BGK model."""
import numpy as np
from kavitaet import cp2


class MapODE:
    def __init__(self,n,re,lid=.1):
        self.n,self.re,self.lid=n,re,lid
        self.dt=lid/(n-1);self.dim=9*n*n;self.m=n
        self.rate=cp2.cp2_lbm_relaxation(n,u0_x=lid,reynolds=re)
        self.weights=np.asarray(cp2.CP2_LBM_WEIGHTS)
        self.scales=self.weights*lid
        self.c=np.array(cp2.CP2_LBM_VELOCITIES)
        self.opp=np.array(cp2.CP2_LBM_REVERSE)
        self.nodes=n*n
        sy,sx=np.indices((n,n));cell=(sy*n+sx).ravel()
        self.node=cell
        self.wall=((sy==0)|(sx==0)|(sx==n-1)).ravel()
        self.lid_mask=(sy==n-1).ravel()
        self.from_cell=[]
        for x,y in self.c:
            yy,xx=sy-y,sx-x
            inside=(xx>=0)&(xx<n)&(yy>=0)&(yy<n)
            self.from_cell.append(np.where(inside, yy*n+xx, sy*n+sx).ravel())
        self.from_cell=np.array(self.from_cell)
        self.rows=np.arange(9)[:,None]
        self.lid_equil=self.weights*(1+3*self.c[:,0]*lid+4.5*(self.c[:,0]*lid)**2-1.5*lid**2)

    def quantities(self,z):
        f=self.weights[:,None]+self.scales[:,None]*np.asarray(z).reshape(9,-1)
        rho=f.sum(axis=0)
        if rho.min()<=0: raise ValueError("nonpositive density")
        u=self.c.T@f/rho
        cu=self.c@u
        poly=1+3*cu+4.5*cu**2-1.5*np.sum(u**2,axis=0)
        return f,rho,u,cu,poly

    def rhs(self,t,z):
        f,rho,u,cu,poly=self.quantities(z)
        post=f-self.rate*(f-self.weights[:,None]*rho*poly)
        post[:,self.wall]=f[self.opp][:,self.wall]
        post[:,self.lid_mask]=self.lid_equil[:,None]*rho[self.lid_mask]
        return ((post[self.rows,self.from_cell]-f)/(self.scales[:,None]*self.dt)).ravel()

    def jac(self,t,z):
        _,_,u,cu,poly=self.quantities(z)
        jac=np.zeros((self.dim,self.dim))
        for j in range(9):
            relative=self.c[j,:,None]-u
            eq_der=self.weights[:,None]*(poly+(3+9*cu)*(self.c@relative)-3*np.sum(u*relative,axis=0))
            deriv=self.rate*eq_der
            deriv[j,:]+=1-self.rate
            deriv[:,self.wall]=(self.opp==j)[:,None]
            deriv[:,self.lid_mask]=self.lid_equil[:,None]
            for i,src in enumerate(self.from_cell):
                jac[i*self.nodes+self.node,j*self.nodes+src]=(self.scales[j]/self.scales[i])*deriv[i,src]
        jac.flat[::self.dim+1]-=1
        return jac/self.dt

    def field(self,z):
        _,_,u,_,_=self.quantities(z)
        out=u.T.reshape(self.n,self.n,2).copy()/self.lid
        out[-1,:,:]=(1,0)
        return out
