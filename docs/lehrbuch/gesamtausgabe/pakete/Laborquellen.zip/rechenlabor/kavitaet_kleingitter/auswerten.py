"""Make method tables, performance profile and the report's data-driven figures."""
import csv
import json
import platform
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from rechnen import ROOT, OUT, QSS, CLASSIC
from kontrollen import write_csv
FIG=ROOT/"abbildungen";FIG.mkdir(exist_ok=True)
TEX=ROOT/"satz";TEX.mkdir(exist_ok=True)
def getcsv(name):
    with (OUT/(name+".csv")).open() as f:return list(csv.DictReader(f))
def dec(x,p=3):
    return f"{float(x):.{p}f}".replace(".",",")
def signif(x):
    if x>=.001: return dec(x,4)
    mant, exp=f"{x:.2e}".split("e")
    return "$"+mant.replace(".",",")+r"\,\cdot 10^{"+str(int(exp))+"}$"
def label(m):
    return {"cqss1":"CQSS1","bqss1":"BQSS1","liqss-bdf":"LIQSS–BDF",
            "euler":"Euler","esdirk32":"ESDIRK32","scipy-LSODA":"LSODA","scipy-BDF":"BDF",
            "scipy-Radau":"Radau IIA","scipy-DOP853":"DOP853"}.get(m,m.replace("mliqss","mLIQSS").replace("eliqss","eLIQSS").replace("cheqss","CheQSS").replace("liqss","LIQSS").replace("qss","QSS").replace("rk","RK"))
def texfile(name,lines):
    (TEX/(name+".tex")).write_text("\n".join(" & ".join(str(x) for x in row)+r" \\" for row in lines)+"\n")
def main():
    rows=[json.loads(p.read_text()) for p in sorted((OUT/"laeufe").glob("*.json"))]
    write_csv("integrationen_alle",rows)
    money={r["method"]:r for r in getcsv("zeiten_median")}
    centered=getcsv("quantisierer_nachversuch"); extra=getcsv("erweiterte_grenzen")
    base={(r["method"],r["quantum"]):r for r in rows if r["model"]=="NS" and r["n"]==17 and r["re"]==1000}
    matrix=[];tab=[]
    for method in QSS:
        r17=base[(method,.001)]; note=""
        if method=="cqss1":
            sup=next(r for r in centered if r["method"]==method and float(r["quantum"])==.001)
            note="Zellmitte"
        elif method=="bqss1":
            sup=next(r for r in extra if r["method"]==method and float(r["quantum"])==.001)
            note="Limit erhöht"
        else: sup=r17
        output=dict(method=method,grid_n=17,re=1000,t_end=.1,spatial_model="NS",unit_error_columns="percent")
        vals=[]
        for q,nick in ((.005,"005"),(.001,"001"),(.0002,"0002")):
            row=base[(method,q)]
            val=row.get("time_l2_rel")
            vals.append(dec(100*val) if val is not None else ("Zeit" if row["status"]=="TimeoutError" else "Zyklus" if method=="cqss1" else "Limit"))
            output["max_rel_percent_d"+nick]=None if val is None else 100*val
            output["status_d"+nick]=row["status"]
        output["check_d001_status"] = sup["status"]
        if sup["status"] != "ok":
            output.update(check_d001_note=note or "Standard",
                          check_d001_max_rel_percent=None, check_d001_max_vector_U=None,
                          check_d001_accepted=None, check_d001_cpu_s=None,
                          check_d001_l2_budget_percent=1, check_d001_max_budget_U=.01)
            matrix.append(output)
            tab.append([label(method), *vals, "–", "–", sup["status"]])
            continue
        ee=100*float(sup["time_l2_rel"]);a=int(sup["accepted"])
        output.update(check_d001_note=note or "Standard",check_d001_max_rel_percent=ee,
               check_d001_max_vector_U=float(sup["time_linf_U"]),check_d001_accepted=a,
               check_d001_cpu_s=float(sup["cpu_s"]),check_d001_l2_budget_percent=1,check_d001_max_budget_U=.01)
        matrix.append(output)
        tab.append([label(method),*vals,dec(ee),f"{a:,}".replace(",","\\,"),note or ""])
    write_csv("methodenmatrix",matrix);texfile("qss",tab)
    tasks=[(9,1000,.1),(17,1000,.1),(9,100,.5)]
    eligible={}
    for n,re,t in tasks:
        select=[r for r in rows if (r['n'],r['re'],r['t_end'])==(n,re,t) and r['model']=='NS'
                         and r['quantum'] in (.001,None) and r.get('within_time_budget') and r['cpu_s'] > 0.0]
        # A zero-duration clock reading cannot normalize a time ratio.
        best = min((r['cpu_s'] for r in select), default=None)
        eligible[(n, re, t)] = {r['method']: r['cpu_s'] / best for r in select}
    ratios=[];profiles=[]
    for met in QSS+CLASSIC:
        rt=[eligible[key].get(met,float("inf")) for key in tasks]
        for key,x in zip(tasks,rt):ratios.append(dict(method=met,n=key[0],re=key[1],t_end=key[2],ratio=x if np.isfinite(x) else "inf"))
        for tau in (1,2,5,10,20,50,100,500,1000):
            profiles.append(dict(method=met,tau=tau,solved_fraction=sum(x<=tau for x in rt)/len(rt)))
    write_csv("dolan_more_quotienten",ratios);write_csv("dolan_more_profil",profiles)
    tt=[]
    for met in CLASSIC:
        r=base[(met,None)];cost=float(money[met]["cpu_s"]) if met in money else r["cpu_s"]
        tt.append((label(met),signif(100*r["time_l2_rel"]),dec(1000*cost,1),
                   "5" if met in money else "1"))
    texfile("klassik",tt)
    rr=getcsv("surrogate");tab=[]
    labels={"linear":"Affin","quadratisch":"Quadratisch","pod_netz":"POD-Netz","fourier":"Fourier","wavelet":"Wavelet","hankel":"Hankel","radon":"Radon","laplace":"Laplace","wavelet_laplace":"Wavelet–Laplace","fourier_mellin":"Fourier–Mellin"}
    for m in dict.fromkeys(row["methode"] for row in rr):
        a=[r for r in rr if r["methode"]==m]
        tab.append([labels[m],*(r['bestanden']+"/"+r['faelle'] for r in a),dec(a[-1]["max_score"],2)])
    texfile("netze",tab)
    rr=getcsv("stationaer")
    texfile("stationaer",[[a["n"],label(a["method"]),dec(float(a["rms_u"])*100,2),dec(float(a["rms_v"])*100,2),
                      signif(float(a["max_field_change_25_to_30_U"])) if a["max_field_change_25_to_30_U"] else "–"]
                     for a in rr if a["n"] in ("17","33","65") and a["method"] in ("NS","D2Q9","qss1")])
    grid=getcsv("gitter")
    texfile("gitter",[[r["n"],dec(100*float(r["interior_ns_minus_lbm_rel"]),2),dec(r["interior_ns_minus_lbm_maxU"],3),dec(r["max_wall_U"],3)] for r in grid if float(r["t"])==.1])
    rr=getcsv("zeiten_median")
    texfile("zeiten",[[label(r["method"]),dec(float(r["cpu_s"])*1000,1),r["repeats"]] for r in rr if r["method"] in ("qss1","qss2","qss3","qss4","liqss-bdf","D2Q9")])
    kin=[r for r in rows if r["model"]=="map" and r['n']==5 and r["quantum"]==.04]
    texfile("kinetik",[[v,", ".join(label(r["method"]) for r in kin if r["status"]==s)] for v,s in (("Vier Zeiten erreicht","ok"),("Zeitlimit","TimeoutError"),("Ereignisabbruch","IntegrationError")) if any(r["status"]==s for r in kin)])
    plots(rows,grid)
def plots(rows,grid):
    plt.rcParams.update({"font.size":9,"axes.spines.top":False,"axes.spines.right":False,"font.family":"DejaVu Sans","pdf.fonttype":42})
    teal="#006d72";gold="#b45d14";blue="#345584"
    fig,axs=plt.subplots(1,2,figsize=(7.15,2.65),layout="constrained")
    for ax,n in zip(axs,(17,257)):
        d=np.load(OUT/"referenz"/f"n{n}_re1000_t0.1.npz"); yy=np.linspace(0,1,n)
        for key,name,color,style in (("lbm","D2Q9",gold,"-"),("ns","Navier–Stokes",blue,"--")):
            ax.plot(d[key][-1,:,n//2,0],yy,color=color,ls=style,label=name,lw=1.8)
        if n==17:
            q=np.load(OUT/"felder"/"n17_re1000_t0.1_qss2_q0.001.npz")["velocity"]
            ax.scatter(q[-1,:,n//2,0],yy,marker="o",facecolors="none",edgecolors=teal,s=22,lw=1,label="QSS2")
        ax.set(xlim=(-.065,1.02),ylim=(.72,1.005),xlabel="Horizontalgeschwindigkeit u/U",title=f"{n} × {n} Knoten",ylabel="Höhe y/L")
        ax.grid(alpha=.22);ax.legend(loc="lower right",frameon=False,fontsize=8)
    fig.savefig(FIG/"deckelprofil.pdf");plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(7.15,2.52),layout="constrained")
    for t,col in ((.025,blue),(.1,gold)):
        rr=[r for r in grid if float(r["t"])==t]
        axs[0].plot([int(r['n']) for r in rr],[100*float(r["interior_ns_minus_lbm_rel"]) for r in rr],"o-",color=col,label=f"t* = {str(t).replace('.',',')}")
    axs[0].set_xscale("log",base=2);axs[0].set_xticks([9,17,33,65,129,257],["9","17","33","65","129","257"])
    axs[0].set(xlabel="Knoten je Richtung",ylabel="Relativer Innenfeldabstand [%]",title="D2Q9 und Navier–Stokes");axs[0].legend(frameon=False,fontsize=8);axs[0].grid(alpha=.2)
    for n,c in ((17,blue),(33,teal),(65,gold)):
        d=np.load(OUT/"referenz"/f"dauer_n{n}.npz");yy=np.linspace(0,1,n)
        axs[1].plot(d["ns"][-1,:,n//2,0],yy,label=f"NS {n}²",color=c)
    gh=np.load(ROOT/"original"/"ghia_Re100.npz")["u"];axs[1].scatter(gh[:,1],gh[:,0],marker="o",s=25,facecolors="white",edgecolors="black",label="Ghia et al.",zorder=5)
    axs[1].set(xlabel="Horizontalgeschwindigkeit u/U",ylabel="Höhe y/L",title="Stationäres Profil bei Re = 100");axs[1].grid(alpha=.22);axs[1].legend(frameon=False,fontsize=7,loc="lower right")
    fig.savefig(FIG/"gitter_ghia.pdf");plt.close(fig)
if __name__=="__main__": main()
