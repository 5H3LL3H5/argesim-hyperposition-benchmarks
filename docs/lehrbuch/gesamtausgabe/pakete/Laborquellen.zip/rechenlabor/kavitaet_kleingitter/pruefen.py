"""Independently rescore every archived successful trajectory from its original arrays."""
import csv
import json
from collections import Counter
import numpy as np
from kavitaet import ROOT,field_errors
OUT=ROOT/"daten"
def verify():
    statuses=Counter()
    models=Counter()
    for path in sorted((OUT/"laeufe").glob("*.json")):
        r=json.loads(path.read_text());statuses[r["status"]]+=1;models[r["model"]]+=1
        if r["status"]!="ok":
            assert r.get("detail") and r.get("failed_at_t")>0
            continue
        refstem="_".join(path.stem.split("_")[:3])+("_map" if r["model"]=="map" else "")
        with np.load(OUT/"felder"/(path.stem+".npz")) as run, np.load(OUT/"referenz"/(refstem+".npz")) as ref:
            assert r["sample_count"]==4 and np.array_equal(run["t"],ref["t"])
            for name,a,b,flag in (("ns","time_l2_rel","time_linf_U","within_time_budget"),("lbm","lbm_l2_rel","lbm_linf_U","within_lbm_budget")):
                e,m=field_errors(run["velocity"],ref[name])
                np.testing.assert_allclose([max(e),max(m)],[r[a],r[b]],rtol=1e-12,atol=1e-15)
                assert r[flag]==bool(max(e)<=.01 and max(m)<=.01)
    rows=list(csv.DictReader((OUT/"methodenmatrix.csv").open()))
    assert len(rows)==len(set(r["method"] for r in rows))==19
    checked = 0
    for r in rows:
        if r["check_d001_status"] != "ok":
            assert all(not r[key] for key in (
                "check_d001_max_rel_percent", "check_d001_max_vector_U", "check_d001_accepted"
            ))
            continue
        assert float(r["check_d001_max_rel_percent"])<=1 and float(r["check_d001_max_vector_U"])<=.01
        tag=r["method"]
        name=f"n17_re1000_t0.1_{tag}_q0.001.npz"
        path=OUT/"kontrollfelder"/(tag+".npz") if tag in ("cqss1","bqss1") else OUT/"felder"/name
        with np.load(path) as run,np.load(OUT/"referenz"/"n17_re1000_t0.1.npz") as ref:
            e,m=field_errors(run["velocity"],ref["ns"])
            np.testing.assert_allclose([100*max(e),max(m)],[float(r["check_d001_max_rel_percent"]),float(r["check_d001_max_vector_U"])],rtol=1e-12,atol=1e-15)
            checked += 1
    surrogate=list(csv.DictReader((OUT/"surrogate_einzel.csv").open()))
    assert len(surrogate)==280
    return dict(regular_configurations=sum(statuses.values()),regular_statuses=dict(statuses),
                regular_models=dict(models),completed_field_rechecks=statuses["ok"],
                quantized_controls_verified=checked,quantized_controls_incomplete=len(rows)-checked,
                surrogate_model_case_pairs=len(surrogate))
if __name__=="__main__": print(json.dumps(verify(), indent=2))
