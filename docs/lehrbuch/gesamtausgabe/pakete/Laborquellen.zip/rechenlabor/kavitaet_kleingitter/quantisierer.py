"""Follow-up only: quantizer grid origin for CQSS1 and intermediate fixed BQSS1 quanta."""
import json
import signal
import time
from concurrent.futures import ProcessPoolExecutor
from rechnen import *
from kontrollen import write_csv

def centered(q):
    n=17; T=.1; c=Cavity(n,1000); states=[];stats=[]
    ref=np.load(OUT/"referenz"/(slug(n,1000,T)+".npz"))
    # x = z + q/2, hence the physical initial value z=0 is in the centre of one cell.
    def f(t,x): return c.rhs(t,np.asarray(x)-q/2)
    def timeout(*unused): raise TimeoutError("CPU limit per prefix")
    signal.signal(signal.SIGPROF,timeout)
    row=dict(method="cqss1",quantum=q,offset_in_quanta=.5,status="ok")
    try:
        for t in times(T):
            tic=time.process_time()
            signal.setitimer(signal.ITIMER_PROF,28)
            try:
                result=solve_ivp(InitialValueProblem(f,0,(q/2,)*c.dim,t,autonomous=True),
                                 method="cqss1",options=dict(quantum=q,max_events=120000))
            finally: signal.setitimer(signal.ITIMER_PROF,0)
            states.append(c.field(np.array(result.final_state)-q/2))
            stats.append(result.stats.accepted_steps)
        e,m=field_errors(np.array(states),ref["ns"])
        row.update(time_l2_rel=max(e),time_linf_U=max(m),accepted=stats[-1],cpu_s=time.process_time()-tic,
                   within_time_budget=bool(max(e)<=.01 and max(m)<=.01))
    except (ArithmeticError,RuntimeError,TimeoutError) as exc:
        row.update(status=type(exc).__name__,detail=str(exc))
    return row
def trial(job):
    method,q=job
    if method=="cqss1": return centered(q)
    r=single(17,1000,.1,method,q,20,1,False)
    return dict(method=method,quantum=q,offset_in_quanta=0,**{k:r[k] for k in
       ("status","time_l2_rel","time_linf_U","accepted","cpu_s","detail","within_time_budget") if k in r})
if __name__=="__main__":
    jobs=[("cqss1",q) for q in (.005,.001,.0002)]+[("bqss1",q) for q in (.004,.003,.0025,.002,.0015,.00075,.0005)]
    with ProcessPoolExecutor(max_workers=3) as pool: results=list(pool.map(trial,jobs))
    write_csv("quantisierer_nachversuch.csv",results)
