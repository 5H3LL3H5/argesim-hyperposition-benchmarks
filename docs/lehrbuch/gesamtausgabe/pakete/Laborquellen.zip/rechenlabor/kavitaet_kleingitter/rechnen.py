"""Reproduce a single run or the full method matrix. English field names for CSV."""
import os
for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[name] = "1"
import argparse
import json
import platform
import signal
import time
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
import scipy
from scipy.integrate import solve_ivp as scipy_ivp
from kavitaet import Cavity, ROOT, diagnostics, field_errors, lattice_fields, cp2
from populationen import MapODE
from argesim_benchmarks import InitialValueProblem, solve_ivp
from argesim_benchmarks.runtime import _QUANTISED_SOLVERS, TIME_STEPPERS

QSS = ("qss1","qss2","qss3","qss4","cqss1","bqss1",
       *(f"{family}{order}" for family in ("liqss","mliqss","eliqss","cheqss") for order in (1,2,3)),"liqss-bdf")
CLASSIC = ("euler","rk4","rk23","rk45","esdirk32","scipy-DOP853","scipy-Radau","scipy-BDF","scipy-LSODA")
assert set(QSS)==set(_QUANTISED_SOLVERS)
assert TIME_STEPPERS==set(CLASSIC[:5])
OUT=ROOT/"daten"
OUT.mkdir(exist_ok=True)
for directory in ("laeufe","felder","referenz"):
    (OUT/directory).mkdir(exist_ok=True)
QUANTA=(.005,.001,.0002)

def slug(n,re,end):
    return f"n{n}_re{re:g}_t{end:g}"
def times(end):
    return end*np.arange(1,5)/4

def reference(n,re,end, cross=True, model="NS"):
    key=slug(n,re,end)+("" if model=="NS" else "_map")
    out=OUT/"referenz"/(key+".npz")
    if out.exists():
        return
    c=Cavity(n,re) if model=="NS" else MapODE(n,re)
    t=times(end)
    args=dict(fun=c.rhs,t_span=(0,end),y0=np.zeros(c.dim),t_eval=t,rtol=2e-12,atol=2e-14)
    tic=time.process_time()
    sol=scipy_ivp(method="DOP853",**args)
    ref_cpu=time.process_time()-tic
    assert sol.success and len(sol.t)==4
    fields=np.array([c.field(z) for z in sol.y.T])
    tic=time.process_time()
    lattice,raw,pops=lattice_fields(n,re,t,retain_populations=True)
    lattice_cpu=time.process_time()-tic
    extra={}
    if cross:
        alt=scipy_ivp(method="Radau",jac=c.jac,**args)
        assert alt.success and len(alt.t)==4
        fa=np.array([c.field(z) for z in alt.y.T])
        extra["reference_check"]=np.array(field_errors(fa,fields))
    np.savez_compressed(out,t=t,states=sol.y.T,ns=fields,lbm=lattice,raw=raw,
                        ref_cpu=ref_cpu,lattice_cpu=lattice_cpu,**extra)

def single(n,re,end,method,q,limit,repeat=1,save=True,model="NS",max_events=120000):
    key=slug(n,re,end)+("" if model=="NS" else "_map"); tag=f"{key}_{method}_q{q:g}"
    paths=[OUT/"laeufe"/(tag+".json"), OUT/"felder"/(tag+".npz")]
    c=Cavity(n,re) if model=="NS" else MapODE(n,re); t=times(end)
    data=np.load(OUT/"referenz"/(key+".npz")); ref=data["ns"]; lbm=data["lbm"]
    row=dict(method=method,n=n,re=re,t_end=end,quantum=q if method in QSS else None,
             status="ok",limit_cpu_s=limit,model=model,sample_count=0)
    def budget(*unused):
        raise TimeoutError("CPU limit per prefix")
    signal.signal(signal.SIGPROF,budget)
    def integrate(end_time):
        if method.startswith("scipy-"):
            engine=method[6:]
            opt={"jac":c.jac} if engine in {"Radau","BDF"} else {}
            result=scipy_ivp(c.rhs,(0,end_time),np.zeros(c.dim),method=engine,
                             rtol=1e-6,atol=1e-9,**opt)
            if not result.success: raise RuntimeError(result.message)
            return result.y[:,-1],(len(result.t)-1,None,result.nfev)
        ivp=InitialValueProblem(c.rhs,0,(0.,)*c.dim,end_time,autonomous=True)
        if method=="euler": opt=dict(step=end/128 if model=="NS" else c.dt)
        elif method=="rk4": opt=dict(step=end/32)
        elif method in ("rk23","rk45","esdirk32"): opt=dict(rtol=1e-6,atol=1e-9)
        else: opt=dict(quantum=q,max_events=max_events)
        if method.startswith(("liqss","mliqss","eliqss","cheqss")) or method=="esdirk32":
            opt["jacobian"]=c.jac
        if method=="liqss-bdf":
            partition=(tuple(range(c.dim-c.m,c.dim)) if model=="NS" else tuple(int(j*c.nodes+i) for j in range(9) for i in np.flatnonzero(c.lid_mask)))
            opt.update(bdf_partition=partition,rtol=1e-3,
                       atol=max(q*.05,2e-6),max_step=end/8,max_steps=40000)
        result=solve_ivp(ivp,method=method,options=opt)
        if abs(result.final_time-end_time)>1e-13:
            raise RuntimeError("incomplete interval")
        s=result.stats
        return result.final_state,(s.accepted_steps,s.rejected_steps,s.rhs_evaluations)
    # Prepare constant analytic spatial operators before the integrator clock.
    if method.startswith(("liqss","mliqss","eliqss","cheqss")) or method in ("esdirk32","scipy-Radau","scipy-BDF"):
        if model=="NS": _=c.operators
    outputs={}; costs=[]; walltimes=[]; overall=time.process_time()
    try:
        for i in (3,0,1,2):
            for k in range(repeat if i==3 else 1):
                signal.setitimer(signal.ITIMER_PROF,limit)
                start=time.process_time(); wall=time.perf_counter()
                try:
                    z,stats=integrate(t[i])
                finally:
                    signal.setitimer(signal.ITIMER_PROF,0)
                duration=time.process_time()-start; elapsed=time.perf_counter()-wall
                field=c.field(z)
                if k and not np.array_equal(field,outputs[i]):
                    raise ArithmeticError("endpoint differs on repeat")
                outputs[i]=field
                if i==3:
                    costs.append(duration);walltimes.append(elapsed)
                    row.update(accepted=stats[0],rejected=stats[1],rhs=stats[2])
            row["sample_count"]=len(outputs)
        a=np.array([outputs[i] for i in range(4)])
        e,m=field_errors(a,ref); le,lm=field_errors(a,lbm)
        div,wall=diagnostics(a)
        row.update(time_l2_rel=float(max(e)),time_linf_U=float(max(m)),
                   lbm_l2_rel=float(max(le)),lbm_linf_U=float(max(lm)),
                   end_l2_rel=float(e[-1]),div_max=div,wall_max_U=wall,
                   within_time_budget=bool(max(e)<=.01 and max(m)<=.01),
                   within_lbm_budget=bool(max(le)<=.01 and max(lm)<=.01))
        if save:
            np.savez_compressed(paths[1],t=t,velocity=a)
    except (ArithmeticError,ValueError,RuntimeError,TimeoutError,TypeError) as exc:
        row.update(status=type(exc).__name__,detail=str(exc),failed_at_t=float(t[i]))
    if costs:
        row.update(cpu_s=float(np.median(costs)),wall_s=float(np.median(walltimes)),repeats=len(costs))
    row["all_prefix_cpu_s"]=time.process_time()-overall
    if save:
        tmp=paths[0].with_suffix(".tmp")
        tmp.write_text(json.dumps(row,indent=2,allow_nan=False));tmp.replace(paths[0])
    return row

def execute(job):
    r=single(*job)
    print(f"{r['n']:2} {r['method']:12} q={r['quantum']} {r['status']} rel={r.get('time_l2_rel',-1):.4g} cpu={r.get('cpu_s',-1):.3g}",flush=True)

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--model",choices=("NS","map"),default="NS")
    ap.add_argument("--grid",type=int,default=9);ap.add_argument("--re",type=float,default=1000)
    ap.add_argument("--end",type=float,default=.1);ap.add_argument("--methods",nargs="*",default=[])
    ap.add_argument("--quanta",type=float,nargs="+",default=QUANTA)
    ap.add_argument("--limit",type=float,default=30);ap.add_argument("--workers",type=int,default=4)
    ap.add_argument("--repeats",type=int,default=1);ap.add_argument("--skip-existing",action="store_true")
    args=ap.parse_args()
    reference(args.grid,args.re,args.end,cross=(args.grid<=17 if args.model=="NS" else args.grid<=5),model=args.model)
    jobs=[]
    for method in (args.methods or QSS+CLASSIC):
        if method not in QSS+CLASSIC: raise ValueError(method)
        for q in (args.quanta if method in QSS else (0,)):
            prefix=slug(args.grid,args.re,args.end)+("" if args.model=="NS" else "_map")
            key=f"{prefix}_{method}_q{q:g}"
            if args.skip_existing and (OUT/"laeufe"/(key+".json")).exists(): continue
            jobs.append((args.grid,args.re,args.end,method,q,args.limit,args.repeats,True,args.model))
    # Distribute across families before consecutive refinements.
    jobs.sort(key=lambda item:-item[4])
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        list(pool.map(execute,jobs))
