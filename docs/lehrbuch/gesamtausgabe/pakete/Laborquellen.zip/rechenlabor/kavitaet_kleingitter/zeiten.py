"""Repeated CPU timings at N=17; four independent diagnostic prefixes for each solver."""
from rechnen import *
from kontrollen import write_csv

def timing():
    rows=[]
    for method,q in (("qss1",.005),("qss2",.001),("qss3",.001),("qss4",.001),
                      ("liqss-bdf",.001),("rk4",0),("rk23",0),("rk45",0),("scipy-DOP853",0)):
        r=single(17,1000,.1,method,q,40,5,False)
        rows.append({k:r.get(k) for k in ("method","quantum","repeats","cpu_s","wall_s","within_time_budget","accepted","rhs")})
    # Same-grid D2Q9 computes a different discrete trajectory.
    cs=[];ws=[]
    for _ in range(10):
        t=time.process_time();w=time.perf_counter()
        lattice_fields(17,1000,[.1]);cs.append(time.process_time()-t);ws.append(time.perf_counter()-w)
    rows.append(dict(method="D2Q9",quantum=None,repeats=9,cpu_s=np.median(cs[1:]),wall_s=np.median(ws[1:]),within_time_budget=None,accepted=16,rhs=None))
    write_csv("zeiten_median.csv",rows)
if __name__=="__main__": timing()
