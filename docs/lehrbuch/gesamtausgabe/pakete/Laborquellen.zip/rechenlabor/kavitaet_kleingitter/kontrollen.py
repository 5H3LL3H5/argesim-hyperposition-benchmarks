"""Spatial, kinetic and published-data checks for the cavity experiments."""
import csv
import json
import time
import numpy as np
from rechnen import Cavity, OUT, ROOT, cp2, diagnostics, field_errors, lattice_fields, reference, scipy_ivp, slug, times

def write_csv(name,rows):
    with (OUT/(name if name.endswith(".csv") else name+".csv")).open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=tuple(dict.fromkeys(k for row in rows for k in row)))
        w.writeheader();w.writerows(rows)

def checks():
    data={}
    c=Cavity(9,1000);h=c.h
    rng=np.random.default_rng(916);z=rng.normal(size=c.dim)*.03;v=rng.normal(size=c.dim)
    p=c.psi(z)
    minuslap=(4*p[1:-1,1:-1]-p[2:,1:-1]-p[:-2,1:-1]-p[1:-1,2:]-p[1:-1,:-2])/h**2
    data["poisson_max_abs"]=float(np.max(abs(minuslap.ravel()-z/h)))
    approx=(c.rhs(0,z+1e-6*v)-c.rhs(0,z-1e-6*v))/(2e-6)
    data["jac_direction_rel"]=float(np.linalg.norm(approx-c.jac(0,z)@v)/np.linalg.norm(approx))
    data["random_field_diagnostics"]=diagnostics(c.field(z)[None])
    fields,raw,f=lattice_fields(17,1000,[.1],retain_populations=True)
    original=cp2.cp2_lbm_initial_state(17)
    for _ in range(16):
        original=cp2.cp2_lbm_step(original,17,u0_x=.1,omega=cp2.cp2_lbm_relaxation(17))
    data["17_scalar_population_max_abs"]=float(np.max(np.abs(f-np.moveaxis(original,-1,0))))
    archived=np.load(ROOT/"original"/"buch_cp2_anlauf.npz")
    records=[]; ref_fields={}
    for n in (9,17,33,65,129,257):
        reference(n,1000,.1,cross=n<=17)
        d=np.load(OUT/"referenz"/(slug(n,1000,.1)+".npz"))
        ns,lb=d["ns"],d["lbm"]; ref_fields[n]=(ns,lb)
        if n in (17,257):
            data[f"{n}_archived_magnitude_max_abs"]=float(np.max(abs(np.linalg.norm(lb[-1],axis=-1)-archived[f"n{n}"])))
        div,wall=diagnostics(lb)
        re,ma=field_errors(ns,lb);alt_re,alt_ma=field_errors(lb,ns)
        for i,t in enumerate(d["t"]):
            records.append(dict(n=n,re=1000,t=t,lbm_lid=.1,lattice_steps=round(t*(n-1)/.1),
                     interior_ns_minus_lbm_rel=re[i],interior_ns_minus_lbm_maxU=ma[i],
                     rel_ns_denominator=alt_re[i],max_wall_U=diagnostics(lb[i:i+1])[1],
                     max_abs_div=diagnostics(lb[i:i+1])[0],ns_cpu=d["ref_cpu"].item(),lbm_cpu=d["lattice_cpu"].item(),
                     a_posteriori_time_crosscheck_max_rel=np.max(d["reference_check"][0]) if "reference_check" in d else None))
    write_csv("gitter.csv",records)
    grid=[]
    for n in (9,17,33,65,129):
        for j,method in enumerate(("NS","D2Q9")):
            for nf in (2*n-1,257):
                if nf==2*n-1 and n==129: continue
                factor=(nf-1)//(n-1)
                restricted=ref_fields[nf][j][:,::factor,::factor,:]
                e,m=field_errors(ref_fields[n][j],restricted)
                for i,t in enumerate(times(.1)):
                    grid.append(dict(method=method,n=n,n_fine=nf,t=t,rel=e[i],linf_U=m[i]))
    write_csv("gittertransfer.csv",grid)
    mach=[]
    for n in (65,129):
        ns=ref_fields[n][0]
        for ul in (.1,.05,.025):
            tic=time.process_time()
            fields=ref_fields[n][1] if ul==.1 else lattice_fields(n,1000,times(.1),lid=ul)
            e,m=field_errors(ns,fields)
            for i,t in enumerate(times(.1)):
                mach.append(dict(n=n,U_lattice=ul,Ma=ul*np.sqrt(3),t=t,steps=round(t*(n-1)/ul),rel=e[i],linf_U=m[i]))
    write_csv("mach.csv",mach)
    assert data["poisson_max_abs"]<3e-12 and data["jac_direction_rel"]<1e-8 and data["random_field_diagnostics"][0]<1e-12
    assert max(data["17_scalar_population_max_abs"],data["17_archived_magnitude_max_abs"],data["257_archived_magnitude_max_abs"])<1e-11
    (OUT/"kontrollen.json").write_text(json.dumps(data,indent=2))

if __name__=="__main__":
    checks()
