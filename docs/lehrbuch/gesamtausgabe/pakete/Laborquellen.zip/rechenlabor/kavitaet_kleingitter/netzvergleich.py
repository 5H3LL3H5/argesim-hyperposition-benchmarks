"""Fresh D2Q9 fields and inference from frozen textbook weights, on their own trajectory contract."""
import os
os.environ["OPENBLAS_NUM_THREADS"]="1"
import csv
import json
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
import numpy as np
ROOT=Path(__file__).resolve().parent
ORIG=ROOT/"original"/"operatoren"
SRC=ORIG/"rechenlabor"/"cp_dynamik"
sys.path.insert(0,str(ROOT/"original"))
sys.path.insert(0,str(SRC))
import kernvergleich as k
import kavitaet as cav
from referenzen import build_cpp

def evaluate():
    matrix=[]; vals=[]
    inputs=np.load(ORIG/"inputs.npz"); base=dict(np.load(SRC/"messung"/"kavitaet_modell.npz"))
    heads=dict(np.load(SRC/"messung"/"kavitaet_kernmodelle.npz"))
    published={(r["gruppe"],int(r["fall"]),r["verfahren"]):float(r["relativ"])
               for r in csv.DictReader((SRC/"messung"/"kavitaet_kerne_einzel.csv").open())}
    delta=0.
    with TemporaryDirectory() as td:
        stage=Path(td); exe=build_cpp(stage)
        for group in ("innen","profile","aussen"):
            controls=inputs[group+"_deckel"]
            truth=np.stack([cav.reference(p,exe,stage)[0] for p in controls])
            for kind in (*cav.METHODS,*k.KINDS):
                if kind in cav.METHODS: fields=cav.predict(controls,base,kind)
                else:
                    basis,weights=k.read_kernel(heads,kind)
                    fields=k.predict("kavitaet",controls,base,basis,weights)
                rel,mx,score=cav.metrics(fields,truth)
                matrix.append(dict(gruppe=group,methode=kind,faelle=len(controls),
                   bestanden=int((score<=1).sum()),max_score=max(score),max_rel=max(rel),max_linf_U=max(mx)))
                for i in range(len(controls)):
                    if kind in k.KINDS:
                        delta=max(delta,abs(rel[i]-published[group,i,kind]))
                    vals.append(dict(gruppe=group,methode=kind,fall=i,rel=rel[i],linf_U=mx[i],score=score[i]))
    assert delta<1.e-9,delta
    for name,rows in (("surrogate",matrix),("surrogate_einzel",vals)):
        with (ROOT/"daten"/(name+".csv")).open("w",newline="") as f:
            w=csv.DictWriter(f,fieldnames=tuple(rows[0]));w.writeheader();w.writerows(rows)
    (ROOT/"daten"/"surrogate_abgleich.json").write_text(json.dumps({"max_absolute_difference_archived_rel": delta}))
if __name__=="__main__":evaluate()
