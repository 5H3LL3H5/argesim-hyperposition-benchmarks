#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
python rechnen.py --grid 9 --workers 3 --limit 25 --repeats 2
python rechnen.py --grid 17 --workers 4 --limit 32
python rechnen.py --grid 9 --re 100 --end .5 --quanta .001 --workers 3 --limit 28
python rechnen.py --grid 33 --methods qss1 qss2 qss3 qss4 rk4 scipy-DOP853 --quanta .005 .001 --workers 2 --limit 45
python kontrollen.py
python rechnen.py --grid 65 --quanta .005 --methods qss2 qss4 scipy-DOP853 rk4 --workers 2 --limit 75
python rechnen.py --model map --grid 5 --workers 4 --quanta .04 --limit 22
python rechnen.py --model map --grid 5 --quanta .01 --methods qss2 qss3 qss4 --workers 3 --limit 50
python rechnen.py --model map --grid 17 --quanta .04 --methods euler scipy-DOP853 qss4 qss2 --workers 2 --limit 45
python rechnen.py --grid 9 --re 100 --end 30 --quanta .003 --methods qss1 qss2 qss3 qss4 liqss2 scipy-DOP853 --workers 3 --limit 40
python rechnen.py --grid 17 --re 100 --end 30 --quanta .003 --methods qss2 qss3 qss4 scipy-DOP853 --workers 2 --limit 70
python rechnen.py --grid 17 --re 100 --end 30 --quanta .01 --methods qss1 qss2 --workers 2 --limit 110
python quantisierer.py
python erweiterte_grenzen.py
python kontrollfelder.py
python gegenproben.py dae map steady
python zeiten.py
python netzvergleich.py
python auswerten.py
python pruefen.py
