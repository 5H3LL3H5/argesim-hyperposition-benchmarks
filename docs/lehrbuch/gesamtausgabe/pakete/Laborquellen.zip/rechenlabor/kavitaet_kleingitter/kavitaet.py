"""Lid-driven square cavity in (x/L,y/L,tU/L). Arrays are indexed [y,x]."""
import sys
from functools import cached_property
from pathlib import Path

import numpy as np
from scipy.fft import dstn, idstn

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "original"))
from argesim_benchmarks.models import cp2_parallel_and_distributed as cp2


class Cavity:
    """Centred FD/Thom vorticity-streamfunction method of lines; state z=h*omega."""
    def __init__(self, n, reynolds):
        self.n, self.re, self.h = n, reynolds, 1.0 / (n - 1)
        self.m = n - 2
        self.dim = self.m**2
        line = 4 * np.sin(np.arange(1, n - 1) * np.pi / (2 * (n - 1)))**2 / self.h**2
        self.eigen = line[:, None] + line[None, :]

    def psi(self, state):
        omega = np.asarray(state).reshape(self.m, self.m) / self.h
        inner = idstn(dstn(omega, type=1, norm="ortho") / self.eigen, type=1, norm="ortho")
        return np.pad(inner, 1)

    def quantities(self, state):
        p = self.psi(state)
        h = self.h
        z = np.pad(np.asarray(state).reshape(self.m, self.m), 1)
        z[0, 1:-1] = -2 * p[1, 1:-1] / h
        z[-1, 1:-1] = -2 * p[-2, 1:-1] / h - 2
        z[1:-1, 0] = -2 * p[1:-1, 1] / h
        z[1:-1, -1] = -2 * p[1:-1, -2] / h
        u = (p[2:, 1:-1] - p[:-2, 1:-1]) / (2*h)
        v = -(p[1:-1, 2:] - p[1:-1, :-2]) / (2*h)
        zx = (z[1:-1, 2:] - z[1:-1, :-2]) / (2*h)
        zy = (z[2:, 1:-1] - z[:-2, 1:-1]) / (2*h)
        diffusion = (z[1:-1, 2:] + z[1:-1, :-2] + z[2:, 1:-1]
                     + z[:-2, 1:-1] - 4*z[1:-1, 1:-1]) / (self.re*h*h)
        return tuple(a.ravel() for a in (diffusion, u, v, zx, zy))

    def rhs(self, t, state):
        diffusion, u, v, zx, zy = self.quantities(state)
        return diffusion - u*zx - v*zy

    @cached_property
    def operators(self):
        zero = self.quantities(np.zeros(self.dim))
        cols = [tuple(q-b for q,b in zip(self.quantities(e),zero)) for e in np.eye(self.dim)]
        return zero, [np.ascontiguousarray(np.column_stack(c)) for c in zip(*cols)]

    def jac(self, t, state):
        _, (diffusion, ux, uy, dx, dy) = self.operators
        _, u, v, zx, zy = self.quantities(state)
        return diffusion - zx[:,None]*ux - zy[:,None]*uy - u[:,None]*dx - v[:,None]*dy

    def field(self, state):
        p = self.psi(state)
        vel = np.zeros((self.n, self.n, 2))
        vel[1:-1, 1:-1, 0] = (p[2:, 1:-1] - p[:-2, 1:-1])/(2*self.h)
        vel[1:-1, 1:-1, 1] = -(p[1:-1, 2:] - p[1:-1, :-2])/(2*self.h)
        vel[-1, :, 0] = 1.0
        return vel


def lattice_fields(n, re, times, *, lid=0.1, retain_populations=False):
    """Published BGK collision, boundary and unwrapped streaming rules, vectorized."""
    vel, weights, opp = cp2.CP2_LBM_VELOCITIES, cp2.CP2_LBM_WEIGHTS, cp2.CP2_LBM_REVERSE
    rate = cp2.cp2_lbm_relaxation(n, u0_x=lid, reynolds=re)
    f = np.broadcast_to(np.asarray(weights)[:,None,None], (9,n,n)).copy()
    targets = np.asarray(times)*(n-1)/lid
    if np.max(abs(targets-np.rint(targets)))>1e-10:
        raise ValueError("Output time must be an integer lattice step")
    indices = set(np.rint(targets).astype(int).tolist())
    fields, raw_fields = [], []
    def mac(p):
        rho = p.sum(axis=0)
        if rho.min() <= 0:
            raise ArithmeticError("nonpositive lattice density")
        x = (p[1]+p[5]+p[8]-p[3]-p[6]-p[7])/rho
        y = (p[2]+p[5]+p[6]-p[4]-p[7]-p[8])/rho
        return rho,x,y
    rho,x,y=mac(f)
    for k in range(1,max(indices)+1):
        speed_sq=x*x+y*y
        out=np.empty_like(f)
        for j, ((dx,dy),w,reverse) in enumerate(zip(vel,weights,opp)):
            cu=dx*x+dy*y
            post=f[j]-rate*(f[j]-w*rho*(1+3*cu+4.5*cu*cu-1.5*speed_sq))
            post[0,:]=f[reverse,0,:]
            post[:,0]=f[reverse,:,0]
            post[:,-1]=f[reverse,:,-1]
            post[-1,:]=w*rho[-1,:]*(1+3*dx*lid+4.5*(dx*lid)**2-1.5*lid**2)
            sy=slice(max(0,-dy),min(n,n-dy)); sx=slice(max(0,-dx),min(n,n-dx))
            ty=slice(max(0,dy),min(n,n+dy)); tx=slice(max(0,dx),min(n,n+dx))
            out[j]=post
            out[j,ty,tx]=post[sy,sx]
        f=out
        rho,x,y=mac(f)
        if k in indices:
            field=np.stack((x/lid,y/lid),axis=-1)
            raw_fields.append(field.copy())
            field[-1,:,:]=(1,0)
            fields.append(field)
    if retain_populations:
        return np.stack(fields), np.stack(raw_fields), f
    return np.stack(fields)


def field_errors(solution, reference):
    """One spatial relative joint L2 and one L-infinity vector error for each sample."""
    sl=(slice(None),slice(1,-1),slice(1,-1),slice(None))
    diff=(solution-reference)[sl]
    ref=reference[sl]
    axes=(1,2,3)
    norm=np.sqrt(np.sum(ref**2,axis=axes))
    if np.any(norm==0):
        raise ValueError("Relative L2 undefined at a zero reference field")
    return np.sqrt(np.sum(diff**2,axis=axes))/norm, np.max(np.linalg.norm(diff,axis=-1),axis=(1,2))


def diagnostics(fields):
    n=fields.shape[1]
    h=1/(n-1)
    u,v=fields[...,0],fields[...,1]
    div=(u[:,1:-1,2:]-u[:,1:-1,:-2]+v[:,2:,1:-1]-v[:,:-2,1:-1])/(2*h)
    wall=np.concatenate((fields[:,0],fields[:,1:-1,0],fields[:,1:-1,-1]),axis=1)
    return float(np.max(abs(div))),float(np.max(np.linalg.norm(wall,axis=-1)))
