"""Index-one DAE, map algebra and independent steady centreline verification."""
import csv
import json
import time
from pathlib import Path
from rechnen import Cavity, MapODE, OUT, ROOT, cp2, field_errors, lattice_fields, np, reference, scipy_ivp, slug, times
from kontrollen import write_csv
from argesim_benchmarks.solvers.dae import solve_dae

def dae(n):
    import casadi as ca
    cavity=Cavity(n,1000);h=cavity.h;m=cavity.m
    def residual(t,z,v,p):
        def ii(y,x): return (y-1)*m+x-1
        def psi(y,x): return p[ii(y,x)] if 0<x<n-1 and 0<y<n-1 else 0
        def vort(y,x):
            if x==0: return -2*psi(y,1)/h
            if x==n-1: return -2*psi(y,n-2)/h
            if y==0: return -2*psi(1,x)/h
            if y==n-1: return -2*psi(n-2,x)/h-2
            return z[ii(y,x)]
        transport=[];poisson=[]
        for y in range(1,n-1):
            for x in range(1,n-1):
                dx=(vort(y,x+1)-vort(y,x-1))/(2*h)
                dy=(vort(y+1,x)-vort(y-1,x))/(2*h)
                u=(psi(y+1,x)-psi(y-1,x))/(2*h);vv=(psi(y,x-1)-psi(y,x+1))/(2*h)
                lap=(vort(y,x+1)+vort(y,x-1)+vort(y+1,x)+vort(y-1,x)-4*vort(y,x))/h**2
                transport.append(v[ii(y,x)]-lap/1000+u*dx+vv*dy)
                poisson.append((4*psi(y,x)-psi(y+1,x)-psi(y-1,x)-psi(y,x+1)-psi(y,x-1))/h**2-z[ii(y,x)]/h)
        return ca.vertcat(*(transport+poisson))
    t=times(.1);zero=np.zeros(cavity.dim)
    tic=time.process_time()
    sol=solve_dae(residual,times=(0.,*t),x0=zero,z0=zero,xdot0=cavity.rhs(0,zero),rtol=1e-7,atol=1e-9)
    total=time.process_time()-tic
    fields=np.array([cavity.field(z) for z in sol.differential[1:]])
    ref=np.load(OUT/"referenz"/(slug(n,1000,.1)+".npz"))
    e,m=field_errors(fields,ref["ns"])
    poisson_recovery=max(np.max(abs(cavity.psi(z)[1:-1,1:-1].ravel()-p)) for z,p in zip(sol.differential,sol.algebraic))
    return dict(n=n,relative_l2_max=max(e),max_error_U=max(m),max_residual=sol.max_residual,
                max_psi_diff=poisson_recovery,cpu_setup_and_solve_s=total)

def identity():
    rows=[]
    for n in (5,17):
        model=MapODE(n,1000);z=np.zeros(model.dim);t=times(.1)
        exact,raw,pops=lattice_fields(n,1000,t,retain_populations=True)
        snapshots=[]
        for k in range(1,n):
            z=z+model.dt*model.rhs((k-1)*model.dt,z)
            if k%((n-1)//4)==0: snapshots.append(model.field(z))
        f=model.weights[:,None]+model.scales[:,None]*z.reshape(9,-1)
        e,m=field_errors(np.array(snapshots),exact)
        data=np.load(OUT/"referenz"/(slug(n,1000,.1)+"_map.npz"))
        re,ma=field_errors(data["ns"],data["lbm"])
        row=dict(n=n,euler_lbm_pop_abs_max=np.max(abs(pops-f.reshape(9,n,n))),euler_lbm_linf_U=max(m),
                 continuous_ode_lbm_end_rel=re[-1],continuous_ode_lbm_worst_rel=max(re),continuous_ode_lbm_end_linf_U=ma[-1],
                 bgk_rate=model.rate,discrete_mode=1-model.rate,continuous_mode=np.exp(-model.rate))
        if n==5:
            rng=np.random.default_rng(916);z=rng.normal(size=model.dim)*.05;v=rng.normal(size=model.dim)
            g=(model.rhs(0,z+1e-6*v)-model.rhs(0,z-1e-6*v))/(2e-6)
            row["map_jac_rel"]=np.linalg.norm(g-model.jac(0,z)@v)/np.linalg.norm(g)
            assert row["map_jac_rel"]<1e-7
        assert row["euler_lbm_linf_U"]<1e-12
        rows.append(row)
    write_csv("abbildungsidentitaet.csv",rows)

def steady():
    gh=np.load(ROOT/"original"/"ghia_Re100.npz")
    rows=[];profiles=[]
    for n in (9,17,33,65):
        c=Cavity(n,100);t=np.array([20.,25.,30.])
        path=OUT/"referenz"/f"dauer_n{n}.npz"
        if path.exists():
            saved=np.load(path);ns,lb=saved["ns"],saved["lbm"]
        else:
            sol=scipy_ivp(c.rhs,(0,30.),np.zeros(c.dim),method="DOP853",rtol=1e-9,atol=1e-11,t_eval=t)
            assert sol.success
            ns=np.array([c.field(z) for z in sol.y.T]);lb=lattice_fields(n,100,t)
            np.savez_compressed(path,t=t,ns=ns,lbm=lb)
        samples=[("NS",None,ns),("D2Q9",None,lb)]
        for path in sorted((OUT/"felder").glob(f"n{n}_re100_t30_qss*.npz")):
            f=np.load(path);tag=path.stem.split("_")
            samples.append((tag[3],float(tag[4][1:]),f["velocity"][-1:]))
        for method,q,a in samples:
            line=np.linspace(0,1,n);mid=(n-1)//2
            au=np.interp(gh["u"][:,0],line,a[-1,:,mid,0]);av=np.interp(gh["v"][:,0],line,a[-1,mid,:,1])
            eu=au-gh["u"][:,1];ev=av-gh["v"][:,1]
            rows.append(dict(n=n,method=method,quantum=q,rms_u=np.sqrt(np.mean(eu**2)),rms_v=np.sqrt(np.mean(ev**2)),
                       max_u=np.max(abs(eu)),max_v=np.max(abs(ev)),max_field_change_25_to_30_U=(
                       np.max(np.linalg.norm(a[-1]-a[-2],axis=-1)) if len(a)>1 else None)))
            for label,actual in (("u",au),("v",av)):
                for (coord,expected),meas in zip(gh[label],actual):
                    profiles.append(dict(n=n,method=method,quantum=q,component=label,coordinate=coord,ghia=expected,measured=meas))
        print(n,"stationary",flush=True)
    write_csv("stationaer.csv",rows);write_csv("ghia_profile.csv",profiles)
if __name__=="__main__":
    import sys
    if "dae" in sys.argv: write_csv("idas.csv",[dae(n) for n in (9,17)])
    if "map" in sys.argv: identity()
    if "steady" in sys.argv: steady()
