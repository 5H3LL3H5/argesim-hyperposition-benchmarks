"""Independent replay of the two special quantizer configurations with stored raw fields."""
import csv
from rechnen import *
from kontrollen import write_csv

def reproduce():
    c=Cavity(17,1000);q=.001;t=times(.1);rd=OUT/'referenz'/'n17_re1000_t0.1.npz'
    dr=np.load(rd);allrows=[];directory=OUT/'kontrollfelder';directory.mkdir(exist_ok=True)
    for method,offset,limit,table in (
        ('cqss1',.5,120000,'quantisierer_nachversuch.csv'),
        ('bqss1',0.,1200000,'erweiterte_grenzen.csv')):
        previous=next(row for row in csv.DictReader((OUT/table).open()) if
                      row['method']==method and float(row['quantum'])==q)
        def f(t,x): return c.rhs(t,np.asarray(x)-q*offset)
        a=[];counts=[]
        for timepoint in t:
            ivp=InitialValueProblem(f,0,(q*offset,)*c.dim,timepoint,autonomous=True)
            sol=solve_ivp(ivp,method=method,options={'quantum':q,'max_events':limit})
            a.append(c.field(np.array(sol.final_state)-q*offset))
            counts.append(sol.stats.accepted_steps)
        fields=np.array(a);e,m=field_errors(fields,dr['ns']);b,bm=field_errors(fields,dr['lbm'])
        assert abs(max(e)-float(previous['time_l2_rel']))<1e-12
        assert abs(max(m)-float(previous['time_linf_U']))<1e-12
        assert counts[-1]==int(previous['accepted'])
        np.savez_compressed(directory/(method+'.npz'),t=t,velocity=fields)
        for i in range(4):
            allrows.append(dict(method=method,t=t[i],accepted=counts[i],quantum=q,quantizer_offset=offset,
                         max_events=limit,ns_rel=e[i],ns_maxU=m[i],lbm_rel=b[i],lbm_maxU=bm[i]))
    write_csv('kontrollfelder.csv',allrows)
if __name__=='__main__': reproduce()
