"""Explicitly logged follow-ups after budget exhaustion in the original matrix."""
from concurrent.futures import ProcessPoolExecutor
from rechnen import *
from kontrollen import write_csv

def calculate(item):
    method,q,limit,max_events=item
    r=single(17,1000,.1,method,q,limit,1,False,"NS",max_events)
    r["max_events"]=max_events
    print(method,q,r["status"],r.get("time_l2_rel",""),flush=True)
    return r
if __name__=="__main__":
    limits=[("bqss1",q,75,1200000) for q in (.001,.0002)]
    limits += [(m,.0002,160,120000) for m in ("liqss1","mliqss1","eliqss1","cheqss1")]
    with ProcessPoolExecutor(max_workers=4) as ex: data=list(ex.map(calculate,limits))
    write_csv("erweiterte_grenzen.csv",data)
