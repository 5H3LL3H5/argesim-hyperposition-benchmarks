"""Check primary keys, compare published and repeated configurations and recompute hold-outs."""
from pathlib import Path
import csv, json, statistics, hashlib, sys
from collections import Counter, defaultdict
root=Path(__file__).resolve().parents[1]; out=root/'messung'; book=root.parents[1]
def read(f):
    with f.open() as io:return list(csv.DictReader(io))
def ident(r):return (r['case'],r.get('solver') or r.get('method'),r.get('level',r.get('quantum_factor','')) or '')
def val(r):
    v=r.get('error_over_limit',r.get('error'))
    return float(v) if v not in (None,'') else None
info={};changes=[]
files={'baseline':('qss-baseline.csv',399),'extension':('qss-extension.csv',456),'selection':('qss-selection.csv',520),'rk23':('rk23-devs.csv',138)}
for name,(slug,expected) in files.items():
    history=(root/'vorher'/slug) if (root/'vorher'/slug).exists() else root/'quellen/docs/evidence'/slug
    fresh=read(out/(name+'.csv'));past=read(history);a={ident(r):r for r in past};b={ident(r):r for r in fresh}
    assert len(a)==len(b)==len(fresh)==len(past)==expected and a.keys()==b.keys(),(name,len(a),len(b),list(a.keys()-b.keys())[:2])
    for k,r in sorted(b.items()):
        old=a[k];v=val(old);z=val(r)
        changes.append(dict(reihe=name,fall=k[0],verfahren=k[1],einstellung=k[2],status_alt=old['status'],status_neu=r['status'],wert_alt=v,wert_neu=z,ms_alt=old.get('median_ms'),ms_neu=r.get('median_ms'),abweichender_status=old['status']!=r['status']))
    subset=[r for r in changes if r['reihe']==name];high=[r for r in subset if r['verfahren'] in ('qss3','qss4')]
    info[name]=dict(n=expected,alt=dict(Counter(r['status'] for r in past)),neu=dict(Counter(r['status'] for r in fresh)),statuswechsel=sum(r['abweichender_status'] for r in subset),qss34=len(high),qss34_statuswechsel=sum(r['abweichender_status'] for r in high))
    if name=='selection':
        cases=sorted({r['case'] for r in fresh if r['case'].startswith('C')});assert len(cases)==8;sets=[{(r['method'],r['level']) for r in fresh if r['case']==c} for c in cases]
        common=set.intersection(*sets)
        def ms(c,k):
            r=b[(c,*k)];return float(r['median_ms']) if r['status']=='pass' else float('inf')
        def ranking(c,k):
            best=min(ms(c,j) for j in common)
            return ms(c,k)/best if ms(c,k)<float('inf') else float('inf')
        folds=[]
        for test in cases:
            def objective(k):
                rs=[ranking(c,k) for c in cases if c!=test]
                finite=[v for v in rs if v<float('inf')]
                return len(rs)-len(finite),statistics.mean(finite) if finite else float('inf'),k
            k=min(common,key=objective);r=b[(test,*k)]
            folds.append(dict(test=test,method=k[0],level=k[1],status=r['status'],relativ=ranking(test,k) if r['status']=='pass' else None))
        info[name].update(gemeinsame_kandidaten=len(common),folds=folds,c05= dict(Counter(b[('C05',*k)]['status'] for k in common)))
with (out/'revisionsvergleich.csv').open('w',newline='') as io:
    w=csv.DictWriter(io,fieldnames=changes[0]);w.writeheader();w.writerows(changes)
(out/'bilanz.json').write_text(json.dumps(info,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
