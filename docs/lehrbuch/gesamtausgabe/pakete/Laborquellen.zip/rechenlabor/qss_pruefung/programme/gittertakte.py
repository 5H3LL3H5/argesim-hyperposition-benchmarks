"""Dichte Ausgabe der Ereignispolynome an den ersten vier D2Q9-Takten."""
import argparse
import csv
from pathlib import Path
import sys
from unittest.mock import patch

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("vollgitter", type=Path)
parser.add_argument("methode", choices=("qss3","qss4"))
parser.add_argument("ausgabe", type=Path)
parser.add_argument("--takte", type=int, choices=(1,2,3,4), default=4)
args=parser.parse_args()
sys.path.insert(0, str(args.vollgitter.resolve()/"src"))
from gemeinsam import Cavity, DT, END, InitialValueProblem, N, RE, compare, np, solve_ivp
from kavitaet import lattice_fields
from argesim_benchmarks.solvers import advanced_qss as qss
from scipy.integrate import solve_ivp as reference_ivp

c=Cavity(N,RE)
times=DT*np.arange(1,args.takte+1)
fields=[]
state_builder=qss._state_polynomials
active={}


def capture(values, rhs_coefficients, order):
    x=state_builder(values, rhs_coefficients, order)
    active["x"]=np.asarray(x)
    return x


def observe(left, before, right, after):
    while len(fields)<len(times) and times[len(fields)]<=right:
        t=times[len(fields)]
        assert t>=left
        z=np.polynomial.polynomial.polyval(t-left, active["x"].T)
        fields.append(c.field(z))
    return len(fields)==len(times)


class LimitedHistory(InitialValueProblem):
    def _record_step(self,times,states,t,state):
        if len(times)>=3:
            del times[1:-1]
            del states[1:-1]
        return super()._record_step(times,states,t,state)


initial=np.zeros(c.dim)
with patch.object(qss,"_state_polynomials",capture):
    ivp=LimitedHistory(c.rhs,0.,tuple(initial),DT*END,autonomous=True,_stop_after_step=observe)
    solve_ivp(ivp,method=args.methode,options={"quantum":.001,"max_events":1200000})
ref=reference_ivp(c.rhs,(0.,times[-1]),initial,method="DOP853",atol=2e-13,rtol=1e-11,t_eval=times)
assert ref.success
lbm=lattice_fields(N,RE,times)
with args.ausgabe.open("w") as f:
    writer=csv.writer(f)
    writer.writerow(["takt","t_stern","qss_ns_prozent","qss_ns_lokal_U","qss_d2q9_prozent",
                     "qss_d2q9_lokal_U","ns_d2q9_prozent","ns_d2q9_lokal_U"])
    for i,t in enumerate(times):
        ns=c.field(ref.y[:,i])
        a,ap=compare(fields[i],ns)
        b,bp=compare(fields[i],lbm[i])
        d,dp=compare(ns,lbm[i])
        writer.writerow([i+1,t,100*a,ap,100*b,bp,100*d,dp])
