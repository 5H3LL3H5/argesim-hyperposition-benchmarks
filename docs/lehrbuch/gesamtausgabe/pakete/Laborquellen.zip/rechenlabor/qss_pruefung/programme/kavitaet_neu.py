"""Wiederhole die drei nativen Vollgitter-Methodenreihen des Buchs (POSIX)."""
from concurrent.futures import ThreadPoolExecutor
import argparse
import os
from pathlib import Path
import subprocess
import sys

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("labor",type=Path)
parser.add_argument("rohdaten",type=Path)
parser.add_argument("protokolle",type=Path)
parser.add_argument("--workers",type=int,default=4)
args=parser.parse_args()
root=args.labor.resolve()
logs=args.protokolle.resolve()
logs.mkdir(exist_ok=True,parents=True)
env=dict(os.environ,KAV_RAW=str(args.rohdaten.resolve()),OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1",MKL_NUM_THREADS="1")
methods=("qss1","qss2","qss3","qss4","cqss1","bqss1",*(f"{f}{i}" for f in ("liqss","mliqss","eliqss","cheqss") for i in (1,2,3)),"liqss-bdf")
jobs=[]
for method in methods:
    jobs.extend([("rom_qss",method,("--limit","180","--quantum",".003")),("korrektur_qss",method,()),
                 ("voll_qss",method,("--limit","240"))])
jobs += [("korrektur_qss","cqss1",("--offset",s)) for s in ("0",".25",".75","-.25")]
def run(job):
    script,method,opts=job
    label=script+"_"+method+("_"+opts[-1] if "--offset" in opts else "")
    with (logs/(label+".log")).open("w") as f:
        subprocess.run([sys.executable,str(root/"src"/(script+".py")),method,*opts],stdout=f,stderr=subprocess.STDOUT,env=env,check=True)
    print(label,flush=True)
with ThreadPoolExecutor(max_workers=args.workers) as pool:
    list(pool.map(run,jobs))
