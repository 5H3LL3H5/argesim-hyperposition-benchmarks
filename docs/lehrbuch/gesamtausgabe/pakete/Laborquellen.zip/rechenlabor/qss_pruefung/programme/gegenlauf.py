"""Paired solver versions at identical settings; wider deadlines isolate numeric behaviour."""
import argparse, csv, json, os, shutil, sys, signal, tempfile
from pathlib import Path
from types import SimpleNamespace
p=argparse.ArgumentParser(description=__doc__);p.add_argument('fassung',choices=['v917','v918']);p.add_argument('--timeout',type=float,default=45.);p.add_argument('--output',type=Path,help='write a separate comparison run');args=p.parse_args()
root=Path(__file__).resolve().parents[1];src=root/'quellen'
with tempfile.TemporaryDirectory() as tmp:
    base=Path(tmp)
    shutil.copytree(src/'argesim_benchmarks',base/'argesim_benchmarks',ignore=shutil.ignore_patterns('__pycache__'))
    if args.fassung=='v917':
        for f in (root/'vorher').glob('*.py'):shutil.copyfile(f,base/'argesim_benchmarks/solvers'/f.name)
    sys.path[:0]=[str(base),str(src),str(src/'benchmarks')]
    import argesim_benchmarks
    import benchmark_solver_extension as study
    assert Path(argesim_benchmarks.__file__).is_relative_to(base)
    signal.signal(signal.SIGALRM,study.timeout_handler)
    out=args.output or root/'messung'/('gegenlauf_'+args.fassung+'.jsonl')
    with out.open('w',buffering=1) as io:
        for name,build,delta in [('C12',study.spheres,.001),('C21',study.bounce,.001),('C13',study.crane,.0002),('C03',study.amplifier,.005)]:
            case=build()
            for solver in ('qss3','qss4'):
                r=study.measure(case,solver,delta,SimpleNamespace(repeat=1,timeout=args.timeout))
                io.write(json.dumps(r)+'\n')
        for d in (2e-4,4e-5,8e-6,1.6e-6):
            r=study.measure(study.switches(),'liqss-bdf',d,SimpleNamespace(repeat=1,timeout=args.timeout))
            io.write(json.dumps(r)+'\n')
