"""Create an implementation-to-evidence register at the exact tested source."""
from pathlib import Path
import csv,json,hashlib,ast
from collections import defaultdict
base=Path(__file__).resolve().parents[1];src=base/'quellen/argesim_benchmarks/solvers';out=base/'messung'
with (out/'vertragsproben.csv').open() as io:records=list(csv.DictReader(io))
with (out/'extension.csv').open() as io:matrix=list(csv.DictReader(io))
families=[
 ('qss',[1,2,3,4],'6.3','Erster Banddurchgang an einem Meldepolynom vom Grad p−1','Explizite Taylorentwicklung für autonome glatte Abschnitte. Eine externe Ableitungsänderung kann den Termin vorziehen.'),
 ('cqss',[1],'6.4A','Feste Zellmitte, Nachmeldung am Rand','Ohne Hysterese sind sofortige Wechsel an einem Zellrand möglich.'),
 ('bqss',[1],'6.4B','Vorwärtsrichtung zum ausgewählten Gitterwert und widersprechende Steigung','Halten nahe der Ruhelage ist algorithmisch möglich. Das grobe Quantum liefert dann eine ungenaue Bahn.'),
 ('liqss',[1,2,3],'6.5A','Schwellenwahl bei lokaler Diagonallinearisierung','Die übrigen Komponenten wirken als Eingänge. Eine starke Kreuzkopplung kann kurze Intervalle erzwingen.'),
 ('mliqss',[1,2,3],'6.5B','Ausgelöste gemeinsame Lösung für ein gekoppeltes Komponentenpaar','Mit und ohne Paaraktivierung getrennt prüfen. Stufe 3 ist eine Implementierungserweiterung.'),
 ('eliqss',[1,2,3],'6.6','Vorgegebener Defekt über das Quantenband','EQSS-Namen sind Aliasse. Ein Rückgriff auf den dokumentierten Kandidaten ist im Code möglich.'),
 ('cheqss',[1,2,3],'6.6','Tschebyscheff-Form im Fehlerband','Erste Ordnung verwendet den gemeinsamen linearen Fall. Interne Extremstellen beachten.'),
 ('liqss-bdf',[0],'6.5C','LIQSS2- und BDF-Partition mit interpoliertem Austausch','Ergebnis hängt von BDF-Partition, Makroschritt und Kopplungstoleranz ab.')]
rows=[]
for name,orders,fig,mechanism,scope in families:
    for p in orders:
        m=name+(str(p) if p else '')
        module='qss.py' if m in ('qss1','qss2','cqss1') else 'backward_qss.py' if m=='bqss1' else 'mixed_qss.py' if m=='liqss-bdf' else 'advanced_qss.py'
        f=src/module;defs={n.name:n.lineno for n in ast.parse(f.read_text()).body if isinstance(n,ast.FunctionDef)}
        method=m.replace('-','_');unit=[r for r in records if r['method']==m];primary=[r for r in matrix if r['method']==m]
        rows.append([m,p or 'partitioniert',fig,module+':'+str(defs[method]),hashlib.sha256(f.read_bytes()).hexdigest(),mechanism,scope,len(unit),sum(r['ok']=='True' for r in unit),len(primary),sum(r['status']=='pass' for r in primary)])
for p in [1,2]:
    rows.append([f'qss{p}-log',p,'6.7A','qss.py / relative_quantum','','Schwelle bei jeder eigenen Meldung neu ansetzen','Relative Schwelle mit komponentenweiser Untergrenze. Unter den 520 Zeilen separat behandelt.','','','',''])
    rows.append([f'Gruppen-QSS{p}',p,'6.7B','kavitaet_vollgitter/src/gruppen_qss.cpp','','Minimum über alle Zellschwellen','Eine schnelle Zelle löst die Gruppenmeldung aus. Unabhängiger Codepfad, zwei frische Gittergegenproben je Ordnung.','','','',''])
with (out/'methodenregister.csv').open('w',newline='') as io:
    w=csv.writer(io);w.writerow(['Methode','Ordnung','Bild','Einstieg','SHA256 Modul','Entscheidung','Geltungsbereich','Analytische Proben','Davon bestanden','456er Einträge','Davon bestanden']);w.writerows(rows)
assert len(rows)==23
