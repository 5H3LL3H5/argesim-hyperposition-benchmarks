"""Die einzelnen Konfigurationen und Zeitgrenzen der Kleinserie erneut ausführen."""
import argparse
import json
from pathlib import Path
import sys
from concurrent.futures import ProcessPoolExecutor

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("labor",type=Path)
parser.add_argument("index",type=Path)
parser.add_argument("--workers",type=int,default=4)
args=parser.parse_args()
sys.path.insert(0,str(args.labor.resolve()))
from rechnen import single
def run(row):
    path=args.labor/"daten/felder"/(row["datei"]+".npz")
    path.unlink(missing_ok=True)
    run=single(row["n"],row["re"],row["t_end"],row["method"],row["quantum"] or 0.,row["limit_cpu_s"],
               row["repeats"],True,row["model"])
    print(row["datei"],run["status"],flush=True)
if __name__=="__main__":
    rows=json.loads(args.index.read_text())
    with ProcessPoolExecutor(max_workers=args.workers) as pool:list(pool.map(run,rows))
