"""Compare the four original v9.18 runs with repeats on the reviewed solver."""

import argparse
import csv
import json
from collections import Counter
from hashlib import sha256
from pathlib import Path

SUITES = {"baseline": 399, "extension": 456, "selection": 520, "rk23": 138}
COUNTERS = ("accepted", "rejected", "rhs", "lu")


def read_suite(path, expected):
    with path.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    indexed = {
        (
            row["case"],
            row.get("method", row.get("solver")),
            row.get("level", row.get("quantum_factor")),
        ): row
        for row in rows
    }
    if len(rows) != expected or len(indexed) != expected:
        raise ValueError(f"{path} must contain {expected} distinct settings")
    return indexed


def compare(archive, repeat):
    result = []
    summary = {}
    for suite, expected in SUITES.items():
        original_path = archive / (suite + ".csv")
        repeat_path = repeat / (suite + ".csv")
        before = read_suite(original_path, expected)
        after = read_suite(repeat_path, expected)
        if before.keys() != after.keys():
            raise ValueError(f"Different configuration keys in {suite}")
        counts = Counter()
        for case, method, level in sorted(before):
            key = case, method, level
            a, b = before[key], after[key]
            old_status, new_status = a["status"], b["status"]
            old_score = a.get("error", a.get("error_over_limit"))
            new_score = b.get("error", b.get("error_over_limit"))
            changed_counters = [
                k for k in COUNTERS if a.get(k) and b.get(k) and a[k] != b[k]
            ]
            counts["configurations"] += 1
            if old_status == new_status:
                counts["same_status"] += 1
            elif "timeout" in (old_status, new_status):
                counts["switch_involving_timeout"] += 1
            else:
                counts["other_status_switch"] += 1
            if old_score and new_score:
                counts["paired_scores"] += 1
                counts["identical_scores"] += float(old_score) == float(new_score)
            counts["different_work_counts"] += bool(changed_counters)
            result.append(
                {
                    "suite": suite,
                    "case": case,
                    "method": method,
                    "level": level,
                    "status_d656b6f": old_status,
                    "status_c635504": new_status,
                    "score_d656b6f": old_score,
                    "score_c635504": new_score,
                    "changed_work_counts": " ".join(changed_counters),
                    "median_ms_d656b6f": a["median_ms"],
                    "median_ms_c635504": b["median_ms"],
                }
            )
        summary[suite] = {
            **counts,
            "archived_csv_sha256": sha256(original_path.read_bytes()).hexdigest(),
            "repeated_csv_sha256": sha256(repeat_path.read_bytes()).hexdigest(),
        }
    return result, summary


if __name__ == "__main__":
    measurements = Path(__file__).resolve().parents[1] / "messung"
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive-dir", type=Path, default=measurements)
    parser.add_argument(
        "--repeat-dir", type=Path, default=measurements / "skalenfix_c635504"
    )
    args = parser.parse_args()
    archived, repeated = args.archive_dir, args.repeat_dir
    rows, checks = compare(archived, repeated)
    with (repeated / "skalenvergleich.csv").open(
        "w", encoding="utf-8", newline=""
    ) as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0], lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    (repeated / "skalenvergleich.json").write_text(
        json.dumps(checks, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
