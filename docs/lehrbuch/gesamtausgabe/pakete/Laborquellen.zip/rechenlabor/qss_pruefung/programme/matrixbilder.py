"""Recalculate the status, time/error and performance-profile illustrations from the 456 runs."""
from collections import Counter
from pathlib import Path
import csv, json, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
root=Path(__file__).resolve().parents[3];lab=root/'rechenlabor/bildpruefung'
sys.path.insert(0,str(lab))
from versuche import run_matrix
from zeichnen import precision, profiles
info=run_matrix()
report=lab/'messung/pruefwerte.json';d=json.loads(report.read_text());d['matrix']=info;report.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
with (root/'daten/qss-extension.csv').open() as io:data=list(csv.DictReader(io))
cases=info['cases'];co={c:Counter(r['status'] for r in data if r['case']==c) for c in cases}
fig,ax=plt.subplots(figsize=(7.3,2.95),layout='constrained')
bottom=[0]*len(cases)
for k,label,color in [('pass','Bestanden','#006962'),('accuracy_miss','Über Budget','#c66927'),('timeout','Zeitlimit','#89939f'),('event_mismatch','Ereigniszahl','#956790'),('solver_error','Solverfehler','#354f72')]:
    vals=[co[c][k] for c in cases];ax.bar(cases,vals,bottom=bottom,label=label,color=color,width=.71);bottom=[a+b for a,b in zip(vals,bottom)]
ax.set_ylabel('Konfigurationen je Modellfenster');ax.set_ylim(0,60);ax.yaxis.set_major_locator(MaxNLocator(5,integer=True));ax.legend(ncol=3,loc='upper center',bbox_to_anchor=(.5,-.13),frameon=False,fontsize=8)
for suffix,folder in [('pdf','druck'),('svg','abbildungen')]:fig.savefig(root/folder/('pruefung_matrix.'+suffix),bbox_inches='tight',pad_inches=.06)
plt.close(fig)
precision();profiles()
