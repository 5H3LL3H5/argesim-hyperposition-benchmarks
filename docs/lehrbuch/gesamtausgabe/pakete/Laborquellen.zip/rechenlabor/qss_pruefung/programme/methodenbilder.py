"""Create the original vector illustrations and raw values used in Chapter 6."""
from pathlib import Path
import sys, math, csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from scipy.linalg import expm
P=Path(__file__).resolve().parents[1]
BOOK=P.parents[1]
sys.path.insert(0,str(P/'quellen'))
from argesim_benchmarks.ivp import InitialValueProblem
from argesim_benchmarks.runtime import solve_ivp
from argesim_benchmarks.solvers.advanced_qss import _difference_coefficients
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,'font.family':'DejaVu Sans','axes.labelcolor':'#233442','text.color':'#233442','axes.titleweight':'bold','axes.titlesize':10})
COL=['#00615e','#bf551f','#31558c','#8f3878']
records=[]
def curves(ax,fig,series,x,y,**kwargs):
    x=np.asarray(x);y=np.asarray(y);records.extend((fig,series,float(a),float(b)) for a,b in zip(x,y))
    return ax.plot(x,y,**kwargs)[0]
def save(f,name):
    for a in f.axes:
        a.grid(axis='y',alpha=.2);a.tick_params(labelsize=8)
    f.tight_layout(pad=.85,w_pad=1.3)
    for path in [BOOK/'abbildungen'/(name+'.svg'),BOOK/'druck'/(name+'.pdf')]:
        f.savefig(path,bbox_inches='tight',pad_inches=.08)
    plt.close(f)
def solve(m,f,x,t,quantum,**kw):
    return solve_ivp(InitialValueProblem(f,0.,x,t,autonomous=True),m,options=dict(quantum=quantum,max_events=100000,**kw))
def title(ax,t,x,y):
    ax.set_title(t,loc='left');ax.set_xlabel(x);ax.set_ylabel(y)
f,axes=plt.subplots(1,2,figsize=(8.5,2.8));a,b=axes;delta=.01
for p in range(1,5):
    h=(math.factorial(p)*delta)**(1/p)
    t=np.linspace(0,h,61);u=t/h
    curves(a,'6.3','QSS'+str(p),t,t**p/math.factorial(p),color=COL[p-1],label=f'QSS{p}',ls=['-','--','-.',':'][p-1],lw=2)
    a.scatter([h],[delta],color=COL[p-1],s=18)
    curves(b,'6.3','QSS'+str(p)+' normiert',u,u**p,color=COL[p-1],ls=['-','--','-.',':'][p-1],lw=2)
a.axhline(delta,color='#555',lw=.7,ls=':');a.legend(ncol=2,frameon=False,fontsize=8)
title(a,'A   Erster Termin für x′ = −q','Zeit s','|x − q|');title(b,'B   Dasselbe Segment normiert','Anteil des ersten Ereignisintervalls','|x − q| / Δ')
save(f,'qss_ordnung')
f,(a,b)=plt.subplots(1,2,figsize=(8.5,2.8))
t=np.linspace(0,1.5,301);x=.15+t;dq=.4
curves(a,'6.4','Zustand',t,x,color=COL[0],label='x');curves(a,'6.4','Zellmitte',t,(np.floor(x/dq)+.5)*dq,drawstyle='steps-post',color=COL[1],label='q')
for k in range(5):a.axhline(k*dq,color='#999',lw=.5,ls=':')
a.legend(frameon=False);title(a,'A   CQSS1 bei gleichförmiger Bewegung','Zeit','Zustand oder Zellmitte')
r=solve('bqss1',lambda t,y:(-10*y[0],),(.1,),.35,.2);t=np.linspace(0,.35,100)
curves(b,'6.4','exakt',t,.1*np.exp(-10*t),color=COL[0],label='Exponentiallösung')
curves(b,'6.4','BQSS1',r.times,[z[0] for z in r.states],color=COL[1],ls='--',label='BQSS1, Δ = 0,2')
b.legend(frameon=False);title(b,'B   BQSS1 hält einen Zustand im Band','Zeit','Zustand x')
save(f,'qss_zelle')
f,(a,b,c)=plt.subplots(1,3,figsize=(9,3.0))
mat=np.array([[-1.,-1.],[1.,-1.]]);load=np.array([.2,1.2]);eq=np.linalg.solve(mat,-load);init=(-4.,4.);end=2.
def rhs(t,x):return (-x[0]-x[1]+.2,x[0]-x[1]+1.2)
def exact(t):return eq+expm(t*mat)@(np.array(init)-eq)
for ax,family,title_name in [(a,'liqss','A   LIQSS'),(b,'mliqss','B   mLIQSS')]:
    for p in (1,2,3):
        m=family+str(p);r=solve(m,rhs,init,end,.05,jacobian=lambda t,q:mat)
        er=[float(np.linalg.norm(v-exact(t))) for t,v in zip(r.times,r.states)]
        curves(ax,'6.5',m,r.times,er,label='Ordnung '+str(p),color=COL[p-1],ls=['-','--','-.'][p-1],lw=1.5)
    title(ax,title_name,'Zeit','Zustandsfehler (2-Norm)');ax.legend(frameon=False,fontsize=7)
r=solve('liqss-bdf',rhs,init,end,.05,bdf_partition=(1,),jacobian=lambda t,q:tuple(map(tuple,mat)),rtol=1e-4,atol=1e-7)
for j in (0,1):
    curves(c,'6.5','Partition '+str(j),r.times,[v[j] for v in r.states],color=COL[j],label=['x₁ · LIQSS2','x₂ · BDF'][j])
c.legend(frameon=False,fontsize=7);title(c,'C   LIQSS–BDF','Zeit','Komponentenwert')
save(f,'qss_implizit')
f,axes=plt.subplots(1,3,figsize=(8.6,2.65));s=np.linspace(0,1,151)
for i,ax in enumerate(axes,1):
    for fam,lab,col,ls in [('extended','eLIQSS',COL[0],'-'),('chebyshev','CheQSS',COL[1],'--')]:
        # For p=1 the implementation shares the same linear candidate; input horizon is half for e.
        if i==1:err=2*s-1
        else:err=np.polynomial.polynomial.polyval(s,_difference_coefficients(fam,i,1.,.5 if fam=='extended' else 1.))
        curves(ax,'6.6',lab+str(i),s,err,color=col,ls=ls,label=lab+str(i),lw=2)
    title(ax,'ABC'[i-1]+'   Ordnung '+str(i),'Zeit / Segmentdauer','(x − q) / Δ');ax.set_ylim(-1.2,1.2);ax.legend(frameon=False,fontsize=8)
save(f,'qss_formen')
f,(a,b)=plt.subplots(1,2,figsize=(8.4,2.7))
for p in (1,2):
    r=solve('qss'+str(p),lambda t,y:(-y[0],),(8.,),1.4,1.,relative_quantum=.25)
    xs=[x[0] for x in r.states];curves(a,'6.7',f'QSS{p} relativ',r.times,[max(1.,.25*abs(x)) for x in xs],drawstyle='steps-post',marker='o',ms=3,color=COL[p-1],ls=['-','--'][p-1],label='QSS'+str(p))
a.legend(frameon=False,fontsize=8);title(a,'A   Relatives Quantum mit Untergrenze','Zeit','Δ beim Neuansatz')
s=np.linspace(0,1,90)
for p in [1,2]:
    curves(b,'6.7','Gruppe Ordnung '+str(p),s,s**p,color=COL[p-1],label='Gruppe '+str(p),ls=['-','--'][p-1],lw=2)
curves(b,'6.7','weitere Zelle',s,.125*s,color=COL[2],ls=':',label='Langsame Zelle (linear)')
b.axvline(1,ls=':',lw=.7,color='#777');b.legend(frameon=False,fontsize=7);title(b,'B   Erste Zelle löst Gruppenmeldung aus','Zeit / erster Gruppentermin','Lokaler Defekt / Δ')
save(f,'qss_varianten')
with (P/'messung/bildkurven.csv').open('w',newline='') as io:
    w=csv.writer(io);w.writerow(['abbildung','kurve','x','y']);w.writerows(records)
