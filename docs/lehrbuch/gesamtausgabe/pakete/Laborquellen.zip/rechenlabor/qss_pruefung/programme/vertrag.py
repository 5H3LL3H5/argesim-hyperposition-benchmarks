"""Independent exact solutions at the public solver entry point. Run from any folder."""
import csv
import json
import math
from pathlib import Path
import sys

here = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(sys.argv[1]).resolve() if len(sys.argv)>1 else here / 'quellen'))
from argesim_benchmarks.ivp import InitialValueProblem
from argesim_benchmarks.runtime import solve_ivp, _QUANTISED_SOLVERS

def run(method, rhs, start, stop, model, options, q, expected, budget):
    args = dict(quantum=q, max_events=10000, **options)
    problem = InitialValueProblem(rhs, 0., start, stop, autonomous=True)
    try:
        answer = solve_ivp(problem, method=method, options=args)
        error = math.dist(answer.final_state, expected)
        monotone = all(a<b for a,b in zip(answer.times,answer.times[1:]))
        ok = answer.final_time == stop and monotone and error <= budget
        return dict(method=method,test=model,quantum=str(q),t=answer.final_time,first=answer.times[1],error_l2=error,budget=budget,ok=ok,detail='')
    except Exception as ex:
        return dict(method=method,test=model,quantum=str(q),t='',first='',error_l2='',budget=budget,ok=False,detail=str(ex))

records=[]
for method in sorted(_QUANTISED_SOLVERS):
    options = dict(bdf_partition=(1,)) if method=='liqss-bdf' else {}
    records.append(run(method,lambda t,y:(0.,0.),(.375,.625),.25,'Ruhezustand',options,.01,(.375,.625),1e-12))
    records.append(run(method,lambda t,y:(.5,-.125),(.375,.625),.25,'Konstante Geschwindigkeiten',options,.01,(.5,.59375),1e-10))
    t=.2
    for quantum in (.01,.0025):
        # x'=-x+y, y'=-x-y; use non-boundary initial conditions.
        a,b=.377,.619
        exact=(math.exp(-t)*(a*math.cos(t)+b*math.sin(t)),math.exp(-t)*(b*math.cos(t)-a*math.sin(t)))
        records.append(run(method,lambda t,y:(-y[0]+y[1],-y[0]-y[1]),(a,b),t,'Gedaempfte Rotation',options,quantum,exact,2*quantum))
for method in ('qss1','cqss1','bqss1','qss3','qss4'):
    records.append(run(method,lambda t,y:(1e12,.5e12),(0.,0.),1.5e-12,'Getrennte schnelle Termine',{},1.,(1.5,.75),2e-12))
records.append(run('qss2',lambda t,y:(y[1],2e26),(0.,0.),1.5e-13,'Positive und negative nahe Nullstelle',{},(1.,1e20),(2.25,3e13),.004))
out=Path(sys.argv[2]).resolve() if len(sys.argv)>2 else here/'messung/vertragsproben.csv'
with out.open('w',newline='') as io:
    w=csv.DictWriter(io,fieldnames=records[0]);w.writeheader();w.writerows(records)
print(json.dumps({'Anzahl':len(records),'bestanden':sum(r['ok'] for r in records),'Abweichungen':[r for r in records if not r['ok']]},indent=2))
