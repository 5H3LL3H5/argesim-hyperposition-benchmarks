"""Regression für Zeitfenster, Mehrfachwurzeln und die nativen Solveraufrufe."""
import argparse
import json
import math
import random
import sys
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("vollgitter", type=Path)
args = parser.parse_args()
sys.path.insert(0, str(args.vollgitter.resolve() / "src"))
from gemeinsam import InitialValueProblem, np, solve_ivp
from argesim_benchmarks.solvers._polynomial import _unit_interval_roots, first_positive_root


def from_roots(roots):
    return np.polynomial.polynomial.polyfromroots(roots).tolist()


def check(coefficients, horizon, expected, *, atol=2e-12, rtol=2e-9):
    t = first_positive_root(coefficients, horizon, time_tolerance=1e-13)
    if not math.isclose(t, expected, abs_tol=atol, rel_tol=rtol):
        raise AssertionError((coefficients, horizon, expected, t))


fixed = 0
for coefficients, horizon, expected in [
    ([0.], 1., math.inf), ([1.], 1., math.inf), ([0.,0.,1.], 1., math.inf),
    (from_roots([0.,0.,0.125]), 1., 0.125), (from_roots([0.,1.]),1.,1.),
    (from_roots([.125,.25]), 1., .125), (from_roots([-.5,-.125]), 1., math.inf),
    (from_roots([.125,.125]), 136.71875, .125),
    (from_roots([.25,.25,.25,.25]), 136.71875, .25),
    (from_roots([.125,.125,.5,.75]), 1., .125),
    ([1., -2., 1.], .9, math.inf), ([1.0000001,-2.,1.], 2., math.inf),
    ([-.001,0.,0.,0.,331313052.57113314],136.71875,(.001/331313052.57113314)**.25),
    ([.001,0.,0.,-3492280.285107953],136.71875,(.001/3492280.285107953)**(1/3)),
]:
    check(coefficients, horizon, expected)
    fixed += 1
for h in (0.1, 1., 136.71875, 1e8):
    check([-.001,0.,0.,0.,331313052.57113314], h, (.001/331313052.57113314)**.25)
    check([-1e-40,0.,1.], h, 1e-20, atol=1e-28,rtol=1e-8)
    fixed += 2
tiny = math.ulp(0.0)
for factors, h, expected in [
    ([2 * tiny, -3 * tiny, tiny], 3., 1.),
    ([3 * tiny, -3 * tiny, tiny], 3., math.inf),
    ([9.88131291682493e-124, -1.4821969375237398e-223, 5e-324], 3e100, 1e100),
]:
    check(factors, h, expected, rtol=2e-15)
    fixed += 1
assert np.allclose(_unit_interval_roots(from_roots([0.,.25,.75]), 1e-13), [0.,.25,.75], atol=1e-12)
rng = random.Random(917)
cases = 0
for degree in (1,2,3,4):
    for _ in range(100):
        # Separated dyadic roots avoid ill-conditioned synthetic oracle values.
        roots = [k/64 for k in rng.sample(list(range(-48,0))+list(range(1,49)),degree)]
        h = rng.choice((.125,.5,1.,136.71875))
        scale = math.ldexp(1., rng.randrange(-90,91))
        expected = min((v for v in roots if 0.<v<=h), default=math.inf)
        check([scale*c for c in from_roots(roots)], h, expected)
        cases += 1

# Exercise the registry, not just the polynomial helpers.
oscillator = lambda t,z: (z[1],-z[0])
integrations = {}
for method in ("qss3","qss4","liqss1","liqss2","liqss3","eliqss1","eliqss2","eliqss3"):
    problem=InitialValueProblem(oscillator,0.,(1.,0.),1.,autonomous=True)
    result=solve_ivp(problem,method=method,options={"quantum":.001,"max_events":200000})
    error=math.dist(result.final_state,(math.cos(1.),-math.sin(1.)))
    if result.times[-1] != 1. or error >= .02:
        raise AssertionError((method, result.times[-1], error))
    integrations[method] = error
print(json.dumps({"explizite_nullstellenfaelle":fixed, "deterministische_faktorpolynome":cases,
                  "einheitsintervall_mit_startwurzel":True,
                  "oszillator_endwertfehler":integrations},indent=2))
