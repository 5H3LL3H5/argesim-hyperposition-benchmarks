"""Prüfe die tatsächlich erreichten QSS-Segmente des uninstrumentierten CP2-Laufs."""
import argparse
import csv
import json
import math
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("vollgitter", type=Path)
parser.add_argument("methode", choices=("qss3", "qss4"))
parser.add_argument("ausgabe", type=Path)
parser.add_argument("--segmente", type=int, default=None, help="feste Zahl statt Protokoll des Zeitlaufs")
args = parser.parse_args()
root = args.vollgitter.resolve()
sys.path.insert(0, str(root / "src"))
from gemeinsam import Cavity, DT, END, InitialValueProblem, N, RE, compare, np, solve_ivp
from argesim_benchmarks.solvers import advanced_qss as qss
from scipy.integrate import solve_ivp as reference_ivp

method = args.methode
quantum = 0.001
order = int(method[-1])
cavity = Cavity(N, RE)
out = args.ausgabe
out.mkdir(parents=True, exist_ok=True)
budget_log = root / "daten" / "voll_qss" / (method + ".json")
captured = {}
times = []
segment_rows = []
state_taylor = qss._state_polynomials
rhs_taylor = qss._rhs_taylor


def trace_rhs(problem, time, quantized, order, derivative_step):
    captured["q"] = np.asarray(quantized, dtype=float)
    return rhs_taylor(problem, time, quantized, order, derivative_step)


def trace_state(values, rhs_coefficients, order):
    x = state_taylor(values, rhs_coefficients, order)
    captured["x"] = np.asarray(x, dtype=float)
    return x


def band_bound(difference, length):
    """Convex hull of the Bernstein coefficients on the closed segment."""
    powers = difference * length**np.arange(order+1)
    result = 0.0
    for k in range(order+1):
        weights = [math.comb(k, j)/math.comb(order, j) for j in range(k+1)]
        bound = np.abs(powers[:, :k+1] @ weights).max()
        result = max(result, float(bound))
    return result


probe_times = (0.25, 0.5, 0.75, 1.0)
stored = tempfile.TemporaryFile()


def observe(left, before, right, after):
    length = right - left
    x = captured["x"]
    defect = x.copy()
    defect[:, :order] -= captured["q"]
    band = band_bound(defect, length)
    for fraction in probe_times:
        elapsed = length * fraction
        predicted = np.polynomial.polynomial.polyval(elapsed, x.T)
        np.asarray(predicted, dtype="<f8").tofile(stored)
        times.append(right if fraction == 1.0 else left+elapsed)
    if not np.allclose(after, predicted, atol=1e-12, rtol=1e-12):
        raise RuntimeError("Rekonstruiertes Polynom und Solverzustand am Segmentende widersprechen sich.")
    endpoint_defect = float(abs(np.polynomial.polynomial.polyval(length, defect.T)).max())
    segment_rows.append({
        "segment": len(segment_rows)+1, "t0": left, "t1": right,
        "band_ende_in_quanten": endpoint_defect/quantum,
        "bernstein_oberschranke_in_quanten": band/quantum,
    })
    if args.segmente is not None:
        return len(segment_rows) >= args.segmente
    if budget_log.exists() and budget_log.stat().st_size:
        target = json.loads(budget_log.read_text())["accepted_output_steps"]
        return len(segment_rows) >= target
    return False


class TraceProblem(InitialValueProblem):
    def _record_step(self, times, states, t, state):
        if len(times) >= 3:
            del times[1:-1]
            del states[1:-1]
        return super()._record_step(times, states, t, state)


initial = np.zeros(cavity.dim)
problem = TraceProblem(cavity.rhs, 0., tuple(initial), DT*END, autonomous=True, _stop_after_step=observe)
with patch.object(qss, "_rhs_taylor", trace_rhs), patch.object(qss, "_state_polynomials", trace_state):
    solve_ivp(problem, method=method, options={"quantum":quantum, "max_events":1200000})

matched = args.segmente
if matched is None:
    timing = json.loads(budget_log.read_text())
    matched = timing["accepted_output_steps"]
    assert matched <= len(segment_rows)
    assert abs(segment_rows[matched-1]["t1"]-timing["last_time"]) < 1e-13
segment_rows = segment_rows[:matched]
times = times[:matched*len(probe_times)]
end = times[-1]
ref = reference_ivp(cavity.rhs, (0., end), initial, method="DOP853", rtol=1e-11, atol=2e-13, dense_output=True)
check_ref = reference_ivp(cavity.rhs, (0., end), initial, method="RK45", rtol=2e-12, atol=4e-14, dense_output=True)
if not ref.success or not check_ref.success:
    raise RuntimeError("Referenzintegration fehlgeschlagen.")

stored.seek(0)
rows = []
for i, t in enumerate(times):
    predicted = np.fromfile(stored, dtype="<f8", count=cavity.dim)
    if matched*len(probe_times) == i+1 and args.segmente is None:
        saved = np.load(budget_log.with_suffix(".npz"))["z"]
        if not np.allclose(predicted, saved, atol=1e-12, rtol=1e-12):
            raise RuntimeError("Endfeld ist nicht reproduzierbar.")
    velocity = cavity.field(predicted)
    target = cavity.field(ref.sol(t))
    rel, point = compare(velocity, target)
    ref_rel, ref_point = compare(cavity.field(check_ref.sol(t)), target)
    rows.append({
        "segment": i//len(probe_times)+1, "segmentanteil":probe_times[i%len(probe_times)],
        "t_stern": t, "feldfehler_prozent":100*rel, "lokal_U":point,
        "ref_abstand_prozent":100*ref_rel, "ref_abstand_U":ref_point,
    })
stored.close()


def write_table(name, data):
    with (out / (method+"_"+name+".csv")).open("w") as f:
        writer = csv.DictWriter(f, fieldnames=data[0])
        writer.writeheader()
        writer.writerows(data)


write_table("segmente", segment_rows)
write_table("feldfehler", rows)
summary = {
    "methode": method, "gitter":N, "zustaende":cavity.dim, "quantum":quantum,
    "erster_termin":segment_rows[0]["t1"], "letzter_termin":end,
    "reproduzierte_segmente":matched, "kontrollfelder":len(rows),
    "max_band_ende_in_quanten":max(r["band_ende_in_quanten"] for r in segment_rows),
    "max_bernstein_oberschranke_in_quanten":max(r["bernstein_oberschranke_in_quanten"] for r in segment_rows),
    "max_feldfehler_prozent":max(r["feldfehler_prozent"] for r in rows),
    "max_lokal_U":max(r["lokal_U"] for r in rows),
    "letzter_feldfehler_prozent":rows[-1]["feldfehler_prozent"],
    "letzter_lokal_U":rows[-1]["lokal_U"],
    "max_ref_abstand_prozent":max(r["ref_abstand_prozent"] for r in rows),
    "max_ref_abstand_U":max(r["ref_abstand_U"] for r in rows),
    "erstes_feld_ausserhalb_budget":next((r for r in rows if r["feldfehler_prozent"]>1 or r["lokal_U"]>.01), None),
}
(out / (method+"_pruefung.json")).write_text(json.dumps(summary, indent=2))
print(json.dumps(summary), flush=True)
