"""Two controlled C19R experiments; run from any directory with the bundled data."""
from pathlib import Path
import json
import sys

import numpy as np
from scipy.integrate import quad
from scipy.special import ndtr

HERE = Path(__file__).resolve().parent
LAB = HERE.parent
sys.path[:0] = [str(LAB / "messplanung/projekt"), str(LAB / "fno_benchmarks")]
import c19r
import transport_check as fixed

OUT = HERE / "messung"


def compare_bands():
    with np.load(LAB / "fno_benchmarks/messung/c19r_modelle.npz") as a:
        train, test = a["train_rates"], a["test_rates"]
        field, point, injected = a["reference"], a["point_reference"], a["mass_injected"]
        labels = train @ a["kernels"].reshape(8, -1)
    with np.load(LAB / "operator_vergleich/messung/c19r.npz") as a:
        base = a["fv_basis"]
    target = np.linalg.lstsq(train, labels, rcond=1e-11)[0].reshape(base.shape)
    mass = c19r.mass(target)
    freq = np.fft.rfft2(target - base, axes=(-2, -1), norm="ortho")
    ky = np.abs(np.fft.fftfreq(base.shape[1]) * base.shape[1]).round().astype(int)
    kx = np.arange(freq.shape[-1])
    results = []
    for x, y in [(0, 0), (4, 2), (8, 4), (12, 8), (24, 12), (32, 16)]:
        mask = (ky[:, None] <= y) & (kx[None, :] <= x)
        corr = np.fft.irfft2(freq * mask, s=base.shape[-2:], axes=(-2, -1), norm="ortho")
        singular = np.linalg.svd(corr.reshape(8, -1), compute_uv=False)
        estimates = (test @ (base + corr).reshape(8, -1)).reshape(field.shape)
        estimates = np.maximum(0, estimates)
        estimates *= ((test @ mass) / c19r.mass(estimates))[:, None, None]
        scores = c19r.report_scores(estimates, field, point, injected)
        results.append(dict(kx=x, ky=y, singular_values=singular.tolist(),
                            rank=int(np.linalg.matrix_rank(corr.reshape(8, -1))),
                            accepted=int(sum(scores["pass"])), scores=scores))
    assert results[-1]["accepted"] == 8
    return dict(train=80, test=8, source_rank=int(np.linalg.matrix_rank(train)), rows=results)


def cell_sensor_reference(x, y, h, sx, sy):
    """Green solution on open plane, cell-integrated then read with the FV sensor."""
    def integrand(age):
        sigma = np.sqrt(2 * c19r.DIFFUSION * age)
        def probabilities(centers, mean):
            return ndtr((centers + h/2 - mean)/sigma) - ndtr((centers-h/2-mean)/sigma)
        px = probabilities(x, c19r.VELOCITY*age)
        py = probabilities(y, 0.)
        return (sx @ px) * (sy @ py) * fixed.p.mass_rate / (c19r.WATER_COLUMN*h*h)
    return quad(integrand, 0, fixed.END, epsabs=1e-5, epsrel=1e-11)[0]


def compare_sources():
    archived = json.loads((LAB / "cp2_genauigkeit/transport_feste_raender.json").read_text())
    point = float(2*np.sum(c19r.point_basis()))
    rows = []
    for old in archived["rows"]:
        h = old["h_m"]
        x = np.arange(-4.5+h/2, 12.5, h)
        y = np.arange(-4.5+h/2, 4.5, h)
        sx, sy = fixed.linear_weights(x, 5.), fixed.linear_weights(y, 0.)
        observed = cell_sensor_reference(x, y, h, sx, sy)
        wx, wy = fixed.linear_weights(x, 0.), fixed.linear_weights(y, 0.)
        for name in ("bilinear", "verbreitert"):
            if name == "verbreitert":
                wx, wy = [np.convolve(w, [.25, .5, .25], mode="same") for w in (wx, wy)]
            np.testing.assert_allclose([wx.sum(), wy.sum(), wx @ x, wy @ y], [1, 1, 0, 0], atol=1e-14)
            source = np.outer(wy, wx)*fixed.p.mass_rate/(c19r.WATER_COLUMN*h*h)
            field, low = fixed.advance(np.zeros_like(source), h, 7200., source)
            value = float(sy @ field @ sx)
            if name == "bilinear":
                np.testing.assert_allclose(value, old["well_mg_m3"], rtol=1e-11)
            rows.append(dict(h_m=h, source=name, well=value, cell_reference=observed,
                             point_reference=point, minimum=float(low), delta_cell=value-observed,
                             delta_point=value-point))
    return dict(horizon_s=fixed.END, dt_s=7200, rows=rows)


if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    for name, experiment in [("c19_baender", compare_bands), ("c19_quellprojektion", compare_sources)]:
        (OUT / (name+".json")).write_text(json.dumps(experiment(), indent=2)+"\n")
