"""Stabilitätsgrenzen, vier Wandspuren, Quellenversuch und Dolan–Moré-Druckkurven."""
from argparse import ArgumentParser
from collections import Counter, defaultdict
import csv
from fractions import Fraction
from hashlib import sha256
import json
from math import cos, factorial, isclose, log, pi, sqrt
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
LAB = HERE.parent
ROOT = LAB.parent
CONTROL = LAB / 'bildpruefung/messung/57_leistungsprofile.csv'
RAW = ROOT / 'daten/qss-extension.csv'
# Linienfarben aus der gedruckten Legende. Alle übrigen Profile sind grau.
COLORS = {'#173549': ('rk45',''), '#b0472e': ('rk4',''),
          '#00796b': ('qss2','0.0002'), '#286192': ('liqss-bdf','0.001')}


def powers(z, order):
    return sum(z**k / factorial(k) for k in range(order + 1))


def zero_interval(polynomial, lo, hi):
    """Das Intervall schließt die Wurzel mit rationaler Arithmetik ein."""
    lo, hi = Fraction(lo), Fraction(hi)
    assert polynomial(lo) < 0 < polynomial(hi)
    for _ in range(70):
        mid = (lo + hi) / 2
        if polynomial(mid) <= 0:
            lo = mid
        else:
            hi = mid
    return [str(lo), str(hi)]


def stability():
    cub = lambda x: x**3 - 4*x**2 + 12*x - 24
    bogacki = lambda x: x**3 - 3*x**2 + 6*x - 12
    prince = lambda x: x**5 - 5*x**4 + 25*x**3 - 100*x**2 + 300*x - 600
    bounds = {'RK4': zero_interval(cub, 2, 3), 'BS3': zero_interval(bogacki, 2, 3),
              'DP5': zero_interval(prince, 3, 4)}
    x = Fraction(1)
    assert powers(-x, 4) == Fraction(3, 8) and powers(-x, 3) == Fraction(1, 3)
    assert powers(-x, 4) + powers(-x, 3) == Fraction(17, 24)
    for x in (Fraction(1, 2), Fraction(1), Fraction(5, 2), Fraction(3), Fraction(4)):
        assert powers(-x, 4)-1 == x*cub(x)/24
        assert powers(-x, 3)+1 == -bogacki(x)/6
        dp = powers(-x, 5) + x**6/600
        assert dp-1 == x*prince(x)/600
        assert dp == powers(-x, 6)+x**6/3600
        assert (1-x*x/2+x**4/24)**2+(x-x**3/6)**2-1 == x**6*(x*x-8)/576
    diff_limit = 1/(2*cos(pi/8)**2)
    assert isclose(diff_limit, 2/(2+sqrt(2)))
    for s in [Fraction(3, 4), Fraction(5, 4)]:
        assert (1-2*s)**2 == 1-4*s*(1-s)
    return {'reelle_Grenzen_rationale_Einschliessung': bounds,
            'reelle_Grenzen': {k: float(Fraction(v[0])) for k,v in bounds.items()},
            'RK4_Baumgarte_h_gleich_T_Eigenfaktor': '3/8',
            'RK4_Baumgarte_Rest_g_bei_gstrich_null': '17/24',
            'Euler_Diffusion_N4': diff_limit}


def calendar_check():
    """Die gedruckte Funktion mit zwei Knotennummerierungen ausführen."""
    from heapq import heappop, heappush
    from math import inf
    master=(ROOT/'lehrbuch_numerische_simulation.md').read_text()
    begin=master.index('def kalender(d, t0, schnitt,')
    printed=master[begin:master.index('~~~',begin)]
    scope={'heappop':heappop, 'heappush':heappush, 'inf':inf}
    exec(compile(printed,'<gedruckter QSS-Kalender>','exec'),scope)
    quarter,half,late=Fraction(1,4),Fraction(1,2),Fraction(3,4)
    logs=[]
    for order in [(0,1,2,3),(3,2,1,0)]:
        q=[0]*4
        next_time=[quarter, half, half, Fraction(5,8)]
        events=[]
        def index(physical):
            return order.index(physical)
        def cut(i,t):
            return next_time[order[i]]
        def deps(i):
            links=({1,3},{2},{1},set())
            return {index(other) for other in links[order[i]]}
        def advance(t,nodes):
            assert nodes
            if events:
                assert t>events[-1][0]
        def value(i):
            k=order[i]
            return 1+q[{1:2,2:1}.get(k,k)]
        def apply(t,packet,nodes):
            deliveries={order[i]:a for i,a in packet.items()}
            events.append((t,deliveries))
            for k,a in deliveries.items():
                assert index(k) in nodes
                q[k]=a
                next_time[k]=inf
            if t==quarter:
                next_time[1],next_time[3]=late,inf
            if t==half:
                next_time[2]=late
        scope['kalender'](4,Fraction(0),cut,advance,value,apply,deps)
        assert events==[(quarter,{0:1}),(half,{2:1}),(late,{1:2,2:1})]
        logs.append([(str(t),sorted(packet.items())) for t,packet in events])
    assert logs[0]==logs[1]
    return {'beide_Knotennummerierungen':logs,
            'stornierter_Termin':'5/8','verschobener_Termin_von_bis':['1/2','3/4']}


def field_checks():
    import numpy as np
    from scipy import sparse
    sys.path.insert(0, str(LAB/'physik_residual'))
    import kavitaet
    with np.load(kavitaet.FIELDS) as fields:
        raw = fields['prediction_Re100_fourier'].astype(float)
        reference = fields['reference_Re100'].astype(float)
    n = raw.shape[-1]
    assert n == 65
    div, boundary, target = kavitaet.constraints(n)
    mask = np.tile((np.arange(n)>0) & (np.arange(n)<n-1),4)
    flux, _ = kavitaet.retract(raw,div,np.zeros(n*n))
    joint, _ = kavitaet.retract(raw,sparse.vstack((div,boundary[mask]),format='csr'),
                               np.r_[np.zeros(n*n),target[mask]])
    archived = json.loads((LAB/'physik_residual/messung/physik_residual.json').read_text())['cp2']['fields']['fourier']
    c = max(2,int(.055*n))
    region = (slice(None),slice(c,-c),slice(c,-c))
    result = {}
    for name,field in [('raw',raw),('flux',flux),('joint',joint)]:
        discrepancy = (boundary @ field.ravel()-target).reshape(4,n)[:,1:-1]
        walls = {}
        for wall,values in zip(('Boden','Deckel','West','Ost'),discrepancy,strict=True):
            j = int(np.argmax(np.abs(values)))+1
            walls[wall] = {'Flaechenindex_ab_0':j,'Position_entlang_der_Wand':(j+.5)/n,
                           'Maximum_durch_U':float(abs(values[j-1]))}
        maximum = max(v['Maximum_durch_U'] for v in walls.values())
        core = float(np.linalg.norm((field-reference)[region])/np.linalg.norm(reference[region]))
        assert isclose(maximum,archived[name]['wall_max'],rel_tol=2e-10,abs_tol=1e-12)
        assert isclose(core,archived[name]['relative_core'],rel_tol=2e-10)
        if name != 'joint':
            assert walls['Ost']['Maximum_durch_U']==maximum and walls['Ost']['Flaechenindex_ab_0']==63
        result[name]={'Innenfeld_relativ':core,'Wandmaximum_durch_U':maximum,'Wandspuren':walls}
    return result


def source_checks():
    import numpy as np
    from transport_varianten import compare_sources, fixed
    recorded=json.loads((HERE/'messung/c19_quellprojektion.json').read_text())
    actual=compare_sources()
    assert actual['horizon_s']==recorded['horizon_s'] and actual['dt_s']==recorded['dt_s']
    for a,b in zip(actual['rows'],recorded['rows'],strict=True):
        for key,val in b.items():
            assert isclose(a[key],val,rel_tol=2e-11,abs_tol=1e-8) if isinstance(val,(float,int)) else a[key]==val
    selected={r['source']:r for r in actual['rows'] if r['h_m']==.25}
    narrow=selected['bilinear']
    total=selected['verbreitert']['well']-narrow['well']
    assert round(total,2)==-1190.48
    moments={}
    for h in sorted({r['h_m'] for r in actual['rows']}):
        moments[h]=[]
        for end in (12.5,4.5):
            centers=np.arange(-4.5+h/2,end,h)
            weights=fixed.linear_weights(centers,0.)
            wide=np.convolve(weights,[.25,.5,.25],mode='same')
            np.testing.assert_allclose([sum(wide),wide@centers],[1,0],atol=1e-14)
            gain=float((wide-weights) @ centers**2)
            assert isclose(gain,h*h/2)
            moments[h].append(gain)
    return {'neue_Rechnung':actual,'Zuwachs_zweites_Moment_x_y_m2':moments,'breit_minus_bilinear':total,
            'bilinear_minus_Green_Zellsensor':narrow['delta_cell'],'bilinear_minus_Green_Punkt':narrow['delta_point']}


def performance():
    with RAW.open() as f:
        rows=list(csv.DictReader(f))
    cases=sorted({r['case'] for r in rows})
    configs=sorted({(r['method'],r['quantum_factor']) for r in rows})
    assert (len(rows),len(cases),len(configs))==(456,8,57)
    assert len({(r['case'],r['method'],r['quantum_factor']) for r in rows})==len(rows)
    ratios={c:[] for c in configs}
    best_by_case={}
    for case in cases:
        passed={}
        for row in (r for r in rows if r['case']==case and r['status']=='pass'):
            ms=Fraction(row['median_ms']); score=Fraction(row['error_over_limit'])
            assert ms>0 and 0<=score<=1
            passed[row['method'], row['quantum_factor']]=ms
        if not passed:
            best_by_case[case]={'bestanden':0,'Minimum_ms':None,'Schnellste':[]}
            continue
        minimum=min(passed.values())
        winners=[list(key) for key,value in passed.items() if value==minimum]
        best_by_case[case]={'bestanden':len(passed),'Minimum_ms':float(minimum),'Schnellste':winners}
        for key,time in passed.items():
            ratios[key].append(time/minimum)
    with CONTROL.open() as f:
        stored=defaultdict(list)
        for row in csv.DictReader(f):
            assert int(row['nenner'])==len(cases)
            stored[row['verfahren'],row['quantum']].append((float(row['tau']),int(row['anzahl'])))
    thresholds={}
    for key,values in ratios.items():
        crossings=sorted({Fraction(1),*values})
        curve=[(float(t),sum(r<=t for r in values)) for t in crossings]
        for (t,count),(old,oldcount) in zip(curve,stored[key],strict=True):
            assert isclose(t,old,rel_tol=3e-14) and count==oldcount
        thresholds[key]=curve
    assert set(stored)==set(configs)
    indicators={key[0]+(' · '+key[1] if key[1] else ''):
                [sum(v<=tau for v in ratios[key]) for tau in [1,2,10,100,5000]] for key in COLORS.values()}
    return thresholds, {'Rohzeilen':len(rows),'Einstellungen':len(configs),'Nenner':len(cases),
                       'Status':dict(Counter(r['status'] for r in rows)),'Fallminima':best_by_case,
                       'Stuetzstellen':sum(map(len,thresholds.values())), 'tau':[1,2,10,100,5000],
                       'Anzahl_je_hervorgehobener_Kurve':indicators,
                       'maximaler_endlicher_Faktor':max(c[-1][0] for c in thresholds.values()),
                       'SHA256_Rohmatrix':sha256(RAW.read_bytes()).hexdigest()}


def trace_curves(pdf, thresholds):
    """Liest Achsenticks und Linienzüge aus den Vektoren der tatsächlich gesetzten Seite."""
    import fitz
    doc=fitz.open(pdf)
    pgids=[0] if len(doc)==1 else [p.number for p in doc if 'Abbildung 18.3. Leistungsprofile' in ' '.join(p.get_text().split())]
    assert len(pgids)==1,(pdf,pgids)
    p=doc[pgids[0]]
    shapes=p.get_drawings()
    ticks=[s['rect'] for s in shapes if s['type']=='fs' and s['color']==(0,0,0)
           and len(s['items'])==1 and s['items'][0][0]=='l']
    ys=sorted((r.y0 for r in ticks if r.height<.01 and 2.5<r.width<4),reverse=True)
    xs=[r.x0 for r in ticks if r.width<.01 and 2.5<r.height<4]
    assert len(ys)==5 and len(xs)==5
    x0,x1=min(xs),max(xs);y0,y8=ys[0],ys[-1]
    text=' '.join(p.get_text().split())
    assert all(label in text for label in ('0/8','8/8','5000','RK45','RK4','QSS2','LIQSS','Übrige Konfigurationen'))
    assert all(abs(y-(y0+(y8-y0)*i/4))<.01 for i,y in enumerate(ys))
    assert all(abs(x-(x0+(x1-x0)*log(t)/log(5000)))<.01 for x,t in zip(sorted(xs),[1,10,100,1000,5000]))
    def expected(curve):
        x=lambda t: x0+(x1-x0)*log(t)/log(5000)
        y=lambda count: y0+(y8-y0)*count/8
        pts=[(x(curve[0][0]),y(curve[0][1]))]
        for tau,count in curve[1:]:
            pts.extend([(x(tau),pts[-1][1]),(x(tau),y(count))])
        pts.append((x1,pts[-1][1]))
        return pts
    unmatched={k:expected(v) for k,v in thresholds.items()}
    errors=[]
    for s in shapes:
        rect=s['rect']
        if s['type']!='s' or not s['color'] or abs(rect.x0-x0)>.01 or abs(rect.x1-x1)>.01:
            continue
        color='#'+''.join(f'{round(v*255):02x}' for v in s['color'])
        if color not in {*COLORS,'#afbfc5'}:
            continue
        lines=s['items'];assert all(v[0]=='l' for v in lines)
        pts=[tuple(lines[0][1])]
        for _,a,b in lines:
            assert max(abs(v-w) for v,w in zip(pts[-1],a))<.001
            if max(abs(v-w) for v,w in zip(pts[-1],b))>1e-5:
                pts.append(tuple(b))
        allowed=[COLORS[color]] if color in COLORS else [k for k in unmatched if k not in COLORS.values()]
        matches=[]
        for k in allowed:
            pred=unmatched[k]
            if len(pts)==len(pred):
                err=max(max(abs(v-w) for v,w in zip(a,b)) for a,b in zip(pts,pred))
                if err<.002:matches.append((err,k))
        assert matches,(pdf,color,pts)
        err,k=min(matches)
        errors.append(err)
        del unmatched[k]
    assert not unmatched,(pdf,unmatched.keys())
    return {'PDF_Seite':p.number+1,'Linienzuege':len(errors),'davon_namentlich':len(COLORS),
            'maximale_Koordinatendifferenz_pt':max(errors)}


if __name__=='__main__':
    ap=ArgumentParser(description=__doc__)
    ap.add_argument('--buch',type=Path,help='Gesetzte Buch-PDF für die Prüfung der gedruckten Vektoren')
    ap.add_argument('--felder',action='store_true',help='Wandspuren und beide Quellvarianten neu berechnen')
    args=ap.parse_args()
    if not __debug__:
        raise SystemExit('Mit aktiven Assertions ausführen.')
    curves,profile=performance()
    out={'Stabilitaetsintervalle':stability(),'QSS_Kalender':calendar_check(),'Leistungsprofile':profile}
    if args.buch:
        out['Druckvorlage']=trace_curves(ROOT/'druck/bild_leistungsprofile.pdf',curves)
        out['Gedruckte_Abbildung_18_3']=trace_curves(args.buch,curves)
    if args.felder:
        out.update(Kavitaet=field_checks(),C19R=source_checks())
    print(json.dumps(out,ensure_ascii=False,indent=2))
