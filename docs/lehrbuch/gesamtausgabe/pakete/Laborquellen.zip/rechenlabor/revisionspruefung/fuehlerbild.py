"""Temperature, elapsed time and nondimensional time for the first worked example."""
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
plt.rcParams.update({"font.family":"DejaVu Sans", "svg.fonttype":"none",
                     "svg.hashsalt":"fuehler-v915", "pdf.fonttype":42})
fig, ax = plt.subplots(figsize=(8.1,2.65))
fig.subplots_adjust(left=.035,right=.98,top=.94,bottom=.06)
ax.set(xlim=(-1.62,2.32),ylim=(-.23,2.75))
ax.axis("off")
teal, blue, ink = "#00756d", "#245684", "#263b48"
rows = [(2.29,"Laboruhr  t  [s]",["0","1","2"],blue),
        (1.63,"Normierte Zeit  s = t / τ",["0","0,5","1"],teal),
        (.89,"Überschuss  y  [K]",["40,00","24,26","14,72"],ink),
        (.28,"Anzeige  T  [°C]",["60,00","44,26","34,72"],ink)]
for x in range(3):
    ax.plot([x,x],[.19,2.61],ls=(0,(2,3)),lw=1,color="#acbabb",zorder=0)
for j,(h,label,values,color) in enumerate(rows):
    ax.text(-1.57,h,label,va="center",size=11,color=color,weight="bold" if j<2 else "regular")
    if j<2:ax.plot([-.09,2.11],[h-.19,h-.19],color=color,lw=1.5)
    for x,val in enumerate(values):
        if j<2:ax.plot([x,x],[h-.24,h-.14],color=color,lw=1.6)
        ax.text(x,h,val,ha="center",va="center",size=12,color=color,
                bbox=dict(facecolor="white",edgecolor="none",pad=1.1))
assert np.allclose(20+40*np.exp(-np.arange(3)/2),[60,44.26122639,34.71517765])
for folder,ext,meta in [("abbildungen","svg",{"Date":None}),("druck","pdf",{"CreationDate":None,"ModDate":None})]:
    fig.savefig(ROOT/folder/("g_fuehleruhr."+ext),metadata=meta)
