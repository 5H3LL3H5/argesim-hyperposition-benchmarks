"""Check printed C++20, the actual Python API and the kernel ranks against the archived matrices."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
import json
import re
import subprocess
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
LAB = HERE.parent
sys.path.insert(0, str(LAB / "messplanung/projekt"))
from argesim_benchmarks.ivp import InitialValueProblem


def check_contracts():
    master = LAB.parent/"lehrbuch_numerische_simulation.md"
    if not master.is_file():
        master = LAB.parent/"kapitel/B.md"
    text = master.read_text()
    printed = re.search(r"```cpp\n(.*?)\n```",text.split("### B.4.1",1)[1],re.S)[1]
    original = (LAB/"rhs_vertrag.cpp").read_text()
    assert printed+"\n" == original
    with TemporaryDirectory() as dirname:
        directory=Path(dirname)
        (directory/"block.cpp").write_text(printed+"\n")
        subprocess.run(["c++","-std=c++20","-Wall","-Wextra","-Werror","-pedantic","block.cpp","-o","probe"],cwd=directory,check=True)
        subprocess.run([str(directory/"probe")],check=True)
    errors = []
    for case in ["NaN-Start","falsche Dimension"]:
        try:
            if case == "NaN-Start":
                InitialValueProblem(lambda t,y:y, 0., (float("nan"),), 1.)
            else:
                broken = InitialValueProblem(lambda t,y:(0.,0.),0.,(1.,),1.)
                broken.evaluate(0., (1.,))
        except ValueError as caught:
            errors.append(str(caught))
        else:
            raise AssertionError(case)
    return dict(cpp20="bestanden",sha256=hashlib.sha256(original.encode()).hexdigest(),python_negativtests=errors)


def kernel_checks():
    result = {}
    blockmap = np.repeat(np.eye(8),8,axis=1)
    methods = ["fourier","laplace","wavelet","hankel","radon","wavelet_laplace","fourier_mellin"]
    with np.load(LAB/"operator_vergleich/messung/c18.npz") as archive:
        for method in methods:
            basis = archive["direct_"+method+"_basis"]
            codes = blockmap @ basis
            u,_,_ = np.linalg.svd(codes,full_matrices=True)
            rank = int(np.linalg.matrix_rank(codes))
            null = u[:,rank:].T
            residual = float(np.linalg.norm(null @ codes)) if len(null) else None
            assert residual is None or residual < 1e-12
            result[method] = dict(rank64=int(np.linalg.matrix_rank(basis)),rank8=rank,
                                  null_vectors=null.tolist(),null_residual=residual)
    # Multiplying a stored dictionary by one impulse selects its corresponding row.
    points = np.array([0,17,31,42,51,58,62,63])
    with np.load(LAB/"operator_vergleich/messung/c18.npz") as archive:
        radon = archive["direct_radon_basis"]
    for center in (30,31,35,41):
        impulse = np.eye(64)[center]
        observed = (impulse @ radon).reshape(3,8)
        for row,width in enumerate((1,5,13)):
            expected = (np.abs(points-center) <= width//2).astype(float)/width
            np.testing.assert_allclose(observed[row],expected,rtol=1e-13,atol=1e-15)
    result["radon"]["impulsbreiten"]=[1,5,13]
    result["radon"]["getestete_impulse"]=[30,31,35,41]
    return result


if __name__ == "__main__":
    report={"schnittstellen":check_contracts(), "kernraenge":kernel_checks()}
    (HERE/"messung/gegenproben.json").write_text(json.dumps(report,indent=2)+"\n")
