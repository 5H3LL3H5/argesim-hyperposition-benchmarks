"""C05, ergänzende statische Quantenreihe mit dem archivierten LIQSS–BDF-Vertrag."""
from argparse import Namespace
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import platform
import signal
import sys

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent / 'messplanung/projekt'
sys.path.insert(0, str(PROJECT))
import benchmark_solver_extension as study


def check_source(path, expected):
    data = path.read_bytes()
    sha = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if sha != expected:
        raise RuntimeError(f'Abweichender Quellenstand in {path.name}: {sha}')


def main():
    check_source(HERE / 'benchmark_solver_extension.py', '6392703c41294c19be56975712c53f718f551012')
    check_source(PROJECT / 'argesim_benchmarks/solvers/mixed_qss.py', '95bffba08af3569614dbc244c1661d92f8962f40')
    check_source(PROJECT / 'argesim_benchmarks/hybrid.py', '885712b4a67c2a4024027ac47927ad96a3bc538e')
    check_source(PROJECT / 'argesim_benchmarks/models/c05_two_state.py', 'e529183b650224e5394c53d25109e7b9970cd86e')
    case = study.switches()
    args = Namespace(repeat=3, timeout=2.0)
    factors = (0.0002, 0.00004, 0.000008, 0.0000016)
    signal.signal(signal.SIGALRM, study.timeout_handler)
    rows = []
    for factor in factors:
        outputs = []
        def capture(method, options):
            result, observations = case.run(method, options)
            outputs.append(list(observations))
            return result, observations
        current = replace(case, run=capture)
        row = study.measure(current, 'liqss-bdf', factor, args)
        row['completed_outputs'] = len(outputs)
        if outputs:
            row['observed'] = outputs[0]
            if len(outputs[0]) == len(case.expected):
                row['component_scores'] = [abs(a-b)/tol for a,b,tol in
                                           zip(outputs[0],case.expected,case.tolerances,strict=True)]
        rows.append(row)
    return {
        'source_commit': '1824c9104152674b82de6cd84d53b0b4f68dca37',
        'python': platform.python_version(),
        'window_s': case.end, 'bdf_indices': list(case.partition),
        'component_scales': list(case.scales),
        'expected_events_then_final_states': list(case.expected),
        'budgets': list(case.tolerances),
        'timeout_s_per_integration': args.timeout, 'timed_repeats_after_first': args.repeat,
        'options_except_quantum': {k:v for k,v in study.options(case,'liqss-bdf',factors[0]).items() if k!='quantum'},
        'results': rows,
    }


if __name__=='__main__':
    print(json.dumps(main(),indent=2,ensure_ascii=False))
