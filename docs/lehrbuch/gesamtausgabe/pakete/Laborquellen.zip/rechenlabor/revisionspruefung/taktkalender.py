"""Ereignisidentität, relative Integrationszeiten und geordnete Resets (Kapitel 5)."""
from fractions import Fraction
from itertools import groupby
import math


def process_ticks(events, period, integrate, reset):
    """Events are (integer tick, model priority, identity); period is exact in seconds."""
    if not isinstance(period, Fraction) or period <= 0:
        raise ValueError("period must be a positive rational number of seconds")
    scheduled = sorted(events)
    if any(type(k) is not int or k < 0 for k, _, _ in scheduled):
        raise ValueError("ticks must be nonnegative integers")
    if len({(k, identity) for k, _, identity in scheduled}) != len(scheduled):
        raise ValueError("duplicate event identity at one tick")
    previous = 0
    for tick, group in groupby(scheduled, key=lambda event: event[0]):
        if tick > previous:
            # Reset the integrator's phase origin for each exact tick interval.
            duration = float((tick-previous)*period)
            if not math.isfinite(duration) or duration <= 0:
                raise ArithmeticError("duration is outside the local clock's resolution")
            integrate(previous, 0.0, duration)
        for _, _, identity in group:
            reset(tick, identity)
        previous = tick


def main():
    origin = float(2**30)
    period = Fraction(1, 2**24)
    assert math.ulp(origin) == 2**-22
    assert [origin+float(k*period) for k in range(3)] == [origin]*3
    steps, resets = [], []
    process_ticks([(2,0,"last"),(1,2,"sample"),(0,0,"start"),(1,1,"gain")], period,
                  lambda k,start,stop: steps.append((k,start,stop)),
                  lambda k,label: resets.append((k,label)))
    assert steps == [(0,0.,float(period)),(1,0.,float(period))]
    assert resets == [(0,"start"),(1,"gain"),(1,"sample"),(2,"last")]
    print("Drei Taktindizes, vier Modellereignisse, zwei positive Zeitintervalle.")


if __name__ == "__main__":
    main()
