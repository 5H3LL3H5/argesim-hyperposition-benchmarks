"""Two independently scrambled Sobol splits; refit models and keep test inputs untouched."""
from pathlib import Path
from tempfile import TemporaryDirectory
import json, sys
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "cp_dynamik"))
import populationen as pop
import kavitaet as cavity
from auswertung import sobol


def repeat(seed, binary, directory):
    result = {}
    for mode in ("population", "kavitaet"):
        inputs, fields = [], []
        for offset, count in enumerate((64, 16, 16)):
            if mode == "population":
                p = pop.LOW + sobol(count, 2, seed+offset) * (pop.HIGH-pop.LOW)
                y = np.stack([pop.reference(start) for start in p])
            else:
                p = 2*sobol(count, cavity.BLOCKS, seed+offset)-1
                y = np.stack([cavity.reference(control, binary, directory)[0] for control in p])
            inputs.append(p)
            fields.append(y)
        assert len(np.unique(np.concatenate(inputs), axis=0)) == sum(map(len, inputs))
        if mode == "population":
            model, config = pop.train(inputs[0], fields[0], inputs[1], fields[1])
            methods = {m:pop.measurements(pop.predict(inputs[2], model, m), fields[2])[-1] for m in ("affin","rbf_pod")}
        else:
            model, config = cavity.fit(inputs[0], fields[0], inputs[1], fields[1])
            methods = {m:cavity.metrics(cavity.predict(inputs[2], model, m), fields[2])[-1] for m in ("linear","quadratisch","pod_netz")}
        result[mode] = dict(train=64, validation=16, test=16, config=config,
                            inputs=[a.tolist() for a in inputs],
                            results={k:dict(accepted=int(sum(v<=1)), scores=v.tolist()) for k,v in methods.items()})
    return result


if __name__ == "__main__":
    with TemporaryDirectory() as directory:
        binary = cavity.build_cpp(Path(directory))
        for seed in (91510,91520):
            path = HERE / "messung" / f"neue_starts_{seed}.json"
            path.write_text(json.dumps(repeat(seed,binary,directory),indent=2,default=float)+"\n")
