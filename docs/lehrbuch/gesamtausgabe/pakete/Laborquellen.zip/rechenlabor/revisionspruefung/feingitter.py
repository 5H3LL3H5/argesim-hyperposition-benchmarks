"""Rechne beide ungeeichten 421er-Vergleiche mit neu aufgebautem 65er-Startfeld."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

import numpy as np

HERE = Path(__file__).resolve().parent
CP2 = HERE.parent / "cp2_operatoren"
sys.path.insert(0, str(CP2))
from referenzen import build_cpp, cavity_case, load_result


def run(amplitude):
    archived = CP2 / "messung" / "lbm_cache" / f"n421_re100_a{amplitude:+.3f}.npz"
    expected, old = load_result(archived)
    with TemporaryDirectory() as directory:
        root = Path(directory)
        fields, new = cavity_case(421, 100, amplitude, root / "felder", build_cpp(root))
    # The portable cache retains the final snapshot only on grids above 65.
    archive_steps = expected.shape[0]
    assert archive_steps in (1, fields.shape[0])
    difference = fields[-archive_steps:] - expected
    report = {
        "amplitude": amplitude, "Re": 100, "gitter": 421,
        "cpp_sha256": hashlib.sha256((CP2 / "cp2_referenz.cpp").read_bytes()).hexdigest(),
        "compiler": subprocess.check_output(["c++", "--version"], text=True).splitlines()[0],
        "referenz_sha256": hashlib.sha256(archived.read_bytes()).hexdigest(),
        "neuer_lauf": new, "archivschritte": old["steps"],
        "archivierte_felder": archive_steps, "neu_gerechnete_felder": len(fields),
        "feld_hashes": [hashlib.sha256(frame.tobytes()).hexdigest() for frame in fields],
        "max_abs_gemeinsame_felder": float(np.abs(difference).max()),
        "relativ_letztes_feld": float(np.linalg.norm(difference[-1]) / np.linalg.norm(expected[-1]))
    }
    if new["steps"] != old["steps"] or report["max_abs_gemeinsame_felder"] > 1e-12:
        raise ArithmeticError(report)
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("amplitude", type=float, choices=[0.0, 0.23])
    parser.add_argument("ergebnis", type=Path)
    args = parser.parse_args()
    report = run(args.amplitude)
    args.ergebnis.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
