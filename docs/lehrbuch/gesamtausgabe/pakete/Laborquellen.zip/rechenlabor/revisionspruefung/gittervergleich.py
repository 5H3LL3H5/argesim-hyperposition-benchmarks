"""Apply exactly the same four archived coarse predictions to 28 new fine-grid runs."""
import csv
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "cp_dynamik"))
import kavitaet as model


def main():
    target = HERE/"messung/kavitaet_33_65.csv"
    with np.load(model.RESULTS/"kavitaet_felder.npz") as fields, TemporaryDirectory() as directory, target.open("w",newline="") as out:
        binary = model.build_cpp(Path(directory))
        writer = csv.writer(out)
        writer.writerow(["gruppe","fall","methode","rel","peak","S"])
        for group in ("innen","profile","aussen"):
            for index,drive in enumerate(fields[group+"_deckel"]):
                fine,_ = model.reference(drive,binary,directory,n=65)
                truth = model.resize_centers(fine.transpose(0,3,1,2),33).transpose(0,2,3,1)[None]
                for method in ("referenz","linear","quadratisch","pod_netz"):
                    relative, peak, score = model.metrics(fields[group+"_"+method][index:index+1],truth)
                    writer.writerow([group,index,method,relative.item(),peak.item(),score.item()])


if __name__ == "__main__":
    main()
