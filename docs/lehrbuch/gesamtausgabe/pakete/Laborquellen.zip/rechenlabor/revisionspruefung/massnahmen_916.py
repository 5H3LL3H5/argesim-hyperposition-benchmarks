"""Rechenproben zu v9.16. Mit --wand die zwei Projektionen aus dem Rohfeld wiederholen."""
import argparse
from collections import Counter
import csv
from fractions import Fraction as F
from heapq import heappop, heappush
import json
from math import isclose, pi, sin
from pathlib import Path

HERE = Path(__file__).resolve().parent
LAB = HERE.parent
ROOT = LAB.parent


def radau():
    """Zwei-Punkt-Quadratur und Fehler der dreistufigen Kurve für y'=t³."""
    c, b = (F(1, 3), F(1)), (F(3, 4), F(1, 4))
    for degree in range(3):
        assert sum(bi * ci**degree for bi, ci in zip(b, c)) == F(1, degree + 1)
    assert sum(bi * ci**3 for bi, ci in zip(b, c)) != F(1, 4)
    # w(s)=(s-1)(s²-4s/5+1/10), in aufsteigender Potenzreihenfolge
    w = (-F(1, 10), F(9, 10), -F(9, 5), F(1))
    def integral(theta):
        return sum(a * theta**(k+1) / (k+1) for k, a in enumerate(w))
    assert integral(F(1, 2)) == F(1, 320) and integral(F(1)) == 0
    return {"Innenfehler geteilt durch h^4": str(integral(F(1, 2))),
            "Endfehler fuer diese rechte Seite": str(integral(F(1)))}


def ereignisse():
    """Gleitfeld, RC-Sprung, beiden Tangenten und verfallener QSS-Termin."""
    links, rechts = (F(2), F(1)), (-F(1), F(4))
    w_plus = links[0] / (links[0] - rechts[0])
    assert tuple((1 - w_plus) * x + w_plus * y for x, y in zip(links, rechts)) == (0, 3)
    assert (F(3) - F(5)) / 1000 == -F(2, 1000)
    v_minus, radius = -F(3, 5), F(3, 10)
    omega_plus = v_minus / radius
    assert omega_plus == -2 and (radius * omega_plus)**2 == v_minus**2
    version = [0, 0]
    heap = []
    def plane(i, zeit):
        version[i] += 1
        heappush(heap, (zeit, i, version[i]))
    plane(0, F(1, 2))
    plane(0, F(3, 4))
    plane(1, F(3, 4))
    gruppen, alt = [], []
    while heap:
        zeit = heap[0][0]
        faellig = []
        while heap and heap[0][0] == zeit:
            _, i, nummer = heappop(heap)
            if nummer == version[i]:
                faellig.append(i)
            else:
                alt.append(zeit)
        if faellig:
            gruppen.append((zeit, faellig))
    assert gruppen == [(F(3, 4), [0, 1])] and alt == [F(1, 2)]
    return {"Gleitgeschwindigkeit": [0, 3], "Omega_nach_Stift": float(omega_plus),
            "verworfener_Termin": str(alt[0]), "gueltiger_Termin": str(gruppen[0][0])}


def moden_und_budgets():
    for j in range(4):
        assert isclose(sin(2*pi*j/4), sin(2*pi*5*j/4), abs_tol=1e-14)
    w = (0, 1, 0, -1, 0)
    assert [w[j-1]-2*w[j]+w[j+1] for j in (1, 2, 3)] == [-2*a for a in w[1:-1]]
    assert F(3, 10) / F(2, 10) == F(3, 2)
    bayes = F(3, 4)*1 + F(1, 4)*5
    assert bayes == 2 and F(1+5, 2) == 3
    return {"Aliasing_Knoten": 4, "Laplace_Eigenwert": -2, "Nullreferenz_S": 1.5,
            "Bayes_und_Minimax_mm": [int(bayes), 3]}


def archiv():
    with (ROOT/'daten/qss-extension.csv').open() as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == 456
    c05 = [r for r in rows if r['case']=='C05']
    status = Counter(r['status'] for r in c05)
    hybrid = [r for r in c05 if r['method']=='liqss-bdf']
    assert len(c05)==57 and status['pass']==0
    assert len(hybrid)==3 and all(r['status']=='accuracy_miss' for r in hybrid)
    bands = json.loads((HERE/'messung/c19_baender.json').read_text())
    narrow, full = (next(r for r in bands['rows'] if (r['kx'],r['ky'])==key)
                    for key in ((4,2), (32,16)))
    assert narrow['rank']==full['rank']==8 and (narrow['accepted'],full['accepted'])==(0,8)
    s = max(full['scores']['score'])
    assert round(s,3)==0.729
    return {"C05_Status": dict(sorted(status.items())), "C05_liqss_bdf": len(hybrid),
            "C19R_Baender": [[4,2,8,0],[32,16,8,8]], "C19R_volles_Band_S": s}


def wand():
    """CP2/2 Re=100, die identischen diskreten Randzeilen für drei Felder verwenden."""
    import sys
    import numpy as np
    from scipy import sparse
    sys.path.insert(0, str(LAB/'physik_residual'))
    import kavitaet
    with np.load(kavitaet.FIELDS) as fields:
        raw = fields['prediction_Re100_fourier'].astype(float)
    n = raw.shape[-1]
    assert n == 65
    div, b_all, g_all = kavitaet.constraints(n)
    inner = np.tile((np.arange(n)>0) & (np.arange(n)<n-1),4)
    b, g = b_all[inner], g_all[inner]
    flux, _ = kavitaet.retract(raw, div, np.zeros(n*n))
    joint, _ = kavitaet.retract(raw, sparse.vstack((div,b),format='csr'),
                               np.r_[np.zeros(n*n),g])
    archivfelder = json.loads((LAB/'physik_residual/messung/physik_residual.json').read_text())
    archived = archivfelder['cp2']['fields']['fourier']
    defects = {}
    for key, field in (('raw',raw),('flux',flux),('joint',joint)):
        defect = float(np.max(np.abs(b @ field.ravel()-g)))
        assert isclose(defect,archived[key]['wall_max'],rel_tol=1e-10,abs_tol=1e-12)
        defects[key] = defect
    assert defects['joint'] < 1e-12 < defects['raw'] < defects['flux']
    return defects


if __name__=='__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--wand', action='store_true', help='NumPy und SciPy erforderlich')
    args = parser.parse_args()
    if not __debug__:
        raise SystemExit('Für die Gegenproben Python ohne -O aufrufen.')
    result = {"Radau": radau(), "Ereignisse": ereignisse(), "Moden_und_Budgets": moden_und_budgets(),
              "Archiv": archiv()}
    if args.wand:
        result['CP2_Wand_neu_aus_Feld'] = wand()
    print(json.dumps(result,ensure_ascii=False,indent=2))
