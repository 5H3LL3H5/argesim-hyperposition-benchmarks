"""Reproduce the cavity projection, the C15 step contract and the C19R meter experiment."""

import argparse
import json
import os
from pathlib import Path
import platform
import statistics
from time import perf_counter

import numpy as np
import scipy

import brunnen
import kavitaet
import kompartimente as c15


def time_query(query):
    query()
    samples = []
    for _ in range(5):
        start = perf_counter()
        query()
        samples.append(perf_counter() - start)
    return {"seconds": samples, "median_ms": 1000 * statistics.median(samples)}


def timings():
    feed = c15.inputs(*c15.DOSES[0])
    weights = c15.residual_weights()
    rates = c15.NOMINAL
    flow = c15.reference_flow(rates)
    validated, bound = c15.classical_checked(feed, rates)
    independent = c15.reference(feed, flow)
    assert np.abs(validated - independent).sum(axis=1).max() <= bound + 2e-8
    return {
        "experiment": "first C15 input, nominal, 480 steps, one warmup and five repetitions",
        "python": platform.python_version(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "threads_openblas": os.environ.get("OPENBLAS_NUM_THREADS"),
        "machine": platform.machine(),
        "checked_hybrid": time_query(lambda: c15.integrate(feed, rates, weights)),
        "checked_classical": time_query(lambda: c15.classical_checked(feed, rates)),
        "prepared_exponential": time_query(lambda: c15.reference(feed, flow)),
    }


def save(path, data):
    path.write_text(
        json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2) + "\n",
        encoding="utf-8",
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("residual_ergebnisse"))
    parser.add_argument("--mit-zeiten", action="store_true")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    save(
        args.out / "physik_residual.json",
        {"c15": c15.run(), "c19r": brunnen.run(), "cp2": kavitaet.run()},
    )
    if args.mit_zeiten:
        save(args.out / "laufzeiten.json", timings())
    print(
        "C15-Schrittabnahme, C19R-Messentscheidung und CP2-Fluss- und Wandprojektion geprüft."
    )


if __name__ == "__main__":
    main()
