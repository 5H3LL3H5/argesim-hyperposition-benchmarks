"""A reference-free acceptance test for a causal residual update of C15."""

from fractions import Fraction as F
import json
from pathlib import Path

import numpy as np
from scipy.linalg import expm

HERE = Path(__file__).resolve().parent
H = F(1, 2)
BUDGET = F(5, 2)
STEPS = 480
GRID = 10**9
ZERO = (F(0), F(0), F(0))
DOSES = ((2500, F(1, 2)), (2500, 3), (2500, 240), (1800, 1), (2900, 5), (2100, 24))
NOMINAL = (F(41, 10000), F(498, 10000), F(585, 10000))


def add(a, b):
    return tuple(x + y for x, y in zip(a, b, strict=True))


def difference(a, b):
    return tuple(x - y for x, y in zip(a, b, strict=True))


def scaled(c, a):
    return tuple(c * x for x in a)


def norm(a):
    return sum(abs(x) for x in a)


def apply_generator(x, rates):
    k01, k21, k12 = rates
    exchange = k21 * x[0] - k12 * x[1]
    loss = k01 * x[0]
    return (-exchange - loss, exchange, loss)


def taylor(x, feed, rates, order):
    """Exact polynomial and rigorous local 1-norm remainder for a constant feed."""
    term = scaled(H, add(apply_generator(x, rates), (feed, 0, 0)))
    center = x
    for degree in range(1, order + 1):
        center = add(center, term)
        term = scaled(H / (degree + 1), apply_generator(term, rates))
    return center, norm(term)


def project(v, total):
    """Euclidean projection onto nonnegative states having a given total."""
    if total < 0:
        raise ValueError("a negative total is infeasible")
    if total == 0:
        return ZERO
    if min(v) >= 0 and sum(v) == total:
        return v
    prefix = F(0)
    for k, value in enumerate(sorted(v, reverse=True), 1):
        prefix += value
        candidate = (prefix - total) / k
        if value > candidate:
            threshold = candidate
    projected = tuple(max(F(0), value - threshold) for value in v)
    assert sum(projected) == total and min(projected) >= 0
    return projected


def round_project(values, total):
    rounded = tuple(F(round(value * GRID), GRID) for value in values)
    return project(rounded, total)


def residual_weights():
    study = json.loads((HERE / "v98/ergebnisse.json").read_text())["c15"]
    # Remove the nominal Euler step from the archived fitted full map.
    nominal_euler = (
        (1 - H * (NOMINAL[0] + NOMINAL[1]), H * NOMINAL[2], H * 5000),
        (H * NOMINAL[1], 1 - H * NOMINAL[2], F(0)),
    )
    return tuple(
        tuple(F(str(weight)) - euler for weight, euler in zip(row, base, strict=True))
        for row, base in zip(study["weights"], nominal_euler, strict=True)
    )


def propose(x, feed, rates, weights, swap):
    total = sum(x) + H * feed
    euler = add(x, scaled(H, add(apply_generator(x, rates), (feed, 0, 0))))
    inputs = (x[0], x[1], feed / 5000)
    correction = tuple(
        sum(w * a for w, a in zip(row, inputs, strict=True)) for row in weights
    )
    first, second = euler[0] + correction[0], euler[1] + correction[1]
    if swap:
        transfer = min(F(7), max(F(0), first))
        first, second = first - transfer, second + transfer
    return round_project((first, second, total - first - second), total)


def integrate(sequence, rates, weights, *, checked=True, corrupt_index=None):
    """No truth, matrix exponential or future sample is available to this decision."""
    x, error_bound = ZERO, F(0)
    states, bounds, actions = [], [], []
    horizon = len(sequence)
    for index, feed in enumerate(sequence):
        total = sum(x) + H * feed
        candidate = propose(x, feed, rates, weights, index == corrupt_index)
        action = "predict"
        if checked:
            local_budget = (BUDGET - error_bound) / (horizon - index)
            center, tail = taylor(x, feed, rates, order=4)
            local_bound = norm(difference(candidate, center)) + tail
            if local_bound > local_budget:
                center, tail = taylor(x, feed, rates, order=8)
                candidate = round_project(center, total)
                local_bound = norm(difference(candidate, center)) + tail
                if local_bound > local_budget:
                    raise ArithmeticError(
                        "fallback cannot certify the remaining budget"
                    )
                action = "fallback"
            error_bound += local_bound
        assert sum(candidate) == total and min(candidate) >= 0
        x = candidate
        states.append(tuple(map(float, x)))
        bounds.append(float(error_bound))
        actions.append(action)
    return np.array(states), np.array(bounds), actions


def reference_flow(rates):
    k01, k21, k12 = map(float, rates)
    block = np.array(
        [[-k01 - k21, k12, 0, 1], [k21, -k12, 0, 0], [k01, 0, 0, 0], [0, 0, 0, 0]]
    )
    return expm(float(H) * block)


def reference(sequence, flow):
    """Independent floating-point validation after all online decisions."""
    x = np.zeros(3)
    states = []
    for feed in sequence:
        x = flow[:3, :3] @ x + flow[:3, 3] * float(feed)
        states.append(x)
    return np.array(states)


def classical_checked(sequence, rates):
    """Classical polynomial step with the same global error and positivity contract."""
    x, error_bound = ZERO, F(0)
    states = []
    for index, feed in enumerate(sequence):
        local_budget = (BUDGET - error_bound) / (len(sequence) - index)
        total = sum(x) + H * feed
        for order in (4, 8):
            center, remainder = taylor(x, feed, rates, order)
            candidate = round_project(center, total)
            bound = norm(difference(candidate, center)) + remainder
            if bound <= local_budget:
                break
        else:
            raise ArithmeticError("classical step exceeds the remaining budget")
        error_bound += bound
        x = candidate
        states.append(tuple(map(float, x)))
    return np.array(states), float(error_bound)


def inputs(amount, duration):
    n = int(duration / H)
    assert n * H == duration and n <= STEPS
    return [F(amount) / duration] * n + [F(0)] * (STEPS - n)


def run():
    weights = residual_weights()
    changed = (NOMINAL[0], 3 * NOMINAL[1], NOMINAL[2])
    results = []
    for name, rates, corrupt in (
        ("nominal", NOMINAL, None),
        ("exchange_x3", changed, None),
        ("balanced_error", NOMINAL, 96),
    ):
        rows = []
        for amount, duration in DOSES:
            feed = inputs(amount, duration)
            accepted, bounds, actions = integrate(
                feed, rates, weights, corrupt_index=corrupt
            )
            raw, _, _ = integrate(
                feed, rates, weights, checked=False, corrupt_index=corrupt
            )
            truth = reference(feed, reference_flow(rates))
            errors = np.abs(accepted - truth).sum(axis=1)
            assert np.all(errors <= bounds + 2e-8)
            assert max(bounds) <= float(BUDGET)
            if corrupt is not None:
                assert actions[corrupt] == "fallback"
            rows.append(
                {
                    "amount": amount,
                    "duration": float(duration),
                    "steps": len(feed),
                    "accepted_predictor": actions.count("predict"),
                    "fallback": actions.count("fallback"),
                    "fallback_at": [
                        i for i, action in enumerate(actions) if action == "fallback"
                    ],
                    "max_certified_l1": float(max(bounds)),
                    "max_observed_l1": float(max(errors)),
                    "unchecked_max_l1": float(np.abs(raw - truth).sum(axis=1).max()),
                    "unchecked_max_component": float(np.abs(raw - truth).max()),
                }
            )
        results.append({"name": name, "rows": rows})
    assert project((F(-1), F(3), F(1)), F(2)) == (0, 2, 0)
    base = inputs(*DOSES[0])
    altered = base[:240] + [F(5)] * 240
    a = integrate(base, NOMINAL, weights)
    b = integrate(altered, NOMINAL, weights)
    assert np.array_equal(a[0][:240], b[0][:240]) and a[2][:240] == b[2][:240]
    return {
        "budget_l1": float(BUDGET),
        "time_step": float(H),
        "steps_per_case": STEPS,
        "model_rates": list(map(float, NOMINAL)),
        "suites": results,
        "unchanged_prefix_steps": 240,
    }
