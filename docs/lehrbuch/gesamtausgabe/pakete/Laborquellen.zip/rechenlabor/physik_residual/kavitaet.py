"""Wall and flux projection on archived cell-centred CP2/2 velocity fields."""

from pathlib import Path

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import lsmr

FIELDS = (
    Path(__file__).resolve().parents[1] / "cp2_operatoren/messung/kavitaet_felder.npz"
)


def constraints(n):
    # Outer face flux is zero. Interior face values are adjacent-cell averages.
    d = sparse.lil_matrix((n, n))
    for i in range(1, n - 1):
        d[i, i - 1], d[i, i + 1] = -0.5, 0.5
    d[0, :2], d[-1, -2:] = [0.5, 0.5], [-0.5, -0.5]
    eye = sparse.eye(n, format="csr")
    divergence = sparse.hstack((sparse.kron(eye, d), sparse.kron(d, eye)), format="csr")
    # One tangential trace per face midpoint, with linear half-cell extrapolation.
    b = sparse.lil_matrix((4 * n, 2 * n * n))
    nodes = np.arange(n * n).reshape(n, n)
    for j in range(n):
        for row, cells in (
            (j, nodes[:2, j]),
            (n + j, nodes[-1:-3:-1, j]),
            (2 * n + j, n * n + nodes[j, :2]),
            (3 * n + j, n * n + nodes[j, -1:-3:-1]),
        ):
            b[row, cells[0]], b[row, cells[1]] = 1.5, -0.5
    wall = np.zeros(4 * n)
    wall[n : 2 * n] = 1.0
    return divergence, b.tocsr(), wall


def retract(field, matrix, target):
    raw = field.ravel()
    correction = lsmr(
        matrix, target - matrix @ raw, atol=1e-14, btol=1e-14, maxiter=2500
    )
    projected = raw + correction[0]
    residual = float(np.max(np.abs(matrix @ projected - target)))
    if correction[1] not in (0, 1, 2) or residual > 5e-10:
        raise ArithmeticError(f"constraint solve did not converge: {residual:g}")
    return projected.reshape(field.shape), int(correction[2])


def check_corner_conflict(d, b, wall, n):
    """Exact left-null witness for extrapolated traces up to the lid corner."""
    cell = np.zeros((n, n), dtype=np.int64)
    cell[-2, :2], cell[-1, :2] = (3, -1), (-9, 3)
    face = np.zeros((4, n), dtype=np.int64)
    face[1, :3], face[2, -3:] = (4, 3, -1), (1, -3, -4)
    witness = np.r_[cell.ravel(), face.ravel()]
    twice_matrix = (2 * sparse.vstack((d, b))).astype(np.int64)
    target = np.r_[np.zeros(n * n, dtype=np.int64), wall.astype(np.int64)]
    assert np.all(twice_matrix.T @ witness == 0) and witness @ target == 6
    return {"transpose_product": 0, "target_product": int(witness @ target)}


def diagnostics(field, truth, divergence, boundary, wall, ghia):
    n = field.shape[-1]
    c = max(2, int(0.055 * n))
    core = (slice(None), slice(c, -c), slice(c, -c))
    shear = (slice(None), slice(-max(2, round(0.04 * n)), None), slice(c, -c))
    coordinate = np.r_[0.0, (np.arange(n) + 0.5) / n, 1.0]
    uline = np.r_[0.0, field[0, :, n // 2], 1.0]
    vline = np.r_[0.0, field[1, n // 2, :], 0.0]
    profile = [
        float(
            np.sqrt(
                np.mean((np.interp(table[:, 0], coordinate, line) - table[:, 1]) ** 2)
            )
        )
        for table, line in zip(ghia, (uline, vline), strict=True)
    ]

    def relative(region):
        return float(
            np.linalg.norm((field - truth)[region]) / np.linalg.norm(truth[region])
        )

    div = (n * (divergence @ field.ravel())).reshape(n, n)
    return {
        "relative_core": relative(core),
        "relative_lid": relative(shear),
        "div_max": float(np.max(np.abs(div))),
        "div_rms_core": float(np.sqrt(np.mean(div[c:-c, c:-c] ** 2))),
        "wall_max": float(np.max(np.abs(boundary @ field.ravel() - wall))),
        "ghia_rms": profile,
        "book_score": max(
            relative(core) / 0.03,
            float(np.sqrt(np.mean(div[c:-c, c:-c] ** 2))) / 0.045,
            max(profile) / 0.025,
        ),
    }


def run():
    report = {}
    with np.load(FIELDS) as fields:
        truth = fields["reference_Re100"].astype(float)
        n = truth.shape[-1]
        d, all_walls, all_values = constraints(n)
        conflict = check_corner_conflict(d, all_walls, all_values, n)
        # At the eight near-corner face midpoints define a ghost value 2*g - u_in.
        # Their wall means meet g by construction and add no interior equation.
        inner = np.tile((np.arange(n) > 0) & (np.arange(n) < n - 1), 4)
        b, wall = all_walls[inner], all_values[inner]
        joint = sparse.vstack((d, b), format="csr")
        target = np.r_[np.zeros(n * n), wall]
        ghia = fields["ghia_u"], fields["ghia_v"]
        cases = {"D2Q9": truth, "affine": fields["affine_Re100"]}
        cases.update(
            {
                key.removeprefix("prediction_Re100_"): fields[key]
                for key in fields.files
                if key.startswith("prediction_Re100_")
            }
        )
        for label, raw in cases.items():
            raw = raw.astype(float)
            flux, _ = retract(raw, d, np.zeros(n * n))
            both, iterations = retract(raw, joint, target)
            interior = np.r_[
                both[0, 0, :], both[0, -1, :], both[1, :, 0], both[1, :, -1]
            ][~inner]
            ghosts = 2 * all_values[~inner] - interior
            assert np.allclose(
                (ghosts + interior) / 2, all_values[~inner], rtol=0, atol=2e-16
            )
            report[label] = {
                "iterations_joint": iterations,
                "raw": diagnostics(raw, truth, d, b, wall, ghia),
                "flux": diagnostics(flux, truth, d, b, wall, ghia),
                "joint": diagnostics(both, truth, d, b, wall, ghia),
            }
            assert report[label]["joint"]["div_max"] < 5e-8
            assert report[label]["joint"]["wall_max"] < 5e-10
            assert np.linalg.norm(both - retract(both, joint, target)[0]) < 2e-8
    return {
        "grid": n,
        "Re": 100,
        "lid_amplitude_perturbation": 0,
        "all_extrapolated_corner_witness": conflict,
        "ghost_face_midpoints": 8,
        "fields": report,
    }
