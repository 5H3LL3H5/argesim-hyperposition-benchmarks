"""CP2/3: fit a dispersion coefficient and test a constrained sine operator."""

import numpy as np
from scipy.fft import dst, idst
from scipy.optimize import least_squares


# Physical constants of the dispersive teaching extension in revision v9.8.
LENGTH = 0.5
SPEED = 0.06
GAMMA = 1.2e-8
BUDGET = 0.01
BOOK_TIMES = np.array([5.0, 8.0])
BOOK_TENTS = [(0.5, 0.05), (0.29, 0.053), (0.71, 0.053), (0.42, 0.044), (0.58, 0.044)]


def triangle(x, position, amplitude):
    """Piecewise linear displacement with zero values at both ends."""
    return amplitude * np.minimum(x / position, (1 - x) / (1 - position))


def ideal(tents, times, x):
    """Odd-reflected d'Alembert reference for arbitrary tent positions."""
    shift = times[:, None] * SPEED / LENGTH

    def extended(points):
        reflected = points % 2
        inside = np.where(reflected <= 1, reflected, 2 - reflected)
        sign = np.where(reflected <= 1, 1.0, -1.0)
        return sign[None, :, :] * triangle(
            inside[None, :, :], *tents.T[:, :, None, None]
        )

    return (extended(x - shift) + extended(x + shift)) / 2


def series_reference(tents, times, x, gamma, modes):
    """Continuum coefficients of the tent, independent of grid samples."""
    mode = np.arange(1, modes + 1)
    position, amplitude = tents.T[:, :, None]
    coeff = 2 * amplitude * np.sin(np.pi * mode * position)
    coeff /= (np.pi * mode) ** 2 * position * (1 - position)
    wave_number = np.pi * mode / LENGTH
    frequency = np.sqrt((SPEED * wave_number) ** 2 + gamma * wave_number**4)
    field = (coeff[:, None, :] * np.cos(times[:, None] * frequency)) @ np.sin(
        np.pi * mode[:, None] * x
    )
    field[..., [0, -1]] = 0.0
    return field


def predict(samples, times, gamma, *, linearized=False):
    """Zero-velocity sine propagator on the interior, with exact zero endpoints."""
    wave_number = np.pi * np.arange(1, samples.shape[-1] - 1) / LENGTH
    ideal_frequency = SPEED * wave_number
    dispersive_term = gamma * wave_number**4
    if linearized:
        frequency = ideal_frequency + dispersive_term / (2 * ideal_frequency)
    else:
        frequency = np.sqrt(ideal_frequency**2 + dispersive_term)
    spectrum = dst(samples[:, 1:-1], type=1, norm="ortho")
    propagated = spectrum[:, None, :] * np.cos(times[:, None] * frequency)
    fields = idst(propagated, type=1, norm="ortho")
    return np.pad(fields, ((0, 0), (0, 0), (1, 1)))


def training_data(material):
    """Synthetic independent modal amplitude readings, with fixed small noise."""
    wave_number = np.pi * np.array([12, 20, 28, 36]) / LENGTH
    ideal_frequency = SPEED * wave_number
    times = 0.7 / ideal_frequency
    phase = times * np.sqrt(ideal_frequency**2 + material * wave_number**4)
    assert np.all((0.3 < phase) & (phase < 1.5))
    amplitudes = np.cos(phase) + np.array([0.0002, -0.00035, 0.00025, -0.0001])
    return wave_number, times, amplitudes


def fit_dispersion(wave_number, times, amplitudes):
    """Bounded fit of one scaled nonnegative parameter, with no test profiles."""
    elastic = (SPEED * wave_number) ** 2
    sensitivity = 1e-8 * wave_number**4

    def residual(parameter):
        return (
            np.cos(times * np.sqrt(elastic + parameter[0] * sensitivity)) - amplitudes
        )

    fit = least_squares(
        residual, [1.0], bounds=([0.0], [4.0]), xtol=1e-13, ftol=1e-13, gtol=1e-13
    )
    if not fit.success:
        raise RuntimeError(fit.message)
    return float(fit.x[0] * 1e-8)


def errors(field, reference):
    return np.linalg.norm(field - reference, axis=-1) / np.linalg.norm(
        reference, axis=-1
    )


def statistics(field, reference):
    relative = errors(field, reference)
    return {
        "relative": relative.tolist(),
        "maximum_relative": float(relative.max()),
        "median_relative": float(np.median(relative)),
        "accepted": int(np.sum(relative.max(axis=1) <= BUDGET)),
        "count": len(relative),
        "max_boundary_m": float(np.abs(field[..., [0, -1]]).max()),
    }


def evaluate(tents, times, nodes, material, estimated, prior):
    x = np.linspace(0, 1, nodes)
    initial = triangle(x[None, :], *tents.T[:, :, None])
    truth = series_reference(tents, times, x, material, modes=8192)
    base = ideal(tents, times, x)
    fitted = predict(initial, times, estimated)
    known = predict(initial, times, material)
    variation = series_reference(tents, times, x, material, modes=4096)
    values = {
        "dalembert": statistics(base, truth),
        "sampled_ideal": statistics(predict(initial, times, 0.0), truth),
        "first_order_phase": statistics(
            predict(initial, times, estimated, linearized=True), truth
        ),
        "fitted_phase": statistics(fitted, truth),
        "exact_material_sampled": statistics(known, truth),
        "fixed_prior_material": statistics(predict(initial, times, prior), truth),
        "reference_truncation": float(errors(variation, truth).max()),
    }
    assert values["fitted_phase"]["max_boundary_m"] == 0.0
    return values


def run():
    gamma = fit_dispersion(*training_data(GAMMA))
    shifted_gamma = fit_dispersion(*training_data(2 * GAMMA))
    generator = np.random.default_rng(134723)
    locations = generator.uniform(0.13, 0.46, 12)
    amplitudes = generator.uniform(0.034, 0.059, 12)
    cases = np.column_stack(
        (np.r_[locations, 1 - locations], np.r_[amplitudes, amplitudes])
    )
    times = np.array([2.3, 5.0, 8.0, 11.7])
    rows = {
        "book": evaluate(np.asarray(BOOK_TENTS), BOOK_TIMES, 501, GAMMA, gamma, gamma),
        "held_out_65": evaluate(cases, times, 65, GAMMA, gamma, gamma),
        "held_out_129": evaluate(cases, times, 129, GAMMA, gamma, gamma),
        "held_out_501": evaluate(cases, times, 501, GAMMA, gamma, gamma),
        "double_stiffness_501": evaluate(
            cases, times, 501, 2 * GAMMA, shifted_gamma, gamma
        ),
    }
    x = np.linspace(0, 1, 501)
    samples = triangle(x[None, :], *cases.T[:, :, None])
    reflected = predict(samples, times, gamma)
    mirror = float(np.max(np.abs(reflected[:12] - reflected[12:, :, ::-1])))
    assert mirror < 1e-12
    assert abs(gamma - GAMMA) / GAMMA < 0.01
    assert abs(shifted_gamma - 2 * GAMMA) / (2 * GAMMA) < 0.01
    assert (
        rows["book"]["fitted_phase"]["maximum_relative"]
        < rows["book"]["dalembert"]["maximum_relative"]
    )
    assert (
        rows["held_out_501"]["fitted_phase"]["maximum_relative"]
        < rows["held_out_65"]["fitted_phase"]["maximum_relative"]
    )
    assert (
        rows["double_stiffness_501"]["fitted_phase"]["maximum_relative"]
        < rows["double_stiffness_501"]["fixed_prior_material"]["maximum_relative"]
    )
    return {
        "gamma": gamma,
        "shifted_gamma": shifted_gamma,
        "budget": BUDGET,
        "book_times_s": BOOK_TIMES.tolist(),
        "held_out_times_s": times.tolist(),
        "held_out_tents": cases.tolist(),
        "fit_amplitude_readings_per_material": 4,
        "mirror_max_m": mirror,
        "groups": rows,
    }
