"""Replay four structure-preserving variants against book and holdout cases."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys

import numpy as np
from numpy.polynomial.legendre import leggauss
import scipy
from scipy.fft import dst, idst
from scipy.integrate import quad

import saite


BOOK = Path(__file__).resolve().parent / "buchreferenzen"
CASES = BOOK / "buchmessung.json"
sys.path.insert(0, str(BOOK))
import c19r  # noqa: E402
import linear  # noqa: E402


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def c19r_cluster(injected, field, well, reference, points):
    scores = c19r.report_scores(field, reference, points, injected)
    if well is not None:
        separately_measured = np.abs(well - points) / points
        scores["well_relative"] = separately_measured.tolist()
        matrix = np.asarray([scores[key] for key in c19r.BUDGETS]).T
        scores["score"] = np.max(matrix / tuple(c19r.BUDGETS.values()), axis=1).tolist()
        scores["pass"] = (
            (np.asarray(scores["score"]) <= 1) & (np.asarray(scores["min_mg_m3"]) >= 0)
        ).tolist()
    return scores | {
        "maximum": max(scores["score"]),
        "accepted": sum(scores["pass"]),
        "count": len(injected),
    }


def mix_fields(rates, kernels):
    field = rates @ kernels.reshape(len(kernels), -1)
    return field.reshape(len(rates), c19r.Y.size, c19r.X.size)


def fit_transport(rates, field, well, durations):
    data = np.column_stack((field.reshape(len(rates), -1) * c19r.CELL_WATER, well))
    response, _, rank, _ = np.linalg.lstsq(rates, data, rcond=None)
    if rank != len(durations):
        raise ValueError("each source bin must be identifiable from training")
    in_window = np.maximum(response[:, :-1], 0) / durations[:, None]
    in_window /= np.maximum(1, in_window.sum(axis=1, keepdims=True))
    # Complement at observation time on the open plane, not integrated outflow.
    outside = np.maximum(0, 1 - in_window.sum(axis=1))
    fields = in_window * (durations[:, None] / c19r.CELL_WATER)
    return fields, outside * durations, np.maximum(response[:, -1], 0)


def short_pulse(age_days, *, nodes=96):
    """One mg/s pulse over an interval of ages at the observation time."""
    younger, older = np.asarray(age_days) * c19r.DAY
    locations, weights = leggauss(nodes)
    duration = older - younger
    ages = younger + (1 + locations) * duration / 2
    x_edges = np.r_[c19r.X - c19r.DX / 2, c19r.X[-1] + c19r.DX / 2]
    y_edges = np.r_[c19r.Y - c19r.DX / 2, c19r.Y[-1] + c19r.DX / 2]
    sigma = np.sqrt(2 * c19r.DIFFUSION * ages)
    along = c19r.axis_probabilities(x_edges, c19r.VELOCITY * ages, sigma)
    transverse = c19r.axis_probabilities(y_edges, np.zeros_like(ages), sigma)
    field = (
        (transverse * weights[:, None]).T @ along * (duration / (2 * c19r.CELL_WATER))
    )

    def at_well(age):
        scale = 4 * c19r.DIFFUSION * age
        return np.exp(-((5.0 - c19r.VELOCITY * age) ** 2) / scale) / (
            np.pi * scale * c19r.WATER_COLUMN
        )

    point = quad(at_well, younger, older, epsabs=1e-11, epsrel=1e-11)[0]
    return field, point


def refined_source_window(age_windows, truth, points):
    """Distinguish two pulses when timing is resolved in a refined source bin."""
    edges = np.unique(np.r_[np.linspace(0, 10, 9), np.linspace(5, 6.25, 21)])
    windows = np.column_stack((edges[:-1], edges[1:]))[::-1]
    durations = np.diff(windows, axis=1).ravel() * c19r.DAY
    prepared = [short_pulse(window) for window in windows]
    fields = np.stack([item[0] for item in prepared])
    point = np.array([item[1] for item in prepared])
    generator = np.random.default_rng(20261125)
    train = generator.uniform(0.3, 3.7, (80, len(windows)))
    model, balance, point_weights = fit_transport(
        train, mix_fields(train, fields), train @ point, durations
    )
    rates = (
        (windows[:, 0] >= age_windows[:, 0, None])
        & (windows[:, 1] <= age_windows[:, 1, None])
    ).astype(float)
    assert np.allclose(rates @ durations, 0.25 * c19r.DAY)
    prediction = mix_fields(rates, model)
    injected = rates @ durations
    mass_error = float(
        np.max(np.abs(c19r.mass(prediction) + rates @ balance - injected))
    )
    assert mass_error < 1e-7
    result = c19r_cluster(injected, prediction, rates @ point_weights, truth, points)
    assert result["accepted"] == len(age_windows)
    return result | {
        "bins": len(windows),
        "training_cases": len(train),
        "min_bin_days": 0.0625,
    }


def transport(book, arrays):
    with np.load(BOOK / "c19r_fixture.npz", allow_pickle=False) as saved:
        train, test, kernels, reference, points = (
            saved[key]
            for key in (
                "train_rates",
                "test_rates",
                "kernels",
                "reference",
                "point_reference",
            )
        )
    duration = c19r.HORIZON / c19r.SEGMENTS
    durations = np.full(c19r.SEGMENTS, duration)
    # Generate labels only for training rows. Holdout fields and points are read separately.
    point_kernel = c19r.point_basis()
    field, outside, well = fit_transport(
        train, mix_fields(train, kernels), train @ point_kernel, durations
    )
    baseline = book["C19R"]

    def reconstruct(rates):
        prediction = mix_fields(rates, field)
        exterior = rates @ outside
        return prediction, rates @ well, exterior

    prediction, well_values, outside_values = reconstruct(test)
    mass_check = c19r.mass(prediction) + outside_values - test @ durations
    point_only = c19r_cluster(test @ durations, prediction, None, reference, points)
    fitted = c19r_cluster(test @ durations, prediction, well_values, reference, points)
    assert np.max(np.abs(mass_check)) < 1e-7
    assert fitted["accepted"] == len(test)
    assert np.max(fitted["well_relative"]) < 1e-12

    generator = np.random.default_rng(20261124)
    extra = generator.uniform(0.1, 4.2, (16, c19r.SEGMENTS))
    additional, point_extra, _ = reconstruct(extra)
    truth_extra = mix_fields(extra, c19r.green_basis(nodes=192))
    extra_scores = c19r_cluster(
        extra @ durations, additional, point_extra, truth_extra, extra @ point_kernel
    )
    assert extra_scores["accepted"] == len(extra)

    # Both pulses are 0.25 days wide and fall wholly in the 5–6.25-day age bin.
    age_windows = np.array([[5.875, 6.125], [5.0625, 5.3125]])
    pair_values = [short_pulse(window, nodes=192) for window in age_windows]
    pulses = np.stack([item[0] for item in pair_values])
    point_pulses = np.array([item[1] for item in pair_values])
    difference = np.linalg.norm(pulses[0] - pulses[1])
    lower_bound = difference / (np.linalg.norm(pulses[0]) + np.linalg.norm(pulses[1]))
    rates_equal = np.zeros((2, c19r.SEGMENTS))
    rates_equal[:, 3] = 0.25 / 1.25
    same_output, same_well, _ = reconstruct(rates_equal)
    assert np.array_equal(same_output[0], same_output[1]) and np.all(
        same_well == same_well[0]
    )
    stress = c19r_cluster(
        rates_equal @ durations, same_output, same_well, pulses, point_pulses
    )
    assert max(stress["field_relative"]) >= lower_bound > c19r.BUDGETS["field_relative"]
    arrays.update(c19_x=c19r.X, c19_y=c19r.Y, c19_pair=pulses, c19_equal=same_output[0])
    return {
        "most_accurate_compact_book": {
            "method": min(
                baseline["methods"], key=lambda k: baseline["methods"][k]["maximum"]
            ),
            "maximum": min(
                method["maximum"] for method in baseline["methods"].values()
            ),
            "accepted": max(
                method["accepted"] for method in baseline["methods"].values()
            ),
            "count": len(test),
        },
        "full_fno_book": baseline["controls"]["fno_full"],
        "green_book": baseline["controls"]["green"],
        "field_and_cell_proxy": point_only,
        "positive_response_with_point": fitted,
        "new_rate_vectors": extra_scores,
        "rank": int(np.linalg.matrix_rank(train)),
        "training_cases": len(train),
        "mass_accounting_max_mg": float(np.abs(mass_check).max()),
        "refined_source_bins": refined_source_window(age_windows, pulses, point_pulses),
        "late_early_pulses": stress
        | {
            "age_windows_days": age_windows.tolist(),
            "equal_input_rates_mg_s": rates_equal[0].tolist(),
            "field_lower_bound": float(lower_bound),
            "point_lower_bound": float(
                np.abs(np.diff(point_pulses))[0] / point_pulses.sum()
            ),
        },
    }


def one_minus_sinc(z):
    # Small-angle series avoids subtracting values close to one.
    sq = z * z
    series = sq * (1 / 6 - sq * (1 / 120 - sq / 5040))
    return np.where(np.abs(z) < 0.02, series, 1 - np.sinc(z / np.pi))


def causal_rope(drive, step, export_every):
    """Solve each semidiscrete mode exactly for a linearly interpolated drive."""
    intervals = linear.ROPE_N
    coefficient = linear.ROPE_COEFFICIENT
    mode = np.arange(1, intervals)
    freq = 2 * np.sqrt(coefficient) * np.sin(np.pi * mode / (2 * intervals))
    boundary = np.zeros(intervals - 1)
    boundary[-1] = coefficient
    coupling = dst(boundary, type=1, norm="ortho")
    phase = step * freq
    cos = np.cos(phase)
    sine_over_freq = step * np.sinc(phase / np.pi)
    squared = freq**2
    hold_x = coupling * 2 * np.sin(phase / 2) ** 2 / squared
    ramp_x = coupling * step * one_minus_sinc(phase) / squared
    hold_v = coupling * sine_over_freq
    ramp_v = hold_x
    position = np.zeros((len(drive), intervals - 1))
    velocity = np.zeros_like(position)
    fields = [position.copy()]
    for k in range(drive.shape[1] - 1):
        left = drive[:, k : k + 1]
        slope = (drive[:, k + 1 : k + 2] - left) / step
        position, velocity = (
            cos * position + sine_over_freq * velocity + left * hold_x + slope * ramp_x,
            -squared * sine_over_freq * position
            + cos * velocity
            + left * hold_v
            + slope * ramp_v,
        )
        if (k + 1) % export_every == 0:
            fields.append(idst(position, type=1, norm="ortho"))
    return np.stack(fields, axis=1)


def rope_metrics(field, truth, probes):
    difference = field - truth
    relative = np.linalg.norm(difference.reshape(len(field), -1), axis=1)
    relative /= np.linalg.norm(truth.reshape(len(field), -1), axis=1)
    probe = np.max(np.abs(difference[:, :, probes]), axis=(1, 2))
    score = np.maximum(relative / 0.01, probe / 0.001)
    return {
        "field_relative": relative.tolist(),
        "probe_max_m": probe.tolist(),
        "score": score.tolist(),
        "maximum": float(score.max()),
        "accepted": int(np.sum(score <= 1)),
        "count": len(score),
    }


def boundary_drive(novel, frequencies, mixtures, time):
    envelope = np.exp(-linear.ROPE_DAMPING * time)
    components = np.sin(frequencies[:, None] * time) * envelope
    return np.vstack((mixtures @ components, np.sin(novel * time) * envelope))


def forced_rope(book, arrays):
    with np.load(BOOK / "cp1_fixture.npz", allow_pickle=False) as saved:
        time, freqs, mixtures, probes, novel_truth, novel_fno = (
            saved[key]
            for key in (
                "times",
                "frequencies",
                "drive",
                "probes",
                "novel_reference",
                "novel_fno",
            )
        )
    novel = book["CP1/C"]["tested_novel_frequency"]
    closed_forms = linear.modal_rope(time, freqs)
    truth = np.concatenate((linear.mixing(mixtures, closed_forms), novel_truth[None]))
    independent = linear.modal_rope(time, [novel])[0]
    assert np.max(np.abs(independent - novel_truth)) < 1e-12
    frozen = rope_metrics(novel_fno[None], novel_truth[None], probes)

    trials = {}
    for divider in (1, 2, 4, 8):
        step = (time[1] - time[0]) / divider
        fine_time = np.arange((len(time) - 1) * divider + 1) * step
        drive = boundary_drive(novel, freqs, mixtures, fine_time)
        fields = causal_rope(drive, step, divider)
        trials[str(divider)] = {
            "step_s": step,
            "known": rope_metrics(fields[:-1], truth[:-1], probes),
            "novel": rope_metrics(fields[-1:], truth[-1:], probes),
        }
    assert trials["8"]["novel"]["accepted"] == 1
    assert trials["8"]["known"]["accepted"] == len(mixtures)
    assert frozen["accepted"] == 0
    arrays.update(
        cp1_time=time,
        cp1_reference=novel_truth[:, probes[2]],
        cp1_transferred=fields[-1, :, probes[2]],
        cp1_book_fno=novel_fno[:, probes[2]],
    )
    return {
        "novel_rad_s": novel,
        "frozen_projected_fno": frozen,
        "projection_relative": book["CP1/C"]["projection_error"],
        "trials": trials,
        "intervals": linear.ROPE_N,
        "probes": probes.tolist(),
    }


def compartments(book):
    train, test, expected, _offset, budget, exact_a, exact_b, step, _cases = (
        linear.c15_problem()
    )
    training_response = linear.rollout(exact_a, exact_b, train)
    past = np.zeros_like(training_response)
    past[:, 1:] = training_response[:, :-1]
    regressor = np.concatenate((past, train[:, :, None]), axis=2).reshape(-1, 3)
    scale = np.linalg.norm(regressor, axis=0)
    weights, _, rank, _ = np.linalg.lstsq(
        regressor / scale, training_response.reshape(-1, 2), rcond=None
    )
    coefficients = (weights / scale[:, None]).T
    advance, response = coefficients[:, :2], coefficients[:, 2]
    if rank != 3 or np.any(coefficients < 0) or np.any(advance.sum(axis=0) > 1):
        raise ValueError(
            "fitted C15 transition violates identifiability or positivity and retention"
        )
    rho = np.abs(np.linalg.eigvals(advance)).max()
    if rho >= 1:
        raise ValueError("fitted C15 transition is unstable")

    def check(inputs, truth):
        prediction = linear.rollout(advance, response, inputs)
        err = np.max(np.abs(prediction - truth) / budget, axis=(1, 2))
        assert prediction.min() >= 0
        return {
            "scores": err.tolist(),
            "accepted": int(np.sum(err <= 1)),
            "count": len(inputs),
            "max_score": float(err.max()),
            "smallest_state": float(prediction.min()),
        }

    generator = np.random.default_rng(15061124)
    samples = np.arange(test.shape[1])
    starts = generator.integers(1, 300, (16, 2))
    ends = starts + generator.integers(1, 70, (16, 2))
    amplitudes = generator.uniform(0.2, 1.3, (16, 2))
    mask = (samples >= starts[:, :, None]) & (samples < ends[:, :, None])
    shifted = (mask * amplitudes[:, :, None]).sum(axis=1)
    held_out = check(test, expected)
    new = check(shifted, linear.rollout(exact_a, exact_b, shifted))
    prefix = len(samples) // 2
    altered = shifted.copy()
    altered[:, prefix:] += 0.5
    assert np.array_equal(
        linear.rollout(advance, response, shifted)[:, :prefix],
        linear.rollout(advance, response, altered)[:, :prefix],
    )
    assert held_out["accepted"] == len(test) and new["accepted"] == len(shifted)
    return {
        "book_tests": held_out,
        "new_pulses": new,
        "sample_step": step,
        "training_sequences": len(train),
        "training_rank": int(rank),
        "weights": coefficients.tolist(),
        "spectral_radius": float(rho),
        "max_column_sum": float(advance.sum(axis=0).max()),
        "compact_fourier_book": book["C15"]["methods"]["fourier"]["complete_readout"],
        "full_fourier_book": book["C15"]["controls"]["fno_full"],
    }


def events(book):
    """Compare stored common-protocol ablations and extract maximum event errors."""
    result = {}
    variants = {
        "C05": ("slow", "lag_formula", "fno_event"),
        "C07": ("midpoint", "hybrid_fno", "rk4", "fno_euler"),
    }
    for name, methods in variants.items():
        result[name] = {}
        for method in methods:
            summary = book[name]["controls"][method]
            errors = [x for x in summary["event_errors_s"] if x is not None]
            result[name][method] = {
                "max_paired_event_error_s": max(errors),
                "max_score": summary["maximum"],
                "accepted": summary["accepted"],
                "count": summary["count"],
                "event_mismatch": summary["event_mismatch"],
            }
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("auswertung"))
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    book = read_json(CASES)
    arrays = {}
    results = {
        "baseline": "Numerische Simulation dynamischer Systeme, v9.8",
        "python": platform.python_version(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "c19r": transport(book, arrays),
        "cp1": forced_rope(book, arrays),
        "c15": compartments(book),
        "cp2_string": saite.run(),
        "event_archive": events(book),
        "book_fixtures_sha256": {
            path.name: sha256(path.read_bytes()).hexdigest()
            for path in sorted(BOOK.iterdir())
            if path.is_file() and path.suffix in (".py", ".json", ".npz")
        },
    }
    (args.out / "ergebnisse.json").write_text(
        json.dumps(results, indent=2, allow_nan=False) + "\n"
    )
    np.savez_compressed(args.out / "bilddaten.npz", **arrays)
    print("Vier neue Versuchsanordnungen und Ereignisvergleich aus v9.8 geprüft.")


if __name__ == "__main__":
    main()
