"""Distinguish insufficient input data from an inaccurate output at a C19R well."""

from collections import Counter
from fractions import Fraction as F
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "messplanung"))
import c19r_plan as source  # noqa: E402

LIMIT = F(1, 100)
COARSE = F(8, 100)
FINE = F(6, 1000)


def enclosure(fractions, blocks):
    """Linear response of two source shapes; optimize at the endpoints."""
    lower, upper = blocks
    lo = min(a * lower[0] + (1 - a) * lower[1] for a in fractions)
    hi = max(a * upper[0] + (1 - a) * upper[1] for a in fractions)
    assert 0 < lo <= hi
    return lo, hi


def robust_score(value, limits):
    return max(abs(value / limit - 1) for limit in limits) / LIMIT


def witness_radius(fractions, blocks):
    """A lower bound from two physically attainable endpoint source histories."""
    left, right = (enclosure((endpoint,), blocks) for endpoint in fractions)
    lower_large = max(left[0], right[0])
    upper_small = min(left[1], right[1])
    return max(F(0), (lower_large - upper_small) / (lower_large + upper_small))


def observe(fractions, reading, accuracy):
    lo, hi = (
        max(fractions[0], reading - accuracy),
        min(fractions[1], reading + accuracy),
    )
    if lo > hi:
        raise ValueError("the observations and their error model are incompatible")
    return lo, hi


def decide(blocks, rectangle, sensors):
    fractions = (F(0), F(1))
    steps = []
    while True:
        limits = enclosure(fractions, blocks)
        lo, hi = limits
        minimax = 2 * lo * hi / (lo + hi)
        if robust_score(minimax, limits) <= 1:
            a = sum(fractions) / 2
            value = a * rectangle[0] + (1 - a) * rectangle[1]
            action = "rectangle"
            if robust_score(value, limits) > 1:
                value, action = minimax, "green_interval"
            return steps, action, value, robust_score(value, limits)
        # Each callable represents a later meter reading; the planner sees no true rate.
        if len(steps) == len(sensors):
            return steps, "unresolved", None, None
        label, accuracy, read = sensors[len(steps)]
        fractions = observe(fractions, read(), accuracy)
        steps.append(label)


def weights(well, *, with_reference=True):
    lo, hi, reference = source.weights(well, with_reference=with_reference)
    starts = (0, 16)
    certified = tuple(
        tuple(F(int(sum(vector[i : i + 4])), source.WEIGHT_SCALE) for i in starts)
        for vector in (lo, hi)
    )
    # Deliberately cheap left rectangular rule over each complete four-cell pulse.
    rough = []
    for start in starts:
        age = source.c19r.HORIZON - source.SOURCE_START - start * source.TIME_STEP
        scale = 4 * source.c19r.DIFFUSION * age
        kernel = np.exp(-((well - source.c19r.VELOCITY * age) ** 2) / scale)
        rough.append(
            F(
                str(
                    float(
                        4
                        * source.TIME_STEP
                        * kernel
                        / (np.pi * scale * source.c19r.WATER_COLUMN)
                    )
                )
            )
        )
    independent = (
        tuple(float(sum(reference[i : i + 4])) for i in starts) if with_reference else None
    )
    return certified, rough, independent


def run():
    wells = []
    for well in (5.0, 5.25):
        blocks, cheap, independent = weights(well)
        rows = []
        for i in range(33):
            alpha = F(i, 32)
            for sign_first in (-1, 0, 1):
                for sign_second in (-1, 0, 1):
                    sensors = [
                        ("Tag 4,0", COARSE, lambda: alpha + sign_first * COARSE),
                        ("Tag 4,5", FINE, lambda: alpha + sign_second * FINE),
                    ]
                    prefix = decide(blocks, cheap, sensors[:1])
                    steps, action, value, score = decide(blocks, cheap, sensors)
                    first_set = observe((F(0), F(1)), sensors[0][2](), COARSE)
                    lower_radius = witness_radius(first_set, blocks)
                    # The independent quadrature and true mixing fraction only validate the output.
                    exact = (
                        float(alpha) * independent[0]
                        + (1 - float(alpha)) * independent[1]
                    )
                    assert value is not None and score <= 1
                    error = abs(float(value) / exact - 1)
                    assert error <= float(score * LIMIT) + 1e-12
                    rows.append(
                        {
                            "alpha": float(alpha),
                            "noise_signs": [sign_first, sign_second],
                            "readings": len(steps),
                            "after_first": prefix[1],
                            "action": action,
                            "lower_radius_after_first": float(lower_radius),
                            "certified_score": float(score),
                            "observed_relative_error": error,
                        }
                    )
        l0, u0 = enclosure((F(0), F(1)), blocks)
        assert decide(blocks, cheap, [])[1] == "unresolved"
        assert witness_radius((F(0), F(1)), blocks) > LIMIT
        counts = dict(Counter((r["action"] for r in rows)))
        wells.append(
            {
                "well_x": well,
                "cases": len(rows),
                "actions": counts,
                "lower_pulse_responses": list(map(float, blocks[0])),
                "upper_pulse_responses": list(map(float, blocks[1])),
                "second_reading": sum(r["readings"] == 2 for r in rows),
                "second_necessary_by_witness": sum(
                    r["lower_radius_after_first"] > float(LIMIT) for r in rows
                ),
                "max_relative_error": max(r["observed_relative_error"] for r in rows),
                "max_certified_score": max(r["certified_score"] for r in rows),
                "initial_relative_radius": float((u0 - l0) / (u0 + l0)),
                "rows": rows,
            }
        )
    return {
        "relative_budget": float(LIMIT),
        "meter_errors_fraction_of_total": [float(COARSE), float(FINE)],
        "source": "first and last four of twenty bins, known total 21.6 g",
        "wells": wells,
    }
