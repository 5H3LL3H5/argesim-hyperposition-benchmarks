"""Learn and independently verify dual witnesses for a discrete CP2/3 Newmark step."""

from dataclasses import dataclass
from fractions import Fraction as F
from functools import lru_cache
import math

import numpy as np
from scipy.fft import dst, idst
from scipy.linalg import solve_banded

TICKS = 10**9
DUAL_DEGREE = 16
DEFAULT_BUDGET = F(1, 100)


def laplace(values):
    return [
        2 * value
        - (values[i - 1] if i else 0)
        - (values[i + 1] if i + 1 < len(values) else 0)
        for i, value in enumerate(values)
    ]


def quantize(values):
    a = np.asarray(values, dtype=float)
    if a.ndim != 1 or not np.isfinite(a).all():
        raise ValueError("invalid proposed field")
    return tuple(int(round(v * TICKS)) for v in a)


def direct(mu, rhs):
    n = len(rhs)
    m = float(mu)
    bands = np.zeros((3, n))
    bands[0, 1:] = -m
    bands[1, :] = 1 + 2 * m
    bands[2, :-1] = -m
    return solve_banded((1, 1), bands, np.asarray(rhs, dtype=float))


def local_basis(v, degree):
    """Columns are Chebyshev filters of the zero-Dirichlet neighbour average."""

    def average(x):
        y = np.zeros_like(x)
        y[1:] += 0.5 * x[:-1]
        y[:-1] += 0.5 * x[1:]
        return y

    columns = [np.asarray(v, dtype=float)]
    if degree:
        columns.append(average(columns[0]))
    for _ in range(2, degree + 1):
        columns.append(2 * average(columns[-1]) - columns[-2])
    return np.stack(columns, axis=1)


class DualOperator:
    """Fitted parametric polynomial filter acting linearly on any spatial observation."""

    def __init__(self, model):
        self.knots = np.asarray(model["log_mu"])
        self.coefficients = np.asarray(model["coefficients"])
        if (
            self.knots.ndim != 1
            or len(self.knots) < 2
            or not np.all(np.diff(self.knots) > 0)
            or self.coefficients.shape != (len(self.knots), DUAL_DEGREE + 1)
            or not np.isfinite(self.knots).all()
            or not np.isfinite(self.coefficients).all()
        ):
            raise ValueError("invalid dual model weights")

    @staticmethod
    def fit():
        mus = (0.125, 0.5, 1, 2, 4, 8, 16)
        coefficients = []
        snapshots = 0
        for mu in mus:
            matrices = []
            targets = []
            for n in (31, 63):
                for index in (1, n // 4, n // 2, n - 2):
                    ell = np.zeros(n)
                    ell[index] = 1
                    matrices.append(local_basis(ell, DUAL_DEGREE))
                    targets.append(direct(mu, ell))
                    snapshots += 1
            theta = np.linalg.lstsq(
                np.vstack(matrices), np.concatenate(targets), rcond=None
            )[0]
            coefficients.append(theta.tolist())
        return {
            "log_mu": np.log(mus).tolist(),
            "coefficients": coefficients,
            "training_grids": [31, 63],
            "training_mu": list(mus),
            "training_snapshots": snapshots,
            "degree": DUAL_DEGREE,
        }

    def propose(self, mu, goal_ticks, degree):
        if degree < 0 or degree >= self.coefficients.shape[1] or mu <= 0:
            raise ValueError("unsupported filter degree or parameter")
        x = math.log(float(mu))
        theta = [
            np.interp(x, self.knots, self.coefficients[:, i]) for i in range(degree + 1)
        ]
        return quantize(
            local_basis(np.asarray(goal_ticks, dtype=float) / TICKS, degree) @ theta
        )


class AnalyticalDual:
    """Matched, training-free Chebyshev expansion for this constant-coefficient stencil."""

    def propose(self, mu, goal_ticks, degree):
        root = math.sqrt(1 + 4 * float(mu))
        ratio = 2 * float(mu) / (1 + 2 * float(mu) + root)
        weights = [1 / root] + [2 * ratio**k / root for k in range(1, degree + 1)]
        return quantize(
            local_basis(np.asarray(goal_ticks, dtype=float) / TICKS, degree) @ weights
        )


@dataclass(frozen=True)
class Problem:
    mu: F
    rhs_num: tuple  # f at common denominator mu.denominator*TICKS
    goal_ticks: tuple

    def __post_init__(self):
        if (
            self.mu <= 0
            or len(self.rhs_num) < 1
            or len(self.rhs_num) != len(self.goal_ticks)
        ):
            raise ValueError("invalid grid, observation or Newmark coefficient")
        if any(type(v) is not int for v in (*self.rhs_num, *self.goal_ticks)):
            raise TypeError("exact integer inputs required")

    def rhs(self):
        return np.array(self.rhs_num, dtype=float) / (self.mu.denominator * TICKS)


def pluck(x, apex):
    return x / apex if x <= apex else (1 - x) / (1 - apex)


def make_problem(n, mu, apex, probe, *, moving=False, averaged=False):
    """Normalized initial displacement and prescribed h*v, rounded once on the input grid."""
    if n < 5 or not 0 < apex < 1 or not 0 < probe < 1:
        raise ValueError("invalid pluck or sensor location")
    mu, apex, probe = map(F, (mu, apex, probe))
    points = [F(i, n + 1) for i in range(1, n + 1)]
    u = [round(TICKS * pluck(x, apex)) for x in points]
    hv = [round(TICKS * pluck(x, 1 - apex) / 12) if moving else 0 for x in points]
    m, d = mu.as_integer_ratio()
    rhs = tuple(d * (a + b) - m * c for a, b, c in zip(u, hv, laplace(u), strict=True))
    j = max(0, min(n - 1, round(probe * (n + 1)) - 1))
    goal = [0] * n
    if averaged and 0 < j < n - 1:
        goal[j - 1 : j + 2] = [TICKS // 4, TICKS // 2, TICKS // 4]
    else:
        goal[j] = TICKS
    return Problem(mu, rhs, tuple(goal))


@lru_cache(maxsize=128)
def modes(n, count):
    k = np.arange(1, min(n, count) + 1)
    return np.sin(np.pi * np.outer(np.arange(1, n + 1), k) / (n + 1)), 4 * np.sin(
        np.pi * k / (2 * (n + 1))
    ) ** 2


def propose_field(problem, count):
    basis, eigen = modes(len(problem.rhs_num), count)
    coeff = (
        (basis.T @ problem.rhs())
        * (2 / (len(problem.rhs_num) + 1))
        / (1 + float(problem.mu) * eigen)
    )
    return quantize(basis @ coeff)


def residual(problem, field):
    m, d = problem.mu.as_integer_ratio()
    if len(field) != len(problem.rhs_num) or any(type(v) is not int for v in field):
        raise ValueError("invalid quantized field")
    return tuple(
        f - d * v - m * lv
        for f, v, lv in zip(problem.rhs_num, field, laplace(field), strict=True)
    )


@dataclass(frozen=True)
class Certificate:
    value: F
    error: F
    raw_value: F
    raw_bound: F
    zero_bound: F


def verify(problem, field, witness):
    """Exact-integer checker, independent of the training method and of any exact solve."""
    if len(witness) != len(problem.goal_ticks) or any(
        type(v) is not int for v in witness
    ):
        raise ValueError("invalid quantized witness")
    m, d = problem.mu.as_integer_ratio()
    r = residual(problem, field)
    dual = [
        d * (ell - z) - m * lz
        for ell, z, lz in zip(
            problem.goal_ticks, witness, laplace(witness), strict=True
        )
    ]
    r_max = max(map(abs, r))
    total = TICKS * TICKS
    correction = F(sum(z * rv for z, rv in zip(witness, r, strict=True)), d * total)
    goal = F(
        sum(ell * v for ell, v in zip(problem.goal_ticks, field, strict=True)), total
    )
    tail = F(r_max * sum(map(abs, dual)), d * d * total)
    zero = F(r_max * sum(map(abs, problem.goal_ticks)), d * total)
    return Certificate(goal + correction, tail, goal, abs(correction) + tail, zero)


def reference(problem):
    """Independent full sine diagonalization, used after the final decision."""
    n = len(problem.rhs_num)
    modes_all = np.arange(1, n + 1)
    eig = 1 + 4 * float(problem.mu) * np.sin(np.pi * modes_all / (2 * (n + 1))) ** 2
    u = idst(dst(problem.rhs(), type=1, norm="ortho") / eig, type=1, norm="ortho")
    return float(np.dot(problem.goal_ticks, u) / TICKS)


def trial(problem, model, tier, *, no_witness=False):
    n = len(problem.rhs_num)
    if tier == "klassisch":
        v = quantize(direct(problem.mu, problem.rhs()))
        z = (0,) * n
    elif tier in ("grob", "verfeinern"):
        count, degree = (6, 3) if tier == "grob" else (18, DUAL_DEGREE)
        v = propose_field(problem, count)
        z = (
            (0,) * n
            if no_witness
            else model.propose(problem.mu, problem.goal_ticks, degree)
        )
    else:
        raise ValueError("unknown solver action")
    return verify(problem, v, z)


def policy_features(problem, result, budget):
    w = np.asarray(problem.goal_ticks, dtype=float) / TICKS
    n = len(w)
    pos = np.dot(w, np.arange(1, n + 1)) / (n + 1)
    return np.array(
        [
            np.log1p(n),
            math.log(float(problem.mu)),
            pos,
            np.sum(w * w),
            math.log1p(float(result.zero_bound / budget)),
            math.log1p(float(result.error / budget)),
            float(abs(result.value - result.raw_value) / budget),
            math.log(float(budget)),
        ]
    )


def solve(problem, model, choose, *, budget=DEFAULT_BUDGET, no_witness=False):
    """Certified online goal estimate. A failed classical certificate leaves the result open."""
    budget = F(budget)
    if budget <= 0:
        raise ValueError("budget must be positive")
    coarse = trial(problem, model, "grob", no_witness=no_witness)
    path = ["grob"]
    if coarse.error <= budget:
        return coarse, path, coarse
    first = choose(problem, coarse, budget)
    if first not in ("verfeinern", "klassisch"):
        raise ValueError("unavailable action")
    if first == "verfeinern":
        refined = trial(problem, model, first, no_witness=no_witness)
        path.append(first)
        if refined.error <= budget:
            return refined, path, coarse
    classic = trial(problem, model, "klassisch")
    path.append("klassisch")
    return (classic if classic.error <= budget else None), path, coarse
