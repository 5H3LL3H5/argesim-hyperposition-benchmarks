#include "zielpruefer.hpp"
#include <iostream>
#include <vector>

int main() {
    std::ios::sync_with_stdio(false);
    try {
        while (std::cin >> std::ws && std::cin.peek() != std::char_traits<char>::eof()) {
            std::size_t n = 0;
            mpz_class m, d, scale;
            if (!(std::cin >> n >> m >> d >> scale) || n == 0 || n > 1000000) {
                throw std::invalid_argument("ungueltiger Auftragskopf");
            }
            std::vector<mpz_class> rhs(n), goal(n), field(n), witness(n);
            for (auto* v : {&rhs, &goal, &field, &witness}) {
                for (auto& entry : *v) {
                    if (!(std::cin >> entry)) throw std::invalid_argument("unvollstaendiger Vektor");
                }
            }
            const auto interval = argesim::pruefe_ziel(m, d, scale, rhs, goal, field, witness);
            std::cout << interval.wert << ' ' << interval.radius << '\n';
            if (!std::cout) return 3;
        }
        return std::cin.bad() ? 2 : 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 2;
    }
}
