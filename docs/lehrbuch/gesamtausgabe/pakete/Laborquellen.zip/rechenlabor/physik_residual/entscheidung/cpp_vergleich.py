"""Compile an independent C++20/GMP checker and compare exact rational outputs."""

from fractions import Fraction as F
from pathlib import Path
import json
import os
import subprocess
from tempfile import TemporaryDirectory

import dualer_operator as dual
import labor

HERE = Path(__file__).resolve().parent


def check():
    model = json.loads((HERE / "messung/modell.json").read_text())
    operator = dual.DualOperator(model["dual"])
    cases = []
    expected = []

    def add(problem, field, witness):
        m, d = problem.mu.as_integer_ratio()
        rows = [
            [len(field), m, d, dual.TICKS],
            problem.rhs_num,
            problem.goal_ticks,
            field,
            witness,
        ]
        cases.append("\n".join(" ".join(map(str, row)) for row in rows))
        cert = dual.verify(problem, field, witness)
        expected.append((cert.value, cert.error))

    for split in ("test", "stress"):
        for p, _, _ in labor.string_cases(split):
            v = dual.propose_field(p, 6)
            z = operator.propose(p.mu, p.goal_ticks, 3)
            add(p, v, z)
    huge = 10**55
    p = dual.Problem(F(7, 11), (huge, -huge), (dual.TICKS, -dual.TICKS))
    add(p, (2 * huge, -3 * huge), (-4 * huge, 5 * huge))
    with TemporaryDirectory() as tmp:
        binary = Path(tmp) / "zielpruefer"
        subprocess.run(
            [
                os.environ.get("CXX", "g++"),
                "-std=c++20",
                "-O2",
                "-Wall",
                "-Wextra",
                "-Wpedantic",
                "-Werror",
                str(HERE / "zielpruefer_cli.cpp"),
                "-lgmpxx",
                "-lgmp",
                "-o",
                str(binary),
            ],
            check=True,
        )
        proc = subprocess.run(
            [str(binary)],
            input="\n".join(cases) + "\n",
            capture_output=True,
            text=True,
            check=True,
        )
        actual = [tuple(map(F, line.split())) for line in proc.stdout.splitlines()]
        assert actual == expected
        for invalid in ("0 1 1 1\n", "2 1 1 1\n0 0\n0", "1 1 0 2\n0 0 0 0\n", "x\n"):
            bad = subprocess.run(
                [str(binary)], input=invalid, capture_output=True, text=True
            )
            assert bad.returncode != 0 and not bad.stdout
    print(
        f"{len(expected)} rationale Zielintervalle in C++20 und Python identisch. Vier fehlerhafte Eingaben zurückgewiesen."
    )


if __name__ == "__main__":
    check()
