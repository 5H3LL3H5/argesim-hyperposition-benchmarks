"""Exact small-system tests and fail-closed properties independent of the benchmark means."""

from fractions import Fraction as F
from pathlib import Path
import json
import unittest
from unittest.mock import patch

import numpy as np
import aktion as a
import dualer_operator as d

HERE = Path(__file__).resolve().parent


def exact_goal(p):
    # Independent rational Thomas solve for the problem, used only in tests.
    n = len(p.rhs_num)
    mu = p.mu
    diagonal = [1 + 2 * mu] * n
    rhs = [F(x, p.mu.denominator * d.TICKS) for x in p.rhs_num]
    for i in range(1, n):
        ratio = -mu / diagonal[i - 1]
        diagonal[i] += ratio * mu
        rhs[i] -= ratio * rhs[i - 1]
    x = [F(0)] * n
    for i in reversed(range(n)):
        x[i] = (rhs[i] + (mu * x[i + 1] if i + 1 < n else 0)) / diagonal[i]
    return sum(ell * y for ell, y in zip(p.goal_ticks, x, strict=True)) / d.TICKS


class DualChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model = d.DualOperator(
            json.loads((HERE / "messung/modell.json").read_text())["dual"]
        )

    def test_arbitrary_witness_against_exact_fractions(self):
        rng = np.random.default_rng(831)
        for n in (1, 2, 7, 15):
            for mu in (F(1, 9), F(3, 2), F(72)):
                arrays = [
                    tuple(map(int, rng.integers(-(10**10), 10**10, n)))
                    for _ in range(4)
                ]
                p = d.Problem(mu, arrays[0], arrays[1])
                target = exact_goal(p)
                for witness in (arrays[3], tuple(-x for x in arrays[3]), (0,) * n):
                    c = d.verify(p, arrays[2], witness)
                    self.assertLessEqual(abs(c.value - target), c.error)
                    self.assertLessEqual(abs(c.raw_value - target), c.raw_bound)
                    self.assertLessEqual(abs(c.raw_value - target), c.zero_bound)

    def test_corrupt_witness_cannot_force_release(self):
        p = d.make_problem(31, F(4), F(1, 4), F(1, 3))
        v = d.propose_field(p, 6)
        false_witness = tuple(100 * d.TICKS * (-1) ** j for j in range(31))
        c = d.verify(p, v, false_witness)
        exact = exact_goal(p)
        self.assertGreater(abs(c.value - exact), F(1, 100))
        self.assertGreaterEqual(c.error, abs(c.value - exact))

        class Broken:
            def propose(self, *_):
                return false_witness

        final, path, _ = d.solve(p, Broken(), lambda *_: "verfeinern")
        self.assertEqual(path[-1], "klassisch")
        self.assertLessEqual(abs(final.value - exact), final.error)

    def test_small_budget_stays_open(self):
        p = d.make_problem(15, F(1, 2), F(1, 3), F(1, 4))
        final, path, _ = d.solve(
            p, self.model, lambda *_: "klassisch", budget=F(1, 10**25)
        )
        self.assertIsNone(final)
        self.assertEqual(path[-1], "klassisch")

    def test_boundary_symmetry_and_superposition(self):
        mu = F(3, 2)
        p = d.make_problem(31, mu, F(2, 7), F(1, 4), moving=True)
        reflected = d.make_problem(31, mu, F(5, 7), F(3, 4), moving=True)
        self.assertEqual(p.rhs_num, reflected.rhs_num[::-1])
        self.assertEqual(exact_goal(p), exact_goal(reflected))
        z = self.model.propose(mu, p.goal_ticks, 16)
        w = self.model.propose(mu, reflected.goal_ticks, 16)
        self.assertEqual(z, w[::-1])
        b = self.model.propose(
            mu,
            tuple(
                x + y for x, y in zip(p.goal_ticks, reflected.goal_ticks, strict=True)
            ),
            16,
        )
        self.assertLessEqual(
            max(abs(x + y - t) for x, y, t in zip(z, w, b, strict=True)), 1
        )

    def test_invalid_arrays_and_empty_grid_rejected(self):
        p = d.make_problem(5, F(1), F(1, 2), F(1, 2))
        with self.assertRaises(ValueError):
            d.verify(p, (0,) * 5, (0,) * 4)
        with self.assertRaises(ValueError):
            d.verify(p, (0, 4.2, 0, 0, 0), (0,) * 5)
        with self.assertRaises(ValueError):
            d.Problem(F(1), (), ())
        with self.assertRaises(ValueError):
            d.quantize([np.nan])


class ActionChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model = a.ActionOperator(
            json.loads((HERE / "messung/modell.json").read_text())["well_policy"]
        )

    def test_online_setup_never_computes_control_quadrature(self):
        with patch.object(
            a.brunnen.source,
            "quad",
            side_effect=AssertionError("reference unavailable"),
        ):
            station, reference = a.prepare(5.0)
            self.assertIsNone(reference)
            value, bound, _, _ = a.execute(
                station, F(1, 2), lambda: F(1, 2), self.model.choose
            )
        self.assertIsNotNone(value)
        self.assertLessEqual(bound, a.BUDGET)

    def test_causal_meter_remains_unread(self):
        station = a.Station(
            5.0, ((F(1), F(1)), (F(1), F(1))), (F(1), F(1)), (F(1), F(1))
        )

        def unused():
            self.fail("late reading exposed")

        value, bound, path, _ = a.execute(station, F(1, 2), unused, self.model.choose)
        self.assertEqual((value, bound, path), (1, 0, []))

    def test_insufficient_sensor_and_contradiction(self):
        station = a.Station(
            5.0, ((F(1), F(9)), (F(1), F(9))), (F(1), F(9)), (F(1), F(9))
        )
        value, _, path, _ = a.execute(
            station, F(1, 2), lambda: F(1, 2), self.model.choose, fine_accuracy=F(1, 25)
        )
        self.assertIsNone(value)
        self.assertEqual(path, ["messen"])
        with self.assertRaises(ValueError):
            a.execute(station, F(1, 2), lambda: F(0), self.model.choose)

    def test_sensor_single_call_and_exact_budget(self):
        station = a.Station(
            5.0, ((F(1), F(9)), (F(1), F(9))), (F(0), F(0)), (F(0), F(0))
        )
        reads = []

        def sensor():
            reads.append(1)
            return F(1, 2)

        value, bound, path, _ = a.execute(
            station, F(1, 2), sensor, self.model.choose, fine_accuracy=F(0)
        )
        self.assertEqual(reads, [1])
        self.assertEqual(path.count("messen"), 1)
        self.assertEqual((value, bound), (5, 0))

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            a.initial(F(-3))
        with self.assertRaises(ValueError):
            a.initial(F(1, 2), F(-1))
        with self.assertRaises(ValueError):
            a.ActionOperator(
                {
                    "shift": [1],
                    "scale": [0],
                    "centers": [[1]],
                    "weights": [[1], [1], [1]],
                }
            )


if __name__ == "__main__":
    unittest.main()
