"""C19R. A learned action-cost map proposes; exact interval arithmetic decides."""

from dataclasses import dataclass
from fractions import Fraction as F
from functools import lru_cache
from itertools import permutations
from pathlib import Path
import sys

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import brunnen  # noqa: E402

ACTIONS = ("messen", "verfeinern", "klassisch")
ORDERS = tuple(permutations(ACTIONS))
INITIAL_COST = 3  # coarse reading, rectangle and gate
COST = {"messen": 14, "verfeinern": 3, "klassisch": 7}
COARSE = brunnen.COARSE
FINE = brunnen.FINE
BUDGET = F(1, 100)


@dataclass(frozen=True)
class Station:
    position: float
    blocks: tuple
    rectangle: tuple
    midpoint: tuple


@lru_cache(maxsize=64)
def prepare(position, *, with_reference=False):
    """Offline preparation; independent reference values never enter Station or the model."""
    certified, rough, reference = brunnen.weights(
        position, with_reference=with_reference
    )
    quadrature = brunnen.source
    midpoint = []
    for start in (0, 16):
        age = (
            quadrature.c19r.HORIZON
            - quadrature.SOURCE_START
            - (start + 2) * quadrature.TIME_STEP
        )
        scale = 4 * quadrature.c19r.DIFFUSION * age
        weight = (
            4
            * quadrature.TIME_STEP
            * np.exp(-((position - quadrature.c19r.VELOCITY * age) ** 2) / scale)
            / (np.pi * scale * quadrature.c19r.WATER_COLUMN)
        )
        midpoint.append(F(str(float(weight))))
    return Station(position, certified, tuple(rough), tuple(midpoint)), reference


@dataclass(frozen=True)
class State:
    interval: tuple
    measured: bool = False
    tried: tuple = ()

    def available(self):
        return tuple(
            a
            for a in ACTIONS
            if a not in self.tried and (a != "messen" or not self.measured)
        )


def bounds(station, state):
    return brunnen.enclosure(state.interval, station.blocks)


def initial(reading, accuracy=COARSE):
    reading, accuracy = F(reading), F(accuracy)
    if accuracy < 0:
        raise ValueError("negative meter error")
    return State(brunnen.observe((F(0), F(1)), reading, accuracy))


def candidate(station, state, method):
    if method == "klassisch":
        lo, hi = bounds(station, state)
        return 2 * lo * hi / (lo + hi)
    if method not in ("rechteck", "verfeinern"):
        raise ValueError("unknown quadrature")
    weights = station.rectangle if method == "rechteck" else station.midpoint
    center = sum(state.interval) / 2
    return center * weights[0] + (1 - center) * weights[1]


def certify(station, state, value):
    return max(abs(value / q - 1) for q in bounds(station, state))


def step(station, state, action, read_fine, fine_accuracy):
    if action not in state.available():
        raise ValueError("unavailable action")
    if action == "messen":
        updated = State(
            brunnen.observe(state.interval, F(read_fine()), fine_accuracy), True
        )
        return updated, candidate(station, updated, "rechteck")
    updated = State(state.interval, state.measured, state.tried + (action,))
    return updated, candidate(station, state, action)


def features(station, state, budget, fine_accuracy):
    lo, hi = bounds(station, state)
    left, right = state.interval
    return np.array(
        [
            station.position - 5,
            float((left + right) / 2),
            float(right - left),
            float((hi - lo) / ((hi + lo) * budget)),
            float(
                certify(station, state, candidate(station, state, "rechteck")) / budget
            ),
            float(budget),
            float(fine_accuracy),
            float(state.measured),
            float("verfeinern" in state.tried),
            float("klassisch" in state.tried),
        ]
    )


class ActionOperator:
    """Radial-basis network fitted on offline continuation costs. Frozen JSON weights."""

    def __init__(self, model):
        self.shift = np.asarray(model["shift"])
        self.scale = np.asarray(model["scale"])
        self.centers = np.asarray(model["centers"])
        self.weights = np.asarray(model["weights"])
        n = self.shift.size
        if (
            self.shift.ndim != 1
            or self.scale.shape != (n,)
            or np.any(self.scale <= 0)
            or self.centers.ndim != 2
            or self.centers.shape[1] != n
            or self.weights.ndim != 2
            or self.weights.shape[0] != 1 + n + len(self.centers)
            or self.weights.shape[1] < 1
            or not all(
                np.isfinite(x).all()
                for x in (self.shift, self.scale, self.centers, self.weights)
            )
        ):
            raise ValueError("invalid action model weights")

    @staticmethod
    def design(x, centers):
        # A short linear extrapolation and local Gaussian responses share one fitted head.
        d2 = ((x[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2)
        return np.column_stack((np.ones(len(x)), x, np.exp(-d2 / 3)))

    @classmethod
    def fit(cls, examples):
        x = np.asarray([row[0] for row in examples])
        y = np.asarray([row[1] for row in examples])
        shift = x.mean(axis=0)
        scale = x.std(axis=0)
        scale[scale < 1e-8] = 1
        x = (x - shift) / scale
        distinct = np.unique(x.round(10), axis=0)
        rng = np.random.default_rng(2411)
        centers = distinct[
            rng.choice(len(distinct), min(96, len(distinct)), replace=False)
        ]
        design = cls.design(x, centers)
        weights = []
        for col in range(y.shape[1]):
            keep = np.isfinite(y[:, col])
            a = design[keep]
            weights.append(
                np.linalg.solve(a.T @ a + 0.01 * np.eye(a.shape[1]), a.T @ y[keep, col])
            )
        return dict(
            shift=shift.tolist(),
            scale=scale.tolist(),
            centers=centers.tolist(),
            weights=np.stack(weights, axis=1).tolist(),
        )

    def prices(self, raw_features):
        x = ((raw_features - self.shift) / self.scale)[None, :]
        return (self.design(x, self.centers) @ self.weights)[0]

    def choose(self, station, state, budget, fine_accuracy, allowed):
        prices = self.prices(features(station, state, budget, fine_accuracy))
        return min(allowed, key=lambda action: prices[ACTIONS.index(action)])


def heuristic(station, state, budget, fine_accuracy, allowed):
    lo, hi = bounds(station, state)
    order = (
        ("messen", "verfeinern", "klassisch")
        if (hi - lo) / (hi + lo) > budget
        else ("verfeinern", "klassisch", "messen")
    )
    return next(a for a in order if a in allowed)


def admissible(station, state, budget):
    """Reject work that cannot pass this same interval checker; compare only feasible actions."""
    lo, hi = bounds(station, state)
    if (hi - lo) / (hi + lo) > budget:
        return () if state.measured else ("messen",)
    # The classical result is guaranteed here and costs less than another reading.
    return tuple(action for action in state.available() if action != "messen")


def execute(
    station,
    first_reading,
    read_fine,
    chooser,
    *,
    budget=BUDGET,
    fine_accuracy=FINE,
    guarded=True,
):
    """Deployable online entry. The second reading is a callback invoked only on demand."""
    budget, fine_accuracy = F(budget), F(fine_accuracy)
    if budget <= 0 or fine_accuracy < 0:
        raise ValueError("invalid error contract")
    state = initial(first_reading)
    actions = []
    cost = INITIAL_COST
    value = candidate(station, state, "rechteck")
    while True:
        error = certify(station, state, value)
        if error <= budget:
            return value, error, actions, cost
        allowed = admissible(station, state, budget) if guarded else state.available()
        if not allowed:
            return None, None, actions, cost
        action = (
            allowed[0]
            if len(allowed) == 1
            else chooser(station, state, budget, fine_accuracy, allowed)
        )
        if action not in allowed:
            raise ValueError("policy selected an inadmissible action")
        state, value = step(station, state, action, read_fine, fine_accuracy)
        cost += COST[action]
        actions.append(action)


def fixed(order):
    def choose(station, state, budget, fine_accuracy, allowed):
        return next(a for a in order if a in allowed)

    return choose


def training_labels(station, first, fine, budget, fine_accuracy, *, guarded=True):
    """Counterfactuals are available in training only. Cost to go for each seen state."""
    examples = []

    @lru_cache(maxsize=None)
    def visit(state):
        prices = [float("nan")] * len(ACTIONS)
        allowed = admissible(station, state, budget) if guarded else state.available()
        if not allowed:
            return (
                1000  # training loss for an unresolved request, never an online release
            )
        for action in allowed:
            after, value = step(station, state, action, lambda: fine, fine_accuracy)
            remaining = 0 if certify(station, after, value) <= budget else visit(after)
            prices[ACTIONS.index(action)] = COST[action] + remaining
        examples.append((features(station, state, budget, fine_accuracy), prices))
        return min(p for p in prices if np.isfinite(p))

    state = initial(first)
    if certify(station, state, candidate(station, state, "rechteck")) > budget:
        visit(state)
    return examples
