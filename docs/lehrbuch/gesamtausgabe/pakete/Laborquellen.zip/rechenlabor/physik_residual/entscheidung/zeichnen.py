"""Plot published action costs and first-stage certificates from the held-out test set."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent


def write_figure(data, output):
    plt.rcParams.update(
        {
            "font.size": 8.5,
            "font.family": "DejaVu Sans",
            "svg.hashsalt": "argesim-v911-entscheidung",
            "pdf.fonttype": 42,
            "axes.spines.top": False,
            "axes.spines.right": False,
        }
    )
    fig, (left, right) = plt.subplots(1, 2, figsize=(7.1, 2.55))
    fig.subplots_adjust(left=0.16, right=0.97, bottom=0.19, top=0.78, wspace=0.95)
    wells = data["test"]["brunnen"]
    first = data["test"]["erste_saite"]
    colors = ["#53718a", "#00675e", "#a04e30"]
    for ax, labels, values, maximum, title, xlabel in (
        (
            left,
            ["Feste Folge", "Gelernte Wahl", "Intervallregel"],
            [
                wells[key]["mean_cost"]
                for key in ("feste_folge", "gelernt", "intervallregel")
            ],
            25,
            "a   Brunnen",
            "Aktionseinheiten je Anfrage",
        ),
        (
            right,
            ["Nullzeuge", "Gelernter Filter", "Analyt. Filter"],
            [
                first[key]
                for key in (
                    "zero_certified",
                    "corrected_certified",
                    "analytical_certified",
                )
            ],
            220,
            "b   Saite",
            "Freigaben im ersten Versuch",
        ),
    ):
        ax.barh(range(3), values, color=colors, height=0.52)
        ax.set_yticks(range(3), labels=labels)
        ax.invert_yaxis()
        ax.set_xlim(0, maximum)
        ax.set_xlabel(xlabel)
        ax.set_title(title, loc="left", fontweight="bold")
        ax.set_axisbelow(True)
        ax.grid(axis="x", alpha=0.18)
        for i, value in enumerate(values):
            number = f"{value:.2f}".replace(".", ",") if ax is left else str(value)
            ax.text(
                value + 0.024 * maximum, i, number, va="center", ha="left", fontsize=8.2
            )
    output.mkdir(parents=True, exist_ok=True)
    fig.savefig(output / "wahl_und_zeuge.svg", metadata={"Date": None})
    fig.savefig(
        output / "wahl_und_zeuge.pdf", metadata={"CreationDate": None, "ModDate": None}
    )
    plt.close(fig)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    write_figure(json.loads((HERE / "messung/ergebnisse.json").read_text()), args.out)
