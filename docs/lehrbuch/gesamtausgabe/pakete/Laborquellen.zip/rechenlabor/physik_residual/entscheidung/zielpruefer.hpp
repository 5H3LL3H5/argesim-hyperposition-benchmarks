#ifndef ARGESIM_ZIELPRUEFER_HPP
#define ARGESIM_ZIELPRUEFER_HPP

#include <gmpxx.h>
#include <span>
#include <stdexcept>

namespace argesim {

struct Zielintervall {
    mpq_class wert;
    mpq_class radius;
};

// rhs has denominator d*scale. Goal, field and witness each have denominator scale.
// K = I + (m/d) L with the positive, zero-Dirichlet three-point stencil L.
inline Zielintervall pruefe_ziel(const mpz_class& m, const mpz_class& d,
                                const mpz_class& scale, std::span<const mpz_class> rhs,
                                std::span<const mpz_class> goal, std::span<const mpz_class> field,
                                std::span<const mpz_class> witness) {
    const auto n = rhs.size();
    if (m <= 0 || d <= 0 || scale <= 0 || n == 0 || goal.size() != n || field.size() != n || witness.size() != n) {
        throw std::invalid_argument("inkompatibler Rechenauftrag");
    }
    const auto stencil = [n](std::span<const mpz_class> v, std::size_t i) {
        mpz_class laplacian = 2 * v[i];
        if (i > 0) laplacian -= v[i - 1];
        if (i + 1 < n) laplacian -= v[i + 1];
        return laplacian;
    };
    mpz_class max_residual = 0;
    mpz_class sum_dual_defects = 0;
    mpz_class numerator = 0;
    for (std::size_t i = 0; i < n; ++i) {
        const mpz_class r = rhs[i] - d * field[i] - m * stencil(field, i);
        const mpz_class dual_defect = d * (goal[i] - witness[i]) - m * stencil(witness, i);
        const mpz_class magnitude = abs(r);
        if (magnitude > max_residual) max_residual = magnitude;
        sum_dual_defects += abs(dual_defect);
        numerator += d * goal[i] * field[i] + witness[i] * r;
    }
    const mpz_class denom = d * scale * scale;
    mpq_class value(numerator, denom);
    mpq_class radius(max_residual * sum_dual_defects, d * denom);
    value.canonicalize();
    radius.canonicalize();
    return {value, radius};
}

}  // namespace argesim
#endif
