"""Train or run two goal-oriented operators. Usage and experimental contract in README.md."""

import argparse
from collections import Counter
from fractions import Fraction as F
import json
from pathlib import Path
from time import perf_counter

import numpy as np
import aktion as a
import dualer_operator as d

HERE = Path(__file__).resolve().parent
CP_COST = {"grob": 3, "verfeinern": 6, "klassisch": 12}
CP_ACTIONS = ("verfeinern", "klassisch")


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(obj, indent=2, ensure_ascii=False, allow_nan=False) + "\n",
        encoding="utf-8",
    )


def well_cases(split):
    if split == "training":
        sites = (4.8, 4.9, 5.0, 5.1, 5.2, 5.35, 5.5)
        alphas = [F(i, 16) for i in range(1, 16, 2)]
        noise = (F(-1), F(0), F(1))
        budgets = (F(1, 125), F(3, 200))
    else:
        sites = (
            (4.825, 4.925, 5.075, 5.175, 5.275, 5.425)
            if split == "test"
            else (4.55, 5.85)
        )
        alphas = [F(i, 19) for i in range(1, 18, 2)]
        noise = (F(-1), F(-1, 4), F(1))
        budgets = (F(1, 100),)
    fine = F(1, 25) if split == "stress" else a.FINE
    for site in sites:
        station, reference = a.prepare(site, with_reference=True)
        for alpha in alphas:
            for first_noise in noise:
                for late_noise in noise:
                    for budget in budgets:
                        yield (
                            station,
                            reference,
                            alpha,
                            alpha + first_noise * a.COARSE,
                            alpha + late_noise * fine,
                            budget,
                            fine,
                        )


def string_cases(split):
    if split == "training":
        grids = (31, 63)
        mus = (F(1, 8), F(1, 2), F(1), F(2), F(4), F(8), F(16))
        apices = [F(i, 8) for i in range(1, 8)]
        sensors = (F(1, 5), F(1, 2), F(4, 5))
        budgets = (F(1, 100), F(1, 400), F(1, 1500))
    else:
        grids = (79, 159, 499) if split == "test" else (159, 499)
        mus = (
            (F(3, 8), F(5, 8), F(5, 4), F(5, 2), F(5), F(10))
            if split == "test"
            else (F(24), F(48))
        )
        apices = (
            [F(i, 17) for i in (2, 6, 9, 14)]
            if split == "test"
            else [F(1, 29), F(26, 29)]
        )
        sensors = (F(3, 20), F(9, 20), F(17, 20))
        budgets = (F(1, 100), F(1, 500))
    for n in grids:
        for mu in mus:
            for i, apex in enumerate(apices):
                for j, pos in enumerate(sensors):
                    moving, averaged = (i + j) % 2 == 1, j == 1
                    p = d.make_problem(
                        n, mu, apex, pos, moving=moving, averaged=averaged
                    )
                    for budget in budgets:
                        yield (
                            p,
                            budget,
                            (
                                n,
                                str(mu),
                                str(apex),
                                str(pos),
                                moving,
                                averaged,
                                str(budget),
                            ),
                        )


def train():
    examples = []
    unfiltered = []
    totals = Counter()
    well_count = 0
    for station, _, _, first, fine, budget, accuracy in well_cases("training"):
        examples.extend(a.training_labels(station, first, fine, budget, accuracy))
        unfiltered.extend(
            a.training_labels(station, first, fine, budget, accuracy, guarded=False)
        )
        well_count += 1
        for order in a.ORDERS:
            value, _, _, cost = a.execute(
                station,
                first,
                lambda: fine,
                a.fixed(order),
                budget=budget,
                fine_accuracy=accuracy,
                guarded=False,
            )
            totals[order] += cost + 1000 * (value is None)
    policy = a.ActionOperator.fit(examples)
    dual = d.DualOperator.fit()
    witness = d.DualOperator(dual)
    cp_examples = []
    cp_count = 0
    fixed_totals = Counter()
    for p, budget, _ in string_cases("training"):
        cp_count += 1
        coarse = d.trial(p, witness, "grob")
        if coarse.error <= budget:
            continue
        refined = d.trial(p, witness, "verfeinern")
        prices = [
            CP_COST["verfeinern"] + CP_COST["klassisch"] * (refined.error > budget),
            CP_COST["klassisch"],
        ]
        cp_examples.append((d.policy_features(p, coarse, budget), prices))
        fixed_totals.update(dict(zip(CP_ACTIONS, prices, strict=True)))
    return {
        "version": 1,
        "dual": dual,
        "well_policy": policy,
        "unfiltered_well_policy": a.ActionOperator.fit(unfiltered),
        "string_policy": a.ActionOperator.fit(cp_examples),
        "fixed_orders": {
            "well": list(min(a.ORDERS, key=lambda order: totals[order])),
            "string": min(CP_ACTIONS, key=lambda act: fixed_totals[act]),
        },
        "training": {
            "well_cases": well_count,
            "well_state_examples": len(examples),
            "unfiltered_well_state_examples": len(unfiltered),
            "string_cases": cp_count,
            "string_state_examples": len(cp_examples),
            "seed": 2411,
        },
    }


def classical_well(station, first, callback, budget, fine_accuracy):
    state = a.initial(first)
    path = []
    cost = 1
    while True:
        value = a.candidate(station, state, "klassisch")
        bound = a.certify(station, state, value)
        path.append("klassisch")
        cost += a.COST["klassisch"]
        if bound <= budget:
            return value, bound, path, cost
        if state.measured:
            return None, None, path, cost
        state = a.State(
            a.brunnen.observe(state.interval, callback(), fine_accuracy), True
        )
        path.append("messen")
        cost += a.COST["messen"] - 2  # no extra rectangle and check here


def recording(value, bound, path, cost, truth, budget):
    if value is None:
        return {
            "released": False,
            "value": None,
            "bound": None,
            "path": path,
            "cost": cost,
            "score": None,
            "error": None,
            "false_release": False,
        }
    error = abs(float(value) - truth)
    safe = float(bound)
    assert bound <= budget and error <= safe + 5e-10 * max(1, abs(truth)), (error, safe)
    return {
        "released": True,
        "value": str(value),
        "bound": str(bound),
        "path": path,
        "cost": cost,
        "score": float(bound / budget),
        "error": error,
        "false_release": error > float(budget) + 5e-10 * max(1, abs(truth)),
    }


def evaluate_well(model, split):
    policy = a.ActionOperator(model["well_policy"])
    unfiltered = a.ActionOperator(model["unfiltered_well_policy"])
    order = a.fixed(tuple(model["fixed_orders"]["well"]))
    rows = []
    for s, reference, alpha, first, late, budget, accuracy in well_cases(split):
        modes = {
            "gelernt": policy.choose,
            "ohne_intervallfilter": unfiltered.choose,
            "feste_folge": order,
            "intervallregel": a.heuristic,
            "klassisch": None,
        }
        row = {
            "x": s.position,
            "alpha": str(alpha),
            "coarse": str(first),
            "fine": str(late),
            "budget": str(budget),
            "methods": {},
        }
        for name, chooser in modes.items():
            reads = []

            def read():
                if reads:
                    raise RuntimeError("second meter read twice")
                reads.append(True)
                return late

            if chooser is None:
                value, bound, path, cost = classical_well(
                    s, first, read, budget, accuracy
                )
            else:
                value, bound, path, cost = a.execute(
                    s,
                    first,
                    read,
                    chooser,
                    budget=budget,
                    fine_accuracy=accuracy,
                    guarded=name in ("gelernt", "intervallregel"),
                )
            # The Green quadrature and hidden alpha are used only after the policy returns.
            truth = float(alpha) * reference[0] + (1 - float(alpha)) * reference[1]
            assert path.count("messen") == len(reads)
            if value is not None:
                error = abs(float(value) / truth - 1)
                assert error <= float(bound) + 1e-12 and bound <= budget
                rec = {
                    "released": True,
                    "score": float(bound / budget),
                    "error": error,
                    "false_release": bool(error > float(budget) + 1e-12),
                }
            else:
                rec = {
                    "released": False,
                    "score": None,
                    "error": None,
                    "false_release": False,
                }
            if name == "gelernt" and value is None:
                possible = (
                    a.brunnen.observe(a.initial(first).interval, late, accuracy)
                    if reads
                    else a.initial(first).interval
                )
                rec["ambiguity_proved"] = (
                    a.brunnen.witness_radius(possible, s.blocks) > budget
                )
            rec.update(
                path=path,
                cost=cost,
                value=str(value) if value is not None else None,
                bound=str(bound) if bound is not None else None,
            )
            row["reference"] = float(truth)
            row["methods"][name] = rec
        rows.append(row)
    return rows


def learned_string(model):
    net = a.ActionOperator(model["string_policy"])

    def choose(problem, result, budget):
        costs = net.prices(d.policy_features(problem, result, budget))
        return CP_ACTIONS[int(np.argmin(costs))]

    return choose


def evaluate_string(model, split):
    witness = d.DualOperator(model["dual"])
    choose = learned_string(model)
    rows = []
    for problem, budget, params in string_cases(split):
        methods = {}
        proposals = {}
        costs = {}
        path_by_name = {}
        for name, rule, zero in [
            ("gelernt", choose, False),
            ("feste_folge", lambda *_: model["fixed_orders"]["string"], False),
            ("direkt_nach_grob", lambda *_: "klassisch", False),
            ("ohne_zeugen", lambda *_: "verfeinern", True),
        ]:
            result, path, coarse = d.solve(
                problem, witness, rule, budget=budget, no_witness=zero
            )
            proposals[name] = result
            path_by_name[name] = path
            costs[name] = sum(CP_COST[act] for act in path)
            if name == "gelernt":
                initial = coarse
        analytical, analytical_path, analytical_coarse = d.solve(
            problem,
            d.AnalyticalDual(),
            lambda *_: model["fixed_orders"]["string"],
            budget=budget,
        )
        proposals["analytischer_zeuge"] = analytical
        path_by_name["analytischer_zeuge"] = analytical_path
        costs["analytischer_zeuge"] = sum(CP_COST[action] for action in analytical_path)
        direct = d.trial(problem, witness, "klassisch")
        proposals["klassisch"] = direct if direct.error <= budget else None
        path_by_name["klassisch"] = ["klassisch"]
        costs["klassisch"] = CP_COST["klassisch"]
        ref = d.reference(problem)
        assert abs(float(initial.raw_value) - ref) <= float(initial.raw_bound) + 2e-10
        assert abs(float(initial.value) - ref) <= float(initial.error) + 2e-10
        for name, item in proposals.items():
            methods[name] = recording(
                item.value if item else None,
                item.error if item else None,
                path_by_name[name],
                costs[name],
                ref,
                budget,
            )
        rows.append(
            {
                "parameters": params,
                "reference": ref,
                "coarse_zero_bound": float(initial.zero_bound),
                "coarse_witness_bound": float(initial.error),
                "raw_certified": bool(initial.raw_bound <= budget),
                "corrected_certified": bool(initial.error <= budget),
                "zero_certified": bool(initial.zero_bound <= budget),
                "analytical_certified": bool(analytical_coarse.error <= budget),
                "methods": methods,
            }
        )
    return rows


def summarize(rows):
    result = {}
    for method in rows[0]["methods"]:
        records = [r["methods"][method] for r in rows]
        passing = [r for r in records if r["released"]]
        success = len(passing)
        cost = sum(r["cost"] for r in records)
        acts = Counter(act for r in records for act in r["path"])
        result[method] = {
            "cases": len(records),
            "released": success,
            "unresolved": len(records) - success,
            "ambiguity_proved": sum(r.get("ambiguity_proved", False) for r in records)
            if method == "gelernt"
            else None,
            "false_releases": sum(r["false_release"] for r in records),
            "actions": dict(acts),
            "mean_cost": cost / len(records),
            "cost_per_success": cost / success if success else None,
            "max_score": max((r["score"] for r in passing), default=None),
            "max_error": max((r["error"] for r in passing), default=None),
        }
    return result


def timings(model):
    from statistics import median

    witness = d.DualOperator(model["dual"])
    choose = learned_string(model)
    well = a.ActionOperator(model["well_policy"])
    # Both methods see the same deterministic subset, prepared input and stored models.
    string_list = list(string_cases("test"))[::17]
    wells = list(well_cases("test"))[::17]

    def sh():
        for p, b, _ in string_list:
            d.solve(p, witness, choose, budget=b)

    def sc():
        for p, b, _ in string_list:
            cert = d.trial(p, witness, "klassisch")
            assert cert.error <= b

    def wh():
        for s, _, _, f, last, b, acc in wells:
            a.execute(s, f, lambda: last, well.choose, budget=b, fine_accuracy=acc)

    def wc():
        for s, _, _, f, last, b, acc in wells:
            classical_well(s, f, lambda: last, b, acc)

    times = {}
    for name, fn, n in [
        ("saite_hybrid", sh, len(string_list)),
        ("saite_klassisch", sc, len(string_list)),
        ("brunnen_hybrid", wh, len(wells)),
        ("brunnen_klassisch", wc, len(wells)),
    ]:
        fn()
        latency = []
        for _ in range(5):
            begin = perf_counter()
            fn()
            latency.append((perf_counter() - begin) * 1000 / n)
        times[name] = {
            "cases": n,
            "samples_ms_per_request": latency,
            "median_ms_per_request": median(latency),
        }
    return times


def evaluate(model, out, runtime=False):
    if model.get("version") != 1:
        raise ValueError("unsupported model version")
    summary = {"training": model["training"], "baselines": model["fixed_orders"]}
    raw = {}
    for split in ("test", "stress"):
        raw[split] = {}
        summary[split] = {}
        for name, evaluator in [("brunnen", evaluate_well), ("saite", evaluate_string)]:
            rows = evaluator(model, split)
            summary[split][name] = summarize(rows)
            raw[split][name] = rows
            if name == "saite":
                summary[split]["erste_saite"] = {
                    key: sum(r[key] for r in rows)
                    for key in (
                        "zero_certified",
                        "raw_certified",
                        "corrected_certified",
                        "analytical_certified",
                    )
                }
            assert all(x["false_releases"] == 0 for x in summary[split][name].values())
    dump(out / "ergebnisse.json", summary)
    dump(out / "einzellaeufe.json", raw)
    if runtime:
        dump(out / "laufzeiten.json", timings(model))
    return summary


class MeasurementRequested(Exception):
    """The first observation has been exhausted and a second reading is required."""


def single(args, model):
    if args.cmd == "brunnen":
        station, _ = a.prepare(args.ort)

        def read():
            if args.fein is None:
                raise MeasurementRequested()
            return args.fein

        try:
            value, bound, path, cost = a.execute(
                station,
                args.grob,
                read,
                a.ActionOperator(model["well_policy"]).choose,
                budget=args.budget,
                fine_accuracy=args.fehler_fein,
            )
        except MeasurementRequested:
            return {
                "status": "zweite Ablesung erforderlich",
                "fehlergrenze_anteil": str(args.fehler_fein),
            }
        return {
            "status": "freigegeben" if value is not None else "offen",
            "wert": float(value) if value is not None else None,
            "relative_fehlergrenze": float(bound) if bound is not None else None,
            "folge": path,
            "aufwandseinheiten": cost,
        }
    p = d.make_problem(
        args.knoten - 2,
        args.mu,
        args.zupfstelle,
        args.sensor,
        moving=args.bewegt,
        averaged=args.gemittelt,
    )
    result, path, _ = d.solve(
        p, d.DualOperator(model["dual"]), learned_string(model), budget=args.budget
    )
    return {
        "status": "freigegeben" if result is not None else "offen",
        "wert": float(result.value) if result is not None else None,
        "absolute_fehlergrenze": float(result.error) if result is not None else None,
        "folge": path,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest="cmd", required=True)
    training = actions.add_parser("trainieren")
    training.add_argument("--modell", type=Path, required=True)
    training.add_argument(
        "--zeitdatei",
        type=Path,
        help="separate Zeitmessung für Datenaufbereitung, Baselinewahl und Training",
    )
    evaluation = actions.add_parser("pruefen")
    evaluation.add_argument("--modell", type=Path, default=HERE / "messung/modell.json")
    evaluation.add_argument("--out", type=Path, required=True)
    evaluation.add_argument("--mit-zeiten", action="store_true")
    well = actions.add_parser("brunnen", help="einen Brunnenwert abnehmen")
    well.add_argument("--ort", type=float, required=True)
    well.add_argument("--grob", type=F, required=True)
    well.add_argument("--fein", type=F)
    well.add_argument("--fehler-fein", type=F, default=a.FINE)
    string = actions.add_parser("saite", help="einen Newmark-Sensorwert abnehmen")
    string.add_argument(
        "--knoten", type=int, required=True, help="einschließlich beider Endpunkte"
    )
    string.add_argument("--mu", type=F, required=True)
    string.add_argument("--zupfstelle", type=F, required=True)
    string.add_argument("--sensor", type=F, required=True)
    string.add_argument("--bewegt", action="store_true")
    string.add_argument("--gemittelt", action="store_true")
    for command in (well, string):
        command.add_argument(
            "--modell", type=Path, default=HERE / "messung/modell.json"
        )
        command.add_argument("--budget", type=F, default=F(1, 100))
    args = parser.parse_args()
    if args.cmd in ("brunnen", "saite"):
        print(
            json.dumps(
                single(args, json.loads(args.modell.read_text())),
                ensure_ascii=False,
                indent=2,
            )
        )
        return
    if args.cmd == "trainieren":
        start = perf_counter()
        model = train()
        elapsed = perf_counter() - start
        dump(args.modell, model)
        if args.zeitdatei:
            import os
            import platform
            import scipy

            dump(
                args.zeitdatei,
                {
                    "train_and_reference_seconds": elapsed,
                    "python": platform.python_version(),
                    "platform": platform.machine(),
                    "numpy": np.__version__,
                    "scipy": scipy.__version__,
                    "openblas_threads": os.environ.get("OPENBLAS_NUM_THREADS"),
                },
            )
        print("Training", model["training"])
    else:
        model = json.loads(args.modell.read_text())
        report = evaluate(model, args.out, args.mit_zeiten)
        for split in ("test", "stress"):
            print(
                split,
                [
                    (
                        task,
                        report[split][task]["gelernt"]["released"],
                        report[split][task]["gelernt"]["cases"],
                    )
                    for task in ("brunnen", "saite")
                ],
            )


if __name__ == "__main__":
    main()
