"""Draw the two figures of the hybrid acceptance experiment from its recorded data."""

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TEAL, BLUE, RUST = "#00675e", "#496781", "#a34f2c"


def finish(fig, name):
    formatter = FuncFormatter(lambda v, _: f"{v:g}".replace(".", ","))
    for ax in fig.axes:
        ax.yaxis.set_major_formatter(formatter)
        if name.endswith("brunnen"):
            ax.xaxis.set_major_formatter(formatter)
    fig.savefig(ROOT / f"abbildungen/{name}.svg", metadata={"Date": None})
    fig.savefig(
        ROOT / f"druck/{name}.pdf", metadata={"CreationDate": None, "ModDate": None}
    )
    plt.close(fig)


def cavity(data):
    fig, axes = plt.subplots(1, 2, figsize=(7, 2.35))
    fig.subplots_adjust(left=0.09, right=0.99, bottom=0.17, top=0.71, wspace=0.38)
    categories = ("D2Q9", "affine", "fourier")
    x = np.arange(len(categories))
    settings = (
        ("raw", "Eingang", BLUE),
        ("flux", "Flussprojektion", RUST),
        ("joint", "Fluss und Wand", TEAL),
    )
    for i, (key, name, color) in enumerate(settings):
        rows = [data["fields"][kind][key] for kind in categories]
        axes[0].bar(
            x + (i - 1) * 0.23,
            [100 * r["relative_core"] for r in rows],
            0.22,
            label=name,
            color=color,
        )
        axes[1].bar(
            x + (i - 1) * 0.23, [r["wall_max"] for r in rows], 0.22, color=color
        )
    for axis in axes:
        axis.set_xticks(x, ["D2Q9", "Affin", "Fourier"])
        axis.grid(axis="y", color="#dce6e6", alpha=0.8)
        axis.set_axisbelow(True)
    axes[0].set(
        ylabel="Relativer Fehler (%)", title="a   Innenfeld gegen D2Q9", ylim=(0, 2.5)
    )
    axes[1].set(
        ylabel="Anteil des Deckeltempos", title="b   Größter Wanddefekt", ylim=(0, 0.42)
    )
    fig.legend(
        *axes[0].get_legend_handles_labels(), loc="upper center", ncol=3, frameon=False
    )
    finish(fig, "hybrid_kavitaet")


def sensor(data):
    fig, axes = plt.subplots(1, 2, sharey=True, figsize=(7, 2.4))
    fig.subplots_adjust(left=0.09, right=0.98, bottom=0.22, top=0.71, wspace=0.2)
    z = np.linspace(0, 1, 201)
    for ax, well in zip(axes, data["wells"], strict=True):
        low, high = (
            np.array(well["lower_pulse_responses"]),
            np.array(well["upper_pulse_responses"]),
        )
        for eps, label, color in (
            (0.08, "Grobes Messgerät", BLUE),
            (0.006, "Feines Messgerät", TEAL),
        ):
            a, b = np.maximum(0, z - eps), np.minimum(1, z + eps)
            lo = np.minimum(
                low[0] * a + low[1] * (1 - a), low[0] * b + low[1] * (1 - b)
            )
            hi = np.maximum(
                high[0] * a + high[1] * (1 - a), high[0] * b + high[1] * (1 - b)
            )
            ax.plot(z, 100 * (hi - lo) / (hi + lo), color=color, lw=2, label=label)
        ax.axhline(1, color=RUST, ls="--", lw=1, label="1-%-Budget")
        ax.set_title(f"Brunnen bei {well['well_x']:g} m".replace(".", ","))
        ax.set(xlim=(0, 1), ylim=(0, 6.4), xlabel="Angezeigter Anteil der Gesamtmasse")
        ax.grid(axis="y", color="#dce6e6")
    axes[0].set_ylabel("Relativer Fehlerradius (%)")
    fig.legend(
        *axes[0].get_legend_handles_labels(), loc="upper center", ncol=3, frameon=False
    )
    finish(fig, "hybrid_brunnen")


if __name__ == "__main__":
    plt.rcParams.update(
        {
            "font.size": 8,
            "font.family": "DejaVu Sans",
            "svg.hashsalt": "argesim-hybrid-2026",
            "pdf.fonttype": 42,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "axes.formatter.use_locale": False,
        }
    )
    data = json.loads((HERE / "messung/physik_residual.json").read_text())
    cavity(data["cp2"])
    sensor(data["c19r"])
