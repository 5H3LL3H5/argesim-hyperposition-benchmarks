#include <array>
#include <cassert>
#include <span>

void rhs(double, std::span<const double, 1> y,
         std::span<double, 1> rate) { rate[0] = -2.0 * y[0]; }

int main() {
    std::array<double, 1> y{0.5}, rate{};
    rhs(0.25, y, rate);
    assert(rate[0] == -1.0 && y[0] == 0.5);
}
