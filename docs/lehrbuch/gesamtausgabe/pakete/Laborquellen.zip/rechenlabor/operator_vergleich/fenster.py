"""Spectral features on known windows, with a fixed readout for all seven families."""

from dataclasses import dataclass

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from scipy.optimize import minimize
import torch

from fourier_layer import forward, objective
from hybrid_operator import (
    fourier_bands,
    haar_bands,
    hankel_bands,
    mellin_bands,
    radon_bands,
)


SPATIAL_TRANSFORMS = {
    "fourier": fourier_bands,
    "wavelet": haar_bands,
    "hankel": hankel_bands,
    "radon": radon_bands,
    "fourier_mellin": mellin_bands,
}


def readout_positions(size, count):
    if size <= count:
        return np.arange(size)
    relative = 1.0 - np.linspace(1.0, 0.0, count) ** 2
    return np.unique(np.rint(relative * (size - 1)).astype(int))


def laplace_weights(size):
    # A sample at s_j enters the physical history from s_j onwards.
    times = np.linspace(0.0, 1.0, size)
    weights = np.exp((-2.0 + 5j) * (1.0 - times)) / (size - 1)
    weights[[0, -1]] *= 0.5
    return np.cumsum(weights[::-1])[::-1]


def dictionary(kind, window, points):
    """Encode every input impulse and keep the same evaluation positions per band."""
    if window < 3 or points < 1:
        raise ValueError("need at least three input points and one readout")
    time_basis = torch.eye(window, dtype=torch.float64)[:, None, :]
    if kind in ("laplace", "wavelet_laplace"):
        weights = laplace_weights(window)
        real = time_basis * torch.from_numpy(weights.real.copy())
        imaginary = time_basis * torch.from_numpy(weights.imag.copy())
        if kind == "laplace":
            bands = [time_basis, real, imaginary]
        else:
            low, medium, high = haar_bands(time_basis)
            bands = [low, medium + haar_bands(real)[0], high + haar_bands(imaginary)[0]]
    else:
        bands = SPATIAL_TRANSFORMS[kind](time_basis)
    select = readout_positions(window, points)
    return torch.cat([field[:, 0, select] for field in bands], dim=-1).numpy()


def history_windows(signal, samples):
    """Do not expose anything after the current sample."""
    return sliding_window_view(np.pad(signal, (samples - 1, 0), mode="edge"), samples)


def encode(path, basis):
    return np.einsum("btc,tk->bck", path, basis).reshape(len(path), -1)


@dataclass(frozen=True)
class WindowOperator:
    basis: np.ndarray
    mean: np.ndarray
    scale: np.ndarray
    target_mean: np.ndarray
    target_scale: np.ndarray
    weights: np.ndarray
    width: int

    def predict(self, path):
        values = encode(path, self.basis)
        values = (values - self.mean) / self.scale
        design = np.column_stack((values, np.ones(len(values))))
        estimate, _, _ = forward(
            self.weights, design, len(self.target_mean), self.width
        )
        return self.target_mean + self.target_scale * estimate


def train_window(basis, paths, target, seed, width=10, penalty=2e-5, iterations=600):
    features = encode(paths, basis)
    mean = features.mean(axis=0)
    scale = np.maximum(features.std(axis=0), 1e-10)
    design = np.column_stack(((features - mean) / scale, np.ones(len(features))))
    target_mean = target.mean(axis=0)
    target_scale = np.maximum(target.std(axis=0), 1e-12)
    labels = (target - target_mean) / target_scale
    rng = np.random.default_rng(seed)
    size = width * (design.shape[1] + labels.shape[1]) + labels.shape[1]
    candidates = [
        minimize(
            objective,
            rng.normal(0, 0.15, size),
            args=(design, labels, width, penalty),
            jac=True,
            method="L-BFGS-B",
            options={"maxiter": iterations, "ftol": 1e-11},
        )
        for _ in range(2)
    ]
    valid = [
        candidate
        for candidate in candidates
        if np.isfinite(candidate.x).all() and np.isfinite(candidate.fun)
    ]
    if not valid:
        raise ArithmeticError("no finite window fit")
    chosen = min(valid, key=lambda candidate: candidate.fun)
    model = WindowOperator(
        basis, mean, scale, target_mean, target_scale, chosen.x, width
    )
    record = {
        "parameters": int(model.weights.size),
        "iterations": int(chosen.nit),
        "stop": str(chosen.message),
        "converged": bool(chosen.success),
        "loss": float(chosen.fun),
    }
    return model, record


def model_arrays(name, model):
    return {f"{name}_{key}": value for key, value in vars(model).items()}
