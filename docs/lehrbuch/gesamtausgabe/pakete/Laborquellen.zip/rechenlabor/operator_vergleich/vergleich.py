"""Run all ten ARGESIM tasks with the seven operator families."""

import argparse
import csv
from hashlib import sha256
import json
from pathlib import Path
import platform
import sys

import numpy as np
import scipy
import torch


LOCAL = Path(__file__).resolve().parent
LAB = LOCAL.parent
for sibling in ("fno_transfer", "fno_benchmarks", "cp2_operatoren"):
    sys.path.insert(0, str(LAB / sibling))


from cp2_lbm_cavity_surrogate import run as cavity_study  # noqa: E402
from cp2_saite_benchmark import run as rope_study  # noqa: E402
from hybrid_operator import TRANSFORMS  # noqa: E402

import ereignisse_und_kraft as events  # noqa: E402
import felder as fields  # noqa: E402
import lineare_antworten as linear  # noqa: E402


SPECS = ("C05", "C07", "C09", "C13", "C15", "C18", "C19R", "CP1/C", "CP2/2", "CP2/3")


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def archive_input():
    transfer = LAB / "fno_transfer/messung"
    old = LAB / "fno_benchmarks/messung"
    return (
        read(transfer / "transfer.json")["cases"],
        read(old / "vergleich.json"),
        transfer,
        old,
    )


def rope_case(data):
    details = {}
    for kind, result in data["methods"].items():
        main = result["ideal_error"]
        details[kind] = {
            "accepted": result["ideal_accepted"],
            "count": len(main),
            "maximum": max(map(max, main)) / 0.01,
            "relative_error": main,
            "dispersive_accepted": result["dispersion_accepted"],
            "dispersion_error": result["dispersion_error"],
            "mirror_ideal": result["ideal_mirror"],
            "mirror_dispersive": result["dispersive_mirror"],
            "parameters": result["parameter_count"],
            "fit_seconds": result["fit_seconds"],
            "non_smooth": result["non_smooth"],
            "inference": result["inference"],
        }
    return {
        "methods": details,
        "tests": 5,
        "contract": "Fixed-end wave, displacement at 5 and 8 s on 501 nodes",
        "controls": data["classical"] | {"exact_dalembert": data["analytic"]},
    }


def cavity_case(data):
    titles = list(data["classical"])
    details = {}
    for kind, result in data["methods"].items():
        primary = result["comparisons"]["421"]
        details[kind] = {
            "accepted": primary["accepted"],
            "count": len(primary["cases"]),
            "maximum": primary["score_max"],
            "parameters": result["head_parameters"],
            "fit_seconds": result["seconds_fit"],
            "groups": result["comparisons"],
            "few_shot": result["few_shot"],
            "inference": result["inference"],
        }
    return {
        "methods": details,
        "tests": 2,
        "validation_groups": titles,
        "contract": "Uncalibrated Re=100 on 421² for the headline; all groups and calibrated cases in the detailed report",
        "controls": {"affine": data["affine"], "d2q9": data["classical"]},
    }


def matrix_rows(case, method, values):
    if case == "C18":
        return [
            (case, variant, method, None, None, None, values[variant]["rmse"])
            for variant in ("direct", "arx_residual")
        ]
    if case == "CP2/2":
        return [
            (
                case,
                name,
                method,
                group["accepted"],
                len(group["cases"]),
                group["score_max"],
                None,
            )
            for name, group in values["groups"].items()
        ]
    variants = {"main": values}
    if case in ("C13", "C15"):
        variants = {
            "reduced_readout": values,
            "complete_readout": values["complete_readout"],
        }
    if case == "C07":
        variants = {"midpoint": values, "euler": values["euler"]}
    if case == "CP1/C":
        variants["novel_frequency"] = values["novel_frequency"]
    if case == "CP2/3":
        variants["dispersive"] = {
            "accepted": values["dispersive_accepted"],
            "count": values["count"],
            "maximum": max(map(max, values["dispersion_error"])) / 0.01,
        }
    return [
        (
            case,
            name,
            method,
            detail["accepted"],
            detail["count"],
            detail["maximum"],
            None,
        )
        for name, detail in variants.items()
    ]


def export_matrix(output, runs):
    temporary = output / "operator_matrix.csv.tmp"
    with temporary.open("w", newline="", encoding="utf-8") as stream:
        rows = csv.writer(stream)
        rows.writerow(
            ("case", "variant", "operator", "accepted", "total", "score_max", "rmse")
        )
        for case, result in runs.items():
            for method, detail in result["methods"].items():
                rows.writerows(matrix_rows(case, method, detail))
    temporary.replace(output / "operator_matrix.csv")


def complete(output, selected, cp2_result=None):
    torch.set_num_threads(1)
    output.mkdir(parents=True, exist_ok=True)
    transfer, old, transfer_dir, prior = archive_input()
    runs = {}
    tasks = {
        "C05": lambda: events.c05(output, transfer, TRANSFORMS),
        "C07": lambda: events.c07(output, transfer, transfer_dir, TRANSFORMS),
        "C09": lambda: events.c09(output, transfer, transfer_dir, TRANSFORMS),
        "C13": lambda: linear.run(output, "c13", transfer, TRANSFORMS),
        "C15": lambda: linear.run(output, "c15", transfer, TRANSFORMS),
        "C18": lambda: events.muscle(output, old, TRANSFORMS),
        "C19R": lambda: fields.c19(output, old, prior, TRANSFORMS),
        "CP1/C": lambda: fields.cp1(output, transfer, transfer_dir, TRANSFORMS),
    }
    if cp2_result is None:
        device = torch.device("cpu")
        home = output / "cp2"
        tasks["CP2/2"] = lambda: cavity_case(
            cavity_study(home, device, reference=LAB / "cp2_operatoren/messung")
        )
        tasks["CP2/3"] = lambda: rope_case(rope_study(home, device))
    else:
        tasks["CP2/2"] = lambda: cavity_case(
            read(cp2_result / "kavitaet_operatoren.json")
        )
        tasks["CP2/3"] = lambda: rope_case(read(cp2_result / "saite_operatoren.json"))
    for case in selected:
        print(f"{case} läuft", flush=True)
        outcome = tasks[case]()
        assert list(outcome["methods"]) == list(TRANSFORMS)
        runs[case] = outcome
        labels = []
        for model, values in outcome["methods"].items():
            if case == "C18":
                detail = f"{values['direct']['rmse']:.5f} RMSE"
            else:
                score = values["maximum"]
                detail = (
                    f"{values['accepted']}/{values['count']} S={score:.4g}"
                    if score is not None
                    else "keine vergleichbare Folge"
                )
            labels.append(f"{model}: {detail}")
        print(" · ".join(labels), flush=True)
    data_hashes = {
        path.relative_to(LAB).as_posix(): sha256(path.read_bytes()).hexdigest()
        for path in (
            transfer_dir / "transfer.json",
            prior / "vergleich.json",
            LAB / "cp2_operatoren/messung/saite_operatoren.json",
            LAB / "cp2_operatoren/messung/kavitaet_operatoren.json",
        )
    }
    manifest = {
        "cases": runs,
        "operator_count": len(TRANSFORMS),
        "combinations": sum(len(c["methods"]) for c in runs.values()),
        "operator_names": TRANSFORMS,
        "source_evidence_sha256": data_hashes,
        "runtime": {
            "python": platform.python_version(),
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "torch": torch.__version__,
            "cpu_threads": torch.get_num_threads(),
            "cuda_available": torch.cuda.is_available(),
        },
    }
    staging = output / "operator_vergleich.json.tmp"
    staging.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    staging.replace(output / "operator_vergleich.json")
    export_matrix(output, runs)
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument(
        "--case", action="append", choices=SPECS, help="repeat for a subset of cases"
    )
    parser.add_argument(
        "--cp2-results",
        type=Path,
        help="use CP2 reports produced by the two lab scripts in another process",
    )
    args = parser.parse_args()
    complete(args.out, dict.fromkeys(args.case or SPECS), args.cp2_results)


if __name__ == "__main__":
    main()
