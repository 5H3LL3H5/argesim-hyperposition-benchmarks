"""C13 and C15 with one learned causal convolution per transformation family."""

from time import perf_counter

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view
from scipy.linalg import svd

import linear as reference
from fenster import dictionary
from fourier_layer import HistoryFNO, max_normalized, median_ms, scores


def histories(values):
    steps = values.shape[1]
    prior = np.pad(values, ((0, 0), (steps - 1, 0)), mode="constant")
    return sliding_window_view(prior, steps, axis=1)


def fit_filter(train, targets, basis):
    lifted = histories(train) @ basis
    design = lifted.reshape(-1, lifted.shape[-1])
    normalizer = np.maximum(np.linalg.norm(design, axis=0), 1e-12)
    coefficient, _, rank, _ = np.linalg.lstsq(
        design / normalizer,
        targets.reshape(len(design), -1),
        rcond=1e-10,
    )
    past_to_now = basis @ (coefficient / normalizer[:, None])
    return (
        HistoryFNO(past_to_now[::-1].copy()),
        int(rank),
        len(coefficient),
        coefficient,
    )


def fit_complete_readout(history_gram, history_target, basis):
    """Solve the training least squares in an orthogonal basis of the readout."""
    column_scale = np.maximum(np.linalg.norm(basis, axis=0), 1e-15)
    image, singular, _ = svd(basis / column_scale, full_matrices=False)
    rank = int(np.sum(singular > 1e-11 * singular[0]))
    image = image[:, :rank]
    projected = image.T @ history_gram @ image
    coefficients = np.linalg.solve(projected, image.T @ history_target)
    causal = (image @ coefficients)[::-1].copy()
    return HistoryFNO(causal), rank


def run(output, case, transfer, transforms):
    setup = perf_counter()
    if case == "c13":
        (
            train,
            forcing,
            expected,
            offset,
            budget,
            advance,
            response,
            step,
            specs,
            terminal,
        ) = reference.c13_problem()
    else:
        train, forcing, expected, offset, budget, advance, response, step, specs = (
            reference.c15_problem()
        )
    train_output = reference.rollout(advance, response, train)
    raw_history = histories(train).reshape(-1, train.shape[1]).copy()
    history_gram = raw_history.T @ raw_history
    history_target = raw_history.T @ train_output.reshape(len(raw_history), -1)
    data_seconds = perf_counter() - setup
    changed = forcing.copy()
    split = forcing.shape[1] // 2
    changed[:, split:] += 0.17
    methods, predicted, model_parameters = {}, {}, {}
    for kind in transforms:
        fit_started = perf_counter()
        basis = dictionary(kind, forcing.shape[1], 32)
        model, rank, parameter_count, coefficient = fit_filter(
            train, train_output, basis
        )
        weights = model.spectrum()
        fit_seconds = perf_counter() - fit_started

        def predict(inputs):
            return offset + model.predict(inputs, weights)

        estimate = predict(forcing)
        assert np.allclose(
            predict(changed)[:, :split], estimate[:, :split], rtol=1e-10, atol=1e-9
        )
        stats = scores(max_normalized(estimate, expected, budget))
        stats.update(
            {
                "batch_ms": median_ms(lambda: predict(forcing), 3),
                "fit_seconds": fit_seconds,
                "rank": rank,
                "parameters": parameter_count * expected.shape[-1],
                "causal_prefix_samples": split,
            }
        )
        if case == "c13":
            terminal_difference = (estimate[:, -1] - expected[:, -1]) @ terminal.T
            stats["terminal_load_max_m"] = float(
                np.max(np.abs(terminal_difference @ [1, 0, 5, 0, 0]))
            )
        else:
            stats["minimum_state"] = float(estimate.min())
            stats["concentration_max_abs"] = float(
                np.max(np.abs(estimate[:, :, 0] - expected[:, :, 0])) / 7.3
            )
        expanded_started = perf_counter()
        complete_basis = dictionary(kind, forcing.shape[1], forcing.shape[1])
        expanded, full_rank = fit_complete_readout(
            history_gram, history_target, complete_basis
        )
        full_spectrum = expanded.spectrum()
        expanded_seconds = perf_counter() - expanded_started

        def predict_complete(inputs):
            return offset + expanded.predict(inputs, full_spectrum)

        expanded_field = predict_complete(forcing)
        assert np.allclose(
            predict_complete(changed)[:, :split],
            expanded_field[:, :split],
            rtol=1e-10,
            atol=1e-9,
        )
        stats["complete_readout"] = scores(
            max_normalized(expanded_field, expected, budget)
        ) | {
            "rank": full_rank,
            "fit_seconds": expanded_seconds,
            "batch_ms": median_ms(lambda: predict_complete(forcing), 3),
            "parameters": full_rank * expected.shape[-1],
            "positions_per_band": forcing.shape[1],
        }
        predicted[f"complete_{kind}"] = expanded_field
        model_parameters[f"complete_kernel_{kind}"] = expanded.kernel
        methods[kind] = stats
        predicted[kind] = estimate
        model_parameters[f"kernel_{kind}"] = model.kernel
        model_parameters[f"readout_{kind}"] = coefficient
    np.savez_compressed(
        output / f"{case}.npz",
        reference=expected,
        forcing=forcing,
        time=np.arange(1, forcing.shape[1] + 1) * step,
        **predicted,
        **model_parameters,
    )
    return {
        "methods": methods,
        "training_seconds": data_seconds,
        "training_inputs": len(train),
        "tests": len(forcing),
        "budget": budget.tolist(),
        "test_conditions": specs,
        "contract": transfer[case]["scope"],
        "controls": {
            name: transfer[case]["methods"][name]
            for name in ("matrix_step", "physics_fft", "fno_full", "fno_cut")
        },
    }
