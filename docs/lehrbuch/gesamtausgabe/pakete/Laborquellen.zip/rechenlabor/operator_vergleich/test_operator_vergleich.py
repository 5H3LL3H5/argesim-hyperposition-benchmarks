"""Check reuse of the seven v9.6 transforms and the two reduced fitters."""

import numpy as np
import torch

from vergleich import TRANSFORMS
from fenster import dictionary, encode, readout_positions
from felder import mix_fit
from hybrid_operator import HybridNeuralOperator
from lineare_antworten import fit_complete_readout, fit_filter, histories


def test_dictionary():
    rng = np.random.default_rng(1970)
    for n in (5, 17, 64):
        signal = rng.normal(size=(3, n))
        known = np.tri(n, dtype=float)
        history = torch.from_numpy((signal[:, None, :] * known[None])[:, :, None, :])
        times = torch.linspace(0, 1, n, dtype=torch.float64)
        controls = torch.ones((len(signal), 1), dtype=torch.float64)
        indexes = readout_positions(n, 8)
        for transform in TRANSFORMS:
            direct = HybridNeuralOperator(transform, 1, 1).features(
                history, times, controls
            )
            expected = direct[:, :, indexes].numpy().reshape(len(signal), -1)
            reduced = encode(signal[:, :, None], dictionary(transform, n, 8))
            np.testing.assert_allclose(reduced, expected, rtol=1e-12, atol=5e-13)


def test_filter():
    rng = np.random.default_rng(953)
    wave = rng.normal(size=(9, 48))
    for kind in TRANSFORMS:
        features = dictionary(kind, wave.shape[-1], 18)
        weights = rng.normal(size=(features.shape[-1], 2))
        labels = histories(wave) @ features @ weights
        model, rank, *_ = fit_filter(wave, labels, features)
        assert rank > 0
        other = rng.normal(size=(4, wave.shape[-1]))
        direct = histories(other) @ features @ weights
        estimate = model.predict(other)
        np.testing.assert_allclose(estimate, direct, rtol=1e-8, atol=1e-8)
        windows = histories(wave).reshape(-1, wave.shape[-1])
        complete, full_rank = fit_complete_readout(
            windows.T @ windows, windows.T @ labels.reshape(-1, 2), features
        )
        assert full_rank >= rank
        np.testing.assert_allclose(
            complete.predict(other), direct, rtol=1e-8, atol=1e-8
        )
        changed = other.copy()
        changed[:, 20:] += 15.0
        np.testing.assert_allclose(
            model.predict(changed)[:, :20], estimate[:, :20], rtol=0, atol=2e-13
        )


def test_field_fit():
    rng = np.random.default_rng(407)
    features = rng.normal(size=(3, 4, 6, 8))
    controls = rng.normal(size=(30, 3))
    ref = rng.normal(size=(3, 4))
    desired = np.einsum("ik,ikxy->ixy", ref, features)
    estimate, weights = mix_fit(features, desired, controls)
    np.testing.assert_allclose(desired, estimate, atol=1e-6)
    np.testing.assert_allclose(weights, ref, atol=1e-6)


def main():
    torch.set_num_threads(1)
    test_dictionary()
    test_filter()
    test_field_fit()
    print("Alle sieben Fenstermatrizen gegen die PyTorch-Schicht geprüft.")
    print("Kausale Faltung, Vorzeichen des Lags und Feldfit im Kovarianzmaß geprüft.")


if __name__ == "__main__":
    main()
