"""Learn additive response fields from fixed C19R and CP1/C teaching cohorts."""

from time import perf_counter

import numpy as np
from scipy.ndimage import convolve1d
import torch

import c19r
import linear as rope
from fourier_layer import median_ms, scores
from hybrid_operator import HybridNeuralOperator


def synthesize(coefficients, response):
    return (coefficients @ response.reshape(len(response), -1)).reshape(
        -1, *response.shape[1:]
    )


def mix_fit(profiles, target_basis, train):
    """Fit in the covariance metric of the common training input amplitudes."""
    inputs, terms = profiles.shape[:2]
    features = profiles.reshape(inputs, terms, -1)
    labels = target_basis.reshape(inputs, -1)
    covariance = train.T @ train / len(train)
    raw = features.reshape(inputs * terms, -1)
    gram = (raw @ raw.T).reshape(inputs, terms, inputs, terms)
    gram = (gram * covariance[:, None, :, None]).reshape(inputs * terms, inputs * terms)
    rhs = np.einsum("ij,ikx,jx->ik", covariance, features, labels).reshape(-1)
    scale = np.sqrt(np.maximum(gram.diagonal(), 1e-24))
    transformed = gram / (scale[:, None] * scale[None, :])
    penalty = 2e-8 * np.eye(inputs * terms)
    weight = np.linalg.solve(transformed + penalty, rhs / scale) / scale
    correction = np.einsum("ik,ikx->ix", weight.reshape(inputs, terms), features)
    return correction.reshape(target_basis.shape), weight.reshape(inputs, terms)


def shape_fields(history):
    # Same unscaled finite-difference input cues, independent of the chosen transform.
    if history.ndim == 3:
        gradient = convolve1d(history, [0.5, 0, -0.5], axis=-1, mode="nearest")
        curvature = convolve1d(history, [1.0, -2.0, 1.0], axis=-1, mode="nearest")
        return np.stack((history, gradient, curvature), axis=2)
    gradient = convolve1d(history, [1.0, -2.0, 1.0], axis=-1, mode="nearest")
    curvature = convolve1d(history, [1.0, -2.0, 1.0], axis=-2, mode="nearest")
    return np.stack((history, gradient, curvature), axis=2)


@torch.no_grad()
def feature_batches(kind, history):
    layer = HybridNeuralOperator(kind, 3, 1)
    times = torch.linspace(0, 1, history.shape[1], dtype=torch.float64)
    blocks = []
    for start in range(0, len(history), 64):
        test = torch.from_numpy(np.ascontiguousarray(history[start : start + 64]))
        condition = torch.ones((len(test), 1), dtype=torch.float64)
        blocks.append(layer.features(test, times, condition).numpy())
    return np.concatenate(blocks)


def c19(output, old, prepared, transforms):
    setup = perf_counter()
    study = old["c19r"]
    with np.load(prepared / "c19r_modelle.npz", allow_pickle=False) as record:
        train, test = record["train_rates"], record["test_rates"]
        observed = record["reference"]
        point, injected = record["point_reference"], record["mass_injected"]
        inputs = record["kernels"]
    train_output = synthesize(train, inputs)
    target, _, rank, _ = np.linalg.lstsq(
        train, train_output.reshape(len(train), -1), rcond=1e-11
    )
    assert rank == c19r.SEGMENTS
    # Known release histories on the existing coarse finite-volume model.
    base, out, history = c19r.finite_volume(np.eye(c19r.SEGMENTS), with_history=True)
    assert np.max(abs(c19r.mass(base) + out - c19r.HORIZON / c19r.SEGMENTS)) < 1e-8
    channels = shape_fields(history)
    y_offset = (len(c19r.X) - len(c19r.Y)) // 2
    square = np.pad(channels, ((0, 0), (0, 0), (0, 0), (y_offset, y_offset), (0, 0)))
    assert square.shape[-1] == square.shape[-2]
    target = target.reshape(base.shape)
    learnt_mass = np.linalg.lstsq(train, c19r.mass(train_output), rcond=1e-11)[0]
    data_seconds = perf_counter() - setup
    values = {
        "reference": observed,
        "rates": test,
        "point_references": point,
        "mass_kernel": learnt_mass,
        "fv_basis": base,
    }
    methods = {}

    def with_mass_limits(coefficients, learned):
        estimate = np.maximum(0.0, synthesize(coefficients, learned))
        masses = c19r.mass(estimate)
        if np.any(masses <= 0.0):
            raise ArithmeticError("insufficient positive field for C19R mass rescaling")
        return estimate * ((coefficients @ learnt_mass) / masses)[:, None, None]

    for kind in transforms:
        started = perf_counter()
        design = feature_batches(kind, square)[
            ..., y_offset : y_offset + len(c19r.Y), :
        ]
        correction, fit = mix_fit(design, target - base, train)
        estimate = base + correction
        fit_seconds = perf_counter() - started
        raw = synthesize(test, estimate)
        field = with_mass_limits(test, estimate)
        control = c19r.report_scores(field, observed, point, injected)
        for measured, predicted in zip(
            test @ learnt_mass, c19r.mass(field), strict=True
        ):
            assert abs(measured - predicted) < 1e-8
        methods[kind] = control | {
            "accepted": int(sum(control["pass"])),
            "count": len(test),
            "maximum": max(control["score"]),
            "raw": c19r.report_scores(raw, observed, point, injected),
            "fit_seconds": fit_seconds,
            "batch_ms": median_ms(lambda: with_mass_limits(test, estimate), 3),
            "parameters": int(fit.size),
        }
        values[kind] = field
        values[f"coefficients_{kind}"] = fit
        values[f"learned_basis_{kind}"] = estimate
    np.savez_compressed(output / "c19r.npz", **values)
    return {
        "methods": methods,
        "training_seconds": data_seconds,
        "training_inputs": len(train),
        "tests": len(test),
        "budgets": study["budgets"],
        "contract": "C19R original field, point and mass on the same 65×33 grid with nonnegative fields",
        "controls": study["methods"],
    }


def rope_base(times, frequencies):
    """200-cell modal physics with exact boundary values and linear interpolation."""
    intervals = 200
    coarse = rope.modal_rope(times, frequencies, intervals)
    right = np.exp(-rope.ROPE_DAMPING * times) * np.sin(
        np.asarray(frequencies)[:, None] * times
    )
    value = np.concatenate(
        (np.zeros_like(right[..., None]), coarse, right[..., None]), axis=-1
    )
    old_x = np.linspace(0, rope.ROPE_LENGTH, intervals + 1)
    x = np.linspace(0, rope.ROPE_LENGTH, rope.ROPE_N + 1)[1:-1]
    flattened = value.reshape(-1, intervals + 1)
    finer = np.stack([np.interp(x, old_x, row) for row in flattened])
    return finer.reshape(*value.shape[:-1], len(x))


def rope_score(prediction, expected, probes):
    difference = prediction - expected
    shape = difference.reshape(len(prediction), -1)
    norm = np.linalg.norm(expected.reshape(len(prediction), -1), axis=1)
    relative = np.linalg.norm(shape, axis=1) / norm
    probe_error = np.abs(difference[:, :, probes]).max(axis=(1, 2))
    return scores(np.maximum(relative / 0.01, probe_error / 0.001)) | {
        "field_relative": relative.tolist(),
        "probe_max_m": probe_error.tolist(),
    }


def cp1(output, transfer, prepared, transforms):
    source = transfer["cp1"]
    started = perf_counter()
    with np.load(prepared / "cp1.npz", allow_pickle=False) as record:
        time, frequencies = record["times"], record["frequencies"]
        test, probes, x = record["drive"], record["probes"], record["x"]
        novel_truth = record["novel_reference"][None]
        old_nominal = record["nominal_reference"]
    rng = np.random.default_rng(105)
    train = rng.uniform(-1.0, 1.0, size=(32, len(frequencies)))
    response = rope.modal_rope(time, frequencies)
    train_y = synthesize(train, response)
    target, _, rank, _ = np.linalg.lstsq(
        train, train_y.reshape(len(train), -1), rcond=1e-11
    )
    assert rank == len(frequencies)
    target = target.reshape(response.shape)
    expected = synthesize(test, rope.modal_rope(time, frequencies[::-1])[::-1])
    assert np.allclose(expected[0], old_nominal, rtol=0, atol=8e-14)
    boundary_input = np.exp(-rope.ROPE_DAMPING * time) * np.sin(
        source["novel_omega"] * time
    )
    boundary_dictionary = np.exp(-rope.ROPE_DAMPING * time[:, None]) * np.sin(
        time[:, None] * frequencies
    )
    novel_coeff, _residual, _rank, _sigma = np.linalg.lstsq(
        boundary_dictionary, boundary_input, rcond=None
    )
    fractions = np.linspace(0.0, 1.0, 5)
    clock = (time[:, None] * fractions).ravel()
    coarse = rope_base(clock, frequencies).reshape(
        len(frequencies), len(time), len(fractions), len(x)
    )
    base = coarse[:, :, -1]
    histories = coarse.reshape(-1, len(fractions), len(x))
    fields = shape_fields(histories)
    data_seconds = perf_counter() - started
    methods = {}
    values = {
        "x": x,
        "time": time,
        "reference_nominal": expected[0],
        "reference_novel": novel_truth[0],
        "reference_drive": test,
        "probe_indices": probes,
        "nominal_base": synthesize(test[:1], base)[0],
    }
    for kind in transforms:
        started = perf_counter()
        design = feature_batches(kind, fields)
        design = design.reshape(
            len(frequencies), len(time), design.shape[1], len(x)
        ).transpose(0, 2, 1, 3)
        correction, fit = mix_fit(design, target - base, train)
        model = base + correction
        fit_seconds = perf_counter() - started
        prediction = synthesize(test, model)
        novel = synthesize(novel_coeff[None], model)
        assert np.max(abs(prediction[:, 0])) < 1e-13
        result = rope_score(prediction, expected, probes)
        result["novel_frequency"] = rope_score(novel, novel_truth, probes)
        result.update(
            {
                "batch_ms": median_ms(lambda: synthesize(test, model), 3),
                "fit_seconds": fit_seconds,
                "parameters": int(fit.size),
            }
        )
        methods[kind] = result
        # Save full probe histories and the nominal field. All eight fields can be recreated from the fit.
        values[f"probes_{kind}"] = prediction[:, :, probes]
        values[f"nominal_{kind}"] = prediction[0]
        values[f"fit_{kind}"] = fit
    np.savez_compressed(output / "cp1.npz", **values)
    return {
        "methods": methods,
        "training_inputs": len(train),
        "training_seconds": data_seconds,
        "tests": len(test),
        "budget": source["budget"],
        "tested_novel_frequency": source["novel_omega"],
        "projection_error": source["novel_boundary_projection_error"],
        "contract": source["scope"],
        "controls": source["methods"]
        | {"coarse_linear": rope_score(synthesize(test, base), expected, probes)},
    }
