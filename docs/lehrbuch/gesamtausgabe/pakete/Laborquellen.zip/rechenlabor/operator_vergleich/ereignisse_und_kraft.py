"""Operator comparisons using the original event gates and C18 causal split."""

from time import perf_counter

import numpy as np

import c18
import ereignisse as reference
from c05_referenz import C05_C3, C05_MODE_1, c05_exact_step
from fenster import dictionary, encode, history_windows, model_arrays, train_window
from fourier_layer import max_normalized, median_ms, scores


def c05(output, transfer, transforms):
    source = transfer["c05"]
    cases = source["case_inputs"]
    before = perf_counter()
    rng = np.random.default_rng(505)
    difference = rng.uniform(-5.5, 3.0, size=96)
    elapsed = rng.uniform(0.015, 1.6, size=len(difference))
    offsets = np.linspace(0.006, 0, 5)
    train_path = (np.exp(-C05_C3 * (elapsed[:, None] - offsets)) * difference[:, None])[
        :, :, None
    ]
    target = np.empty(len(elapsed))
    mode = C05_MODE_1
    for i, (d, t) in enumerate(zip(difference, elapsed, strict=True)):
        x, y = c05_exact_step((4.2, mode.c4 + d), t, mode)
        target[i] = x - y - mode.c2
    unit_path = np.exp(C05_C3 * offsets)[None, :, None]
    training_seconds = perf_counter() - before

    def run(method, learned):
        results = [
            reference.c05_simulate(initial, fast, method, learned)
            for initial, fast in cases
        ]
        states, events, counts = zip(*results, strict=True)
        return np.array(states), events, counts

    states, events, _ = run("closed", 0.0)
    assert list(events[1]) == [tuple(item) for item in source["references"][1]]
    weights, results, sequences = {}, {}, {}
    for kind in transforms:
        started = perf_counter()
        basis = dictionary(kind, 5, 5)
        design = encode(train_path, basis)
        learned, _, rank, _ = np.linalg.lstsq(design, target, rcond=1e-10)
        lag = float((encode(unit_path, basis) @ learned)[0])
        fit_seconds = perf_counter() - started
        predicted, observed, fallback = run("learned", lag)
        stats = reference.hybrid_score(
            predicted,
            states,
            observed,
            events,
            source["state_budget"],
            source["event_budget_s"],
        )
        stats.update(
            {
                "coef": lag,
                "analytic_fallback": list(fallback),
                "certified_candidate_lower_bound": max(
                    0, sum(map(len, observed)) - sum(fallback)
                ),
                "observed_events": [list(marks) for marks in observed],
                "training_rank": int(rank),
                "parameters": int(learned.size),
                "fit_seconds": fit_seconds,
                "batch_ms": median_ms(lambda: run("learned", lag), 3),
            }
        )
        assert rank == 1 and stats["certified_candidate_lower_bound"] > 0
        assert stats["analytic_fallback"][6] > 0
        results[kind] = stats
        sequences[kind] = predicted
        weights[f"{kind}_readout"] = learned
    np.savez_compressed(output / "c05.npz", reference=states, **sequences, **weights)
    return {
        "methods": results,
        "training_seconds": training_seconds,
        "training_windows": len(train_path),
        "reference_events": events,
        "contract": source["scope"],
        "tests": len(cases),
        "controls": {
            key: source["methods"][key]
            for key in ("closed", "slow", "lag_formula", "fno_event")
        },
    }


def c07(output, transfer, prepared, transforms):
    source = transfer["c07"]
    with np.load(prepared / "c07.npz", allow_pickle=False) as evidence:
        expected, grid = evidence["reference"], evidence["time"]
    specs = source["specs"]
    event_reference = source["reference_events"]
    start_time = perf_counter()
    rng = np.random.default_rng(705)
    initial = rng.uniform([-0.90, -6.0], [0.90, 6.0], size=(1250, 2))
    damping = rng.uniform(0.05, 0.28, size=len(initial))
    training = {"fno_euler": [], "hybrid_fno": []}
    for side, length in enumerate(reference.LENGTHS):
        field = reference.pendulum(length, damping)
        exact = reference.dopri_many(field, initial, reference.C07_H)
        for track in training:
            path = reference.base_path(
                field, initial, reference.C07_H, midpoint=track == "hybrid_fno"
            )
            encoding = np.concatenate(
                (path, np.broadcast_to(damping[:, None, None], (len(path), 5, 1))),
                axis=2,
            )
            training[track].append((encoding, exact - path[:, -1], 705 + side))
    data_seconds = perf_counter() - start_time
    values = {"reference": expected, "time": grid}
    report = {}

    def run(method, models):
        all_runs = [
            reference.c07_run([angle, speed], friction, method, models)
            for angle, speed, friction in specs
        ]
        fields, events, learned, fallback, defect = zip(*all_runs, strict=True)
        return np.stack(fields), events, learned, fallback, max(defect)

    for kind in transforms:
        started = perf_counter()
        basis = dictionary(kind, 5, 5)
        method_fits = {}
        model = {}
        for track, sets in training.items():
            result = [
                train_window(basis, path, target, seed) for path, target, seed in sets
            ]
            model[track] = [item[0] for item in result]
            method_fits[track] = [item[1] for item in result]
            for side, (fitted, _) in enumerate(result):
                values.update(model_arrays(f"{kind}_{track}_{side}", fitted))
        fit_seconds = perf_counter() - started
        per_track = {}
        for track in training:
            fields, events, learned, fallback, impulse = run(track, model)
            result = reference.hybrid_score(
                fields,
                expected,
                events,
                event_reference,
                source["state_budget"],
                source["event_budget_s"],
            )
            assert np.isfinite(fields).all() and impulse < 1e-12 and min(learned) > 0
            result.update(reference.constraint_defects(fields, events, specs, grid))
            result.update(
                {
                    "batch_ms": median_ms(lambda: run(track, model), 3),
                    "events": events,
                    "learned_steps": list(learned),
                    "arc_solves": list(fallback),
                    "reset_error_m_s": impulse,
                }
            )
            values[f"prediction_{kind}_{track}"] = fields
            per_track[track] = result
        report[kind] = per_track["hybrid_fno"] | {
            "euler": per_track["fno_euler"],
            "fit": method_fits,
            "fit_seconds": fit_seconds,
        }
    np.savez_compressed(output / "c07.npz", **values)
    return {
        "methods": report,
        "training_seconds": data_seconds,
        "training_windows_per_arc": len(initial),
        "tests": len(specs),
        "test_cases": specs,
        "reference_events": event_reference,
        "contract": source["scope"],
        "controls": {
            key: source["methods"][key]
            for key in ("rk4", "midpoint", "hybrid_fno", "fno_euler")
        },
    }


def c09(output, transfer, prepared, transforms):
    source = transfer["c09"]
    with np.load(prepared / "c09.npz", allow_pickle=False) as saved:
        expected, reference_pump = saved["reference"], saved["reference_voltage"]
        initial, setpoint, burst = (
            saved[name] for name in ("initial", "setpoint", "burst")
        )
    before = perf_counter()
    rng = np.random.default_rng(905)
    train = rng.uniform([0.37, 0.21], [0.69, 0.45], size=(1200, 2))
    train = train[train[:, 0] - train[:, 1] >= 0.045]
    voltage = rng.uniform(0, 0.43, len(train))

    def rhs(state):
        return reference.pump_reference(state, voltage)

    path = reference.base_path(rhs, train, 1.0)
    truth = reference.dopri_many(rhs, train, 1.0)
    features = reference.pump_features(path, voltage)
    data_seconds = perf_counter() - before
    values = {"reference": expected, "reference_voltage": reference_pump}
    report = {}
    for kind in transforms:
        started = perf_counter()
        basis = dictionary(kind, 5, 5)
        model, fit = train_window(basis, features, truth - path[:, -1], 905)
        fit_seconds = perf_counter() - started

        def run():
            return reference.tank_run(initial, setpoint, burst, "hybrid_fno", model)

        fields, control, active, fallback = run()
        state = max_normalized(fields, expected, np.repeat(source["budget_m"], 2))
        pump = np.max(np.abs(control - reference_pump) / source["budget_v"], axis=1)
        assert np.isfinite(fields).all() and np.all(
            active + fallback == source["tacts"]
        )
        assert active.sum() > 0 and fallback[-2:].sum() > 0
        report[kind] = (
            scores(np.maximum(state, pump))
            | fit
            | {
                "batch_ms": median_ms(run, 3),
                "fit_seconds": fit_seconds,
                "learned_steps": active.tolist(),
                "fallback_steps": fallback.tolist(),
                "level_max_mm": float(np.max(np.abs(fields - expected)) * 1_000),
                "voltage_max_v": float(np.max(np.abs(control - reference_pump))),
            }
        )
        values[f"prediction_{kind}"] = fields
        values[f"voltage_{kind}"] = control
        values.update(model_arrays(kind, model))
    np.savez_compressed(output / "c09.npz", **values)
    return {
        "methods": report,
        "training_windows": len(train),
        "training_seconds": data_seconds,
        "tests": len(expected),
        "contract": source["scope"],
        "tacts": source["tacts"],
        "controls": {
            key: source["methods"][key] for key in ("rk4", "euler", "hybrid_fno")
        },
    }


def muscle(output, old, transforms):
    (time_train, input_train, target), (time_test, input_test, measured), provenance = (
        c18.load_sequences(None, None)
    )
    arx = c18.fit_arx(input_train, target)
    base_train = c18.rollout_arx(input_train, target[:2], arx)
    base_test = c18.rollout_arx(input_test, measured[:2], arx)
    train = history_windows(input_train, c18.WINDOW)[:, :, None]
    test = history_windows(input_test, c18.WINDOW)[:, :, None]
    cutoff = len(input_test) // 2
    changed = input_test.copy()
    changed[cutoff:] += 1.5
    future = history_windows(changed, c18.WINDOW)[:, :, None]
    arrays = {
        "training_time": time_train,
        "validation_time": time_test,
        "validation_force": measured,
        "arx": base_test,
    }
    report = {}
    for kind in transforms:
        started = perf_counter()
        basis = dictionary(kind, c18.WINDOW, 8)
        config = {
            "width": c18.HIDDEN,
            "penalty": c18.RIDGE,
            "iterations": c18.MAX_ITERATIONS,
        }
        direct, direct_fit = train_window(
            basis, train[2:], target[2:, None], 1810, **config
        )
        residual, residual_fit = train_window(
            basis, train[2:], (target - base_train)[2:, None], 1810, **config
        )
        fit_seconds = perf_counter() - started
        estimate = direct.predict(test)[:, 0]
        hybrid = base_test + residual.predict(test)[:, 0]
        changed_hybrid = (
            c18.rollout_arx(changed, measured[:2], arx) + residual.predict(future)[:, 0]
        )
        assert np.allclose(
            direct.predict(future)[:cutoff, 0], estimate[:cutoff], rtol=0, atol=1e-12
        )
        assert np.allclose(changed_hybrid[:cutoff], hybrid[:cutoff], rtol=0, atol=1e-12)
        stats = {
            "direct": c18.metrics(estimate, measured),
            "arx_residual": c18.metrics(hybrid, measured),
            "fit_seconds": fit_seconds,
            "fit": {"direct": direct_fit, "arx_residual": residual_fit},
            "causal_prefix_samples": cutoff,
            "batch_ms": median_ms(lambda: direct.predict(test), 3),
        }
        report[kind] = stats
        arrays[f"direct_{kind}"] = estimate
        arrays[f"arx_residual_{kind}"] = hybrid
        arrays.update(model_arrays(f"direct_{kind}", direct))
        arrays.update(model_arrays(f"arx_residual_{kind}", residual))
    np.savez_compressed(output / "c18.npz", **arrays)
    return {
        "methods": report,
        "provenance": provenance,
        "training_samples": len(train) - 2,
        "scored_samples": len(measured) - 2,
        "tests": 1,
        "sampling_hz": 100,
        "controls": {
            key: val["validation"] for key, val in old["c18"]["methods"].items()
        },
        "contract": "RMSE between measured and predicted force on the other published curve",
    }
