"""Shared reporting for the two independent solution-operator experiments."""
import csv
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy.stats import qmc

HERE = Path(__file__).resolve().parent
LAB = HERE.parent
RESULTS = HERE / "messung"


def sobol(size, dim, seed):
    """Disjoint scrambled Sobol designs for reproducible development and test cohorts."""
    if size <= 0 or size & (size - 1):
        raise ValueError("the Sobol design size must be a power of two")
    return qmc.Sobol(dim, scramble=True, seed=seed).random_base2(size.bit_length()-1)


def seconds_per_query(function, *args, repetitions=7):
    function(*args)
    samples = []
    for _ in range(repetitions):
        start = perf_counter()
        function(*args)
        samples.append(perf_counter() - start)
    return float(np.median(samples))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n")


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf8") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def summary(rows):
    result = {}
    for cohort, method in dict.fromkeys((r["gruppe"], r["verfahren"]) for r in rows):
        subset = [r for r in rows if r["gruppe"] == cohort and r["verfahren"] == method]
        result.setdefault(cohort, {})[method] = {
            "n": len(subset), "bestanden": sum(1 for x in subset if x["score"] <= 1),
            "median_relativ": float(np.median([x["relativ"] for x in subset])),
            "max_relativ": max(x["relativ"] for x in subset), "max_score": max(x["score"] for x in subset),
        }
    return result
