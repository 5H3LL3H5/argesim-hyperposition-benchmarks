"""Seven archived one-dimensional kernel maps, fitted to full CP1/B paths and CP2/2 fields."""
import argparse
from pathlib import Path
from time import perf_counter
import json
import math
from tempfile import TemporaryDirectory

import numpy as np

from auswertung import LAB, RESULTS, seconds_per_query, sobol, summary, write_csv, write_json
import populationen as pop
import kavitaet as cav

KINDS = ('fourier', 'laplace', 'wavelet', 'hankel', 'radon', 'wavelet_laplace', 'fourier_mellin')
WIDTH = 96


def encode(curves, basis):
    # Curves are chronological on their last axis. Each channel uses the same physical time grid.
    return (curves @ basis).reshape(len(curves), -1)


def normalized_codes(curves, basis, weights):
    raw = encode(curves, basis)
    return (raw - weights['shift']) / weights['scale']


def features(codes, weights):
    return np.column_stack((np.ones(len(codes)), codes,
                            np.tanh(codes @ weights['hidden'] + weights['bias'])))


def design(curves, basis, weights, zero):
    result = features(normalized_codes(curves, basis, weights), weights)
    if zero:
        rest = normalized_codes(np.zeros_like(curves[:1]), basis, weights)
        result -= features(rest, weights)
    return result


def fit_candidates(curves, basis, target, zero):
    codes = encode(curves, basis)
    scale = codes.std(axis=0)
    scale[scale < 1e-8] = 1.
    rng = np.random.default_rng(3917)
    weights = {'shift': codes.mean(axis=0), 'scale': scale,
               'hidden': rng.normal(0, 1 / np.sqrt(codes.shape[1]), (codes.shape[1], WIDTH)),
               'bias': rng.normal(0, .6, WIDTH)}
    matrix = design(curves, basis, weights, zero)
    u, s, vt = np.linalg.svd(matrix, full_matrices=False)
    for ridge in (1e-8, 1e-5, 1e-2):
        gain = s / (s**2 + ridge)
        yield ridge, {**weights, 'output': (vt.T * gain) @ (u.T @ target)}


def population_curves(p, model):
    # The full affine baseline is available from the initial parameters alone.
    base = pop.features('affin', p, None, None) @ model['gewicht_affin']
    log_paths = (model['mittel'] + base @ model['moden']).reshape(-1, len(pop.TIMES), 10)
    log_paths[:, 0] = 0.
    return log_paths[:, :64, :].transpose(0, 2, 1), base


def cavity_curves(p, model):
    lags = cav.histories(p)
    # Exactly eight equal-duration samples per held lid factor. Future blocks are inaccessible.
    curves = np.repeat(lags[:, ::-1], 8, axis=1)[:, None]
    return curves, lags @ model['linear']


def predict(problem, p, model, basis, weights):
    if problem == 'population':
        curves, base = population_curves(p, model)
        coefficients = base + design(curves, basis, weights, False) @ weights['output']
        return pop.reconstruct(p, coefficients, model['mittel'], model['moden'])
    if problem != 'kavitaet':
        raise ValueError('unknown model')
    curves, base = cavity_curves(p, model)
    coords = base + design(curves, basis, weights, True) @ weights['output']
    return (coords @ model['basis']).reshape(-1, cav.BLOCKS, cav.N, cav.N, 2)


def study(problem, out, dictionaries):
    is_pop = problem == 'population'
    with np.load(out / (problem + '_modell.npz')) as data:
        model = dict(data)
    if is_pop:
        points = [pop.LOW + sobol(n, 2, seed) * (pop.HIGH - pop.LOW) for n, seed in ((64,2301),(16,2302))]
        train, val = [np.stack([pop.reference(p) for p in cohort]) for cohort in points]
        curves, base = population_curves(points[0], model)
        logs = np.log(train / pop.initial(points[0])[:,None]).reshape(len(train), -1)
        residual = (logs-model['mittel']) @ model['moden'].T - base
        raw_file, endings, groups = 'population_bahnen.npz', '_parameter', ('innen','nominal','aussen')
        measure = pop.measurements
    else:
        points = [2*sobol(n, cav.BLOCKS, seed)-1 for n,seed in ((64,3801),(16,3802))]
        with TemporaryDirectory() as stage:
            binary = cav.build_cpp(Path(stage))
            train, val = [np.stack([cav.reference(p,binary,stage)[0] for p in cohort]) for cohort in points]
        curves, base = cavity_curves(points[0], model)
        residual = train.reshape(len(base),-1) @ model['basis'].T - base
        raw_file, endings, groups = 'kavitaet_felder.npz', '_deckel', ('innen','profile','aussen')
        measure = cav.metrics
    rows, saved, selected, costs = [], {}, {}, []
    common_clock = json.loads((out / (problem+'_zeiten.json')).read_text())
    common_cost = sum(common_clock[key] for key in ('training','validierung','anpassung'))
    ref_seconds = common_clock['median_abfrage_s']['klassisch' if is_pop else 'd2q9']
    with np.load(out / raw_file) as testing:
        for kind in KINDS:
            basis = dictionaries[kind]
            start = perf_counter()
            choice = None
            for ridge, weights in fit_candidates(curves, basis, residual, not is_pop):
                prediction = predict(problem, points[1], model, basis, weights)
                validation = float(np.mean(measure(prediction, val)[-1]))
                if choice is None or validation < choice[0]:
                    choice = validation, ridge, weights
            validation, ridge, weights = choice
            fitting = perf_counter() - start
            benchmarks = [seconds_per_query(predict,problem,one,model,basis,weights,repetitions=11)
                          for one in testing['innen'+endings][:5]]
            latency = float(np.median(benchmarks))
            # All archived shared arrays plus this branch. The trained count is the output matrix.
            shared_bytes = sum(arr.nbytes for arr in model.values())
            branch_bytes = basis.nbytes + sum(arr.nbytes for arr in weights.values())
            costs.append(dict(verfahren=kind,anpassung_zusaetzlich_s=fitting,vorbereitung_gemeinsam_s=common_cost,
                              inferenz_s=latency,referenz_s=ref_seconds,trainierte_ausgabegewichte=weights['output'].size,
                              array_bytes_inkl_gemeinsam=shared_bytes+branch_bytes,
                              amortisationsanfragen=math.floor((common_cost+fitting)/(ref_seconds-latency))+1
                              if ref_seconds>latency else ''))
            selected[kind] = {'ridge':ridge, 'validierung_mittlerer_score':validation}
            saved.update({kind+'_'+key:value for key,value in {'basis':basis,**weights}.items()})
            for group in groups:
                values = testing[group+endings]
                guessed = predict(problem, values, model, basis, weights)
                if not is_pop:
                    assert np.allclose(predict(problem,np.zeros(cav.BLOCKS),model,basis,weights),0,rtol=0,atol=2e-14)
                    changed = values[:1].copy(); changed[:,4:] += .37
                    probe = predict(problem,np.concatenate((values[:1],changed)),model,basis,weights)
                    np.testing.assert_allclose(probe[0,:4], probe[1,:4], rtol=0, atol=3e-14)
                else:
                    assert np.array_equal(guessed[:,0],pop.initial(values)) and (guessed > 0).all()
                measures = measure(guessed,testing[group+'_referenz'])
                labels = ('relativ','max_abs','endwertfehler','sensor_z2_t10','score') if is_pop else ('relativ','max_vektor_durch_U','score')
                for i, vals in enumerate(zip(*measures,strict=True)):
                    rows.append(dict(gruppe=group, fall=i, verfahren=kind, **dict(zip(labels,vals,strict=True))))
    write_csv(out / (problem+'_kerne_einzel.csv'), rows)
    write_csv(out / (problem+'_kerne_aufwand.csv'), costs)
    write_json(out / (problem+'_kerne.json'), {'gruppen':summary(rows), 'wahl':selected, 'breite':WIDTH})
    np.savez_compressed(out / (problem+'_kernmodelle.npz'), **saved)


def read_kernel(file, kind):
    # Explicit names avoid parsing overlaps such as 'wavelet' and 'wavelet_laplace'.
    basis = file[kind+'_basis']
    weights = {k:file[kind+'_'+k] for k in ('shift','scale','hidden','bias','output')}
    return basis,weights


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=RESULTS)
    args = parser.parse_args()
    with np.load(LAB/'operator_vergleich/messung/c18.npz') as archive:
        dictionaries = {k:archive['direct_'+k+'_basis'] for k in KINDS}
    for problem in ('population','kavitaet'):
        study(problem, args.out, dictionaries)
        print(problem, '· sieben Kerne auf allen Testfällen gerechnet', flush=True)
