"""A causal lid-history to velocity-field operator for the CP2/2 transient cavity."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from time import perf_counter

import numpy as np
from scipy.optimize import minimize

from auswertung import HERE, LAB, RESULTS, seconds_per_query, sobol, summary, write_csv, write_json

sys.path.insert(0, str(LAB/"cp2_operatoren"))
from referenzen import build_cpp, resize_centers

N, BLOCKS, RE, U = 33, 8, 100., .055
METHODS = ("linear", "quadratisch", "pod_netz")


def reference(controls, binary, directory, n=N, steps=None):
    """Solve from rest at fixed viscosity with the project's C++20 D2Q9 kernel."""
    steps = 2*n if steps is None else steps
    with TemporaryDirectory(dir=directory) as stage:
        path = Path(stage)/"geschwindigkeit.bin"
        result = subprocess.run(
            [str(binary), "history", str(n), str(RE), str(U), str(steps), str(path),
             *[format(float(u), ".17g") for u in controls]],
            check=True, capture_output=True, text=True)
        meta = json.loads(result.stdout)
        fields = np.fromfile(path, dtype=np.float64).reshape(len(controls), n, n, 2)
    if meta["max_mass_drift"] > 1e-11 or not np.isfinite(fields).all():
        raise ArithmeticError("invalid D2Q9 time history")
    return fields, meta


def comparison_with_scalar(binary, directory):
    sys.path.insert(0, str(LAB.parent/"beispiele"))
    from lbm_d2q9 import D2Q9
    drive = (.65, -.25, 0., 1.)
    n, steps = 9, 5
    expected, _ = reference(drive, binary, directory, n=n, steps=steps)
    previous = None
    actual = []
    for speed in drive:
        box = D2Q9(n,n,.5+3*U*n/RE,lid=U*speed,boundary="halbweg")
        if previous is not None:
            box.f = previous
        for _ in range(steps):
            box.step()
        previous = box.f
        actual.append(np.asarray(box.field())[:,1:].reshape(n,n,2)/U)
    delta = float(np.max(np.abs(np.array(actual)-expected)))
    assert delta < 3e-13
    return delta


def histories(inputs):
    p = np.atleast_2d(np.asarray(inputs,dtype=float))
    if p.shape[1] != BLOCKS or not np.isfinite(p).all():
        raise ValueError("eight finite lid-speed factors required")
    windows = np.zeros((len(p),BLOCKS,BLOCKS))
    for lag in range(BLOCKS):
        windows[:, lag:, lag] = p[:, :BLOCKS-lag]
    return windows.reshape(-1,BLOCKS)


def quadratic(p):
    i,j = np.triu_indices(BLOCKS)
    return np.column_stack([p,p[:,i]*p[:,j]])


def nonlinear_train(x, target):
    """Train a tanh branch on the remaining temporal response. Its value at rest is zero."""
    d, h, k = x.shape[1], 24, target.shape[1]
    rng = np.random.default_rng(31807)
    sizes = (d*h, d*h+h)
    def unpack(theta):
        w,b,v = np.split(theta,sizes)
        return w.reshape(d,h), b, v.reshape(h,k)
    def objective(theta):
        w,b,v = unpack(theta)
        a = np.tanh(x@w + b)
        zero = np.tanh(b)
        phi = a-zero
        diff = phi@v-target
        back = diff @ v.T
        hidden = back * (1-a*a)
        dw = x.T@hidden
        db = np.sum(hidden-back*(1-zero*zero), axis=0)
        dv = phi.T@diff
        penalty = 1e-6
        loss = np.sum(diff**2)/(2*len(x)) + penalty*(theta@theta)/2
        grad = np.concatenate((dw.ravel(),db,dv.ravel()))/len(x) + penalty*theta
        return loss, grad
    init = np.r_[rng.normal(0,.55,d*h),rng.normal(0,.2,h),rng.normal(0,.015,h*k)]
    result = minimize(objective, init, jac=True, method="L-BFGS-B",
                      options={"maxiter":220,"ftol":1e-10,"gtol":1e-7,"maxcor":8})
    if not np.isfinite(result.fun) or result.status not in (0,1):
        raise ArithmeticError(result.message)
    w,b,v = unpack(result.x)
    return w,b,v,{"iterationen":int(result.nit),"konvergiert":bool(result.success),"status":str(result.message)}


def predict(inputs, model, method="pod_netz"):
    x = histories(inputs)
    if method=="linear":
        coordinates = x @ model["linear"]
    elif method in ("quadratisch","pod_netz"):
        coordinates = quadratic(x) @ model["quadratisch"]
        if method=="pod_netz":
            hidden = np.tanh(x@model["w"]+model["b"])-np.tanh(model["b"])
            coordinates += model["anteil"]*(hidden @ model["v"])*model["skala"]
    else:
        raise ValueError("unknown cavity operator")
    shape = (len(x)//BLOCKS, BLOCKS, N, N, 2)
    return (coordinates @ model["basis"]).reshape(shape)


def metrics(guess, ref):
    axes = tuple(range(1,ref.ndim))
    diff = guess - ref
    reference_norm = np.sum(ref**2,axis=axes)
    numerator = np.sum(diff**2,axis=axes)
    # A quiescent test input has an exact zero field and is checked separately.
    if np.any(reference_norm == 0):
        raise ValueError("relative score requires a nonzero reference field")
    rel = np.sqrt(numerator/reference_norm)
    maximum = np.max(np.linalg.norm(diff,axis=-1),axis=(1,2,3))
    return rel, maximum, np.maximum(rel/.02,maximum/.05)


def fit(params, fields, val_p, val_fields):
    x=histories(params)
    raw = fields.reshape(len(x),-1)
    u,s,vt = np.linalg.svd(raw,full_matrices=False)
    rank=40
    coefficients = u[:,:rank]*s[:rank]
    lin = np.linalg.lstsq(x,coefficients,rcond=1e-10)[0]
    q=quadratic(x)
    square = np.linalg.lstsq(q,coefficients,rcond=1e-10)[0]
    residual = coefficients-q@square
    deviation = residual.std(axis=0)
    scale = np.maximum(deviation, .05*deviation.max())
    w,b,v,status = nonlinear_train(x,residual/scale)
    model = dict(basis=vt[:rank], linear=lin, quadratisch=square,
                 w=w,b=b,v=v,skala=scale,anteil=np.array(1.))
    candidates=[]
    for weight in (.5,1.):
        model["anteil"]=np.array(weight)
        valid=predict(val_p,model)
        candidates.append((float(metrics(valid,val_fields)[-1].mean()),weight))
    best,weight=min(candidates)
    model["anteil"]=np.array(weight)
    status.update({"rang":rank,"energieanteil":float(np.sum(s[:rank]**2)/np.sum(s**2)),
                   "restanteil":weight,"validierung_mittlerer_score":best})
    return model,status


def run(out):
    out.mkdir(parents=True,exist_ok=True)
    params={name:2*sobol(n,BLOCKS,seed)-1 for name,n,seed in (
        ("training",64,3801),("validierung",16,3802),("innen",16,3803))}
    params["profile"]=np.array([[.8]*8,[.8]*4+[-.8]*4,[.7]*3+[0]*5,[(-1.)**k*.8 for k in range(8)]])
    params["aussen"]=2*sobol(8,BLOCKS,3804)-1
    params["aussen"]*=1.6/np.max(np.abs(params["aussen"]),axis=1)[:,None]
    all_controls=np.vstack(tuple(params.values()))
    assert len(all_controls)==len(np.unique(all_controls,axis=0))
    clock={}
    with TemporaryDirectory() as stage:
        binary=build_cpp(Path(stage))
        scalar_delta=comparison_with_scalar(binary,stage)
        targets={}
        max_drift=0
        for name,group in params.items():
            start=perf_counter()
            traces=[]
            for drive in group:
                field,meta=reference(drive,binary,stage)
                max_drift=max(max_drift,meta["max_mass_drift"])
                traces.append(field)
            targets[name]=np.asarray(traces)
            clock[name]=perf_counter()-start

        start=perf_counter()
        model,optimization=fit(params["training"],targets["training"],params["validierung"],targets["validierung"])
        clock["anpassung"]=perf_counter()-start
        rows=[]
        saved={}
        for name in ("innen","profile","aussen"):
            group,truth=params[name],targets[name]
            saved[name+"_deckel"]=group
            saved[name+"_referenz"]=truth
            for method in METHODS:
                predicted=predict(group,model,method)
                saved[name+"_"+method]=predicted
                rel,peak,score=metrics(predicted,truth)
                for i in range(len(group)):
                    rows.append(dict(gruppe=name,fall=i,verfahren=method,relativ=rel[i],
                                     max_vektor_durch_U=peak[i],score=score[i]))
        plus=np.array([.2,-.45,.1,.55,.3,.4,-.2,.8])
        swapped=plus.copy(); swapped[4:]*=-1
        probe=predict(np.stack([plus,swapped]),model)
        assert np.array_equal(probe[0,:4],probe[1,:4]) and np.array_equal(predict(np.zeros(BLOCKS),model),np.zeros_like(probe[:1]))
        fp,_=reference(params["profile"][1],binary,stage,n=65)
        reduced=resize_centers(fp.transpose(0,3,1,2),N).transpose(0,2,3,1)
        coarse=targets["profile"][1]
        grid_effect=float(np.linalg.norm(reduced-coarse)/np.linalg.norm(reduced))

        # Same five unseen histories, serial, all eight fields. The C++ clock excludes file I/O.
        times={k:[] for k in ("d2q9",*METHODS)}
        for drive in params["innen"][:5]:
            reference(drive,binary,stage)
            times["d2q9"].append(float(np.median([reference(drive,binary,stage)[1]["seconds"] for _ in range(5)])))
            for method in METHODS:
                times[method].append(seconds_per_query(predict,drive,model,method,repetitions=11))
        clock["median_abfrage_s"]={k:float(np.median(v)) for k,v in times.items()}
    np.savez_compressed(out/"kavitaet_modell.npz",**model)
    np.savez_compressed(out/"kavitaet_felder.npz",**saved)
    write_csv(out/"kavitaet_einzel.csv",rows)
    info={"gitter":N,"intervalle":BLOCKS,"schritte_pro_intervall":2*N,"re_bezogen_auf_U":RE,"U":U,
          "t_stern":2*BLOCKS*U,"gruppen":summary(rows),"anzahl":{k:len(v) for k,v in params.items()},
          "budget":{"relativ":.02,"max_vektor_durch_U":.05},"netz":optimization,"max_massendrift_referenz":max_drift,
          "python_cpp_abweichung":scalar_delta,"gitter_33_65_umkehr":grid_effect,
          "feingitter":65,"feine_schritte_je_intervall":130}
    write_json(out/"kavitaet.json",info)
    write_json(out/"kavitaet_zeiten.json",clock)
    return info


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out",type=Path,default=RESULTS)
    print(run(parser.parse_args().out))
