"""CP1/B: initial-value to full-trajectory operator for five coupled predator–prey pairs."""
import argparse
import sys
from time import perf_counter

import numpy as np
from scipy.integrate import solve_ivp
from scipy.spatial.distance import cdist

from auswertung import LAB, RESULTS, seconds_per_query, sobol, summary, write_csv, write_json

sys.path.insert(0, str(LAB / "messplanung/projekt"))
from argesim_benchmarks.models import cp1_parallel as cp1

TIMES = np.arange(401) / 4.0
RHS = cp1.cp1_task_b_rhs()
LOW = np.array([.8, .9])
HIGH = np.array([1.25, 1.1])
NAMES = tuple(cp1.CP1_TASK_B_TERMINAL_VALUES)


def initial(inputs):
    p = np.atleast_2d(inputs)
    if p.shape[1] != 2 or not np.isfinite(p).all() or np.any(p <= 0):
        raise ValueError("two positive initial populations are required")
    state = np.ones((len(p), 10))
    state[:, [0, 9]] = p
    return state


def reference(p, method="DOP853"):
    start = initial(p)[0]
    solution = solve_ivp(RHS, (0, 100), start, t_eval=TIMES, method=method,
                         rtol=2e-11, atol=2e-13)
    if not solution.success or solution.y.shape != (10, 401) or not (solution.y > 0).all():
        raise ArithmeticError("invalid CP1/B reference")
    return solution.y.T.copy()


def normalized(p):
    return (np.atleast_2d(p) - LOW) / (HIGH - LOW)


def radial(p, centers, width):
    return np.exp(-cdist(normalized(p), normalized(centers), "sqeuclidean") / (2 * width**2))


def features(method, p, centers, width):
    p = np.atleast_2d(p)
    base = np.column_stack([np.ones(len(p)), normalized(p)])
    if method == "affin":
        return base
    if method == "rbf_pod":
        return np.column_stack([base, radial(p, centers, width)])
    raise ValueError("unknown population operator")


def reconstruct(p, coefficients, mean, modes):
    logs = (mean + coefficients @ modes).reshape(len(np.atleast_2d(p)), len(TIMES), 10)
    logs[:, 0, :] = 0.0  # The prescribed initial state is a known boundary value.
    return initial(p)[:, None, :] * np.exp(logs)


def predict(p, model, method="rbf_pod"):
    branch = features(method, p, model["zentren"], float(model["breite"]))
    return reconstruct(p, branch @ model["gewicht_" + method], model["mittel"], model["moden"])


def fit_branch(p, coefficients, method, width):
    design = features(method, p, p, width)
    return np.linalg.lstsq(design, coefficients, rcond=1e-10)[0]


def measurements(guess, truth):
    axes = (1, 2)
    difference = guess - truth
    relative = np.sqrt(np.sum(difference**2, axis=axes) / np.sum(truth**2, axis=axes))
    maximum = np.max(np.abs(difference), axis=axes)
    end = np.max(np.abs(difference[:, -1]), axis=1)
    at10 = np.abs(difference[:, 40, -1])
    score = np.maximum.reduce([relative / .01, maximum / .10, end / .02, at10 / .06])
    return relative, maximum, end, at10, score


def train(train_p, train_y, valid_p, valid_y):
    logs = np.log(train_y / initial(train_p)[:, None, :]).reshape(len(train_y), -1)
    mean = logs.mean(axis=0)
    u, singular, spatial = np.linalg.svd(logs - mean, full_matrices=False)
    # Determine the selectable hyperparameters using validation responses only.
    ranking = []
    for rank in (8, 16, 32):
        coefficients = u[:, :rank] * singular[:rank]
        for width in (.16, .32, .64, 1.28):
            weights = fit_branch(train_p, coefficients, "rbf_pod", width)
            vg = reconstruct(valid_p, features("rbf_pod", valid_p, train_p, width) @ weights,
                             mean, spatial[:rank])
            ranking.append((float(measurements(vg, valid_y)[-1].mean()), rank, width))
    best, rank, width = min(ranking)
    fitted = {"zentren": train_p, "mittel": mean, "moden": spatial[:rank], "breite": np.array(width)}
    coefficients = u[:, :rank] * singular[:rank]
    for method in ("affin", "rbf_pod"):
        fitted["gewicht_" + method] = fit_branch(train_p, coefficients, method, width)
    return fitted, {"rang": rank, "breite": width, "validierung_mittlerer_score": best}


def run(out):
    out.mkdir(parents=True, exist_ok=True)
    inputs = {name: LOW + sobol(n, 2, seed) * (HIGH - LOW) for name, n, seed in (
        ("training", 64, 2301), ("validierung", 16, 2302), ("innen", 16, 2303))}
    inputs["nominal"] = np.array([[1., 1.]])
    inputs["aussen"] = np.array([(v, z) for v in (.45, .60, 1.55, 1.8) for z in (.72, 1.32)])
    all_points = np.vstack(tuple(inputs.values()))
    assert len(np.unique(all_points, axis=0)) == len(all_points)
    clock = {}
    targets = {}
    for name, params in inputs.items():
        start = perf_counter()
        targets[name] = np.stack([reference(p) for p in params])
        clock[name] = perf_counter() - start
    official = np.array([cp1.CP1_TASK_B_TERMINAL_VALUES[name] for name in NAMES])
    nominal_error = float(np.max(np.abs(targets["nominal"][0, -1] - official)))
    independent = float(np.max(np.abs(targets["nominal"][0] - reference(inputs["nominal"][0], "Radau"))))
    assert nominal_error < 2e-7 and independent < 3e-8

    start = perf_counter()
    model, selection = train(inputs["training"], targets["training"], inputs["validierung"], targets["validierung"])
    clock["anpassung"] = perf_counter() - start
    np.savez_compressed(out/"population_modell.npz", **model)
    saved = {"t": TIMES, "namen": np.array(NAMES), "amtliche_endwerte": official}
    rows = []
    for group in ("innen", "nominal", "aussen"):
        params, truth = inputs[group], targets[group]
        saved[group + "_parameter"] = params
        saved[group + "_referenz"] = truth
        for method in ("affin", "rbf_pod"):
            result = predict(params, model, method)
            assert np.all(result > 0) and np.allclose(result[:, 0], initial(params), rtol=0, atol=5e-14)
            saved[group + "_" + method] = result
            scores = measurements(result, truth)
            for i, (rel, peak, end, sensor, score) in enumerate(zip(*scores, strict=True)):
                rows.append(dict(gruppe=group, fall=i, verfahren=method, v1_start=params[i, 0],
                                 z2_start=params[i, 1], relativ=rel, max_abs=peak, endwertfehler=end,
                                 sensor_z2_t10=sensor, score=score))
    write_csv(out/"population_einzel.csv", rows)
    np.savez_compressed(out/"population_bahnen.npz", **saved)

    # Compare one whole 401×10 output per timed query on the same test inputs.
    cpus = {k: [] for k in ("klassisch", "rbf_pod", "affin")}
    for p in inputs["innen"][:5]:
        cpus["klassisch"].append(seconds_per_query(reference, p, repetitions=3))
        for name in ("rbf_pod", "affin"):
            cpus[name].append(seconds_per_query(predict, p, model, name, repetitions=11))
    clock["median_abfrage_s"] = {k:float(np.median(v)) for k,v in cpus.items()}
    info = {"anzahl": {k:len(v) for k,v in inputs.items()}, "t_ende":100, "zustaende":list(NAMES),
            "abtastungen":len(TIMES), "wahl":selection, "endwert_dop853_tabelle":nominal_error,
            "max_dop853_radau":independent,"budget":{"relativ":.01,"max_abs":.10,"ende":.02,"z2_t10":.06},
            "gruppen":summary(rows)}
    write_json(out/"population.json", info)
    write_json(out/"population_zeiten.json", clock)
    return info


if __name__=="__main__":
    from pathlib import Path
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=RESULTS)
    print(run(parser.parse_args().out))
