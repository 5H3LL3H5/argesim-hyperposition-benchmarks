"""Draw three textbook plates from the portable test data and kernel measurements."""
import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import colors
from matplotlib.ticker import FuncFormatter, MaxNLocator, NullFormatter
import numpy as np

from auswertung import LAB, RESULTS

TEAL, BLUE, RUST, INK = '#007d75', '#205383', '#b04624', '#20333b'
NAMES = ('Fourier','Laplace','Wavelet','Hankel','Radon (1D)','Wavelet–Laplace','Fourier–Mellin')
KEYS = ('fourier','laplace','wavelet','hankel','radon','wavelet_laplace','fourier_mellin')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.labelcolor':INK,'text.color':INK,
                     'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold',
                     'axes.titlesize':10,'axes.edgecolor':'#78888c','legend.frameon':False,
                     'svg.hashsalt':'cp-dynamik-2026','svg.fonttype':'path','pdf.fonttype':42})


def save(fig, root, name):
    for directory, ext in [('abbildungen','svg'),('druck','pdf')]:
        (root/directory).mkdir(parents=True,exist_ok=True)
        meta = {'Date':None,'Creator':'ARGESIM-Rechenlabor'} if ext=='svg' else {'CreationDate':None,'ModDate':None,'Creator':'ARGESIM-Rechenlabor'}
        fig.savefig(root/directory/(name+'.'+ext),metadata=meta)
    plt.close(fig)


def population(data, root):
    with np.load(data/'population_bahnen.npz') as archive:
        t = archive['t']; ref=archive['nominal_referenz'][0]; pred=archive['nominal_rbf_pod'][0]
        series = [(cohort, np.max(np.abs(archive[cohort+'_rbf_pod'][0]-archive[cohort+'_referenz'][0]),axis=1)) for cohort in ('nominal','aussen')]
        inside_ref = archive['innen_referenz'][2, :, 1]
        inside_affine = archive['innen_affin'][2, :, 1]
    fig, (a,b,c) = plt.subplots(1,3,figsize=(8.4,3.25),layout='constrained')
    a.set_title('A   Nominelles Paar',loc='left'); view=t<=30
    for i,label,color in [(0,'Beute $v_1$',TEAL),(1,'Räuber $v_2$',BLUE)]:
        a.plot(t[view],ref[view,i],color=color,lw=1.65,label=label)
        a.plot(t[view][1::8],pred[view,i][1::8],ls='none',marker='o',ms=3.4,markerfacecolor='white',markeredgecolor=color,markeredgewidth=.9)
    a.plot([],[],ls='none',marker='o',mfc='white',mec=INK,ms=3.6,label='Operator'); a.set(xlabel='Zeit $t$',ylabel='Populationsgröße',xlim=(0,30)); a.legend(fontsize=8)
    b.set_title('B   Größter Bahnfehler',loc='left')
    for (cohort,err),label,col in zip(series,('Nomineller Start','Außenfall (0,45 / 0,72)'),(TEAL,RUST),strict=True):
        b.plot(t[1:],err[1:],color=col,lw=1.35,label=label)
    b.axhline(.1,ls='--',color=INK,lw=1,label='Absolutes Budget 0,10')
    b.set(yscale='log',xlim=(0,100),ylim=(1e-8,2.5),xlabel='Zeit $t$',ylabel='Max. absoluter Fehler'); b.legend(fontsize=7.6,loc='lower right')
    c.set_title('C   Frühe Räuberspitze', loc='left')
    window = (t >= 13.5) & (t <= 18)
    c.plot(t[window], inside_ref[window], color=BLUE, lw=1.8, label='DOP853')
    c.plot(t[window], inside_affine[window], color=RUST, lw=1.6, ls='--', label='Affin')
    at = int(np.flatnonzero(t == 15.5)[0])
    c.vlines(t[at], inside_ref[at], inside_affine[at], color=INK, lw=2.5)
    c.plot([t[at]]*2,[inside_ref[at],inside_affine[at]],'o',mfc='white',mec=INK,ms=4)
    c.set(xlabel='Zeit $t$', ylabel='Population $v_2$', xticks=[14,15.5,17],
          xticklabels=['14','15,5','17'])
    c.legend(fontsize=7.1, loc='lower right')
    for ax in (a,b,c):
        ax.grid(alpha=.2)
        ax.set_axisbelow(True)
    save(fig,root,'dynamik_population')


def cavity(data, root):
    with np.load(data/'kavitaet_felder.npz') as a:
        truth=a['profile_referenz'][1]; guess=a['profile_pod_netz'][1]
    import csv
    with (data/'kavitaet_einzel.csv').open() as stream:
        coarse_rows = list(csv.DictReader(stream))
    with (LAB/'revisionspruefung/messung/kavitaet_33_65.csv').open() as stream:
        fine_rows = list(csv.DictReader(stream))
    fig=plt.figure(figsize=(8.05,5.75),layout='constrained')
    gs=fig.add_gridspec(3,4,width_ratios=(1,1,.09,1.12),height_ratios=(1,1,.78))
    vscale=colors.Normalize(-.8,.8); errors=np.linalg.norm(truth-guess,axis=-1)
    escale=colors.Normalize(0,np.max(errors[[3,4]]))
    fields=[(truth[...,0],vscale,'RdBu_r'),(guess[...,0],vscale,'RdBu_r'),(errors,escale,'magma')]
    maps=[]
    for row,block in enumerate((3,4)):
        for col,(matrix,norm,cmap) in enumerate(fields):
            ax=fig.add_subplot(gs[row,(0,1,3)[col]])
            im=ax.imshow(matrix[block],extent=(0,1,0,1),origin='lower',interpolation='none',norm=norm,cmap=cmap)
            ax.set_xticks([0,.5,1],['0','0,5','1']); ax.set_yticks([0,.5,1],['0','0,5','1']); ax.tick_params(labelsize=7,pad=2)
            if row==0:ax.set_title(('D2Q9 · $u_x/U$','POD-Netz · $u_x/U$','Vektorfehler / $U$')[col])
            if row==1:ax.set_xlabel('$x/L$',labelpad=1)
            if col==0:ax.set_ylabel(('Vor Umkehr\n$y/L$','Nach Umkehr\n$y/L$')[row],size=9)
            if row==0:maps.append(im)
    german = FuncFormatter(lambda x,_: f'{x:g}'.replace('.',','))
    fig.colorbar(maps[0],cax=fig.add_subplot(gs[:2,2]),ticks=[-.8,0,.8],format=german)
    fig.colorbar(maps[2],ax=[maps[2].axes,fig.axes[-2]],location='right',fraction=.052,pad=.04,ticks=MaxNLocator(nbins=4),format=german)
    check=fig.add_subplot(gs[2,:])
    for y, (key, caption) in enumerate((('linear','Linear'),('quadratisch','Quadratik'),('pod_netz','Quadratik + Netz'))):
        small = 100*np.median([float(r['relativ']) for r in coarse_rows if r['gruppe']=='innen' and r['verfahren']==key])
        fine = 100*np.median([float(r['rel']) for r in fine_rows if r['gruppe']=='innen' and r['methode']==key])
        check.hlines(y,small,fine,color='#a9b7bd',lw=1.1)
        check.scatter(small,y,c=TEAL,s=28,label='D2Q9 33²' if y==0 else None,zorder=3)
        check.scatter(fine,y,c=RUST,s=28,marker='D',label='D2Q9 65²' if y==0 else None,zorder=3)
    check.axvline(2,color=INK,lw=1,ls='--',label='Feldbudget 2 %')
    check.set(xscale='log',xlim=(.075,23),ylim=(2.6,-.6),yticks=[0,1,2],yticklabels=['Linear','Quadratik','Quadratik + Netz'],
              xlabel='Median des relativen Feldfehlers [%], 16 Innenantriebe',title='Welche D2Q9-Referenz entscheidet über die Freigabe?')
    check.set_xticks([.1,.2,.5,1,2,5,10,20],['0,1','0,2','0,5','1','2','5','10','20'])
    check.legend(fontsize=7,loc='upper center',ncol=3,bbox_to_anchor=(.55,-.48))
    save(fig,root,'dynamik_kavitaet')


def kernels(data,root):
    fig, axes=plt.subplots(1,2,figsize=(8.2,3.32),layout='constrained',sharey=True)
    for ax,problem,title in zip(axes,('population','kavitaet'),('A   CP1/B · Populationen','B   CP2/2 · Deckelantrieb'),strict=True):
        cohorts=json.loads((data/(problem+'_kerne.json')).read_text())['gruppen']
        for offset,key,col,symbol,label in [(-.15,'innen',TEAL,'o','Trainingsbereich (16)'),(.15,'aussen',RUST,'D','Außenfälle (8)')]:
            x=[cohorts[key][kind]['max_score'] for kind in KEYS]
            ax.scatter(x,np.arange(7)+offset,c=col,marker=symbol,s=28,label=label,zorder=4)
        ax.axvline(1,ls='--',color=INK,lw=1.15)
        ax.set_xscale('log'); ax.set_title(title,loc='left'); ax.grid(axis='x',which='major',alpha=.24)
        ax.set_yticks(range(7),NAMES);ax.set_xlabel('Größter Budgetquotient $S$'); ax.tick_params(axis='y',length=0)
        ax.xaxis.set_minor_formatter(NullFormatter())
    axes[0].set_xlim(.005,65);axes[0].set_xticks([.01,.1,1,10],['0,01','0,1','1','10']); axes[0].invert_yaxis()
    axes[1].set_xlim(.55,4.5);axes[1].set_xticks([.6,1,2,3,4],['0,6','1','2','3','4']);axes[0].legend(loc='lower center',bbox_to_anchor=(.55,-.47),ncol=2,fontsize=8)
    save(fig,root,'dynamik_kerne')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--daten',type=Path,default=RESULTS)
    parser.add_argument('--wurzel',type=Path,default=LAB.parent)
    args=parser.parse_args()
    population(args.daten,args.wurzel);cavity(args.daten,args.wurzel);kernels(args.daten,args.wurzel)
