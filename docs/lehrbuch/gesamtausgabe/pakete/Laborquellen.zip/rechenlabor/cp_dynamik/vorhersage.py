"""One complete trajectory or field history from archived weights, with no solver calls."""
from argparse import ArgumentParser
from pathlib import Path

import numpy as np

from auswertung import RESULTS
from kernvergleich import KINDS, predict as kernel_predict, read_kernel
import kavitaet as cav
import populationen as pop


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument('--modelle', type=Path, default=RESULTS)
    commands = parser.add_subparsers(dest='problem', required=True)
    population = commands.add_parser('population', help='Zehn Populationsverläufe')
    population.add_argument('--v1', type=float, required=True)
    population.add_argument('--z2', type=float, required=True)
    population.add_argument('--verfahren', choices=('rbf_pod','affin',*KINDS),default='rbf_pod')
    cavity = commands.add_parser('kavitaet', help='Acht Geschwindigkeitsfelder')
    cavity.add_argument('--deckel', type=float, nargs=8, required=True)
    cavity.add_argument('--verfahren', choices=(*cav.METHODS,*KINDS),default='pod_netz')
    for command in (population,cavity):
        command.add_argument('--ausgabe', type=Path, required=True)
    args=parser.parse_args()
    is_pop=args.problem=='population'
    p=np.array([args.v1,args.z2] if is_pop else args.deckel)
    if is_pop:
        pop.initial(p)
    else:
        cav.histories(p)
    with np.load(args.modelle/(args.problem+'_modell.npz')) as model:
        if args.verfahren in KINDS:
            with np.load(args.modelle/(args.problem+'_kernmodelle.npz')) as bank:
                transform,weights=read_kernel(bank,args.verfahren)
            estimate=kernel_predict(args.problem,p,model,transform,weights)[0]
        else:
            estimate=(pop.predict if is_pop else cav.predict)(p,model,args.verfahren)[0]
    if not np.isfinite(estimate).all():
        raise ArithmeticError('Keine endliche Vorhersage für diese Eingabe.')
    if is_pop:
        data=dict(t=pop.TIMES,namen=np.array(pop.NAMES),population=estimate,v1=p[0],z2=p[1])
        interior=bool(np.all((p>=pop.LOW)&(p<=pop.HIGH)))
    else:
        data=dict(t_stern=np.arange(1,cav.BLOCKS+1)*2*cav.U,
                  xy_zellmitten=(np.arange(cav.N)+.5)/cav.N,geschwindigkeit_durch_U=estimate,
                  deckelfaktoren=p,U_referenz=cav.U,re_referenz=cav.RE)
        interior=bool(np.all(np.abs(p)<=1))
    data.update(verfahren=np.array(args.verfahren),im_trainingsbereich=interior)
    with args.ausgabe.open('wb') as file:
        np.savez_compressed(file,**data)
    print(f'{estimate.shape} Wertegitter, Eingabe im Trainingsbereich: {interior} · {args.ausgabe}')


if __name__=='__main__':
    main()
