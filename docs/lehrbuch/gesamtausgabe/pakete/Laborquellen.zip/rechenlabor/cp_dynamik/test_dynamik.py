"""Regression and evidence checks for surrogate outputs, reference solvers and all seven kernels."""
import csv
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

import numpy as np

from auswertung import HERE, RESULTS
import kavitaet as c
import populationen as p
import kernvergleich as k


class Dynamics(unittest.TestCase):
    def test_official_endpoint_and_second_integrator(self):
        nominal=p.reference([1.,1.])
        table=[p.cp1.CP1_TASK_B_TERMINAL_VALUES[name] for name in p.NAMES]
        np.testing.assert_allclose(nominal[-1],table,rtol=0,atol=2e-7)
        np.testing.assert_allclose(nominal,p.reference([1.,1.],'Radau'),rtol=0,atol=3e-8)

    def test_population_weights_and_budgets(self):
        with np.load(RESULTS/'population_modell.npz') as model, np.load(RESULTS/'population_bahnen.npz') as bank:
            for group in ('innen','nominal','aussen'):
                params,truth=bank[group+'_parameter'],bank[group+'_referenz']
                for kind in ('affin','rbf_pod'):
                    y=p.predict(params,model,kind)
                    np.testing.assert_allclose(y,bank[group+'_'+kind],rtol=1e-10,atol=1e-11)
                    np.testing.assert_array_equal(y[:,0],p.initial(params))
                    self.assertTrue((y>0).all())
                    self.check_csv('population_einzel',group,kind,p.measurements(y,truth)[-1])

    def test_independent_lattice_and_constant_drive(self):
        with TemporaryDirectory() as d:
            dst=Path(d); binary=c.build_cpp(dst)
            self.assertLess(c.comparison_with_scalar(binary,d),3e-13)
            native,meta=c.reference([1.,1.],binary,d,n=15,steps=30)
            # The fixed-lid entry point runs to t*=60*U/15. Its output ends with the final field.
            output=dst/'static.bin'
            subprocess.run([str(binary),'cavity','15','100','0',str(c.U),str(60*c.U/15),'0',str(output)],
                           capture_output=True,check=True)
            fixed=np.fromfile(output,dtype=np.float64).reshape(-1,15,15,2)[-1]
            np.testing.assert_allclose(native[-1],fixed,rtol=0,atol=2e-13)
            self.assertLess(meta['max_mass_drift'],1e-11)

    def test_cavity_field_weights_budgets_and_causality(self):
        with np.load(RESULTS/'kavitaet_modell.npz') as model, np.load(RESULTS/'kavitaet_felder.npz') as bank:
            for method in c.METHODS:
                for group in ('innen','profile','aussen'):
                    drive=bank[group+'_deckel']
                    guess=c.predict(drive,model,method); truth=bank[group+'_referenz']
                    np.testing.assert_allclose(guess,bank[group+'_'+method],rtol=1e-10,atol=1e-12)
                    dif=truth-guess
                    peak=np.sqrt((dif[...,0]**2+dif[...,1]**2)).reshape(len(dif),-1).max(axis=1)
                    rel=np.array([np.linalg.norm(a)/np.linalg.norm(b) for a,b in zip(dif,truth,strict=True)])
                    self.check_csv('kavitaet_einzel',group,method,np.maximum(peak/.05,rel/.02))
                np.testing.assert_array_equal(c.predict(np.zeros(8),model,method),0.)
                original=bank['innen_deckel'][:1]; variant=original.copy(); variant[:,4:]*=-1
                y=c.predict(np.concatenate((original,variant)),model,method)
                np.testing.assert_array_equal(y[0,:4],y[1,:4])

    def check_csv(self,name,group,method,scores):
        with (RESULTS/(name+'.csv')).open() as stream:
            rows=[r for r in csv.DictReader(stream) if r['gruppe']==group and r['verfahren']==method]
        self.assertEqual([int(r['fall']) for r in rows],list(range(len(scores))))
        np.testing.assert_allclose(scores,[float(r['score']) for r in rows],atol=4e-9,rtol=3e-8)

    def test_all_seven_saved_outputs_and_scores(self):
        for task,groups,ending,datafile,metric in (
                ('population',('innen','nominal','aussen'),'_parameter','population_bahnen',p.measurements),
                ('kavitaet',('innen','profile','aussen'),'_deckel','kavitaet_felder',c.metrics)):
            totals=json.loads((RESULTS/(task+'_kerne.json')).read_text())['gruppen']
            with (np.load(RESULTS/(datafile+'.npz')) as bank,
                  np.load(RESULTS/(task+'_modell.npz')) as common,
                  np.load(RESULTS/(task+'_kernmodelle.npz')) as models):
                for kind in k.KINDS:
                    basis,weights=k.read_kernel(models,kind)
                    for group in groups:
                        params=bank[group+ending]
                        output=k.predict(task,params,common,basis,weights)
                        scores=metric(output,bank[group+'_referenz'])[-1]
                        self.check_csv(task+'_kerne_einzel',group,kind,scores)
                        self.assertEqual(int(np.sum(scores<=1)),totals[group][kind]['bestanden'])
                    if task=='kavitaet':
                        drive=bank['innen_deckel'][:1]; other=drive.copy();other[:,3:]+=.29
                        pair=k.predict(task,np.concatenate((drive,other)),common,basis,weights)
                        np.testing.assert_allclose(pair[0,:3],pair[1,:3],rtol=0,atol=2e-14)
                        np.testing.assert_allclose(k.predict(task,np.zeros(8),common,basis,weights),0,rtol=0,atol=2e-14)

    def test_cli_and_invalid_inputs(self):
        with TemporaryDirectory() as d:
            dst=Path(d)/'vorhersage.npz'
            for args,key,shape in [(('population','--v1','1','--z2','1','--verfahren','laplace'),'population',(401,10)),
                                   (('kavitaet','--deckel',*['0.2']*8,'--verfahren','hankel'),'geschwindigkeit_durch_U',(8,33,33,2))]:
                subprocess.run([sys.executable,str(HERE/'vorhersage.py'),*args,'--ausgabe',str(dst)],check=True,capture_output=True)
                with np.load(dst) as data:
                    self.assertEqual(data[key].shape,shape);self.assertTrue(np.isfinite(data[key]).all())
        for invalid in ([0.,1.],[np.nan,1.],[1.]):
            with self.assertRaises(ValueError):p.initial(invalid)
        for invalid in ([1.]*7,[float('inf')]*8):
            with self.assertRaises(ValueError):c.histories(invalid)


if __name__=='__main__':
    unittest.main(verbosity=2)
