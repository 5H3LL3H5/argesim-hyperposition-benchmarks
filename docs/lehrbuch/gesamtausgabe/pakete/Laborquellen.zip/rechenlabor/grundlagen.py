"""Nachrechenbare Gegenproben aus dem mathematischen Grundlagenteil."""
import cmath
import math
import statistics
from fractions import Fraction as Q


def skalen_und_lineare_algebra():
    assert Q(2, 4) == Q(1, 2)
    u = math.exp(-0.5)
    assert math.isclose(30 * u, 18.1959197914, rel_tol=1e-11)
    assert math.isclose(20 + 40 / math.e, 34.7151776469, rel_tol=1e-11)

    x = (Q(2, 3), Q(1, 3))
    assert (2 * x[0] - x[1], -x[0] + 2 * x[1]) == (1, 0)
    assert math.hypot(3, 4) == 5 and max(3, 4) == 4
    epsilon, delta = Q(1, 100), Q(2, 1000)
    second = (epsilon + delta) / epsilon
    first = 2 - second
    assert (first, second) == (Q(4, 5), Q(6, 5))
    assert first + (1 + epsilon) * second == 2 + epsilon + delta
    print(f"Skalierter Fühler: Überschuss bei halber Zeitkonstante {30*u:.6f} K")


def analysis_und_moden():
    step = Q(1, 4)
    assert 2 * step - 4 * step**2 / 2 == Q(3, 8)
    for h in (Q(1, 4), Q(1, 2)):
        linear = 1 - h
        quadratic = linear + h*h/2
        exact = math.exp(-h)
        assert linear < exact < quadratic
        assert quadratic - exact <= h**3 / 6

    def apply(x):
        a, b = x
        return -3*a + 2*b, 2*a - 3*b

    assert apply((1, 1)) == (-1, -1) and apply((1, -1)) == (-5, 5)
    t = 0.2
    slow, fast = 2*math.exp(-t), math.exp(-5*t)
    solution = (slow + fast, slow - fast)
    assert math.isclose(sum(solution), 4*math.exp(-t), rel_tol=1e-14)
    assert math.isclose(solution[0] - solution[1], 2*math.exp(-5*t), rel_tol=1e-14)
    assert 1 - 5*Q(1, 2) == Q(-3, 2)


def fehler_und_nullstellen():
    errors = [math.exp(-1) - (1 - 1/n)**n for n in (10, 20, 40)]
    first, second = [math.log2(a/b) for a, b in zip(errors, errors[1:])]
    assert 1.03 < first < 1.04 and 1.01 < second < 1.02
    tiny = 2.0**-54
    assert 1.0 + tiny == 1.0
    assert math.sqrt(1.0 + tiny) - 1.0 == 0.0
    difference = tiny / (math.sqrt(1.0 + tiny) + 1.0)
    assert difference == 2.0**-55
    print(f"Euler: beobachtete Ordnungen {first:.4f} und {second:.4f}; "
          f"rationalisierte Differenz {difference:.6e}")

    def g(s):
        return s*s - 3

    left, right = Q(1), Q(2)
    for _ in range(2):
        trial = (left + right) / 2
        if g(trial) < 0:
            left = trial
        else:
            right = trial
    assert (left, right) == (Q(3, 2), Q(7, 4))
    assert g(left) < 0 < g(right)
    newton = Q(2) - g(Q(2)) / 4
    assert newton == right
    assert abs((left+right)/2 - math.sqrt(3)) <= (right-left)/2

    first_iterate = Q(2, 3)
    second_iterate = (first_iterate + 2) / 3
    assert 1 - second_iterate == (second_iterate - first_iterate) / 2 == Q(1, 9)


def felder_und_daten():
    # Schwache Ableitung des Dreiecks. Auf jeder Halbzelle ist sie konstant.
    assert Q(1, 2)*2**2 + Q(1, 2)*(-2)**2 == 4
    projection_error = Q(3, 4)
    assert 1 + projection_error**2 == Q(5, 4)**2
    assert projection_error / Q(5, 4) == Q(3, 5)

    for n, first, second in ((4, 1, 5), (6, 1, 7)):
        for j in range(n):
            left = cmath.exp(2j * math.pi * first * j / n)
            right = cmath.exp(2j * math.pi * second * j / n)
            assert abs(left - right) < 8e-15

    errors = [1, 2, 2, 7, 8]
    assert statistics.mean(errors) == 4 and statistics.median(errors) == 2
    assert Q(sum(e*e for e in errors), len(errors)) == Q(122, 5)
    data = ((1, 1), (2, 3), (3, 4))
    a = Q(sum(x*y for x,y in data), sum(x*x for x,_y in data))
    assert a == Q(19, 14)
    assert sum(x*(a*x-y) for x,y in data) == 0
    print("Schwache Ableitung des Dreiecks, modaler Fehler, Aliasing und Kleinste-Quadrate-Fit geprüft.")


if __name__ == "__main__":
    skalen_und_lineare_algebra()
    analysis_und_moden()
    fehler_und_nullstellen()
    felder_und_daten()
