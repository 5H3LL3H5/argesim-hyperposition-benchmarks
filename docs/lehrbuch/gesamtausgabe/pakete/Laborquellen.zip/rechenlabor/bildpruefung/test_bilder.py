"""Regression tests for the scored measurements, figure orientation and study populations."""
import collections
import csv
import math
import unittest

import fitz
import numpy as np

from versuche import HERE, OUT, ROOT, classify, weights


def table(stem):
    with (OUT/f"{stem}.csv").open(encoding="utf8") as stream:
        return list(csv.DictReader(stream))


def page(name):
    return fitz.open(ROOT/"druck"/f"{name}.pdf")[0]


class Vertrag(unittest.TestCase):
    def test_budgetgrenze_und_ausfaelle(self):
        contract=[("1->2",1.,.25),("2->3",2.,.25)]
        self.assertEqual(classify("complete",[("1->2",1.25),("2->3",2.)],contract),("pass",1))
        self.assertEqual(classify("complete",[("1->2",1.5),("2->3",2.)],contract),("accuracy_miss",2))
        for reason in ("timeout","solver_error"):
            self.assertEqual(classify(reason,[],contract),(reason,None))
        for bad in [[],[("2->3",1.),("1->2",2.)],[("1->2",1.),("1->2",2.)]]:
            self.assertEqual(classify("complete",bad,contract),("event_mismatch",None))
        self.assertEqual(classify("complete",[("1->2",math.nan),("2->3",2.)],contract),("invalid_output",None))
        with self.assertRaises(ValueError):classify("complete",[],[("1->2",1.,0.)])

    def test_drei_stoesse(self):
        rows=table("c12_bahnen")
        self.assertEqual([float(r["t_s"]) for r in rows],[0,1,2,3,4])
        for i in range(3):
            point=rows[i+1]
            gap=float(point[f"x{i+2}_m"])-float(point[f"x{i+1}_m"])
            self.assertEqual(gap,1.)
            self.assertEqual(float(point[f"v{i+2}_m_s"]),1.)
        self.assertEqual([float(rows[-1][f"x{j}_m"]) for j in range(1,5)],[1,3,5,7])

    def test_16_takte(self):
        rows=table("c09_takte")
        self.assertEqual({int(r["k"]) for r in rows},set(range(16)))
        for k in range(16):
            block=[r for r in rows if int(r["k"])==k]
            self.assertEqual(len(set(r["u_regler_V"] for r in block)),1)
            self.assertAlmostEqual(float(block[0]['u_wirksam_V'])-float(block[0]['u_regler_V']),.1 if k>=4 else 0.)

    def test_gitter_und_gewichte(self):
        rows=table("c19r_projektion")
        for name,nx,ny,rule in [("Quelle",33,17,"Zentren fest"),("Brunnen",34,18,"Flächen fest")]:
            group=[r for r in rows if r['h']=='0.5' and r['regel']==rule and r['ort']==name]
            self.assertEqual((int(group[0]['nx']),int(group[0]['ny'])),(nx,ny))
            self.assertEqual([float(r['gewicht']) for r in group], [1.] if nx==33 else [.25]*4)
        with self.assertRaises(ValueError):weights(-.1,0.,np.arange(3.),np.arange(3.))

    def test_hysterese_und_ast(self):
        phases=table("c05_phasen")
        for stage,threshold in enumerate((5.8,2.5,5.8),1):
            tail=[r for r in phases if int(r["phase"])==stage][-1]
            head=next(r for r in phases if int(r["phase"])==stage+1)
            for key in ("time_s","y1","y2"): self.assertAlmostEqual(float(tail[key]),float(head[key]),places=10)
            self.assertAlmostEqual(float(head["y1"]),threshold,places=7)
        samples=table("c21_quelle")
        self.assertLess(max(float(r["z_V"]) for r in samples),.1)
        self.assertGreater(max(float(r["u0_V"]) for r in samples),.99)
        same_b=[r for r in table("c21_kennlinie") if abs(float(r["b_V"])-.2)<1e-10]
        self.assertEqual(len(same_b),2)
        self.assertGreater(abs(float(same_b[0]["z_V"])-float(same_b[1]["z_V"])),.15)

    def test_front_und_profile(self):
        rows=table("456_arbeit_fehler"); counts=collections.Counter(r["status"] for r in rows)
        self.assertEqual(counts, {'event_mismatch': 13, 'timeout': 81, 'pass': 224, 'accuracy_miss': 126, 'solver_error': 12})
        costs=collections.defaultdict(list)
        for case in {r["aufgabe"] for r in rows}:
            case_rows=[r for r in rows if r["aufgabe"]==case]
            self.assertEqual(len(case_rows),57)
            numeric=[r for r in case_rows if r["score"]!=""]
            self.assertEqual({r["status"] for r in numeric} - {"pass","accuracy_miss"},set())
            fastest=min((float(r['ms']) for r in case_rows if r["status"]=="pass"),default=None)
            for r in numeric:
                t,s=float(r['ms']),float(r['score'])
                dominated=any(float(q["ms"])<=t and float(q["score"])<=s and
                              (float(q["ms"])<t or float(q["score"])<s) for q in numeric)
                self.assertEqual(int(r["pareto"]),int(not dominated))
                if r["status"]=="pass":
                    costs[(r['verfahren'],r['quantum'])].append(t/fastest)
            if case=="C05":self.assertIsNone(fastest)
        for p in table("57_leistungsprofile"):
            self.assertEqual(int(p["nenner"]),8)
            self.assertEqual(int(p["anzahl"]),sum(x<=float(p["tau"]) for x in costs[p["verfahren"],p["quantum"]]))

    def test_seitenorientierung(self):
        for name,left,right in [
            ('steifigkeit','Exakte Moden','Schnelle'),
            ('fno_transfer_zeit','Lastpuls','Bolus'),
            ('fno_transfer_saite','Nominelle Anregung','Neue Frequenz'),
            ('cp2_operator_ghia','Vertikale Mittellinie','Horizontale Mittellinie'),
            ('studie_fno_kavitaet_profile','Vertikale Mittellinie','Horizontale Mittellinie'),
        ]:
            sheet=page(name)
            for term,half in ((left,0),(right,1)):
                matches=sheet.search_for(term)
                self.assertTrue(matches,(name,term))
                self.assertEqual(int(matches[0].x0>sheet.rect.width/2),half)
        sheet=page('t1_mol')
        self.assertEqual(sheet.get_text().splitlines()[:4],["8","16","32","64"])
        self.assertTrue(page('t1_stern').search_for("Eingänge am Deckel"))

    def test_native_kavitaet(self):
        images=page("bild_cp2_feingitter").get_images(full=True)
        self.assertEqual(sorted((im[2],im[3]) for im in images if im[2]==im[3]),
                         [(n,n) for n in (17,65,257,421)])
        with np.load(OUT/'cp2_anlauf.npz') as data:
            for size in (17,257):
                grid=data[f'n{size}']
                self.assertEqual(grid.shape,(size,size))
                np.testing.assert_array_equal(grid[-1],np.ones(size))
                self.assertTrue(np.all(np.isfinite(grid)))


if __name__=="__main__":
    unittest.main()
