"""Rebuild the revised original figures from the original data and vector artwork."""
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from xml.etree import ElementTree as ET
import os
import subprocess

import fitz
import matplotlib as mpl

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def module(name, path):
    spec = spec_from_file_location(name, path)
    result = module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def add_panel_titles():
    name = "studie_fno_kavitaet_profile"
    titles = ("A   Vertikale Mittellinie", "B   Horizontale Mittellinie")
    source = HERE / "vorlagen"
    raw = (source / f"{name}.svg").read_text()
    old = ET.fromstring(raw)
    w, h = map(float, old.attrib["viewBox"].split()[2:])
    band = 17.
    labels = "".join(f'<text x="{x:.3f}" y="11" font-family="DejaVu Sans" font-size="10" font-weight="bold" fill="#173549">{t}</text>' for x,t in zip((29,w*.55),titles,strict=True))
    nested = raw[raw.index("<svg "):]
    svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}pt" height="{h+band}pt" viewBox="0 0 {w} {h+band}">{labels}<g transform="translate(0,{band})">{nested}</g></svg>'
    (ROOT/"abbildungen"/f"{name}.svg").write_text(svg)
    with fitz.open(source/f"{name}.pdf") as original, fitz.open() as revised:
        page = revised.new_page(width=w,height=h+band)
        page.show_pdf_page(fitz.Rect(0,band,w,h+band),original,0)
        from matplotlib.font_manager import FontProperties, findfont
        page.insert_font(fontname="dbold", fontfile=findfont(FontProperties(family="DejaVu Sans", weight="bold")))
        for x,label in zip((29,w*.55),titles,strict=True):
            page.insert_text((x,11),label,fontname="dbold",fontsize=10,color=(.09,.21,.29))
        revised.save(ROOT/"druck"/f"{name}.pdf",deflate=True,no_new_id=True)


def main():
    with mpl.rc_context():
        basics = module("zeichengrundlagen",ROOT/"abbildungen/zeichnen.py")
        basics.raum(); basics.stern()
    for name in ("t1_mol","t1_stern"):
        subprocess.run(["inkscape",str(ROOT/"abbildungen"/f"{name}.svg"),
                        "--export-type=pdf","--export-filename="+str(ROOT/"druck"/f"{name}.pdf")],check=True,
                       env=os.environ | {"SOURCE_DATE_EPOCH":"1795478400","TZ":"UTC"})
    style={"font.size":9.1,"axes.titlesize":10,"font.family":"DejaVu Sans","axes.spines.top":False,
           "axes.spines.right":False,"text.color":"#173549","svg.hashsalt":"argesim-bildpruefung",
           "pdf.fonttype":42,"svg.fonttype":"none"}
    with mpl.rc_context(style):
        transfer=module("zeichentransfer",ROOT/"rechenlabor/fno_transfer/zeichnen.py")
        transfer.histories(); transfer.rope()
        cp2=module("zeichencp2",ROOT/"rechenlabor/cp2_operatoren/zeichnen.py")
        cp2.ghia(ROOT/"rechenlabor/cp2_operatoren/messung",ROOT)
    add_panel_titles()


if __name__=="__main__":
    main()
