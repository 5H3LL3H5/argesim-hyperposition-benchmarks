"""Reproduce the physical traces, grid geometry and audit of the 456 stored runs."""
from collections import Counter
from itertools import groupby
from pathlib import Path
import csv
import json
import math
import sys

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OUT=HERE/"messung"
sys.path[:0]=[str(ROOT/"beispiele"),str(HERE.parent/"messplanung/projekt")]
import c05
from argesim_benchmarks.models import c09_fuzzy_tanks as tank
from argesim_benchmarks.models import c21_state_events as diode
from argesim_benchmarks.models import cp2_parallel_and_distributed as cavity
from argesim_benchmarks.models.c12_collision import c12_collision_processes as balls


def csv_write(path, rows):
    with path.open("w",newline="",encoding="utf-8") as f:
        out=csv.DictWriter(f,fieldnames=list(rows[0]));out.writeheader();out.writerows(rows)


def classify(status, observations, contract):
    """Check termination, typed ordered observations, then numerical budgets."""
    if status in ("timeout","solver_error"):
        return status,None
    if status!="complete":
        raise ValueError("unknown termination status")
    if not contract or any(not math.isfinite(q) or not math.isfinite(b) or b<=0 for _,q,b in contract):
        raise ValueError("invalid reference contract")
    if [name for name,_ in observations]!=[name for name,_,_ in contract]:
        return "event_mismatch",None
    if any(not math.isfinite(q) for _,q in observations):
        return "invalid_output",None
    score=max(abs(val-ref)/b for (_,val),(_,ref,b) in zip(observations,contract,strict=True))
    return ("pass" if score<=1 else "accuracy_miss"),score


def hysteresis():
    switches,final=c05.schaltfolge()
    rows=[];start=(4.2,.3);t0=0
    for i,t1 in enumerate([t for t,_ in switches]+[3.5]):
        c2,c4,level,direction=c05.MODEN[i%2]
        stop=t1-t0
        times=np.unique(np.r_[0.,np.geomspace(1e-10,min(stop,12/c05.A),100),np.linspace(0,stop,260)])
        for tau in times:
            x,y=c05.phase(tau,start,c2,c4)
            rows.append(dict(phase=i+1,time_s=t0+tau,phase_us=tau*1e6,y1=x,y2=y))
        start=c05.phase(stop,start,c2,c4)
        if i<len(switches):assert abs(start[0]-level)<1e-7
        t0=t1
    np.testing.assert_allclose(start,final,atol=1e-13)
    csv_write(OUT/"c05_phasen.csv",rows)
    return dict(switch_s=[t for t,sgn in switches],end=start)


def collisions():
    params=balls.C12Parameters(e=1.,v0=1.,a=1.,max_time=4.)
    radius=params.d/2
    n,_,_,history=balls._simulate(params)
    assert n==3
    position=np.arange(4,dtype=float)*(1+2*radius)
    vel=np.array(history[0][2])
    t0=0.
    rows=[]
    for t,gaps,next_v in [*history,(4.,None,history[-1][2])]:
        position=position+vel*(t-t0);vel=np.asarray(next_v)
        if gaps is not None:
            np.testing.assert_allclose(np.diff(position)-2*radius,gaps,atol=1e-13)
        assert np.isclose(vel.sum(),1) and np.isclose(vel@vel/2,.5)
        rows.append(dict(t_s=t,**{f"x{i+1}_m":x for i,x in enumerate(position)},**{f"v{i+1}_m_s":v for i,v in enumerate(vel)}))
        t0=t
    np.testing.assert_allclose([r['t_s'] for r in rows],[0,1,2,3,4])
    csv_write(OUT/"c12_bahnen.csv",rows)
    return dict(radius_m=radius,contact_s=[1,2,3],momentum=1,energy=.5)


def tanks():
    state=np.array([.503,.30])
    rows=[];taps=[];balance=0.
    for k in range(16):
        u=tank.c09_pfc_control(.30-state[1],state[1])
        applied=u+(.1 if k>=4 else 0.)
        def rhs(t,z):
            d=tank.c09_plant_rhs(*z[:2],applied)
            p=tank.C09PlantParameters()
            out=(1.2 if z[1]<.16 else 1)*p.c2*p.v2*math.sqrt(abs(z[1]))*(1 if z[1]>=0 else -1)
            return (*d,p.c1*applied-out)
        z=solve_ivp(rhs,(k,k+1),[*state,balance],method="DOP853",rtol=1e-12,atol=1e-14,dense_output=True,max_step=.15)
        assert z.success
        taps.append(dict(k=k,u_regler_V=u,u_wirksam_V=applied))
        sample=np.linspace(k,k+1,21)
        for t,(h1,h2,net) in zip(sample,z.sol(sample).T,strict=True):
            assert abs(h1+h2-.803-net)<5e-14
            rows.append(dict(k=k,t_s=t,h1_m=h1,h2_m=h2,u_regler_V=u,u_wirksam_V=applied))
        state=z.y[:2,-1];balance=z.y[2,-1]
    independent=tank.simulate_c09(tank.C09Controller.PFC,t_bound=16.,sample_time=1.,output_step=1.,disturbance_time=4.,disturbance=.1)
    levels=np.array([(x["h1_m"],x["h2_m"]) for x in rows if x["t_s"]==x["k"]+1])
    delta=float(np.max(np.abs(levels-np.column_stack((independent.h1,independent.h2))[1:])))
    assert len(taps)==16 and delta<1e-6
    assert abs(taps[0]['u_regler_V']-0.13833333333333334)<1e-12
    csv_write(OUT/"c09_takte.csv",rows)
    return dict(ticks=16,initial_V=taps[0]['u_regler_V'],end_m=state.tolist(),max_delta_project_rk4_m=delta)


def diode_model():
    p=diode.C21RLCDiodeParameters()
    def gain(z):
        return p.r2*p.i_s*np.expm1(np.maximum(z,0)/p.u_t)
    def load(z):return z-gain(z)
    zstar=p.u_t*math.log(p.u_t/(p.r2*p.i_s))
    bstar=float(load(zstar))
    low=brentq(lambda z:load(z)-.2,0,zstar)
    high=brentq(lambda z:load(z)-.2,zstar,.38)
    assert abs(low-.200446)<1e-6 and abs(high-.352082)<1e-6
    def inverse(b):
        if b<=0:return b
        return brentq(lambda z:load(z)-b,0,zstar,xtol=5e-15)
    def rhs(t,x):
        i,uc=x;b=uc+p.r2*i;z=inverse(b)
        return [(diode.c21_rlc_input(t)-p.r1*i-z)/p.l, i/p.c]
    t=np.linspace(0,500e-6,10001)
    sol=solve_ivp(rhs,(0,t[-1]),[0.,0.],method="Radau",t_eval=t,rtol=5e-9,atol=[2e-13,2e-11],max_step=1/(16*150000))
    assert sol.success
    b=sol.y[1]+p.r2*sol.y[0];real=np.array([inverse(float(w)) for w in b])
    residual=float(np.max(np.abs(load(real)-b)))
    events=int(np.count_nonzero((real[1:-1]>0)!=(real[2:]>0)))
    assert residual<1e-12 and real.max()<.1 and events==149
    curve=np.unique(np.r_[np.linspace(-.095,.355,850),zstar,low,high])
    csv_write(OUT/"c21_kennlinie.csv",[dict(z_V=z,b_V=load(z)) for z in curve])
    csv_write(OUT/"c21_quelle.csv",[dict(t_s=tt,u0_V=diode.c21_rlc_input(tt),b_V=w,z_V=z) for tt,w,z in zip(t,b,real,strict=True)])
    return dict(z_falte_V=zstar,b_falte_V=bstar,wurzeln_V=[low,high],max_z_V=float(np.max(real)),residuum_V=residual,wechsel=events)


def weights(x,y,xx,yy):
    def support(s,a):
        j=int(np.searchsorted(a,s))
        if j<len(a) and a[j]==s:return [(j,1.)]
        if not 0<j<len(a):raise ValueError("outside center interpolation domain")
        q=(s-a[j-1])/(a[j]-a[j-1]);return [(j-1,1-q),(j,q)]
    points=[(xx[i],yy[j],p*q) for i,p in support(x,xx) for j,q in support(y,yy)]
    np.testing.assert_allclose(np.sum([[a*w,b*w,w] for a,b,w in points],axis=0),[x,y,1.],atol=1e-14)
    return points


def grids():
    records=[];meshes=[]
    original=json.loads((HERE.parent/"cp2_genauigkeit/transport_feste_raender.json").read_text())
    for h,ref in zip((1.,.5,.25),original["rows"],strict=True):
        for rule in ("Zentren fest","Flächen fest"):
            if rule=="Flächen fest":
                xx=np.arange(-4.5+h/2,12.5,h);yy=np.arange(-4.5+h/2,4.5,h)
                assert [len(yy),len(xx)]==ref['shape_yx']
            else:
                xx=np.arange(-4,12+h/2,h);yy=np.arange(-4,4+h/2,h)
            faces=[xx[0]-h/2,xx[-1]+h/2,yy[0]-h/2,yy[-1]+h/2]
            meshes.append(dict(regel=rule,h=h,shape_xy=[len(xx),len(yy)],faces=faces))
            for label,x in [('Quelle',0.),('Brunnen',5.)]:
                for a,b,w in weights(x,0,xx,yy):
                    records.append(dict(regel=rule,h=h,nx=len(xx),ny=len(yy),ort=label,x_m=a,y_m=b,gewicht=w))
    csv_write(OUT/"c19r_projektion.csv",records)
    return meshes


def cavity_field(n,steps):
    vel=cavity.CP2_LBM_VELOCITIES;opp=cavity.CP2_LBM_REVERSE
    omega=cavity.cp2_lbm_relaxation(n,u0_x=.1,reynolds=1000.)
    f=np.broadcast_to(np.array(cavity.CP2_LBM_WEIGHTS)[:,None,None],(9,n,n)).copy()
    def macros(pops):
        rho=pops.sum(axis=0); assert np.all(rho>0)
        return rho,(pops[1]+pops[5]+pops[8]-pops[3]-pops[6]-pops[7])/rho,(pops[2]+pops[5]+pops[6]-pops[4]-pops[7]-pops[8])/rho
    for _ in range(steps):
        rho,ux,uy=macros(f);s=ux**2+uy**2
        result=np.empty_like(f)
        for j,((dx,dy),w,reverse) in enumerate(zip(vel,cavity.CP2_LBM_WEIGHTS,opp,strict=True)):
            cu=dx*ux+dy*uy
            collided=f[j]-omega*(f[j]-w*rho*(1+3*cu+4.5*cu**2-1.5*s))
            collided[0,:]=f[reverse,0,:]
            collided[:,0]=f[reverse,:,0];collided[:,-1]=f[reverse,:,-1]
            collided[-1]=w*rho[-1]*(1+.3*dx+.045*dx*dx-.015)
            sy=slice(max(0,-dy),min(n,n-dy));sx=slice(max(0,-dx),min(n,n-dx))
            ty=slice(max(0,dy),min(n,n+dy));tx=slice(max(0,dx),min(n,n+dx))
            result[j]=collided;result[j,ty,tx]=collided[sy,sx]
        f=result
    rho,ux,uy=macros(f)
    return f,np.hypot(ux,uy)/.1


def cavity_check():
    meta={}
    arrays={}
    for n in (17,257):
        steps=n-1
        populations,field=cavity_field(n,steps)
        field[-1]=1  # prescribed macroscopic velocity for the official output.
        arrays[f'n{n}']=field
        if n==17:
            reference=cavity.cp2_lbm_initial_state(n)
            omega=cavity.cp2_lbm_relaxation(n,u0_x=.1,reynolds=1000)
            for _ in range(steps):
                reference=cavity.cp2_lbm_step(reference,n,omega,.1)
            err=np.max(np.abs(populations-np.asarray(reference).transpose(2,0,1)))
            assert err<5e-14
            check=cavity.cp2_lbm_velocity_magnitude(reference,reference_speed=.1,driving_speed=.1)
            np.testing.assert_allclose(field,check,atol=1e-13)
            meta['population_delta17']=float(err)
        assert np.isfinite(field).all()
    np.savez_compressed(OUT/'cp2_anlauf.npz',**arrays)
    return meta|dict(Re=1000,U=.1,t_star=.1,grids_steps=[[17,16],[257,256]])


def run_matrix():
    with (ROOT/"daten/qss-extension.csv").open() as f:rows=list(csv.DictReader(f))
    cases=sorted({r["case"] for r in rows})
    configs=sorted({(r["method"],r["quantum_factor"]) for r in rows})
    assert len(rows)==456 and len(cases)==8 and len(configs)==57
    assert len(set((r["case"],r["method"],r["quantum_factor"]) for r in rows))==456
    audit=[];profiles=[]
    for case in cases:
        group=[r for r in rows if r["case"]==case]
        usable=[];passes=[]
        for r in group:
            timed=r["status"] in ("pass","accuracy_miss")
            point=(float(r["median_ms"]),float(r["error_over_limit"])) if timed else None
            if timed:
                assert point[0]>0 and point[1]>=0 and (point[1]<=1)==(r["status"]=="pass")
                usable.append(point)
            if r["status"]=="pass":passes.append(point[0])
        for r in group:
            numeric=r["status"] in ("pass","accuracy_miss")
            ms=float(r["median_ms"]) if numeric else None
            s=float(r["error_over_limit"]) if numeric else None
            pareto=numeric and not any(a<=ms and b<=s and (a<ms or b<s) for a,b in usable)
            relative=ms/min(passes) if r["status"]=="pass" else None
            audit.append(dict(aufgabe=case,verfahren=r["method"],quantum=r["quantum_factor"],status=r["status"],ms=ms,score=s,pareto=int(pareto),zeitverhaeltnis=relative))
    for method,q in configs:
        part=[r for r in audit if (r["verfahren"],r["quantum"])==(method,q)]
        ratio=sorted(r["zeitverhaeltnis"] for r in part if r["zeitverhaeltnis"] is not None)
        for tau in sorted({1.,*ratio}):
            profiles.append(dict(verfahren=method,quantum=q,tau=tau,anzahl=sum(v<=tau for v in ratio),nenner=len(cases)))
    csv_write(OUT/"456_arbeit_fehler.csv",audit);csv_write(OUT/"57_leistungsprofile.csv",profiles)
    return dict(status=dict(Counter(r["status"] for r in rows)),cases=cases,configs=len(configs),n_numeric=sum(r['score'] is not None for r in audit),on_front=sum(r['pareto'] for r in audit))


def main():
    OUT.mkdir(exist_ok=True)
    summary=dict(c05=hysteresis(),c12=collisions(),c09=tanks(),c21=diode_model(),c19r=grids(),cp2=cavity_check(),matrix=run_matrix())
    (OUT/"pruefwerte.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False))
    print('C05, C12, C09, C21, C19R, CP2 und 456 Archivläufe geprüft.')

if __name__=="__main__":
    main()
