"""Draw the chapter figures from the numeric traces stored alongside this script."""
from collections import defaultdict
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import PowerNorm
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch
from matplotlib.ticker import FixedLocator, NullLocator, FuncFormatter
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DATA = HERE / "messung"
INK, BLUE, TEAL, ORANGE, GREY = "#173549", "#286192", "#00796b", "#b0472e", "#71838e"
PALETTE = [BLUE, ORANGE, TEAL, "#784473"]
plt.rcParams.update({
    "font.size": 9, "font.family": "DejaVu Sans", "text.color": INK,
    "axes.labelcolor": INK, "axes.titlecolor": INK, "axes.titlesize": 10,
    "axes.titleweight": "bold", "axes.spines.top": False, "axes.spines.right": False,
    "legend.fontsize": 8, "legend.frameon": False, "svg.fonttype": "none",
    "pdf.fonttype": 42, "svg.hashsalt": "argesim-bildrevision-913",
})


def save(fig, slug):
    for folder, ext, metadata in [
        ("druck", "pdf", {"CreationDate": None}), ("abbildungen", "svg", {"Date": None})
    ]:
        fig.savefig(ROOT / folder / f"bild_{slug}.{ext}", dpi=240, metadata=metadata)
    plt.close(fig)


def numbers(stem):
    return np.genfromtxt(DATA / f"{stem}.csv", delimiter=",", names=True, encoding="utf8")


def records(stem):
    with (DATA / f"{stem}.csv").open(encoding="utf8") as stream:
        return list(csv.DictReader(stream))


def gate():
    fig, ax = plt.subplots(figsize=(7, 3.15), layout="constrained")
    ax.set(xlim=(0, 1), ylim=(0, 1)); ax.axis("off")
    rows = [
        ("Lauf regulär beendet?", "Zeitlimit / Solverfehler"),
        ("Ereignisse vollständig und geordnet?", "Ereignisvertrag verletzt"),
        ("Alle Messwerte endlich?", "Ungültiger Messwert"),
        ("Größter Budgetanteil S ≤ 1?", "Genauigkeitsbudget verfehlt"),
    ]
    levels = [.89, .695, .50, .305]
    def box(x, y, w, label, foreground, background):
        ax.add_patch(FancyBboxPatch((x,y-.052),w,.104,boxstyle="round,pad=0.012",
                                    edgecolor=foreground,facecolor=background,lw=1))
        ax.text(x+w/2,y,label,ha="center",va="center",color=foreground,fontsize=9.1)
    def arrow(x1,y1,x2,y2):
        ax.annotate("",(x2,y2),(x1,y1),arrowprops=dict(arrowstyle="->",lw=.95,color=GREY))
    for i, ((question,reject), y) in enumerate(zip(rows,levels,strict=True)):
        box(.035,y,.47,question,INK,"#eef4f5"); box(.674,y,.294,reject,ORANGE,"#fbf0eb")
        arrow(.522,y,.654,y); ax.text(.587,y+.016,"nein",ha="center",fontsize=8,color=ORANGE)
        arrow(.27,y-.066,.27,y-.137)
        ax.text(.288,y-.112,"ja",fontsize=8,color=TEAL)
    box(.115,.11,.31,"Budget eingehalten",TEAL,"#e1f1eb")
    save(fig,"abnahme")


def phase():
    r=numbers("c05_phasen")
    fig,(a,b)=plt.subplots(1,2,figsize=(7.15,2.85),layout="constrained")
    for phase_number in np.unique(r['phase']):
        sub=r[r['phase']==phase_number]; warm=int(phase_number)%2==1
        col=BLUE if warm else ORANGE
        a.plot(sub['y2'],sub['y1'],color=col,ls='-' if warm else '--',lw=1.45,
               label=(f"Modus {int(phase_number)}" if phase_number<3 else None))
        if phase_number<4:a.plot(sub['y2'][-1],sub['y1'][-1],"o",mec=INK,mfc="white",ms=4)
    for threshold in (2.5,5.8):a.axhline(threshold,color=GREY,lw=.8,ls=':')
    a.scatter(.3,4.2,s=30,color=INK,marker='*',zorder=5,label="Start")
    a.set(xlabel="Zustand $y_2$ [1]",ylabel="Zustand $y_1$ [1]")
    a.set_title("A   Bahn und Schaltschwellen",loc="left")
    a.legend(loc="lower right",fontsize=7.4)
    cut=r[(r['phase']==2)&(r['phase_us']<=6.01)]
    b.plot(cut['phase_us'],cut['y1'],color=ORANGE,lw=1.7,label="$y_1$")
    b.plot(cut['phase_us'],cut['y2'],color=BLUE,ls="--",lw=1.5,label="$y_2$")
    b.set(xlabel="Zeit seit der ersten Schaltung [µs]",ylabel="Zustand [1]",xlim=(0,4))
    b.set_title("B   Die ersten Mikrosekunden",loc="left");b.legend()
    save(fig,"c05_phase")


def balls():
    r=numbers("c12_bahnen");t=r["t_s"]
    fig,(a,b)=plt.subplots(1,2,figsize=(7.15,2.87),layout="constrained")
    for i,col in enumerate(PALETTE):
        j=i+1
        a.plot(t,r[f'x{j}_m'],color=col,ls=['-','--','-.',':'][i],lw=1.8,label=f"Kugel {j}")
        b.stairs(r[f'v{j}_m_s'][:-1]*.64+j,t,baseline=j,color=col,fill=True,alpha=.88)
    for x in (1,2,3):
        a.axvline(x,color=GREY,ls=":",lw=.8);b.axvline(x,color=GREY,ls=":",lw=.8)
    a.set(xlabel="Zeit [s]",ylabel="Position des Mittelpunkts [m]",xlim=(0,4),xticks=range(5))
    a.legend(loc="upper left",ncols=2,fontsize=7.4)
    b.set(xlabel="Zeit [s]",ylabel="Kugel",yticks=np.arange(1,5)+.28,yticklabels=list("1234"),xlim=(0,4),ylim=(.9,4.84),xticks=range(5))
    a.set_title("A   Absolute Mittelpunkte",loc="left");b.set_title("B   Bewegung mit 1 m/s",loc="left")
    save(fig,"c12_kugeln")


def branches():
    curve=numbers("c21_kennlinie"); orbit=numbers("c21_quelle")
    info=json.loads((DATA/"pruefwerte.json").read_text())["c21"]
    fig,(a,b)=plt.subplots(1,2,figsize=(7.15,2.92),layout="constrained")
    for side,col,ls,name in [(curve['z_V']<=info['z_falte_V'],TEAL,'-','unterer Ast'),
                             (curve['z_V']>=info['z_falte_V'],ORANGE,'--','oberer Ast')]:
        a.plot(curve['b_V'][side],curve['z_V'][side],color=col,ls=ls,lw=1.7,label=name)
    a.axvline(.2,color=GREY,lw=.8,ls=':')
    a.scatter([.2,.2],info['wurzeln_V'],facecolor='white',edgecolor=INK,s=27,zorder=4)
    a.plot(info['b_falte_V'],info['z_falte_V'],'D',color=INK,ms=4,label="Falte")
    a.set(xlabel="Effektive Spannung $b$ [V]",ylabel="Diodenspannung $z$ [V]")
    a.set_title("A   Zwei algebraische Lösungen",loc='left');a.legend(fontsize=7.2,loc="upper left")
    b.plot(orbit['u0_V'],1000*orbit['z_V'],color="#b3c3ca",lw=.65)
    first=orbit['t_s']<=2/150000
    b.plot(orbit['u0_V'][first],1000*orbit['z_V'][first],color=BLUE,lw=1.25,label="Erste zwei Perioden")
    b.plot([],[],color="#a1b1ba",label="Gesamte 500 µs")
    b.set(xlabel="Äußere Quellspannung $u_0$ [V]",ylabel="Diodenspannung $z$ [mV]")
    b.set_title("B   Tatsächlich durchlaufene Bahn",loc="left")
    b.legend(loc='upper left',fontsize=7.1)
    save(fig,"c21_diode")


def tanks():
    r=numbers("c09_takte")
    fig,(a,b)=plt.subplots(2,1,sharex=True,figsize=(7.15,3.5),layout="constrained")
    a.plot(r['t_s'],r['h1_m'],color=BLUE,label="$h_1$");a.plot(r['t_s'],r['h2_m'],color=ORANGE,ls="--",label="$h_2$")
    a.set_ylabel("Füllstand [m]");a.legend(ncols=2,loc='center right')
    a.set_title("A   Die Pegel entwickeln sich zwischen den Takten",loc="left")
    at=np.r_[True,np.diff(r['k'])!=0];edges=np.arange(17)
    b.stairs(r['u_wirksam_V'][at],edges,baseline=None,color=ORANGE,lw=2,label="Pumpe einschließlich Störung")
    b.stairs(r['u_regler_V'][at],edges,baseline=None,color=BLUE,ls="--",lw=1.5,label="Reglerausgang")
    for ax in (a,b):
        ax.axvline(4,color=GREY,ls=":",lw=1);ax.set_xlim(0,16)
    b.set(xlabel="Zeit [s]",ylabel="Spannung [V]",xticks=np.arange(0,17,2))
    b.xaxis.set_minor_locator(FixedLocator(np.arange(17)))
    b.set_title("B   Stellgröße während jedes Takts",loc="left");b.legend(loc="center right",fontsize=7.7)
    save(fig,"c09_takte")


def geometry():
    rows=records("c19r_projektion")
    fig=plt.figure(figsize=(7.15,3.15),layout="constrained")
    gs=fig.add_gridspec(2,2,width_ratios=[1.85,1])
    a=fig.add_subplot(gs[:,0])
    for x in np.arange(-4.5,13,1):a.axvline(x,color="#c7d4d8",lw=.52)
    for y in np.arange(-4.5,5,1):a.axhline(y,color="#c7d4d8",lw=.52)
    a.scatter([0],[0],color=ORANGE,s=46,marker="*",zorder=3);a.scatter([5],[0],facecolor='white',edgecolor=BLUE,s=35,marker="o",zorder=3)
    for x,name,dy in [(0,'Quelle',4),(5,'Brunnen',-14)]:
        a.annotate(name,(x,0),xytext=(5,dy),textcoords='offset points',fontsize=8,color=INK)
    a.set(xlim=(-4.5,12.5),ylim=(-4.5,4.5),xticks=[-4.5,0,5,12.5],yticks=[-4.5,0,4.5],xlabel='Ort $x$ [m]',ylabel='Ort $y$ [m]',aspect='equal')
    for s in a.spines.values():s.set_visible(True)
    a.set_title("A   Gebiet bei 1 m Zellweite",loc="left")
    for i,(rule,lab,shift) in enumerate([('Zentren fest','B   Feste Zentren',0),('Flächen fest','C   Feste Außenflächen',.25)]):
        panel=fig.add_subplot(gs[i,1])
        xy=np.arange(-1,1.01,.5)+shift
        for x in xy:panel.scatter(np.full_like(xy,x),xy,s=6,color="#aec0c8")
        subset=[r for r in rows if r['h']=='0.5' and r['regel']==rule and r['ort']=='Quelle']
        xs=[float(r['x_m']) for r in subset];ys=[float(r['y_m']) for r in subset]
        panel.scatter(xs,ys,facecolors='none',edgecolors=TEAL,s=43,lw=1.3)
        panel.plot(0,0,'+',color=ORANGE,ms=8);panel.text(.64,.56,'1 × 1' if i==0 else '4 × ¼',transform=panel.transAxes,color=INK,fontsize=9)
        panel.set(xlim=(-.84,1.52),ylim=(-.64,.64),xticks=[-.5,0,.5],yticks=[-.5,0,.5],aspect='equal')
        panel.tick_params(labelsize=7);panel.set_title(lab,loc="left",fontsize=9)
        if i:panel.set_xlabel('Abstand zur Quelle [m]',fontsize=8)
    save(fig,"c19r_gitter")


def finer():
    lab=HERE.parent/"cp2_operatoren/messung/kavitaet_felder.npz"
    with np.load(DATA/"cp2_anlauf.npz") as c, np.load(lab) as data:
        raw=[c['n17'],c['n257']]
        errors=[np.hypot(*(data[pred]-data[ref])) for ref,pred in (
            ("reference_Re100","prediction_Re100_fourier"),("reference_n421","prediction_421_fourier"))]
    fig,axes=plt.subplots(2,2,figsize=(7.05,4.18),layout="constrained")
    for i,(pair,titles,unit,cmap,limits) in enumerate([
        (raw,["A   Anlauf · 17 × 17","B   Anlauf · 257 × 257"],"Betrag |u| / U","viridis",[0,1]),
        (errors,["C   Hybridfehler · 65 × 65","D   Hybridfehler · 421 × 421"],"Vektorfehler / U","magma",[0,max(np.max(e) for e in errors)])
    ]):
        for ax,img,title in zip(axes[i],pair,titles,strict=True):
            extent=(0,1,0,1) if i else tuple(x for bounds in ([(-.5)/(img.shape[0]-1),(img.shape[0]-.5)/(img.shape[0]-1)],)*2 for x in bounds)
            im=ax.imshow(img,origin='lower',extent=extent,interpolation='none',cmap=cmap,norm=PowerNorm(.5,*limits))
            ax.set(aspect='equal',xlim=(0,1),ylim=(0,1),xticks=[0,.5,1],yticks=[0,.5,1],xlabel="x/L",ylabel="y/L")
            ax.tick_params(labelsize=7);ax.set_title(title,fontsize=9,loc="left")
        fig.colorbar(im,ax=list(axes[i]),pad=.015,shrink=.92,label=unit,
                     ticks=([0,.0625,.25,.5625,1] if i==0 else [0,.01,.05,.15,.4]))
    save(fig,"cp2_feingitter")


def precision():
    records_456=records("456_arbeit_fehler")
    fig,panels=plt.subplots(4,2,figsize=(7.1,5.75),layout='constrained')
    for ax,case in zip(panels.flat,sorted({r['aufgabe'] for r in records_456}),strict=True):
        rows=[r for r in records_456 if r['aufgabe']==case]
        numeric=[r for r in rows if r['score']]
        boundary=sorted((float(r['ms']),float(r['score'])) for r in numeric if r['pareto']=='1')
        for status,marker,color in [('accuracy_miss','x',ORANGE),('pass','o',BLUE)]:
            points=[r for r in numeric if r['status']==status]
            ax.scatter([float(r['ms']) for r in points],[float(r['score']) for r in points],s=13,color=color,marker=marker,linewidths=.8)
        if boundary:
            xs,ys=zip(*boundary);ax.plot(xs,ys,'D-',color=TEAL,lw=.85,ms=3,mfc='white',zorder=3)
        ax.axhline(1,color=GREY,lw=.8,ls='--')
        scores=[float(r["score"]) for r in numeric]
        ax.set_xscale("log")
        tvalues=[float(r["ms"]) for r in numeric]
        ax.set(xlim=(min(.3,min(tvalues)*.8),max(3000,max(tvalues)*1.2)),xticks=[1,10,100,1000])
        ax.set_xticklabels(["1","10","100","1000"])
        ax.xaxis.set_minor_locator(NullLocator())
        if min(scores)==0:
            ax.set_yscale("symlog",linthresh=1e-13)
            ax.set(ylim=(-1e-14,2),yticks=[0,1e-8,1],yticklabels=["0","10⁻⁸","1"])
        else:
            ax.set_yscale("log")
            low=min(0,int(np.floor(np.log10(min(scores)))))
            high=max(0,int(np.ceil(np.log10(max(scores)))))
            powers=sorted({low,0,high})
            ax.set_ylim(10.**(low-.35),10.**(high+.35))
            ax.set_yticks([10.**v for v in powers],
                          [("1" if v==0 else f"$10^{{{v}}}$") for v in powers])
        ax.yaxis.set_minor_locator(NullLocator())
        ax.tick_params(labelsize=7,pad=1);ax.grid(axis='y',alpha=.12)
        passed=sum(r['status']=='pass' for r in rows)
        ax.set_title(f"{case}    {passed} bestanden · {len(numeric)} Zahlenpaare",loc='left',fontsize=8.1)
    fig.supxlabel("Medianlaufzeit der Wiederholung [ms]",fontsize=9);fig.supylabel("Größter Budgetanteil S",fontsize=9)
    save(fig,"arbeit_fehler")


def profiles():
    groups=defaultdict(list)
    for row in records("57_leistungsprofile"):groups[(row['verfahren'],row['quantum'])].append(row)
    fig,ax=plt.subplots(figsize=(7.05,3.22),layout='constrained')
    highlights={('rk45',''):('RK45',INK,'-'),('rk4',''):('RK4',ORANGE,'--'),
        ('qss2','0.0002'):('QSS2 · 0,0002',TEAL,'-.'),('liqss-bdf','0.001'):('LIQSS–BDF · 0,001',BLUE,':')}
    for key,group in sorted(groups.items(),key=lambda pair:pair[0] in highlights):
        x=[float(r['tau']) for r in group]+[5000];y=[int(r['anzahl'])/8 for r in group]
        label,col,style=highlights.get(key,(None,'#afbfc5','-'))
        ax.step(x,y+[y[-1]],where='post',lw=1.9 if label else .65,ls=style,color=col,label=label)
    ax.plot([],[],color='#a9b9c1',label='Übrige Konfigurationen')
    ax.set_xscale('log');ax.set_xlim(1,5000);ax.set_ylim(-.03,1.035)
    ax.set_yticks(np.arange(0,9,2)/8,["0/8","2/8","4/8","6/8","8/8"])
    ax.set_xticks([1,10,100,1000,5000],["1","10","100","1000","5000"])
    ax.axhline(7/8,color=GREY,ls=':',lw=.8);ax.text(1.12,.90,'7/8 · höchste erreichbare Abdeckung',fontsize=8)
    ax.set(xlabel='Zugelassener Zeitfaktor gegenüber der schnellsten bestandenen Rechnung',ylabel='Anteil der acht Modellfenster')
    ax.legend(loc='lower right',ncols=2,fontsize=7.5,frameon=True,facecolor='white',edgecolor='white',framealpha=.93)
    save(fig,"leistungsprofile")


if __name__=="__main__":
    for draw in (gate,phase,balls,branches,tanks,geometry,finer,precision,profiles):
        draw()
