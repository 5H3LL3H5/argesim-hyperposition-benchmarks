"""Cross-benchmark cost learning and independently checked finite observation duals."""

from fractions import Fraction as F
from functools import cache
from itertools import combinations
from pathlib import Path
import csv
import json
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "messplanung/messung/messplanung.json"
OUT = HERE / "messung"
sys.path.insert(0, str(HERE.parent / "messplanung"))
sys.path.insert(0, str(HERE.parent / "physik_residual/entscheidung"))
from aktion import ActionOperator
from planer import digitize


def exact(v):
    return F(str(v))


class Bank:
    """Reference bank, including the observation model available offline at design time."""

    def __init__(self, case, extended):
        self.key = case["identifier"]
        self.rows = case["scenarios"]
        self.goals = case["quantities"]
        self.probes = case["probes"] + (case["extra_probes"] if extended else [])
        self.codes = tuple(
            tuple(
                digitize(v, p["quantum"])
                for v, p in zip(
                    row["readings"] + (row["extra"] if extended else []),
                    self.probes,
                    strict=True,
                )
            )
            for row in self.rows
        )
        self.targets = tuple(
            tuple(
                exact(v) / exact(q["budget"])
                for v, q in zip(row["values"], self.goals, strict=True)
            )
            for row in self.rows
        )
        self.events = tuple(row["event"] for row in self.rows)
        self.all = tuple(range(len(self.rows)))
        self.m = len(self.probes)

    @cache
    def hull(self, group):
        columns = zip(*(self.targets[i] for i in group), strict=True)
        return tuple((min(x), max(x)) for x in columns)

    @cache
    def ready(self, group):
        return len({self.events[i] for i in group}) == 1 and all(
            b - a <= 2 for a, b in self.hull(group)
        )

    @cache
    def split(self, group, slot):
        children = {}
        for i in group:
            children.setdefault(self.codes[i][slot], []).append(i)
        return {k: tuple(v) for k, v in children.items()}

    @cache
    def choices(self, group, start):
        if self.ready(group):
            return ()
        options = []
        for slot in range(start, self.m):
            parts = self.split(group, slot)
            if len(parts) < 2:
                continue
            # Never skip the last way to distinguish two complete sensor signatures.
            if any(
                self.codes[a][slot:] == self.codes[b][slot:]
                and self.codes[a][start:slot] != self.codes[b][start:slot]
                for a, b in combinations(group, 2)
            ):
                continue
            options.append(slot)
        return tuple(options)

    @cache
    def features(self, group, start, slot):
        branches = list(self.split(group, slot).values())
        n = len(group)
        return (
            start / self.m,
            slot / self.m,
            (slot - start) / self.m,
            len(branches) / n,
            max(map(len, branches)) / n,
            sum(len(g) ** 2 for g in branches) / n**2,
            sum(len(g) for g in branches if self.ready(g)) / n,
            len(group) / len(self.all),
        )

    @cache
    def continuation(self, group, start):
        costs = [self.cost(group, start, slot) for slot in self.choices(group, start)]
        return min(costs, default=0.0)

    def cost(self, group, start, slot):
        return 1 + sum(
            len(g) * self.continuation(g, slot + 1)
            for g in self.split(group, slot).values()
        ) / len(group)

    def examples(self):
        visited = set()

        def visit(group, start):
            if (group, start) in visited:
                return
            visited.add((group, start))
            for slot in self.choices(group, start):
                yield self.features(group, start, slot), [self.cost(group, start, slot)]
                for g in self.split(group, slot).values():
                    yield from visit(g, slot + 1)

        return list(visit(self.all, 0))

    @cache
    def dual(self, slots, train):
        # Fit a goal functional on the training rows. Check the residual on every
        # column of the full observation operator after rounding coefficients.
        data = np.asarray(
            [[self.codes[i][s] for s in slots] for i in train], dtype=float
        )
        q = np.asarray([[float(x) for x in self.targets[i]] for i in train])
        scale = data.std(axis=0)
        scale[scale < 1.0e-10] = 1
        shift = data.mean(axis=0)
        h = (data - shift) / scale
        z = (
            np.linalg.solve(
                h.T @ h + 1.0e-5 * np.eye(len(slots)), h.T @ (q - q.mean(axis=0))
            )
            / scale[:, None]
        )
        offset = q.mean(axis=0) - shift @ z
        coefficients = []
        radii = []
        for j in range(q.shape[1]):
            row = tuple(F(int(round(v * 1.0e8)), 10**8) for v in (offset[j], *z[:, j]))
            coefficients.append(row)
            radii.append(
                max(
                    abs(self.targets[i][j] - self.apply(row, slots, self.codes[i]))
                    for i in self.all
                )
            )
        return tuple(coefficients), tuple(radii)

    @staticmethod
    def apply(weights, slots, codes):
        return weights[0] + sum(
            w * codes[s] for s, w in zip(slots, weights[1:], strict=True)
        )

    def query(self, read, train, net, policy):
        group, start, slots, observed = self.all, 0, (), {}
        while True:
            if self.ready(group):
                hull = self.hull(group)
                coef, radius = self.dual(slots, train)
                learned = max(radius) <= 1
                constant = max(self.dual((), train)[1]) <= 1
                values = (
                    tuple(self.apply(w, slots, observed) for w in coef)
                    if learned
                    else tuple((a + b) / 2 for a, b in hull)
                )
                bounds = radius if learned else tuple((b - a) / 2 for a, b in hull)
                return dict(
                    status="Dual" if learned else "Hülle",
                    slots=slots,
                    values=values,
                    bounds=bounds,
                    constant=constant,
                    event=self.events[group[0]],
                    pair=(),
                )
            options = self.choices(group, start)
            if not options:
                a, b = next(
                    (a, b) for a, b in combinations(group, 2) if not self.ready((a, b))
                )
                return dict(
                    status="Paar",
                    slots=slots,
                    pair=(a, b),
                    values=(),
                    bounds=(),
                    constant=False,
                    event=None,
                )
            if policy == "chronologisch":
                slot = start  # comparator reads even an uninformative slot
            elif policy == "gierig":
                slot = min(
                    options, key=lambda s: (self.features(group, start, s)[5], s)
                )
            elif policy == "optimum":
                slot = min(options, key=lambda s: (self.cost(group, start, s), s))
            elif policy == "gelernt":
                slot = min(
                    options,
                    key=lambda s: (
                        float(net.prices(self.features(group, start, s))[0]),
                        s,
                    ),
                )
            else:
                raise ValueError(policy)
            code = read(slot)
            observed[slot] = code
            slots = (*slots, slot)
            group = self.split(group, slot).get(code, ())
            if not group:
                return dict(
                    status="unbekannt",
                    slots=slots,
                    pair=(),
                    values=(),
                    bounds=(),
                    constant=False,
                    event=None,
                )
            start = slot + 1


def save_csv(path, rows):
    with path.open("w", encoding="utf8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    OUT.mkdir(exist_ok=True)
    cases = [x for x in json.loads(SOURCE.read_text())["cases"] if x.get("scenarios")]
    banks = [Bank(c, bool(c["extra_probes"])) for c in cases]
    examples = [b.examples() for b in banks]
    groups = list(dict.fromkeys(b.key.split("/")[0] for b in banks))
    fold = {key: i % 3 for i, key in enumerate(groups)}
    nets = []
    for f in range(3):
        training = [
            row
            for b, ex in zip(banks, examples, strict=True)
            if fold[b.key.split("/")[0]] != f
            for row in ex
        ]
        fitted = ActionOperator.fit(training)
        nets.append(ActionOperator(fitted))
        (OUT / f"aktionsnetz_{f}.json").write_text(
            json.dumps(
                {
                    "ausgeschlossene_gruppen": [k for k in groups if fold[k] == f],
                    "modell": fitted,
                },
                allow_nan=False,
            )
        )
    details, summary = [], []
    for case, full in zip(cases, banks, strict=True):
        for variant, bank in (
            [("Basis", Bank(case, False)), ("Ergänzt", full)]
            if case["extra_probes"]
            else [("Basis", full)]
        ):
            splits = np.random.default_rng(1703).permutation(len(bank.all))
            assignment = {int(row): i % 3 for i, row in enumerate(splits)}
            stats = {}
            for policy in ("gelernt", "gierig", "chronologisch", "optimum"):
                rows = []
                for i in bank.all:
                    train = tuple(j for j in bank.all if assignment[j] != assignment[i])
                    reads = []

                    def read(slot):
                        assert not reads or slot > reads[-1]
                        reads.append(slot)
                        return bank.codes[i][slot]

                    r = bank.query(
                        read, train, nets[fold[bank.key.split("/")[0]]], policy
                    )
                    assert tuple(reads) == r["slots"]
                    assert r["status"] != "unbekannt"
                    score = None
                    if r["values"]:
                        assert r["event"] == bank.events[i]
                        errors = [
                            abs(x - y)
                            for x, y in zip(r["values"], bank.targets[i], strict=True)
                        ]
                        assert all(
                            e <= b <= 1
                            for e, b in zip(errors, r["bounds"], strict=True)
                        )
                        score = float(max(errors))
                    else:
                        a, b = r["pair"]
                        assert bank.codes[a] == bank.codes[b] and not bank.ready((a, b))
                    item = dict(
                        auftrag=bank.key,
                        variante=variant,
                        regel=policy,
                        fall=i,
                        fold=assignment[i],
                        status=r["status"],
                        anzahl=len(reads),
                        kanaele=" ".join(str(s + 1) for s in reads),
                        score=score,
                        nullzeuge=int(r["constant"]),
                        paar=" ".join(map(str, r["pair"])),
                        ziel=" ".join(
                            str(float(x * exact(q["budget"])))
                            for x, q in zip(r["values"], bank.goals)
                        ),
                        label=r["event"],
                    )
                    rows.append(item)
                    details.append(item)
                stats[policy] = rows
            r = stats["gelernt"]
            summary.append(
                dict(
                    auftrag=bank.key,
                    variante=variant,
                    faelle=len(r),
                    frei=sum(x["score"] is not None for x in r),
                    dual=sum(x["status"] == "Dual" for x in r),
                    konstant=sum(x["nullzeuge"] for x in r),
                    paar=sum(x["status"] == "Paar" for x in r),
                    **{
                        f"summe_{p}": sum(x["anzahl"] for x in rows)
                        for p, rows in stats.items()
                    },
                    max_score=max(
                        (x["score"] for x in r if x["score"] is not None), default=0
                    ),
                )
            )
    save_csv(OUT / "katalog_einzeln.csv", details)
    save_csv(OUT / "katalog.csv", summary)
    print(
        len(cases),
        "endliche Aufträge",
        sum(len(b.all) for b in banks),
        "Prüffälle",
        flush=True,
    )


if __name__ == "__main__":
    main()
