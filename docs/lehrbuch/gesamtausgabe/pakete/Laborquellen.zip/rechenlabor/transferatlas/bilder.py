"""Vector figures from the published run files and explicit numerical teaching examples."""

from collections import Counter
from pathlib import Path
import csv
import json
import re
import sys

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import FancyArrowPatch, Patch
from matplotlib.ticker import MaxNLocator
import numpy as np

from katalog import OUT, SOURCE, digitize

HERE = Path(__file__).resolve().parent
LAB = HERE.parent
ROOT = LAB.parent
sys.path.insert(0, str(LAB / "physik_residual/entscheidung"))
import dualer_operator as dual

INK = "#17384b"
TEAL = "#087e79"
RED = "#aa482e"
BLUE = "#4e73a0"
GOLD = "#d99836"
LIGHT = "#dce5eb"
PALETTE = LinearSegmentedColormap.from_list(
    "anzahl", ["#edf3f4", "#a4d1c9", "#308c8b", "#17475d"]
)
plt.rcParams.update(
    {
        "svg.hashsalt": "argesim-241124-atlas",
        "font.family": "DejaVu Sans",
        "font.size": 9.2,
        "axes.titlesize": 10.3,
        "axes.titleweight": "bold",
        "axes.labelsize": 8.2,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "text.color": INK,
        "axes.labelcolor": INK,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.edgecolor": "#9caaaf",
        "axes.axisbelow": True,
        "grid.color": "#d8e1e4",
        "grid.linewidth": 0.65,
        "legend.frameon": False,
        "pdf.fonttype": 42,
        "savefig.facecolor": "white",
    }
)
CASES = {r["identifier"]: r for r in json.loads(SOURCE.read_text())["cases"]}
TITLES = {
    "C01": ("Clusterbildung", "Cluster f bei 1 ms", "Cluster m bei 10 s"),
    "C02": ("Montage", "Paletten anfangs auf B1", "Ausgebrachte Teile"),
    "C03": ("Verstärker", "Spannung u₂ bei 2 µs [V]", "Spannung u₄ bei 20 µs [V]"),
    "C04": ("Philosophen I", "Zeitanteil Denken [0–1]", "Abgeschlossene Mahlzeiten"),
    "C05": ("Hysterese", "Differenz x−y bei 0,2 s", "Erste Schaltzeit [s]"),
    "C06": ("Behandlung", "Klasse 1 · Mittel [min]", "Gesamtmittel [min]"),
    "C07": ("Stiftpendel", "Winkel bei 0,1 s [rad]", "Winkel bei 1,3 s [rad]"),
    "C08": ("Kanalschleuse", "Ostankünfte bis 20 min", "Mittlere Transitzeit [s]"),
    "C09": ("Zwei Tanks", "Pegel 1 bei 4 s [m]", "Pegel 1 bei 36 s [m]"),
    "C10": ("Philosophen II", "Freie Stäbchen", "Neue Mahlzeiten"),
    "C11": ("Roboter", "Strom I₃ bei 0,1 ms [A]", "Höhe z bei 0,9 ms [m]"),
    "C12": ("Kugelreihe", "Kugel 2 bei 0,65 s [m/s]", "Geschw. Kugel 4 [m/s]"),
    "C13": ("Portalkran", "Seilwinkel bei 2 s [rad]", "Lastposition bei 15 s [m]"),
    "C14": ("Lieferkette", "Produkte an Tag 9", "Produkte an Tag 30"),
    "C15": ("Clearance", "Konzentration A bei 1 ZE", "Konzentration A bei 160 ZE"),
    "C16": ("Restaurants", "Anzahl nach 26 Wochen", "Anzahl nach 5 Jahren"),
    "C17R": ("Kompartimente", "Bestand I bei 2 ZE", "Bestand R bei 60 ZE"),
    "C18": ("Identifikation", "Verdickung bei 0 ms", "Kraft bei 450 ms"),
    "C20": ("Produktion", "Erste Durchlaufzeit [s]", "Median Durchlaufzeit [s]"),
    "C21": ("Fallender Ball", "Höhe bei 0,17 s [m]", "Zeit des 3. Kontakts [s]"),
    "C22": ("Warteschlange", "Maximale Schlangenlänge", "Mittlere Wartezeit [ZE]"),
    "CP1/A": ("Oszillator", "Position bei 0,1 s [m]", "Position bei 1,6 s [m]"),
    "CP1/B": ("Populationen", "v₁ bei 0,5 ZE", "z₂ bei 10 ZE"),
    "CP1/C": ("Randgetriebene Saite", "u(5 m, 3 s) [m]", "u(7,5 m, 20 s) [m]"),
    "CP2/1": ("Monte-Carlo-Mittel", "Erstes Blockmittel [m]", "Ensemblemittel [m]"),
    "CP2/2": ("Kavität", "Tempo im Knoten (9, 2)", "Tempo im Knoten (13, 9)"),
    "CP2/3": ("Gezupfte Saite", "u(0,25 m, 0,8 s) [m]", "u(0,375 m, 8 s) [m]"),
}
GROUPS = [
    ("c01", ["C01", "C02", "C03", "C04"]),
    ("c05", ["C05", "C06", "C07", "C08"]),
    ("c09", ["C09", "C10", "C11", "C12"]),
    ("c13", ["C13", "C14", "C15", "C16"]),
    ("c17", ["C17R", "C18", "C20", "C21"]),
    ("cp1", ["C22", "CP1/A", "CP1/B", "CP1/C"]),
    ("cp2", ["CP2/1", "CP2/2", "CP2/3"]),
]


def save(fig, name):
    for path, meta in (
        (ROOT / "abbildungen" / f"atlas_{name}.svg", {"Date": None}),
        (ROOT / "druck" / f"atlas_{name}.pdf", {"CreationDate": None}),
    ):
        path.parent.mkdir(exist_ok=True)
        fig.savefig(path, metadata=meta)
    plt.close(fig)


def catalogue(name, keys):
    fig, axes = plt.subplots(2, 2, figsize=(7.05, 4.32), layout="constrained")
    for ax, key in zip(axes.flat, keys):
        case = CASES[key]
        q = case["probes"][0]["quantum"]
        pts = Counter(
            (digitize(r["readings"][0], q) * q, r["values"][0])
            for r in case["scenarios"]
        )
        for (x, y), count in pts.items():
            ax.scatter(
                x,
                y,
                s=20 + 10 * (count - 1),
                color=TEAL,
                alpha=0.83,
                edgecolor="white",
                lw=0.55,
            )
        title, xlabel, ylabel = TITLES[key]
        ax.set_title(key + "  " + title, loc="left")
        ax.set(xlabel=xlabel, ylabel=ylabel)
        ax.ticklabel_format(axis="both", style="plain", useOffset=False)
        ax.xaxis.set_major_locator(MaxNLocator(4))
        ax.yaxis.set_major_locator(MaxNLocator(4))
        ax.grid(True)
    if len(keys) < 4:
        ax = axes.flat[-1]
        ax.axis("off")
        ax.text(
            0.1,
            0.74,
            "Wie liest man einen Punkt?",
            weight="bold",
            transform=ax.transAxes,
        )
        ax.text(
            0.1,
            0.58,
            "Waagerecht: erster Sensorcode\nin den Einheiten des Modells.\nSenkrecht: spätere Zielgröße.\nGrößere Punkte bündeln gleiche Paare.",
            va="top",
            linespacing=1.55,
            transform=ax.transAxes,
        )
    save(fig, "mess_" + name)


def dining(data):
    ring = data["unprotected"]["wait_edges"]
    fig, ax = plt.subplots(figsize=(6.8, 3.25), layout="constrained")
    ax.set_aspect("equal")
    ax.axis("off")
    pos = {}
    for j in range(5):
        for label, angle in ((f"P{j}", 90 - 72 * j), (f"S{j}", 126 - 72 * j)):
            a = np.deg2rad(angle)
            pos[label] = np.array([np.cos(a), np.sin(a)])
    for u, v in ring:
        owns = u[0] == "S"
        ax.add_patch(
            FancyArrowPatch(
                pos[u],
                pos[v],
                shrinkA=14,
                shrinkB=14,
                arrowstyle="-|>",
                mutation_scale=14,
                linewidth=2,
                color=TEAL if owns else RED,
                linestyle="-" if owns else "--",
            )
        )
    for s, (x, y) in pos.items():
        ax.scatter(
            x,
            y,
            marker="o" if s[0] == "P" else "s",
            s=315,
            color=INK if s[0] == "P" else "#dae8e8",
            edgecolors=INK,
            linewidths=1,
            zorder=3,
        )
        ax.text(
            x,
            y,
            s,
            ha="center",
            va="center",
            weight="bold",
            color="white" if s[0] == "P" else INK,
            zorder=4,
        )
    ax.set(xlim=(-1.23, 2.5), ylim=(-1.18, 1.18))
    ax.text(1.24, 0.66, "Nach dem ersten Zugriff", weight="bold", size=10)
    ax.text(1.24, 0.39, "P = Person\nS = Stäbchen", linespacing=1.55)
    ax.text(1.24, -0.03, "S → P   im Besitz", color=TEAL, weight="bold")
    ax.text(1.24, -0.28, "P ⇢ S   angefordert", color=RED, weight="bold")
    ax.text(
        1.24, -0.69, "Alle fünf warten.\nKeine Freigabe ist geplant.", linespacing=1.4
    )
    save(fig, "kreis")
    colors = {"thinking": "#ccd6de", "waiting": "#d68242", "eating": TEAL}
    fig, axes = plt.subplots(
        2, 1, sharex=True, figsize=(7.05, 3.65), layout="constrained"
    )
    for ax, (name, title) in zip(
        axes,
        [
            ("unprotected", "Einzelner Zugriff"),
            ("atomic", "Gemeinsame Vergabe beider Stäbchen"),
        ],
        strict=True,
    ):
        trace = data[name]
        for p in range(5):
            t0 = 0
            state = "thinking"
            for t, who, old, new in trace["states"]:
                if who == p:
                    assert state == old
                    if t > t0:
                        ax.broken_barh(
                            [(t0, t - t0)], (p - 0.36, 0.72), facecolors=colors[state]
                        )
                    state, t0 = new, t
            ax.broken_barh([(t0, 8 - t0)], (p - 0.36, 0.72), facecolors=colors[state])
        ax.set(
            yticks=range(5),
            yticklabels=[f"P{i}" for i in range(5)],
            ylim=(4.6, -0.6),
            xlim=(0, 8),
        )
        ax.set_title(
            f"{title}  ·  {trace['summary']['meals']} abgeschlossene Mahlzeiten",
            loc="left",
        )
        ax.grid(axis="x")
    axes[-1].set_xlabel("Modellzeit")
    axes[0].legend(
        handles=[
            Patch(color=v, label=l)
            for v, l in zip(colors.values(), ["denkt", "wartet", "isst"], strict=True)
        ],
        loc="upper right",
        bbox_to_anchor=(1, 1.36),
        ncol=3,
        fontsize=7.5,
    )
    save(fig, "essverlauf")
    trace = data["C10"]["conflicts"][0]
    states = ["thinking", "waiting_left", "waiting_right", "eating"]
    names = ["denkt", "wartet links", "wartet rechts", "isst"]
    colors = ["#dce5ea", "#f5d6aa", "#e7a45a", "#a1cebc"]
    fig, ax = plt.subplots(figsize=(7.05, 2.85), layout="constrained")
    ax.axis("off")
    ax.set(xlim=(-0.1, 6.3), ylim=(-0.55, 2.6))
    for i in range(5):
        ax.text(
            i + 1.3,
            2.17,
            f"P{i}" + ("  •" if i == trace["winner_id"] else ""),
            ha="center",
            weight="bold",
        )
    for y, (key, lbl) in enumerate(
        (("states_after", "danach"), ("states_before", "davor"))
    ):
        ax.text(0.56, y + 0.45, lbl, ha="right", va="center")
        for i, state in enumerate(trace[key]):
            k = states.index(state)
            ax.add_patch(
                plt.Rectangle(
                    (i + 0.83, y + 0.09),
                    0.94,
                    0.7,
                    facecolor=colors[k],
                    edgecolor="white",
                )
            )
            ax.text(
                i + 1.3,
                y + 0.45,
                names[k].replace(" ", "\n"),
                va="center",
                ha="center",
                size=8,
            )
    ax.text(
        0.05,
        -0.32,
        f"Ereigniszeit {trace['time']}  ·  Stäbchen S{trace['chopstick_id']}  ·  konkurrierende Plätze P{trace['left_philosopher_id']} und P{trace['right_philosopher_id']}",
    )
    save(fig, "gleichzeitigkeit")


def numerical():
    fig, (a, b) = plt.subplots(1, 2, figsize=(7.05, 2.8), layout="constrained")
    h = 0.08
    t = np.arange(39) * h
    x = np.array([np.real((1 + 1j * h) ** n) for n in range(len(t))])
    y = np.array([np.imag((1 + 1j * h) ** n) for n in range(len(t))])
    u, v = (
        np.cos(np.arange(len(t)) * np.arctan(h)),
        np.sin(np.arange(len(t)) * np.arctan(h)),
    )
    a.plot(np.cos(t), np.sin(t), color=INK, label="exakter Kreis")
    a.plot(x, y, "--", color=RED, label="Euler")
    a.plot(u[::3], v[::3], ".", color=TEAL, label="Euler + Projektion")
    a.axis("equal")
    a.set(xlabel="x [m]", ylabel="y [m]")
    a.legend(fontsize=7.4)
    b.plot(t, x * x + y * y - 1, color=RED, label="Euler")
    b.plot(t, u * u + v * v - 1, color=TEAL, label="mit Projektion")
    b.set(xlabel="Zeit [s]", ylabel="Zwangsfehler x² + y² − 1 [m²]")
    b.grid(True)
    a.set_title("Ort auf dem Kreis", loc="left")
    b.set_title("Verletzung der Bindung", loc="left")
    save(fig, "bindung")
    fig, (a, b) = plt.subplots(1, 2, figsize=(7.05, 2.85), layout="constrained")
    q = 1.0
    x = 1.0
    t = 0.0
    delta = 0.1
    T = [0.0]
    Q = [q]
    X = [x]
    while q > delta / 2:
        h = delta / q
        t += h
        x -= delta
        q = round(q - delta, 10)
        T.append(t)
        Q.append(q)
        X.append(x)
    ts = np.linspace(0, T[-1], 300)
    a.plot(ts, np.exp(-ts), color=INK, label="exakt")
    a.plot(T, X, color=TEAL, label="Zustand x")
    a.step(T, Q, where="post", color=RED, ls="--", label="quantisiert q")
    a.set(xlabel="Modellzeit", ylabel="Zustand")
    a.legend(fontsize=7.6)
    a.grid(True)
    b.bar(np.arange(1, len(T)), np.diff(T), color=TEAL)
    b.set(xlabel="Nummer des Ereignisses", ylabel="Zeit bis zum Ereignis")
    a.set_title("Abklingen bei Δ = 0,1", loc="left")
    b.set_title("Die Ereignisabstände wachsen", loc="left")
    save(fig, "quantum")


def kernels():
    fig, (a, b) = plt.subplots(1, 2, figsize=(7.05, 2.9), layout="constrained")
    ell = np.zeros(81)
    ell[40] = 1.0
    mu = 6.0
    tick = dual.quantize(ell)
    learned = dual.DualOperator(
        json.loads(
            (LAB / "physik_residual/entscheidung/messung/modell.json").read_text()
        )["dual"]
    )
    x = np.arange(81) - 40
    a.plot(x, dual.direct(mu, ell), color=INK, lw=2.4, label="Bandlösung")
    for k, color, style in [(3, RED, "--"), (16, TEAL, "-.")]:
        z = np.asarray(learned.propose(mu, tick, k)) / dual.TICKS
        a.plot(x, z, color=color, ls=style, label=f"Grad {k}")
        residual = ell - z - mu * np.array(dual.laplace(z))
        b.plot(x, np.abs(residual), color=color, ls=style, label=f"Grad {k}")
    for ax in (a, b):
        ax.set_xlim(-18, 18)
        ax.set_xlabel("Abstand vom Sensorknoten")
        ax.grid(True)
        ax.legend(fontsize=7.2)
    a.set_title("Duales Feld eines Punktsensors", loc="left")
    a.set_ylabel("Gewicht")
    b.set_title("Defekt des Vorschlags", loc="left")
    b.set_ylabel("Betrag des dualen Residuums")
    save(fig, "dualfilter")


def heat():
    rows = list(csv.DictReader((OUT / "kerne.csv").open()))
    keys = list(CASES)
    kinds = list(dict.fromkeys(r["kern"] for r in rows))
    names = ["F", "L", "W", "H", "R", "WL", "FM"]
    table = {
        (r["auftrag"], r["kern"]): 100 * int(r["direkt_frei"]) / int(r["n"])
        for r in rows
    }
    fig, axes = plt.subplots(1, 2, figsize=(7.05, 4.35), layout="constrained")
    for ax, group in zip(axes, (keys[:14], keys[14:]), strict=True):
        vals = np.array([[table[key, kind] for kind in kinds] for key in group])
        ax.imshow(
            vals, cmap=PALETTE, vmin=0, vmax=100, aspect="auto", interpolation="none"
        )
        ax.set(
            yticks=range(len(group)),
            yticklabels=group,
            xticks=range(7),
            xticklabels=names,
        )
        ax.xaxis.tick_top()
        ax.tick_params(axis="both", length=0)
        for row in range(len(group)):
            for col in range(7):
                v = vals[row, col]
                ax.text(
                    col,
                    row,
                    str(int(np.rint(v))),
                    color="white" if v >= 66 else INK,
                    ha="center",
                    va="center",
                    size=7.4,
                )
    save(fig, "kerne")


def field():
    z = np.load(LAB / "cp2_operatoren/messung/kavitaet_felder.npz")
    ref = z["reference_Re100"]
    pred = z["prediction_Re100_fourier"]
    fig, (a, b) = plt.subplots(1, 2, figsize=(7.05, 3.05), layout="constrained")
    xy = (np.arange(ref.shape[-1]) + 0.5) / ref.shape[-1]
    a.streamplot(
        xy, xy, ref[0], ref[1], density=0.85, linewidth=0.78, color=TEAL, arrowsize=0.7
    )
    a.set_title("Referenzströmung", loc="left")
    err = np.hypot(*(pred - ref))
    im = b.imshow(
        err, origin="lower", extent=[0, 1, 0, 1], cmap="magma", aspect="equal"
    )
    b.set_title("Fehler der hybriden Vorhersage", loc="left")
    fig.colorbar(im, ax=b, shrink=0.7, label="Geschwindigkeitsfehler / Deckeltempo")
    for ax in (a, b):
        ax.set(xlabel="x / L", ylabel="y / L", aspect="equal", xlim=(0, 1), ylim=(0, 1))
    save(fig, "strom")


def paths():
    fig, axes = plt.subplots(1, 2, figsize=(7.05, 2.85), layout="constrained")
    for ax, k, ylabel in zip(
        axes, ("C09", "C13"), ("Pegel 1 [m]", "Seilwinkel [rad]"), strict=True
    ):
        case = CASES[k]
        t = [float(re.search(r"bei ([.\d]+) s", p["label"])[1]) for p in case["probes"]]
        for i, r in enumerate(case["scenarios"]):
            ax.plot(
                t,
                r["readings"],
                ".-",
                markersize=3,
                color=TEAL if i == 0 else BLUE,
                alpha=1 if i == 0 else 0.36,
                lw=1,
            )
        ax.set_title(k + "  " + TITLES[k][0], loc="left")
        ax.set(xlabel="Ablesezeit [s]", ylabel=ylabel)
        ax.grid(True)
    save(fig, "abtastung")


def groundwater():
    rows = {p: [] for p in ("gelernt", "immer", "nur_am_ende")}
    for r in csv.DictReader((OUT / "quelle_einzeln.csv").open()):
        rows[r["regel"]].append(r)
    sample = rows["gelernt"]
    fig, (a, b) = plt.subplots(1, 2, figsize=(7.05, 2.83), layout="constrained")
    for i, (k, label) in enumerate(
        (
            ("gelernt", "Aktionsnetz"),
            ("immer", "Immer scharf"),
            ("nur_am_ende", "Nur bei Bedarf am Ende"),
        )
    ):
        r = rows[k]
        a.barh(
            2 - i,
            sum(int(x["scharfe_pruefungen"]) for x in r),
            color=[TEAL, BLUE, RED][i],
        )
        a.text(
            max(1, sum(int(x["scharfe_pruefungen"]) for x in r)) * 1.16,
            2 - i,
            str(sum(int(x["scharfe_pruefungen"]) for x in r)),
            va="center",
            fontsize=8,
        )
    a.set_xscale("symlog", linthresh=1)
    a.set_xlim(0, 2e5)
    a.set(
        yticks=[2, 1, 0],
        yticklabels=["Aktionsnetz", "Immer scharf", "Nur am Ende"],
        xlabel="Anzahl scharfer Prüfungen",
    )
    a.set_title("Aufwand für 5 101 Quellen", loc="left")
    b.hist(
        [float(x["score"]) for x in sample],
        bins=np.linspace(0, 1, 21),
        color=TEAL,
        edgecolor="white",
    )
    b.axvline(1, color=RED, ls="--")
    b.set(
        xlabel="Tatsächlicher Fehler / Budget", ylabel="Anzahl Quellen", xlim=(0, 1.04)
    )
    b.set_title("Freigegebene Brunnenwerte", loc="left")
    save(fig, "brunnendual")


def reflection():
    length, speed, amplitude, pluck = 0.5, 0.06, 0.05, 0.3
    x = np.linspace(0, length, 501)
    t = np.linspace(0, 8, 321)

    def odd(s):
        unfolded = np.mod(s, 2 * length)
        u = np.minimum(unfolded, 2 * length - unfolded) / length
        return (
            np.where(unfolded <= length, 1, -1)
            * amplitude
            * np.minimum(u / pluck, (1 - u) / (1 - pluck))
        )

    field = (
        odd(x[None, :] - speed * t[:, None]) + odd(x[None, :] + speed * t[:, None])
    ) / 2
    k = np.arange(1, 13) * np.pi
    b = 2 * amplitude * np.sin(k * pluck) / (k * k * pluck * (1 - pluck))
    compact = (np.cos(t[:, None] * speed * k / length) * b) @ np.sin(
        k[:, None] * x / length
    )
    assert np.max(np.abs(field[:, [0, -1]])) < 1e-15
    assert (
        np.max(
            np.abs(
                field[0]
                - amplitude
                * np.minimum(
                    x / (length * pluck), (length - x) / (length * (1 - pluck))
                )
            )
        )
        < 1e-14
    )
    fig, axes = plt.subplots(1, 2, figsize=(7.05, 3.1), layout="constrained")
    for ax, val, cmap, title, unit, limits in zip(
        axes,
        (field * 1000, np.abs(compact - field) * 1000),
        ("RdBu_r", "magma"),
        ("Wandernde und reflektierte Knicke", "Fehler nach 12 Sinusmoden"),
        ("Auslenkung [mm]", "Betragsfehler [mm]"),
        ((-50, 50), (0, None)),
        strict=True,
    ):
        im = ax.imshow(
            val,
            origin="lower",
            extent=(0, length, 0, 8),
            aspect="auto",
            cmap=cmap,
            vmin=limits[0],
            vmax=limits[1],
        )
        fig.colorbar(
            im, ax=ax, orientation="horizontal", shrink=0.91, pad=0.15, label=unit
        )
        ax.set(xlabel="Ort [m]", ylabel="Zeit [s]")
        ax.set_title(title, loc="left")
    save(fig, "reflexion")


def costs():
    with (OUT / "katalog.csv").open() as f:
        rows = {r["auftrag"]: r for r in csv.DictReader(f)}
    keys = list(rows)
    fig, axes = plt.subplots(
        1, 2, figsize=(7.05, 4.45), layout="constrained", sharex=True
    )
    for ax, group in zip(axes, (keys[:14], keys[14:]), strict=True):
        yy = np.arange(len(group))
        for j, k in enumerate(group):
            row = rows[k]
            n = int(row["faelle"])
            chrono = int(row["summe_chronologisch"]) / n
            best = int(row["summe_optimum"]) / n
            ax.plot([best, chrono], [j, j], color="#becad1", lw=2)
        for field, marker, color, label in (
            ("chronologisch", "|", BLUE, "Chronologisch"),
            ("optimum", "o", TEAL, "Optimum"),
            ("gelernt", "x", RED, "Netz"),
        ):
            xx = [
                int(rows[k]["summe_" + field]) / int(rows[k]["faelle"]) for k in group
            ]
            ax.plot(
                xx,
                yy,
                ls="none",
                marker=marker,
                color=color,
                ms=6,
                markerfacecolor="none",
                mew=1.2,
                label=label,
            )
        ax.set(
            yticks=yy,
            yticklabels=group,
            ylim=(len(group) - 0.5, -0.5),
            xlim=(-0.22, 7.15),
            xlabel="Mittlere Ablesezahl pro Fall",
        )
        ax.set_xticks([0, 1, 2, 3, 4, 5, 6, 7])
        ax.grid(axis="x")
    axes[0].legend(loc="lower center", bbox_to_anchor=(1.08, 1.0), ncol=3, fontsize=8.3)
    save(fig, "lesekosten")


def main():
    data = json.loads((OUT / "philosophen.json").read_text())
    dining(data)
    numerical()
    kernels()
    heat()
    field()
    paths()
    groundwater()
    reflection()
    costs()
    for name, keys in GROUPS:
        catalogue(name, keys)


if __name__ == "__main__":
    main()
