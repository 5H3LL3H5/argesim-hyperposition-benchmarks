"""Regression and adversarial tests for observation access and objective bounds."""

import csv
import itertools
import json
from fractions import Fraction
import unittest

import numpy as np

from katalog import Bank, OUT, SOURCE
from quelle import TICKS, dual_value, inside
from philosophen import trace


def tiny():
    return dict(
        identifier="Spiel",
        scenarios=[
            dict(name="a", readings=[0, 1], extra=[], values=[0], event="A"),
            dict(name="b", readings=[1, 1], extra=[], values=[7], event="B"),
            dict(name="c", readings=[0, 0], extra=[], values=[0], event="A"),
        ],
        quantities=[dict(budget=1)],
        probes=[dict(quantum=1), dict(quantum=1)],
        extra_probes=[],
    )


class WitnessTests(unittest.TestCase):
    def test_future_and_unknown(self):
        b = Bank(tiny(), False)
        self.assertNotIn(1, b.choices(b.all, 0))

        def reader(slot):
            self.assertEqual(slot, 0)
            return 99

        r = b.query(reader, (0, 1), None, "gierig")
        self.assertEqual(r["status"], "unbekannt")

    def test_indistinguishable_and_scope(self):
        case = tiny()
        case["scenarios"][1]["readings"] = [0, 1]
        b = Bank(case, False)
        r = b.query(lambda i: b.codes[0][i], (0, 2), None, "gierig")
        self.assertEqual(r["status"], "Paar")
        a, c = r["pair"]
        self.assertEqual(b.codes[a], b.codes[c])
        self.assertNotEqual(b.events[a], b.events[c])
        # In an open world an unseen target at the very same sensor signature
        # cannot be ruled out even when the original finite bank could certify.
        original = Bank(tiny(), False)
        answer = original.query(lambda i: original.codes[0][i], (0, 1), None, "gierig")
        self.assertGreater(abs(100 - answer["values"][0]), 1)

    def test_fitted_bounds_include_unseen_training_rows(self):
        b = Bank(tiny(), False)
        for slots in ((), (0,), (1,), (0, 1)):
            co, r = b.dual(slots, (0, 2))
            for i in b.all:
                actual = abs(b.apply(co[0], slots, b.codes[i]) - b.targets[i][0])
                self.assertLessEqual(actual, r[0])
        self.assertGreater(b.dual((), (0, 2))[1][0], 1)

    def test_false_multipliers_remain_bounds(self):
        weights = [-4, 3, 8]
        for x in itertools.product((0, TICKS // 4, TICKS), repeat=3):
            truth = sum(a * b for a, b in zip(weights, x, strict=True))
            for w in (-100, 0, 6, 100):
                self.assertLessEqual(dual_value(weights, sum(x), w, False), truth)
                self.assertGreaterEqual(dual_value(weights, sum(x), w, True), truth)

    def test_impossible_mass_and_relative_endpoints(self):
        with self.assertRaises(ValueError):
            dual_value([1, 2], -1, 0, True)
        self.assertTrue(inside(99, 101))
        self.assertFalse(inside(99, 102))
        value = Fraction(2 * 99 * 101, 200)
        for c in (99, 101):
            self.assertLessEqual(abs(value / c - 1), Fraction(1, 100))

    def test_c04_ring_and_progress(self):
        dead = trace("unprotected")
        live = trace("atomic")
        self.assertEqual(len(dead["wait_edges"]), 10)
        self.assertTrue(dead["summary"]["deadlocked"])
        self.assertEqual(live["summary"]["meals"], 16)
        arcs = dict(dead["wait_edges"])
        node = "P0"
        seen = set()
        for _ in range(10):
            self.assertNotIn(node, seen)
            seen.add(node)
            node = arcs[node]
        self.assertEqual(node, "P0")

    def test_all_contracts_and_baselines(self):
        cases = json.loads(SOURCE.read_text())["cases"]
        with (OUT / "kerne.csv").open() as f:
            matrix = list(csv.DictReader(f))
        self.assertEqual(len(matrix), 196)
        keys = {c["identifier"] for c in cases}
        pairs = {(r["auftrag"], r["kern"]) for r in matrix}
        self.assertEqual(len(pairs), 196)
        self.assertEqual({k for k, _ in pairs}, keys)
        for r in matrix:
            self.assertLessEqual(int(r["direkt_frei"]), int(r["roh_ok"]))
            self.assertLessEqual(int(r["roh_ok"]), int(r["n"]))
            self.assertEqual(r["mit_pruefer"], r["n"])
        with (OUT / "katalog.csv").open() as f:
            rows = list(csv.DictReader(f))
        final = {r["auftrag"]: r for r in rows}
        self.assertEqual(sum(int(r["faelle"]) for r in final.values()), 352)
        for r in rows:
            for k in ("gelernt", "gierig", "chronologisch"):
                self.assertLessEqual(int(r["summe_optimum"]), int(r["summe_" + k]))
            self.assertEqual(int(r["frei"]) + int(r["paar"]), int(r["faelle"]))

    def test_frozen_transform_weights(self):
        import spektral
        from fenster import WindowOperator

        index = json.loads((OUT / "netzindex.json").read_text())
        with (OUT / "kerne_einzeln.csv").open() as f:
            scores = {
                (r["kern"], int(r["fall"])): float(r["roh_score"])
                for r in csv.DictReader(f)
                if r["auftrag"] == "C07"
            }
        case = next(
            c
            for c in json.loads(SOURCE.read_text())["cases"]
            if c["identifier"] == "C07"
        )
        b = Bank(case, False)
        with np.load(OUT / "kernnetze.npz") as data:
            for kind in spektral.TRANSFORMS:
                name = "C07_" + kind + "_0"
                params = lambda key: data[name + "_" + key]
                net = WindowOperator(
                    spektral.basis(kind),
                    *(
                        params(k)
                        for k in (
                            "mean",
                            "scale",
                            "target_mean",
                            "target_scale",
                            "weights",
                        )
                    ),
                    6,
                )
                tests = index[name]["test"]
                path = spektral.embedded(
                    np.asarray(b.codes)[tests],
                    params("input_mean"),
                    params("input_scale"),
                )
                estimates = net.predict(path)[:, 0]
                for i, y in zip(tests, estimates, strict=True):
                    self.assertAlmostEqual(
                        abs(y - float(b.targets[i][0])), scores[kind, i], places=7
                    )


if __name__ == "__main__":
    unittest.main()
