"""Sensitivity of the raw proposals to a fourfold optimization budget."""

import csv
import json
import torch

from spektral import (
    OUT,
    SOURCE,
    TRANSFORMS,
    finite,
    groundwater,
    water_scores,
    save_csv,
)


def main():
    torch.set_num_threads(1)
    with (OUT / "kerne.csv").open() as f:
        regular = {(r["auftrag"], r["kern"]): r for r in csv.DictReader(f)}
    records = []
    for case in json.loads(SOURCE.read_text())["cases"]:
        key = case["identifier"]
        if key not in ("C04", "C19R", "CP2/3"):
            continue
        if key == "C19R":
            well = groundwater(case)
        for kernel in TRANSFORMS:
            weights = {}
            index = {}
            if key == "C19R":
                rows = water_scores(kernel, *well, weights, index, 800)
            else:
                rows = finite(case, kernel, weights, index, 800)
            base = regular[key, kernel]
            records.append(
                dict(
                    auftrag=key,
                    kern=kernel,
                    n=len(rows),
                    direkt_200=int(base["direkt_frei"]),
                    direkt_800=sum(r[4] for r in rows),
                    roh_200=int(base["roh_ok"]),
                    roh_800=sum(r[2] <= 1 and r[3] for r in rows),
                    konvergiert_800=sum(x["converged"] for x in index.values()),
                    anpassungen=len(index),
                )
            )
        print(key, flush=True)
    save_csv(OUT / "trainingsdauer.csv", records)


if __name__ == "__main__":
    main()
