"""C19R: a posteriori LP-dual bounds for twenty source rates and a learned action."""

from functools import lru_cache
from pathlib import Path
import json
import sys

import numpy as np
from katalog import ActionOperator, OUT, SOURCE, save_csv

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "messplanung"))
import c19r_plan as ref

TICKS = ref.RATE_TICKS
TOTAL = ref.DOSE * TICKS


def inside(lo, hi):
    return lo > 0 and 99 * hi <= 101 * lo


def dual_value(weights, mass, multiplier, upper):
    """Integer support-function inequality, valid for *any* proposed multiplier."""
    if not 0 <= mass <= len(weights) * TICKS:
        raise ValueError("inconsistent cumulative measurement")
    a = int(multiplier)
    if upper:
        return a * mass + TICKS * sum(max(0, int(w) - a) for w in weights)
    return a * mass - TICKS * sum(max(0, a - int(w)) for w in weights)


def fit_weights(lo, hi):
    # Fit the normalized supporting slopes at 15 interior mass fractions on
    # each segment. No test release schedule or test concentration is used.
    polynomials = {}
    for start in range(len(lo)):
        for end in range(start + 1, len(lo) + 1):
            fits = []
            for w in (np.sort(lo[start:end]), np.sort(hi[start:end])[::-1]):
                x = np.arange(1, 16) / 16
                low, high = min(w), max(w)
                span = max(int(high - low), 1)
                y = (w[np.minimum((x * len(w)).astype(int), len(w) - 1)] - low) / span
                fits.append((int(low), span, np.polynomial.polynomial.polyfit(x, y, 3)))
            polynomials[start, end] = fits
    return polynomials


class Continuous:
    def __init__(self, lo, hi, cuts):
        self.lo, self.hi, self.cuts = lo, hi, tuple(cuts)
        self.polys = fit_weights(lo, hi)
        self.planner = ref.Planner(lo, hi)

    @lru_cache(maxsize=100000)
    def segment(self, start, end, mass, method):
        if not 0 <= mass <= (end - start) * TICKS:
            raise ValueError("inconsistent cumulative measurement")
        if method == "scharf":
            return self.planner.group_bounds(start, end, mass)
        if method != "gelernt":
            raise ValueError(method)
        if mass in (0, (end - start) * TICKS):
            factor = 0 if mass == 0 else TICKS
            return int(sum(self.lo[start:end])) * factor, int(
                sum(self.hi[start:end])
            ) * factor
        x = mass / ((end - start) * TICKS)
        vals = []
        for up, (low, span, coef) in enumerate(self.polys[start, end]):
            w = self.hi[start:end] if up else self.lo[start:end]
            a = round(low + span * np.polynomial.polynomial.polyval(x, coef))
            vals.append(dual_value(w, mass, a, up))
        return tuple(vals)

    def step(self, known, method):
        points = [(0, 0), *known, (ref.CELLS, TOTAL)]
        bounds = [
            self.segment(s, e, b - a, method)
            for (s, a), (e, b) in zip(points, points[1:])
        ]
        return max(0, sum(x[0] for x in bounds)), sum(x[1] for x in bounds)

    def features(self, known, lo, hi):
        pos, mass = known[-1] if known else (0, 0)
        return [
            len(known) / len(self.cuts),
            pos / ref.CELLS,
            mass / TOTAL,
            min(1, (hi - lo) / max(1, lo + hi)),
            (TOTAL - mass) / ((ref.CELLS - pos) * TICKS),
        ]

    def calibration(self):
        rng = np.random.default_rng(2106)
        rows = []
        for _ in range(280):
            # Independent interior sources, convex combination of two random vertices.
            u, v = (rng.choice(ref.CELLS, ref.DOSE, replace=False) for _ in range(2))
            rate = np.zeros(ref.CELLS, dtype=np.int64)
            blend = int(rng.integers(1, TICKS))
            rate[u] += blend
            rate[v] += TICKS - blend
            cumulative = np.cumsum(rate)
            known = []
            for cut in self.cuts:
                lo, hi = self.step(known, "gelernt")
                if inside(lo, hi):
                    break
                success = inside(*self.step(known, "scharf"))
                rows.append(
                    (self.features(known, lo, hi), [0.25 if success else 1.25, 1.0])
                )
                known.append((cut, int(cumulative[cut - 1])))
        return ActionOperator.fit(rows), len(rows)

    def run(self, read, net, policy):
        known = []
        checks = 0
        for i in range(len(self.cuts) + 1):
            lo, hi = self.step(known, "gelernt")
            source = "Dual"
            if not inside(lo, hi):
                price = (
                    net.prices(self.features(known, lo, hi))
                    if policy == "gelernt"
                    else (0, 1)
                )
                if (
                    i == len(self.cuts)
                    or policy == "immer"
                    or (policy == "gelernt" and price[0] <= price[1])
                ):
                    lo, hi = self.step(known, "scharf")
                    source = "LP"
                    checks += 1
            if inside(lo, hi):
                return lo, hi, len(known), checks, source
            if i == len(self.cuts):
                raise ArithmeticError("contract unresolved")
            cut = self.cuts[i]
            total = int(read(cut))
            prev, old = known[-1] if known else (0, 0)
            if (
                not 0 <= total - old <= (cut - prev) * TICKS
                or not 0 <= TOTAL - total <= (ref.CELLS - cut) * TICKS
            ):
                raise ValueError("impossible observation")
            known.append((cut, total))


def main():
    case = next(
        c for c in json.loads(SOURCE.read_text())["cases"] if c["identifier"] == "C19R"
    )
    lo, hi, reference = ref.weights(5.0)
    model = Continuous(lo, hi, case["source_enclosure"]["targeted"]["cuts"])
    weights, n = model.calibration()
    (OUT / "quellnetz.json").write_text(
        json.dumps(
            dict(
                aktionsmodell=weights,
                multiplikatoren={
                    f"{a},{b}": [[w, s, c.tolist()] for w, s, c in levels]
                    for (a, b), levels in model.polys.items()
                },
                trainingsentscheidungen=n,
            )
        )
    )
    net = ActionOperator(weights)
    rows = []
    for k, rate in enumerate(ref.dose_histories()):
        cum = np.cumsum(rate)
        truth = float(reference @ rate / TICKS)
        for policy in ("gelernt", "immer", "nur_am_ende"):
            low, high, reads, checks, source = model.run(
                lambda cut: int(cum[cut - 1]), net, policy
            )
            L = low / (ref.WEIGHT_SCALE * TICKS)
            U = high / (ref.WEIGHT_SCALE * TICKS)
            value = 2 * L * U / (L + U)
            assert L <= truth <= U and abs(value / truth - 1) <= 0.01
            rows.append(
                dict(
                    fall=k,
                    regel=policy,
                    messungen=reads,
                    scharfe_pruefungen=checks,
                    freigabe=source,
                    untergrenze=L,
                    obergrenze=U,
                    referenz=truth,
                    score=abs(value / truth - 1) / 0.01,
                )
            )
    save_csv(OUT / "quelle_einzeln.csv", rows)
    stats = {}
    for p in ("gelernt", "immer", "nur_am_ende"):
        part = [r for r in rows if r["regel"] == p]
        stats[p] = dict(
            n=len(part),
            dual=sum(r["freigabe"] == "Dual" for r in part),
            messungen=sum(r["messungen"] for r in part),
            max_messungen=max(r["messungen"] for r in part),
            scharfe_pruefungen=sum(r["scharfe_pruefungen"] for r in part),
            max_score=max(r["score"] for r in part),
        )
    (OUT / "quelle.json").write_text(json.dumps(stats, indent=2, allow_nan=False))
    print(stats)


if __name__ == "__main__":
    main()
