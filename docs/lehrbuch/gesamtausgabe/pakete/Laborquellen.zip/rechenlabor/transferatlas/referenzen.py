"""Regenerate the 27 finite scenario banks from the included project models."""

from dataclasses import asdict
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "messplanung"))
from vergleich import REGISTRY


def main():
    bank = json.loads(
        (HERE.parent / "messplanung/messung/messplanung.json").read_text()
    )
    for case in bank["cases"]:
        key = case["identifier"]
        if REGISTRY[key] is None:
            continue
        fresh = json.loads(json.dumps(asdict(REGISTRY[key]())))
        for field, value in fresh.items():
            if value != case[field]:
                raise AssertionError((key, field))
        print(key, len(fresh["scenarios"]), flush=True)


if __name__ == "__main__":
    main()
