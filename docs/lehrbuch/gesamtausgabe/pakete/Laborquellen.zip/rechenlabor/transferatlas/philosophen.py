"""Passive event instrumentation of C04 and an original C10 scheduler replay."""

from dataclasses import asdict
from pathlib import Path
import inspect
import json
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "messplanung/projekt"))
from argesim_benchmarks.models import c04_dining_philosophers as c04
from argesim_benchmarks.models import c10_dining_philosophers as c10


class RecordedC04(c04._C04Simulation):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.transitions = []
        self.allocations = []

    def transition(self, philosopher, state):
        old = self.state[philosopher]
        super().transition(philosopher, state)
        if old != state:
            self.transitions.append([self.now, philosopher, old.value, state.value])

    def try_acquire(self, philosopher):
        result = super().try_acquire(philosopher)
        owners = list(self.fork_owner)
        for stick, owner in enumerate(owners):
            if owner is not None:
                assert stick in self.held[owner]
        for p, status in enumerate(self.state):
            if status is c04.C04State.EATING:
                assert all(owners[s] == p for s in self.forks(p))
        self.allocations.append([self.now, philosopher, owners])
        return result


def trace(strategy):
    options = inspect.signature(c04.run_c04).bind(
        strategy, seed=21, horizon=8.0, initial_thinking_times=(0.0,) * 5
    )
    options.apply_defaults()
    params = dict(options.arguments)
    expected = c04.run_c04(**params)
    params["strategy"] = c04.C04Strategy(strategy)
    sim = RecordedC04(**params)
    result = sim.run()
    assert result == expected
    edges = []
    if result.deadlocked:
        for p, owned in enumerate(sim.held):
            left, right = sim.forks(p)
            assert owned == {left} and sim.fork_owner[right] == (p + 1) % sim.size
            edges.extend([(f"S{left}", f"P{p}"), (f"P{p}", f"S{right}")])
    return dict(
        summary=asdict(result),
        states=sim.transitions,
        allocations=sim.allocations,
        wait_edges=edges,
    )


def run():
    traces = {name: trace(name) for name in ("unprotected", "atomic")}
    assert (
        traces["unprotected"]["summary"]["deadlocked"]
        and traces["atomic"]["summary"]["meals"] > 0
    )
    rep = c10.run_c10_simulation(seed=21)
    events = [asdict(t) for t in rep.simultaneous_access_traces]
    assert events
    for event in events:
        assert event["winner_id"] == event["right_philosopher_id"]
    traces["C10"] = dict(seed=21, end=rep.termination_time, conflicts=events)
    return traces


if __name__ == "__main__":
    data = run()
    (HERE / "messung/philosophen.json").write_text(
        json.dumps(data, default=lambda v: v.value, ensure_ascii=False, indent=1)
    )
    print(
        [(k, data[k]["summary"]["meals"]) for k in ("unprotected", "atomic")],
        data["C10"]["end"],
        len(data["C10"]["conflicts"]),
        data["C10"]["conflicts"][0]["time"],
    )
