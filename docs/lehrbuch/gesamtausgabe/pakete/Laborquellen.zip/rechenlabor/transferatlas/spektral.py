"""Seven fitted transform/readout families on all 28 observation-to-goal contracts."""

from fractions import Fraction
from dataclasses import fields
from functools import lru_cache
from pathlib import Path
import json
import sys

import numpy as np

from katalog import Bank, OUT, SOURCE, exact, save_csv
from quelle import Continuous, TICKS, ref

LAB = Path(__file__).resolve().parents[1]
sys.path[:0] = [
    str(LAB / p) for p in ("operator_vergleich", "cp2_operatoren", "fno_transfer")
]
import torch
from fenster import WindowOperator, dictionary, train_window
from hybrid_operator import TRANSFORMS

SIZE = 33


@lru_cache
def basis(kind):
    return dictionary(kind, SIZE, 8)


def embedded(data, shift, scale):
    slots = np.rint(np.linspace(0, SIZE - 1, data.shape[1])).astype(int)
    if len(set(slots)) != len(slots):
        raise ValueError("sensor grid is too small")
    path = np.zeros((len(data), SIZE, 1))
    path[:, slots, 0] = (data - shift) / scale
    return path


def fit(key, kind, fold, X, Y, I, J, storage, iterations=200):
    shift = X[I].mean(axis=0)
    scale = X[I].std(axis=0)
    scale[scale < 1e-10] = 1
    path = embedded(X, shift, scale)
    model, info = train_window(
        basis(kind), path[I], Y, 3401 + fold, width=6, iterations=iterations
    )
    # Text labels and the target order accompany the weights in netzindex.json.
    name = f"{key.replace('/', '_')}_{kind}_{fold}"
    storage[name + "_input_mean"] = shift
    storage[name + "_input_scale"] = scale
    for s in fields(WindowOperator):
        if s.name not in ("basis", "width"):
            storage[name + "_" + s.name] = getattr(model, s.name)
    return model.predict(path[J]), info, name


def finite(case, kind, storage, index, iterations=200):
    bank = Bank(case, bool(case["extra_probes"]))
    X = np.asarray(bank.codes, dtype=float)
    q = np.asarray(bank.targets, dtype=float)
    folds = np.random.default_rng(1703).permutation(len(q))
    details = []
    for f in range(3):
        J = folds[f::3]
        I = np.setdiff1d(np.arange(len(q)), J)
        classes = sorted({bank.events[i] for i in I})
        one = np.array([[bank.events[i] == v for v in classes] for i in I], dtype=float)
        Y = np.column_stack((q[I], one)) if len(classes) > 1 else q[I]
        pred, info, name = fit(bank.key, kind, f, X, Y, I, J, storage, iterations)
        index[name] = dict(
            **info,
            classes=classes,
            train=I.tolist(),
            test=J.tolist(),
            goal_count=q.shape[1],
        )
        for j, row in zip(J, pred, strict=True):
            values = [exact(float(v)) for v in row[: q.shape[1]]]
            event = (
                classes[np.argmax(row[q.shape[1] :])]
                if len(classes) > 1
                else classes[0]
            )
            consistent = tuple(k for k in bank.all if bank.codes[k] == bank.codes[j])
            numeric = max(
                abs(v - t) for v, t in zip(values, bank.targets[j], strict=True)
            )
            safe = all(
                bank.events[k] == event
                and all(
                    abs(v - t) <= 1
                    for v, t in zip(values, bank.targets[k], strict=True)
                )
                for k in consistent
            )
            assert bank.ready(consistent)
            if safe:
                certified = values
            else:
                certified = [(a + b) / 2 for a, b in bank.hull(consistent)]
            certified_score = max(
                abs(v - t) for v, t in zip(certified, bank.targets[j], strict=True)
            )
            assert certified_score <= 1 and (not safe or event == bank.events[j])
            details.append(
                (
                    int(j),
                    f,
                    float(numeric),
                    int(event == bank.events[j]),
                    int(safe),
                    float(certified_score),
                )
            )
    return details


def groundwater(case):
    cuts = case["source_enclosure"]["targeted"]["cuts"]
    lo, hi, w = ref.weights(5.0)
    model = Continuous(lo, hi, cuts)
    rng = np.random.default_rng(241124)
    tp = []
    for _ in range(240):
        rate = np.zeros(20, dtype=np.int64)
        mix = np.diff(
            np.r_[0, np.sort(rng.choice(np.arange(1, TICKS), 2, replace=False)), TICKS]
        )
        for weight in mix:
            rate[rng.choice(20, 4, replace=False)] += weight
        tp.append(rate)
    test = list(ref.dose_histories())
    assert not {tuple(r) for r in tp}.intersection(tuple(r) for r in test)
    all_rates = np.asarray(tp + test)
    X = np.cumsum(all_rates, axis=1)[:, np.asarray(cuts) - 1] / TICKS
    q = all_rates @ w / TICKS
    ranges = []
    for x in X[len(tp) :]:
        bounds = model.step(
            list(zip(cuts, (x * TICKS).astype(int), strict=True)), "scharf"
        )
        ranges.append(bounds)
    return X, q[:, None], np.array(ranges), len(tp)


def water_scores(kind, X, q, ranges, n, store, index, iterations=200):
    I, J = np.arange(n), np.arange(n, len(q))
    pred, info, name = fit("C19R", kind, 0, X, q[I], I, J, store, iterations)
    index[name] = dict(
        **info, classes=[], train_count=n, test_count=len(J), goal_count=1
    )
    details = []
    for j, ((a, b), v, t) in enumerate(zip(ranges, pred[:, 0], q[J, 0], strict=True)):
        denominator = ref.WEIGHT_SCALE * TICKS
        scaled = Fraction.from_float(float(v)) * denominator
        safe = 99 * int(b) <= 100 * scaled <= 101 * int(a)
        low, high = int(a) / denominator, int(b) / denominator
        center = v if safe else 2 * low * high / (low + high)
        score = abs(center / t - 1) / 0.01
        assert low <= t <= high and score <= 1
        details.append((j, 0, abs(v / t - 1) / 0.01, 1, int(safe), score))
    return details


def main():
    torch.set_num_threads(1)
    cases = json.loads(SOURCE.read_text())["cases"]
    summary, all_rows, store, index = [], [], {}, {}
    for case in cases:
        key = case["identifier"]
        if key == "C19R":
            X, q, ranges, n = groundwater(case)
        for kind in TRANSFORMS:
            if key == "C19R":
                details = water_scores(kind, X, q, ranges, n, store, index)
            else:
                details = finite(case, kind, store, index)
            all_rows.extend(
                dict(
                    auftrag=key,
                    kern=kind,
                    fall=j,
                    fold=f,
                    roh_score=s,
                    ereignis_richtig=e,
                    direkt_frei=a,
                    end_score=c,
                )
                for j, f, s, e, a, c in details
            )
            summary.append(
                dict(
                    auftrag=key,
                    kern=kind,
                    n=len(details),
                    roh_ok=sum(s <= 1 and e for _, _, s, e, _, _ in details),
                    direkt_frei=sum(a for _, _, _, _, a, _ in details),
                    mit_pruefer=len(details),
                    median_roh=float(np.median([r[2] for r in details])),
                    max_roh=max(r[2] for r in details),
                )
            )
        print(key, flush=True)
    save_csv(OUT / "kerne.csv", summary)
    save_csv(OUT / "kerne_einzeln.csv", all_rows)
    np.savez_compressed(OUT / "kernnetze.npz", **store)
    (OUT / "netzindex.json").write_text(
        json.dumps(index, ensure_ascii=False, allow_nan=False)
    )


if __name__ == "__main__":
    main()
