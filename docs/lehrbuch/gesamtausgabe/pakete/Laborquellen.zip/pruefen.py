"""Alle ausführbaren Lehrrechnungen dieser Ausgabe, ohne Installation von Python-Paketen."""
import subprocess
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
examples = sorted(p for p in (root / "beispiele").glob("*.py") if p.name != "ereignis.py")
labs = [root / "rechenlabor" / name for name in
        ("kapitelproben.py", "kapitelvergleich.py", "methodenlabor.py",
         "rk4_vertrag.py", "auditproben.py", "grundlagen.py", "revisionspruefung/taktkalender.py")]


def main():
    if not __debug__:
        raise SystemExit("Python ohne die Option -O aufrufen, damit die Assertions aktiv sind.")
    for script in examples + labs:
        print(f"\n{script.relative_to(root)}", flush=True)
        subprocess.run([sys.executable, "-B", "-S", str(script)], cwd=script.parent, check=True)
    print(f"\n{len(examples)+len(labs)} Python-Prüfprogramme bestanden. "
          "Der C++20-Test wird separat übersetzt.")


if __name__ == "__main__":
    main()
