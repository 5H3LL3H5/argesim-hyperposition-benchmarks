"""Steifer Folgeregler. Beide Zeitlösungen auf denselben 2001 Messzeiten."""
from math import cos, exp, sin
from bdf import bdf2, euler_rueck
from radau_iia import C, RadauLinear


RATE, T, INTERVALLE = 1000.0, 0.02, 2000  # 1/s, s, Anzahl


def quelle(t):
    return RATE*cos(t) - sin(t)


def integriert(theta):
    gewichte = []
    for j, c in enumerate(C):
        p, q = [v for k, v in enumerate(C) if k != j]
        integral = theta * (theta**2/3 - (p+q)*theta/2 + p*q)
        gewichte.append(integral / ((c-p)*(c-q)))
    return gewichte


def vergleich(n):
    if n <= 0 or INTERVALLE % n:
        raise ValueError("Schrittzahl muss das gemeinsame Messgitter teilen")
    h, teilung = T/n, INTERVALLE//n
    radau = RadauLinear()
    y_r = y_b = alt = 0.0
    knoten_r = fehler_r = fehler_b = 0.0
    for j in range(n):
        t = j*h
        stufen = radau.stufen(t, y_r, h, -RATE, quelle)
        r_neu = stufen[-1]
        k = [-RATE*y + quelle(t+c*h) for c, y in zip(C, stufen)]
        if j == 0:
            b_neu = euler_rueck(y_b, h, -RATE, quelle(t+h))
        else:
            b_neu = bdf2(y_b, alt, h, h, -RATE, quelle(t+h))

        for m in range(1, teilung+1):
            theta = m/teilung
            zeit = T * (j*teilung+m) / INTERVALLE
            exakt = cos(zeit) - exp(-RATE*zeit)
            if m == teilung:
                pr, pb = r_neu, b_neu
                knoten_r = max(knoten_r, abs(pr-exakt))
            else:
                pr = y_r + h*sum(w*f for w, f in zip(integriert(theta), k))
                pb = y_b + theta*(b_neu-y_b)
                if j > 0:
                    pb += theta*(theta-1)*(alt-2*y_b+b_neu)/2
            fehler_r = max(fehler_r, abs(pr-exakt))
            fehler_b = max(fehler_b, abs(pb-exakt))
        y_r, alt, y_b = r_neu, y_b, b_neu
    return knoten_r, fehler_r, fehler_b, radau.zerlegungen


if __name__ == "__main__":
    budget = 1e-4
    for n in (2, 20, 200, 2000):
        ek, er, eb, lu = vergleich(n)
        assert lu == 1 and ek <= er
        assert (ek <= budget) == (n >= 20)
        assert (er <= budget) == (n >= 200)
        assert (eb <= budget) == (n >= 2000)
        print(f"{n:4d}  {20000/n:6.0f} µs  {ek:.6e}  {er:.6e}  {eb:.6e}")
