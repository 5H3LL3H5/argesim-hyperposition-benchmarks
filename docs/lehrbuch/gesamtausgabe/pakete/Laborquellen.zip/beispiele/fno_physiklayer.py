"""Kapitel 9.7. Ein Physik-Layer für die Saite, mit Gegenproben und Blindtest."""
from dataclasses import dataclass
import math
import random
import statistics

from fourier_operator import fft, pluck, relative, sine_coeff, synthesis
from fno_physik import (
    ACC_NOISE, DT, EPS, NONLINEAR_MODES, SEEDS, SPEED, Node, calibration,
    dalembert, eval_step, fit_acceleration, kappa, make_training, test_profiles,
    train_step, trig_profile,
)

N_TEST = 128  # Intervalle; 129 Knoten mit den beiden festen Enden.
DAMPING = 0.60  # s^-1, nur Datengenerator und unabhängige Referenz.
ACC_PAIR_NOISE = 0.02  # m/s², Schranke für jede Einzelmessung.
CONDITIONS = ("Daten-FNO", "FNO mit Physikterm", "Layer 6+1",
              "Layer alle Moden", "Layer und FNO-Korrektur", "Kontrolle mit wahrem c")


def sine_grid(coefficients, n):
    """Inverse ungerade DFT für die N-1 Sinuskoeffizienten auf N Intervallen."""
    if n < 2 or len(coefficients) > n-1:
        raise ValueError("Für diese Darstellung sind höchstens N-1 Moden verfügbar.")
    spectrum = [0j] * (2*n)
    for k, value in enumerate(coefficients, 1):
        spectrum[k] = -1j*n*value
        spectrum[-k] = spectrum[k].conjugate()
    sampled = fft(spectrum, inverse=True)
    return [0.0] + [z.real for z in sampled[1:n]] + [0.0]


def oscillator_step(q, v, omega, h, beta=0.0):
    """Fortschritt von Auslenkung und Geschwindigkeit für einen linearen Modenoszillator."""
    if (not all(math.isfinite(x) for x in (q,v,omega,h,beta))
            or omega <= 0 or h < 0 or beta < 0):
        raise ValueError("Endliche Daten, omega>0, h>=0 und beta>=0 erforderlich.")
    if beta < omega:
        frequency = math.sqrt((omega-beta)*(omega+beta))
        decay = math.exp(-beta*h)
        argument = frequency*h
        kernel = decay*math.cos(argument)
        sine = decay*h*(math.sin(argument)/argument if argument else 1.0)
    elif beta == omega:
        kernel = math.exp(-beta*h)
        sine = h*kernel
    else:
        frequency = math.sqrt((beta-omega)*(beta+omega))
        slow = math.exp(-omega**2*h/(beta+frequency))
        kernel = 0.5*slow*(1+math.exp(-2*frequency*h))
        sine = slow*(-math.expm1(-2*frequency*h))/(2*frequency)
    return ((kernel+beta*sine)*q + sine*v,
            -omega**2*sine*q + (kernel-beta*sine)*v)


def physics_step(displacement, velocity, speed, h, beta=0.0):
    """Fortschritt des vollständigen Gitterzustands bei zwei festen Enden."""
    if len(displacement) != len(velocity) or len(displacement) < 3:
        raise ValueError("Beide Zustandskanäle brauchen dasselbe Dirichlet-Gitter.")
    n = len(displacement)-1
    q = sine_coeff(displacement,n-1)
    v = sine_coeff(velocity,n-1)
    advanced = [oscillator_step(a,b,kappa(k)*speed,h,beta)
                for k,(a,b) in enumerate(zip(q,v,strict=True),1)]
    aq,av = zip(*advanced)
    return sine_grid(aq,n),sine_grid(av,n)


def rest_step(field, speed, h, common_tail=False):
    """Ein Schritt aus der Ruhe; 6+1 teilt das Gewicht der siebten Mode mit allen höheren."""
    n = len(field)-1
    if speed <= 0 or h < 0 or not math.isfinite(speed*h):
        raise ValueError("Positive Geschwindigkeit und endlicher nichtnegativer Zeitschritt erforderlich.")
    cutoff = NONLINEAR_MODES + 1 if common_tail else n-1
    coeff = sine_coeff(field,n-1)
    weights = [math.cos(kappa(min(k,cutoff))*speed*h) for k in range(1,n)]
    return sine_grid([a*r for a,r in zip(coeff,weights,strict=True)],n)


def physical_skip(rows, n, speed):
    """Denselben Trainingspunkten den physikalischen Ausgabewert als Basisterm zuweisen."""
    points = n-1
    if len(rows) % points:
        raise ValueError("Unvollständiges Feld mit fehlenden Innenknoten.")
    replaced = []
    for start in range(0,len(rows),points):
        group = rows[start:start+points]
        field = [0.] + [node.input_value for node in group] + [0.]
        physical = rest_step(field,speed,DT)
        replaced.extend(Node(node.features,base,node.target)
                        for node,base in zip(group,physical[1:-1],strict=True))
    return replaced


@dataclass(frozen=True)
class Comparison:
    speed: float
    smooth: tuple
    triangle: tuple


def blind_fields(n):
    fields = []
    for coeff in test_profiles():
        a = synthesis(coeff,n)
        ref = dalembert(lambda x:trig_profile(coeff,x),n,DT,SPEED)
        fields.append((a,ref))
    a = [pluck(j/n,.37) for j in range(n+1)]
    return fields, (a,dalembert(lambda x:pluck(x,.37),n,DT,SPEED))


@dataclass(frozen=True)
class Models:
    c: float
    free: tuple
    soft: tuple
    residual: tuple


def train_models(seed):
    fitted = fit_acceleration(calibration(seed,SPEED,ACC_NOISE),ACC_NOISE)
    c = math.sqrt(fitted.shared)
    measured,unlabelled = make_training(fitted.shared,seed)
    free = train_step(measured,unlabelled,0.)
    soft = train_step(measured,unlabelled,1.)
    residual = train_step(physical_skip(measured,32,c),physical_skip(unlabelled,64,c),1.)
    return Models(c,tuple(free),tuple(soft),tuple(residual))


def blind_run(models, n=N_TEST):
    c = models.c
    def evaluate(field, reference):
        base = rest_step(field,c,DT)
        residual_output = eval_step(models.residual,field)
        hybrid = [p+(net-a) for p,net,a in zip(base,residual_output,field,strict=True)]
        # SPEED wird hier ausschließlich für die separate Referenzkontrolle verwendet.
        oracle = rest_step(field,SPEED,DT)
        results = [eval_step(models.free,field),eval_step(models.soft,field),rest_step(field,c,DT,True),
                   base,hybrid,oracle]
        errors = tuple(relative(y,reference) for y in results)
        # Dreiecksungleichung, diskrete Sinusorthogonalität und |cos'| <= 1.
        coeff = sine_coeff(field,n-1)
        k_norm = math.sqrt(n/2 * math.fsum((kappa(k)*a)**2 for k,a in enumerate(coeff,1)))
        ref_norm = math.sqrt(math.fsum(y*y for y in reference))
        assert errors[3] <= errors[5] + DT*abs(c-SPEED)*k_norm/ref_norm + 128*n*EPS
        assert all(max(abs(y[0]),abs(y[-1])) < 128*n*EPS for y in results)
        return errors

    smooth,triangle = blind_fields(n)
    smooth_errors = [evaluate(*case) for case in smooth]
    return Comparison(c,tuple(map(statistics.mean,zip(*smooth_errors))),evaluate(*triangle))


def paired_measurements(seed, speed, beta, max_error):
    """20 Paare bei gleichem Ort und entgegengesetzter Modalgeschwindigkeit."""
    draw = random.Random(607)
    sensor = random.Random(8100+seed)
    pairs = []
    for k in range(1,5):
        omega = kappa(k)*speed
        for _ in range(5):
            q = draw.uniform(-.045,.045)
            v = draw.uniform(.15,.65)
            acc_plus = -omega**2*q - 2*beta*v + sensor.uniform(-max_error,max_error)
            acc_minus = -omega**2*q + 2*beta*v + sensor.uniform(-max_error,max_error)
            pairs.append((v,acc_plus,acc_minus))
    return pairs


def infer_damping(pairs, max_error):
    denom = 4 * math.fsum(v*v for v,_,_ in pairs)
    if denom <= 0:
        raise ValueError("Messungen aus der Ruhe identifizieren die Dämpfung nicht.")
    beta = math.fsum(v*(minus-plus) for v,plus,minus in pairs)/denom
    budget = 2*max_error*math.fsum(abs(v) for v,_,_ in pairs)/denom
    return beta,budget


def taylor_reference(q, v, omega, t, beta):
    """Unabhängige Exponentialreihe auf dem dimensionsgleichen Zustand (q, v/omega)."""
    pieces = max(1,math.ceil(2*t*(omega+2*beta)))
    h = t/pieces
    scaled_v = v/omega
    for _ in range(pieces):
        term_q,term_v = q,scaled_v
        qsum,vsum = [q],[scaled_v]
        for order in range(1,19):
            term_q,term_v = (h*omega*term_v/order,
                             -h*(omega*term_q+2*beta*term_v)/order)
            qsum.append(term_q)
            vsum.append(term_v)
        q,scaled_v = math.fsum(qsum),math.fsum(vsum)
    return q, omega*scaled_v


def damped_case(seed, c):
    beta,budget = infer_damping(paired_measurements(seed,SPEED,DAMPING,ACC_PAIR_NOISE),
                                ACC_PAIR_NOISE)
    assert abs(beta-DAMPING) <= budget+32*EPS
    t = 0.8
    rows = []
    for a in test_profiles():
        field = synthesis(a,N_TEST)
        rest = [0.]*len(field)
        true_coeff = [taylor_reference(value,0.,kappa(k)*SPEED,t,DAMPING)[0]
                      for k,value in enumerate(a,1)]
        truth = synthesis(true_coeff,N_TEST)
        y0,_ = physics_step(field,rest,c,t)
        yd,_ = physics_step(field,rest,c,t,beta)
        rows.append((relative(y0,truth),relative(yd,truth)))
    return beta,budget,tuple(map(statistics.mean,zip(*rows)))


def check_layer():
    n = 64
    coeff = [.41,-.2,.07,.12]
    field = synthesis(coeff,n)
    vel = synthesis([.15,.02,-.3,.06],n)
    ref_scale = max(1.,max(map(abs,field+vel)))
    tol = 128*n*EPS*ref_scale
    assert max(abs(a-b) for a,b in zip(sine_grid(coeff,n),field))<=tol
    u,v = physics_step(field,vel,SPEED,0.)
    assert max(abs(a-b) for a,b in zip(u+v,field+vel))<=tol
    u,_ = physics_step(field,[0.]*len(field),SPEED,DT)
    assert max(abs(a-b) for a,b in zip(u,rest_step(field,SPEED,DT)))<=tol
    # Ein Viertel der Periode wandelt einen reinen Geschwindigkeitsstoß in Auslenkung um.
    omega1 = kappa(1)*SPEED
    u,v = physics_step([0.]*(n+1),synthesis([omega1],n),SPEED,math.pi/(2*omega1))
    assert max(abs(a-b) for a,b in zip(u,synthesis([1.],n)))<=tol
    assert max(map(abs,v))<=omega1*tol
    # Genau sechs freie Spektralplätze und ein gemeinsamer lokaler Multiplikator.
    band = [.25,-.2,.1,.07,.01,.08,-.13,.06]
    many = synthesis(band,n)
    k0 = NONLINEAR_MODES+1
    high = math.cos(kappa(k0)*SPEED*DT)
    low = [a*(math.cos(kappa(k)*SPEED*DT)-high)
           for k,a in enumerate(band[:NONLINEAR_MODES],1)]
    local_form = [high*a+b for a,b in zip(many,synthesis(low,n))]
    assert max(abs(a-b) for a,b in zip(local_form,rest_step(many,SPEED,DT,True)))<=tol
    # Auf dem 129er Gitter ist der Weg vier Zellen. Test mit beliebigen Knotenwerten.
    draw = random.Random(33)
    arbitrary = [0.]+[draw.uniform(-1.,1.) for _ in range(N_TEST-1)]+[0.]
    extended = arbitrary+[-a for a in arbitrary[-2:0:-1]]
    offset = SPEED*DT*N_TEST
    assert offset==4
    shifted = [0.5*(extended[(j-4)%(2*N_TEST)]+extended[(j+4)%(2*N_TEST)])
               for j in range(N_TEST+1)]
    assert max(abs(a-b) for a,b in zip(shifted,rest_step(arbitrary,SPEED,DT))) <= 128*N_TEST*EPS
    for beta in (0.,0.6,4.0,4.0+1e-9,6.0):
        omega,h = 4.,.37
        q0,v0 = .1,.72
        a,b = oscillator_step(q0,v0,omega,h,beta)
        ra,rb = taylor_reference(q0,v0,omega,h,beta)
        # Norm des skalierten Generators <= omega+2*beta, je Teilstück <= 1/2.
        pieces = max(1,math.ceil(2*h*(omega+2*beta)))
        tail = math.exp(.5)*.5**19/math.factorial(19)
        bound = pieces*(tail+128*EPS)*max(1.,math.hypot(q0,v0/omega))
        assert math.hypot(a-ra,(b-rb)/omega)<=bound
        a2,b2 = oscillator_step(a,b,omega,h,beta)
        at,bt = oscillator_step(q0,v0,omega,2*h,beta)
        assert math.hypot(a2-at,(b2-bt)/omega)<=2*bound
        assert math.hypot(a,b/omega)<=math.hypot(q0,v0/omega)+bound
        if beta==0:
            assert abs(math.hypot(a,b/omega)-math.hypot(q0,v0/omega))<=bound
    beta,_ = infer_damping(paired_measurements(1,SPEED,0.,0.),0.)
    assert beta==0.
    try:
        infer_damping([(0.,1.,1.)],ACC_PAIR_NOISE)
    except ValueError:
        pass
    else:
        raise AssertionError("Dämpfung ohne Geschwindigkeitsanregung identifiziert.")


def rollout_demo():
    k,c,m = 3,SPEED,32
    omega = kappa(k)*c
    q,v = 1.,0.
    for _ in range(m):
        q,v = oscillator_step(q,v,omega,DT)
    reset = math.cos(omega*DT)**m
    assert abs(q-math.cos(m*omega*DT)) <= 32*m*EPS
    assert abs(v/omega+math.sin(m*omega*DT)) <= 32*m*EPS
    return q,reset


def main():
    check_layer()
    direct,reset = rollout_demo()
    print(f"Mode 3 nach 32 Schritten: Zustand fortgeführt {direct:.7f}, "
          f"Geschwindigkeit immer auf null gesetzt {reset:.7f}.")
    trained = [train_models(seed) for seed in SEEDS]
    runs = [blind_run(model) for model in trained]
    # Kapitel 9.6 veröffentlicht die früheren Prozentwerte auf vier Dezimalstellen.
    for attr,published in (("smooth",.2589),("triangle",.9847)):
        old_value = 100*statistics.median(getattr(run,attr)[1] for run in runs)
        assert abs(old_value-published) <= .5e-4 + 32*EPS
    for run in runs:
        # Paarvergleich genau für die archivierten Eingangsfelder und Rauschfolgen.
        assert run.triangle[3] < run.triangle[4] < run.triangle[1]
        assert run.smooth[3] < min(run.smooth[1],run.smooth[4])
    print("Ideale Saite, relativer Feldfehler in Prozent. Reihenfolge wie im Tabellenkopf.")
    print("Varianten: "+" | ".join(CONDITIONS))
    for seed,run in zip(SEEDS,runs):
        print(f"Seed {seed}, glatt  : "+" / ".join(f"{100*v:.6g}" for v in run.smooth))
        print(f"Seed {seed}, Dreieck: "+" / ".join(f"{100*v:.6g}" for v in run.triangle))
    for name in ("smooth","triangle"):
        med=[statistics.median(col) for col in zip(*(getattr(run,name) for run in runs))]
        print(f"Median {name} [%]: "+" / ".join(f"{100*v:.6g}" for v in med))
    print("Dreieck bei gleichem h und eingefrorenen Gewichten: halbzellige Charakteristik")
    for n in (112,240):
        offgrid=[blind_run(model,n) for model in trained]
        med=[statistics.median(col) for col in zip(*(run.triangle for run in offgrid))]
        print(f"N={n+1} Knoten, c*h in Zellen={SPEED*DT*n:.1f}, Median [%]: "
              +" / ".join(f"{100*v:.6g}" for v in med))
    print("Gedämpfte Saite, 0,8 s: beta [1/s], Schranke [1/s], Fehler ohne/mit Dämpfung [%]")
    damped = []
    for seed,run in zip(SEEDS,runs):
        beta,budget,errors=damped_case(seed,run.speed)
        damped.append(errors)
        print(f"Seed {seed}: {beta:.6f} / {budget:.6f} / {100*errors[0]:.5f} / {100*errors[1]:.5f}")
    print("Median gedämpft [%]: "+" / ".join(f"{100*statistics.median(col):.5f}" for col in zip(*damped)))


if __name__ == "__main__":
    main()
