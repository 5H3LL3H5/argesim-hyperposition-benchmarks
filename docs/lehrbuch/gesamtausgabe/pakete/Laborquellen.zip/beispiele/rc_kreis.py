R, C, U = 1000.0, 0.001, 5.0  # Ohm, Farad, Volt


def rhs_rc(t, y, quelle=U):
    (u,) = y
    return ((quelle - u) / (R * C),)


def res_rc(t, y, yp, quelle=U):
    u, i = y
    du, _ = yp
    return C * du - i, u + R * i - quelle


tol_i, tol_u = 0.5e-9, 0.5e-6  # A bzw. V, halbe Anzeigeeinheit
for quelle, strom, steigung in ((5.0, 0.004, 4.0), (3.0, 0.002, 2.0)):
    (du,) = rhs_rc(0.0, (1.0,), quelle)
    assert abs(du - steigung) <= tol_i / C
    r_i, r_u = res_rc(0.0, (1.0, strom), (du, -du / R), quelle)
    assert abs(r_i) <= tol_i and abs(r_u) <= tol_u

r_i, r_u = res_rc(0.0, (1.0, 0.0), (0.0, 0.0))
assert abs(r_i) <= tol_i and abs(r_u + 4.0) <= tol_u
print(f"Inkonsistenter Start: {r_i:.9f} A, {r_u:.6f} V")

r_i, r_u = res_rc(0.0, (1.0, 0.004), (4.0, -0.004), 3.0)
assert abs(r_i) <= tol_i and abs(r_u - 2.0) <= tol_u
print(f"Alter Strom bei neuer Quelle: {r_i:.9f} A, {r_u:.6f} V")
