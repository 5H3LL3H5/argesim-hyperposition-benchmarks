"""Aus einer nach der höchsten Ableitung aufgelösten skalaren DGL."""
def reduzieren(hoechste_ableitung):
    def rhs(t, y):
        if not y:
            raise ValueError("Der Zustand benötigt mindestens einen Eintrag.")
        return (*y[1:], hoechste_ableitung(t, *y))
    return rhs


# Ordnung eins und drei. Die Tupel enthalten Zahlenwerte in SI.
abkuehlung = reduzieren(lambda t, q: -2.0 * q)
assert abkuehlung(0.5, (1.5,)) == (-3.0,)

# q(t) = 1 + 2t - 3t² + t³, t als Zahlenwert in Sekunden.
polynom = reduzieren(lambda t, q, v, w: 6.0)
for t in (0.0, 0.5, 1.0):
    q = 1.0 + 2.0*t - 3.0*t*t + t**3
    v = 2.0 - 6.0*t + 3.0*t*t
    w = -6.0 + 6.0*t
    assert polynom(t, (q, v, w)) == (v, w, 6.0)

# Hier hängt die höchste Ableitung vom mittleren Zustand ab.
schwingung = reduzieren(lambda t, q, v, w: -4.0 * v)
assert schwingung(0.0, (1.0, 2.0, -3.0)) == (2.0, -3.0, -8.0)
print("Ordnungen 1 und 3: alle Komponenten an der richtigen Stelle.")
