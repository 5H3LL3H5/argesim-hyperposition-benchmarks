"""Kapitel 4. Index-1-RC-Kreis, Residuum und RATTLE für einen Kreis."""
import math


def rc_step(u, h, supply, R, C):
    # Lösung beider linearer Residualgleichungen eines Rückwärts-Euler-Schritts.
    current=(supply-u)/(R+h/C)
    return u+h*current/C,current


def rattle(q,v,h,acc=(0.,-9.81),length=1.0):
    trial=tuple(x+h*w+h*h*g/2 for x,w,g in zip(q,v,acc))
    dot=lambda a,b: math.fsum(x*y for x,y in zip(a,b))
    # Normierung vermeidet, dass alte Rundungsreste die nächste Norm vorgeben.
    unit=tuple(x/math.hypot(*q) for x in q)
    proj=dot(trial,unit)
    perp=tuple(x-proj*n for x,n in zip(trial,unit))
    disc=length**2-dot(perp,perp)
    if disc<=0 or h==0:
        raise ValueError("Lokaler RATTLE-Ast nicht eindeutig oder h=0")
    new=tuple(x+math.sqrt(disc)*n for x,n in zip(perp,unit))
    unc=tuple((x-old)/h+h*a/2 for x,old,a in zip(new,q,acc))
    normal=dot(unc,new)/dot(new,new)
    return new,tuple(w-normal*x for w,x in zip(unc,new))


def check():
    h,R,C,U=.1,2000.,.001,5.
    u,i=rc_step(0.,h,U,R,C)
    scale=math.ulp(U)
    assert abs(U-u-R*i)<=4*scale and abs(C*u/h-i)<=4*math.ulp(i)
    assert abs(u-U*h/(R*C+h))<=4*scale
    print(f"RC: U1={u:.9f} V, I1={1000*i:.9f} mA")
    for h in (.1,.05):
        q,v=(1.,0.),(0.,1.)
        steps=round(1/h)
        for _ in range(steps):
            q,v=rattle(q,v,h,acc=(0.,0.))
            assert abs(math.hypot(*q)-1)<=8*math.ulp(1.)
            assert abs(sum(x*y for x,y in zip(q,v)))<=16*math.ulp(1.)
        phase=math.atan2(q[1],q[0])
        reference=steps*math.asin(h)
        rounding=64*steps*math.ulp(1.)/h
        assert abs(phase-reference)<=rounding
        bound=steps*h**3/(6*(1-h*h)**1.5)
        assert abs(phase-1)<=bound+rounding
        print(f"RATTLE h={h:g} s: Phasenfehler={phase-1:.8f} rad, Budget={bound:.8f}")
    # Bei dem regulären Testast z²+y=1 und y'=z: Newton auf dem
    # nach Substitution y=y0+h*z verbleibenden Schrittresiduum.
    h=.5; start=0.; z=1.
    for _ in range(5):
        z-=(z*z+h*z+start-1)/(2*z+h)
    end=start+h*z
    root=2*(1-start)/(h+math.sqrt(h*h+4*(1-start)))
    assert abs(z-root)<=4*math.ulp(1.) and abs(z*z+end-1)<=4*math.ulp(1.)
    assert abs((end-start)/h-z)<=2*math.ulp(1.) and z>0
    print(f"Nichtlinearer DAE-Schritt: y={end:.9f}, z={z:.9f}")
    for eps in (.1,.01):
        t=1.
        fast=1-math.exp(-t/eps)
        slow=1-math.exp(-t)-(math.exp(-t)-math.exp(-t/eps))/(1/eps-1)
        # Integral des Defekts e'=-e-exp(-t/eps) mit Integrationsfaktor.
        defect=-math.exp(-t)*math.expm1(t*(1-1/eps))/(1-1/eps)
        assert abs((slow-(1-math.exp(-t)))-defect)<=4*math.ulp(1.)
        assert abs(defect)<=eps/(1-eps) and 0<=fast<=1
    # Ein frei beschleunigtes Pendel: Umgekehrter Zeitschritt muss den
    # Ausgangszustand derselben lokalen Wurzel wiederfinden.
    q0,v0=(1.,0.),(0.,1.); h=.01
    q,v=rattle(q0,v0,h)
    qr,vr=rattle(q,v,-h)
    assert math.dist(qr,q0)<64*math.ulp(1.)
    assert math.dist(vr,v0)<64*math.ulp(1.)/h


if __name__=="__main__":
    check()
