"""Kapitel 6. QSS1-Kalender für x'=Aq und skalare QSS1–4-Schrittpolynome."""
import heapq
import math


def qss1(matrix, initial, quantum, until, ordering=None, forcing=None):
    n=len(initial)
    if quantum<=0 or until<0 or any(len(r)!=n for r in matrix) or len(matrix)!=n:
        raise ValueError("Matrix, Endzeit oder Quantum ungültig")
    forcing=(0.,)*n if forcing is None else tuple(forcing)
    if len(forcing)!=n: raise ValueError("Ungültiger Eingang")
    x=list(initial); q=x.copy(); versions=[0]*n
    derivatives=[c+sum(a*b for a,b in zip(row,q)) for c,row in zip(forcing,matrix)]
    priority=list(range(n)) if ordering is None else ordering
    calendar=[]; t=0.; log=[]; stale=0
    def schedule(i):
        versions[i]+=1
        v=derivatives[i]
        if v:
            limit=q[i]+math.copysign(quantum,v)
            at=t+(limit-x[i])/v
            if at<=t: raise ArithmeticError("Zeitauflösung des Quantisierers")
            heapq.heappush(calendar,(at,priority[i],i,versions[i]))
    for i in range(n): schedule(i)
    while calendar and calendar[0][0]<=until:
        at=calendar[0][0]; due=[]
        while calendar and calendar[0][0]==at:
            _,_,i,version=heapq.heappop(calendar)
            if version==versions[i]: due.append(i)
            else: stale+=1
        if not due: continue
        x=[a+(at-t)*v for a,v in zip(x,derivatives)];t=at
        for i in due: q[i]=x[i]
        affected={j for j,row in enumerate(matrix) if any(row[i] for i in due)}
        for j in affected: derivatives[j]=forcing[j]+sum(a*b for a,b in zip(matrix[j],q))
        for j in sorted(affected.union(due)): schedule(j)
        log.append((t,tuple(x),tuple(q),tuple(sorted(due))))
    final=tuple(a+(until-t)*v for a,v in zip(x,derivatives))
    return final,log,stale


def scalar_order(order, delta, end=1.0):
    """x'=-q. Taylorpolynom für die Meldung und dessen Integral."""
    if order not in (1,2,3,4) or delta<=0 or end<0: raise ValueError("Labordaten")
    t,x,count=0.,1.,0
    while t<end and x!=0:
        dt=(math.factorial(order)*delta/abs(x))**(1/order)
        stop=min(t+dt,end)
        if stop<=t: raise ArithmeticError("Kein Zeitfortschritt")
        s=stop-t
        approx=x*sum((-s)**j/math.factorial(j) for j in range(order))
        new=approx+x*(-s)**order/math.factorial(order)
        assert abs(new-approx)<=delta+32*math.ulp(1.)
        if t+dt<=end: count+=1
        t,x=stop,new
    return x,count


def check():
    matrix=((-1.,0.),(1.,-2.))
    for quantum in (1/8,1/16):
        y,log,stale=qss1(matrix,(1.,0.),quantum,2.)
        for t,x,q,_ in log:
            assert max(abs(a-b) for a,b in zip(x,q))<=quantum+32*math.ulp(1.)
            exact=(math.exp(-t),math.exp(-t)-math.exp(-2*t))
            assert max(abs(a-b) for a,b in zip(x,exact))<=3*quantum*(-math.expm1(-t))+64*math.ulp(1.)
        assert stale>0
        print(f"QSS1 D={quantum:.4f}: {len(log)} Zeitpunkte, {stale} alte Prognosen, x(2)={y}")
    matrix=((-1.,0.),(0.,-1.))
    a=qss1(matrix,(1.,1.),.25,1.)
    b=qss1(matrix,(1.,1.),.25,1.,ordering=[1,0])
    assert a==b and a[1][0][3]==(0,1)
    # Gleiche Termine, ein gemeinsamer Verbraucher. Keine Zwischenmeldung
    # zwischen den beiden Ausgaben darf dessen Ableitung verfälschen.
    A=((0.,0.,0.),(0.,0.,0.),(1.,-1.,0.))
    options=dict(matrix=A,initial=(0.,0.,0.),quantum=.25,until=1.,forcing=(1.,1.,0.))
    y,log,_=qss1(**options)
    assert y==(1.,1.,0.) and all(row[3]==(0,1) for row in log)
    assert qss1(**options,ordering=[1,0,2])==qss1(**options)
    gain,steady,D=1000.,.03,.1
    up,down=gain*steady,gain*(steady-D)
    period=D/up-D/down
    assert abs(D+down*(period-D/up))<=8*math.ulp(1.)
    assert abs(steady)<D and gain*(steady-steady)==0
    for p in range(1,5):
        y,count=scalar_order(p,.002)
        assert abs(y-math.exp(-1))<=.002*(1-math.exp(-1))+50*math.ulp(1.)
        print(f"QSS{p} skalar: {count} Meldungen, Endfehler {abs(y-math.exp(-1)):.3e}")


if __name__=="__main__":
    check()
