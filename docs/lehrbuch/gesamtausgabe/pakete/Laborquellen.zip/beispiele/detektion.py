"""Zwei Durchgänge, Berührung und Zeitfehler einer dichten RK4-Ausgabe."""
import math
from ereignis import brent, first_crossing, rk4_dense
from ball import XTOL


def growth(step):
    """y'=y in der dimensionslosen Zeit s=t/(1 s); gesucht ist y=2."""
    n = round(1/step)
    t, y = 0.0, (1.0,)
    rhs = lambda s, x: x
    for k in range(n):
        stop = (k+1)/n
        y1, dense = rk4_dense(rhs, t, y, stop)
        hit = first_crossing(lambda s: dense(s)[0]-2, t, stop, 1, XTOL)
        if hit is not None:
            return hit
        t, y = stop, y1
    raise ArithmeticError("Schwellenwert 2 wurde nicht erreicht")


def quadratic_turning_times(a, b, left, right):
    """Innere stationäre Stellen von a*t**2 + b*t + c im Lehrversuch."""
    if a == 0:
        return ()
    turn = -b / (2 * a)
    return (turn,) if left < turn < right else ()


def check():
    signal = lambda t: (t-0.25)*(t-0.75)
    turn = quadratic_turning_times(1, -1, 0, 1)
    assert turn == (0.5,)
    assert quadratic_turning_times(0, 1, 0, 1) == ()
    assert first_crossing(signal, 0, 1, -1, XTOL) is None
    for direction, exact in ((-1, 0.25), (1, 0.75)):
        hit = first_crossing(signal, 0, 1, direction, XTOL, turn)
        assert abs(hit - exact) <= XTOL
    grazing = lambda t: (t-0.5)**2
    for direction in (-1, 1):
        assert first_crossing(grazing, 0, 1, direction, XTOL, turn,
                              rate=lambda t: 2*(t-0.5)) is None
    assert grazing(0.5) == 0       # eigener Berührwächter am Minimum
    # Im angegebenen Intervall sind diese Nullstellen einfach und isoliert.
    cases = [(lambda t: t*t-2, 1.0, 2.0, math.sqrt(2)),
             (lambda t: math.cos(t), 1.0, 2.0, math.pi/2),
             (lambda t: 1e-270*(t-0.7), -1.0, 2.0, 0.7)]
    for f, lo, hi, ref in cases:
        assert abs(brent(f, lo, hi, XTOL)-ref) <= XTOL + 2*math.ulp(ref)
    # Ein konstanter Höhenfehler dq verschiebt eine lineare Nullstelle um dq/v.
    for speed in (2.0, 0.02):
        dq = 1e-4       # m
        hit = brent(lambda t: speed*(1-t)+dq, 0, 2, XTOL)
        assert abs((hit-1)-dq/speed) <= XTOL + 3*math.ulp(hit)
    for n in (2, 4, 8, 16):
        h = 1/n
        hit = growth(h)
        err = abs(hit-math.log(2))
        grid = math.e*h**4/120
        dense = (1+h/4)*grid + math.e*h**4/384
        rounding = 128*(n+1)*math.ulp(4.0)
        assert err <= dense + XTOL + rounding
        print(f"h={h:.4f} s, Zeitfehler {err:.6e} s, "
              f"analytisches Budget {dense:.6e} s")


if __name__ == "__main__":
    check()
