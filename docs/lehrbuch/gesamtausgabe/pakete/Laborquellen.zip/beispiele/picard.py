"""Picard-Iteration für eine normierte Temperatur, Zeit in Sekunden."""
from math import exp, factorial


def picard_polynom(t, rate, grad):
    term = wert = 1.0
    for j in range(1, grad + 1):
        term *= -rate * t / j
        wert += term
    return wert, term


h, rate, budget = 0.1, 2.0, 1e-6
rho = h * rate
assert h * 4.0 <= 1.0 and rho < 1.0

for grad in range(1, 6):
    wert, letzter_term = picard_polynom(h, rate, grad)
    fehler = abs(wert - exp(-rho))
    taylor = rho**(grad + 1) / factorial(grad + 1)
    banach = rho / (1.0 - rho) * abs(letzter_term)
    assert fehler <= taylor and fehler <= banach
    if grad < 5:
        assert fehler > budget
    if grad == 5:
        assert max(taylor, banach) < budget
    print(f"m={grad}: u={wert:.9f}, Fehler={fehler:.3e}, "
          f"Taylor<={taylor:.3e}, Banach<={banach:.3e}")
