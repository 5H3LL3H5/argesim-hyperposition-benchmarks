"""Kapitel 9. DFT-Konvention, gelernter Saitenpropagator und nichtlinearer FNO."""
import cmath
import math
import random


def fft(values, inverse=False):
    """Unnormierte Vorwärts-DFT; inverse DFT mit 1/N. Für Radix 2 schnell."""
    n=len(values)
    if not n: raise ValueError("Leere Folge")
    if inverse: return [z.conjugate()/n for z in fft([complex(v).conjugate() for v in values])]
    if n==1: return [complex(values[0])]
    if n%2: return [sum(v*cmath.exp(-2j*math.pi*k*j/n) for j,v in enumerate(values)) for k in range(n)]
    even=fft(values[::2]);odd=fft(values[1::2])
    twist=[b*cmath.exp(-2j*math.pi*k/n) for k,b in enumerate(odd)]
    return [a+b for a,b in zip(even,twist)]+[a-b for a,b in zip(even,twist)]


def layer(channels,W,R,bias,activation=math.tanh):
    """W[out][in], R[k][out][in], Kanäle auf periodischem Gitter ohne Endduplikat."""
    n=len(channels[0]); kmax=len(R)-1
    if not 0<=kmax<=(n-1)//2: raise ValueError("Modenzahl überschreitet eindeutige Paare")
    if any(len(x)!=n for x in channels): raise ValueError("Verschiedene Gitter")
    spectra=[fft(x) for x in channels]
    out=[]
    for o,row in enumerate(W):
        bins=[0j]*n
        for k,weights in enumerate(R):
            z=sum(w*xs[k] for w,xs in zip(weights[o],spectra,strict=True))
            bins[k]=z.real if k==0 else z
            if k: bins[-k]=z.conjugate()
        nonlocal_part=fft(bins,inverse=True)
        out.append([activation(bias[o]+val.real+sum(w*x[j] for w,x in zip(row,channels,strict=True)))
                    for j,val in enumerate(nonlocal_part)])
    return out


def sine_coeff(field,kmax):
    n=len(field)-1
    if not 0<kmax<n or field[0]!=0 or field[-1]!=0: raise ValueError("Dirichlet-Gitter")
    spec=fft(list(field)+[-v for v in field[-2:0:-1]])
    return [-spec[k].imag/n for k in range(1,kmax+1)]


def synthesis(a,n):
    return [0.]+[sum(v*math.sin(k*math.pi*j/n) for k,v in enumerate(a,1))
                 for j in range(1,n)]+[0.]


def train_string(samples,kmax):
    cross=[0.]*kmax; power=[0.]*kmax
    for x,y in samples:
        for k,(ak,bk) in enumerate(zip(sine_coeff(x,kmax),sine_coeff(y,kmax))):
            cross[k]+=ak*bk;power[k]+=ak*ak
    if not all(z>1e-12 for z in power): raise ValueError("Eine Trainingsmode ist unbestimmt")
    return [a/b for a,b in zip(cross,power)]


def pluck(x,peak=.37):
    # Ungerade, 2-periodische Fortsetzung des dreieckigen Profils auf [0,1].
    z=x%2
    if z>1: return -pluck(2-z,peak)
    return z/peak if z<=peak else (1-z)/(1-peak)


def relative(pred,ref):
    nr=math.sqrt(sum(a*a for a in ref))
    if nr==0: raise ValueError("Absolute Fehlergröße für verschwindende Referenz wählen")
    return math.sqrt(sum((a-b)**2 for a,b in zip(pred,ref)))/nr


def string_run():
    rng=random.Random(2026); T=.19; K=8; n0=32
    exact=[math.cos(k*math.pi*T) for k in range(1,K+1)]
    samples=[]
    for _ in range(12):
        a=[rng.uniform(-1,1) for _ in range(K)]
        samples.append((synthesis(a,n0),synthesis([v*r for v,r in zip(a,exact)],n0)))
    learned=train_string(samples,K)
    test=[rng.uniform(-1,1) for _ in range(K)]
    results=[]
    for n in (32,128,256):
        a=synthesis(test,n)
        pred=synthesis([r*v for r,v in zip(learned,sine_coeff(a,K))],n)
        ref=synthesis([r*v for r,v in zip(exact,test)],n)
        band=relative(pred,ref)
        bump=[pluck(j/n) for j in range(n+1)]
        true=[(pluck(j/n-T)+pluck(j/n+T))/2 for j in range(n+1)]
        pred=synthesis([r*v for r,v in zip(learned,sine_coeff(bump,K))],n)
        results.append((n,band,relative(pred,true),pred,true))
    return learned,exact,results


def features(x,K):
    n=len(x);s=fft(x)
    rows=[]
    for j,v in enumerate(x):
        row=[1.,v,s[0].real/n]
        for k in range(1,K+1):
            basis=2/n*s[k]*cmath.exp(2j*math.pi*j*k/n)
            row.extend((basis.real,-basis.imag))
        rows.append(row)
    return rows


def teacher(x):
    # Unabhängige Ortsraumquadratur einer hergestellten nichtlinearen Abbildung.
    n=len(x)
    kernel=[.8*math.cos(2*math.pi*j/n)+.3*math.sin(2*math.pi*j/n)
            -.4*math.cos(4*math.pi*j/n) for j in range(n)]
    return [math.tanh(.1+.35*v+sum(kernel[(j-i)%n]*a for i,a in enumerate(x))/n)
            for j,v in enumerate(x)]


def periodic_field(n,pars):
    return [pars[0]+sum(pars[2*k-1]*math.cos(2*math.pi*k*j/n)
            +pars[2*k]*math.sin(2*math.pi*k*j/n) for k in (1,2,3,4))
            for j in range(n)]


def train_nonlinear():
    rng=random.Random(17); samples=[]
    for _ in range(10):
        x=periodic_field(24,[rng.uniform(-.65,.65) for _ in range(9)])
        samples.extend(zip(features(x,2),teacher(x)))
    p=[0.]*7
    for _ in range(650):
        grad=[0.]*len(p)
        for row,target in samples:
            y=math.tanh(sum(w*z for w,z in zip(p,row)))
            d=(y-target)*(1-y*y)
            for i,z in enumerate(row): grad[i]+=d*z
        p=[w-.65*g/len(samples) for w,g in zip(p,grad)]
    return p


def check():
    for n in (15,32):
        u=[math.sin(j*.31) for j in range(n)]
        assert max(abs(a-b) for a,b in zip(u,fft(fft(u),inverse=True)))<=64*n*math.ulp(1.)
    learned,exact,rows=string_run()
    assert max(abs(a-b) for a,b in zip(learned,exact))<=256*math.ulp(1.)
    for n,band,triangle,_,_ in rows:
        # Bis K=8: großzügige Rundungsreserve für Summen, Fit und Transformation.
        assert band<=128*n*math.ulp(1.)
        print(f"Saite N={n} Intervalle: bandbegrenzt {band:.3e}, Dreieck {100*triangle:.4f} %")
    p=train_nonlinear()
    R=[[[p[2]]],[[complex(*p[3:5])]],[[complex(*p[5:7])]]]
    pars=[.18,-.49,.55,.34,-.23,-.38,.28,-.12,.09]
    for n in (24,96):
        x=periodic_field(n,pars); y=layer([x],[[p[1]]],R,[p[0]])[0]
        rms=math.sqrt(sum((a-b)**2 for a,b in zip(y,teacher(x)))/n)
        # |tanh'|<=1. Der Cauchy-Schwarz-Test nutzt unabhängige Koeffizienten
        # des bekannten Ortsraumkerns (dessen Mittelwert ist null).
        true=(.1,.35,0.,.4,-.15,-.2,0.)
        coeff=math.sqrt(sum((a-b)**2 for a,b in zip(p,true)))
        norm=math.sqrt(sum(sum(v*v for v in row) for row in features(x,2))/n)
        assert rms<=coeff*norm+128*n*math.ulp(1.) and rms<.001
        print(f"Nichtlinearer FNO N={n}: RMS={rms:.5e}, Parameterbudget={coeff*norm:.5e}")
    # Ein räumlicher Gegenbeweis: sin(32*pi*x) verschwindet an j/32.
    a=[math.sin(32*math.pi*j/32) for j in range(33)]
    assert max(map(abs,a))<64*math.ulp(math.pi)
    assert abs(math.sin(32*math.pi/64)-1)<math.ulp(1.)
    n=31
    x=[math.cos(2*math.pi*j/n) for j in range(n)]
    shifted=layer([x],[[0.]],[[[0.]],[[1j]]],[0.],lambda v:v)[0]
    assert max(abs(v+math.sin(2*math.pi*j/n)) for j,v in enumerate(shifted))<=128*n*math.ulp(1.)
    # Mehrere Kanäle: konstante Felder testen Kanal- und Modenachsen.
    identity=lambda v:v
    x=layer([[1.]*15,[2.]*15],[[1.,2.]],[[[3.,-1.]]],[.25],identity)
    assert max(abs(y-6.25) for y in x[0])<100*math.ulp(6.25)


if __name__=="__main__":
    check()
