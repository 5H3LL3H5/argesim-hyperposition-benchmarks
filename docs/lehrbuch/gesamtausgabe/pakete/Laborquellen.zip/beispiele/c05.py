"""Kurzes C05-Fenster: Referenz aus exakten Phasen und Bisektion."""
from math import exp


A, B = 2.7e6, 3.5651205  # Raten in 1/s
MODEN = ((0.4, 5.5, 5.8, 1), (-0.3, 2.73, 2.5, -1))


def phase(dt, start, c2, c4):
    y1, y2 = start
    d = y2 - c4
    k = A*d / (A-B)
    langsam = exp(-B*dt)
    schnell = exp(-A*dt)
    return (c2+c4 + k*langsam + (y1-c2-c4-k)*schnell,
            c4 + d*langsam)


def schaltfolge(ende=3.5):
    t, zustand, modus = 0.0, (4.2, 0.3), 0
    ereignisse = []
    while t < ende:
        c2, c4, schwelle, richtung = MODEN[modus]
        rest = ende - t
        ziel = phase(rest, zustand, c2, c4)
        if richtung*(ziel[0]-schwelle) < 0:
            return ereignisse, ziel
        links, rechts = 0.0, rest
        while rechts-links > 2e-10:
            mitte = (links+rechts)/2
            y1, _ = phase(mitte, zustand, c2, c4)
            if richtung*(y1-schwelle) >= 0:
                rechts = mitte
            else:
                links = mitte
        dt = (links+rechts)/2
        zustand = phase(dt, zustand, c2, c4)
        t += dt
        ereignisse.append((t, richtung))
        modus = 1-modus
    return ereignisse, zustand


if __name__ == "__main__":
    folge, ende = schaltfolge()
    soll = (1.108306, 2.129685, 3.054153)  # Projektwerte in s
    assert [r for _, r in folge] == [1, -1, 1]
    for (t, richtung), t_ref in zip(folge, soll):
        assert abs(t-t_ref) <= 0.5e-6 + 1e-9 < 1e-3
        print(f"{richtung:+d} bei {t:.9f} s")
    assert max(abs(ende[0]-2.97475519), abs(ende[1]-3.27475448)) < 1e-5
    print(f"Endzustand ({ende[0]:.8f}, {ende[1]:.8f})")
