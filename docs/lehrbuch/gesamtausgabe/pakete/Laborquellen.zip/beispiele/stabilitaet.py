"""Stabilitätsfaktoren für eine normierte Abweichung."""
from cmath import exp as cexp
from math import exp


def radau_faktor(z):
    zaehler = 1 + z * (2/5 + z/20)
    nenner = 1 + z * (-3/5 + z * (3/20 - z/60))
    return zaehler / nenner


def rueckwaerts(z):
    return 1 / (1 - z)


def trapez(z):
    return (1 + z/2) / (1 - z/2)


if __name__ == "__main__":
    aufloesung = 0.5e-9  # halbe letzte Stelle der Faktorentabelle
    for z in (-10.0, -100.0):
        print(f"{z:5.0f} {exp(z):.9f} {rueckwaerts(z):.9f} "
              f"{trapez(z):.9f} {radau_faktor(z):.9f}")
    assert abs(radau_faktor(-10) - 3/58) <= aufloesung
    assert abs(trapez(-100) + 49/51) <= aufloesung
    # Physikalisches Ziel: Rest nach einem groben Schritt unter 1 %.
    assert exp(-100) < 0.01
    assert abs(rueckwaerts(-100)) < 0.01 < abs(trapez(-100))
    z = -1 + 2j
    assert abs(cexp(z)) < 1 < abs(1 + z)
    assert max(abs(rueckwaerts(z)), abs(trapez(z)),
               abs(radau_faktor(z))) < 1
