"""Stoßsensitivität bei gleicher Uhrzeit. Einheiten wie im Kapitel."""
import math


def after_bounce(height, T, e, g):
    tau = math.sqrt(2*height/g)
    dt = T-tau
    u = e*g*tau
    if not 0 < dt < 2*u/g:
        raise ValueError("Die Beobachtung muss im ersten Rückflug liegen")
    return (u*dt-g*dt*dt/2, u-g*dt)


def moving_event(x0, T=0.75):
    # Vorher x'=3, Wächter x-t-1, Reset x/2+t, nachher x'=-1.
    tau = (1-x0)/2
    if not 0 < tau < T:
        raise ValueError("Das Beobachtungsfenster muss den Übergang enthalten")
    xminus = x0+3*tau
    return xminus/2 + tau - (T-tau)


def check():
    H, T, g, e = 2.0, 0.8, 9.81, 0.85
    tau = math.sqrt(2*H/g)
    vminus = -g*tau
    s21 = -(1+e)*g/vminus
    # Erste Spalte der gemeinsamen Flussableitung am Zeitpunkt T.
    predicted = (-e+(T-tau)*s21, s21)
    delta = 2**-12                      # symmetrische Änderung von H in m
    plus = after_bounce(H+delta, T, e, g)
    minus = after_bounce(H-delta, T, e, g)
    measured = tuple((a-b)/(2*delta) for a, b in zip(plus, minus))
    # Für w(H)=sqrt(2gH) ist w'''=3 g³/(2gH)^(5/2).
    third = 3*g**3/(2*g*(H-delta))**2.5
    for i, factor in enumerate((T, 1.0)):
        trunc = (1+e)*factor*third*delta**2/6
        # Skalen für die beiden Komponenten: g*T²+H (m), g*T+|v-| (m/s).
        scale = (g*T*T+H, g*T+abs(vminus))[i]
        roundoff = 64*math.ulp(scale)/delta
        assert abs(measured[i]-predicted[i]) <= trunc+roundoff
    print("Ball, d(q,v)/dH bei 0.8 s:", *(f"{a:.9f}" for a in measured))
    # Bewegte Fläche und explizit zeitabhängiger Reset. Alle Zahlen sind
    # dyadisch. Die Abbildung ist affin; der zentrale Quotient ist hier exakt.
    delta = 2**-8
    observed = (moving_event(delta)-moving_event(-delta))/(2*delta)
    full = 0.5+(-1-0.5*3-1)/(3-1)
    assert observed == full == -1.25
    print("Bewegte Schwelle, Sensitivität:", full)


if __name__ == "__main__":
    check()
