def wagen_rhs(t, y):
    q, v = y
    return v, -4.0 * q  # k/m = 4 s^-2


def energie(q, v):
    return (4.0 * q * q + v * v) / 2  # Joule bei m = 1 kg


q, v, h = 0.10, 0.0, 0.1
e0 = energie(q, v)
faktor = 1.0 + 4.0 * h * h
tol_joule = 0.5e-6  # halbe Auflösung einer Anzeige in Mikrojoule
for n in range(1, 11):
    dq, dv = wagen_rhs((n - 1) * h, (q, v))
    q, v = q + h * dq, v + h * dv
    e_n = energie(q, v)
    assert abs(e_n - e0 * faktor**n) <= tol_joule
    if n == 1:
        assert abs(e_n - 0.0208) <= tol_joule
        assert e_n - e0 > 0.01 * e0
print(f"Nach 1 s: {e_n:.6f} J, Energiezuwachs {e_n/e0-1:.2%}")
