"""Zeitpuls, C12-Einzelkontakt und ein Filippov-Gleitversuch."""
import math
from ereignis import first_crossing, rk4_dense


def impulse(step):
    # Kraft in N; der Zustand ist der seit t=0 eingetragene Kraftstoß (N s).
    t, y = 0.0, (0.0,)
    states = []
    for edge, force in ((4.0, 0.0), (7.0, -800.0), (15.0, 0.0)):
        def rhs(time, state):
            return (force,)
        while t < edge:
            stop = min(t+step, edge)
            if stop <= t:
                raise ArithmeticError("Zeitauflösung erschöpft")
            y, _ = rk4_dense(rhs, t, y, stop)
            t = stop
        states.append((t, y[0]))
    return states


def check():
    for step in (0.375, 10.0):   # dyadische Länge und ganze Pulsgrenzen
        assert impulse(step) == [(4, 0), (7, -2400), (15, -2400)]
    print("C13-Eingang: Kraftstoß nach der zweiten Flanke −2400 N s")
    m, gap = 1.0, 0.60
    vi, vj = 0.80, 0.20
    time = first_crossing(lambda t: gap + (vj-vi)*t, 0, 2, -1, 2e-14)
    assert abs(time-1) <= 2e-14 + 2*math.ulp(1.0)
    after_i, after_j = vj, vi   # gleicher Masse, zentral, ideal elastisch
    assert after_j-after_i > 0 and after_i-vj == after_j-vi == 0
    assert m*(vi+vj) == m*(after_i+after_j)
    assert m*(vi**2+vj**2)/2 == m*(after_i**2+after_j**2)/2
    print(f"C12-Einzelkontakt: {time:.6f} s, auslaufender Spalt öffnet sich")
    x, quantum = 0.25, 1.0
    assert (quantum-x)/1.0 == 0.75 and (quantum-x)/2.0 == 0.375
    # g=x, beide Felder zeigen zur Fläche. Zeitanteile im Hystereseband.
    a_minus, a_plus = 2.0, -1.0
    alpha = a_minus/(a_minus-a_plus)
    slide = (1-alpha)*1.0 + alpha*4.0
    assert abs((1-alpha)*a_minus + alpha*a_plus) <= 2*math.ulp(1.0)
    counts = []
    for delta in (1/16, 1/32):
        left_time, right_time = 2*delta/a_minus, -2*delta/a_plus
        period = left_time + right_time
        cycles = 3.0/period
        assert cycles.is_integer()
        counts.append(2*int(cycles))
        y = cycles*(left_time + 4*right_time)
        assert y == 9.0 and abs(y/3-slide) <= 2*math.ulp(3.0)
    assert counts == [32, 64]
    print("Gleiten: dy/dt=3 m/s; 32 bzw. 64 Schaltungen in 3 s")


if __name__ == "__main__":
    check()
