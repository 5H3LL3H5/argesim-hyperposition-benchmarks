"""D2Q9 ohne Drittbibliotheken. y wächst nach oben; Einheiten im Gitter."""
import math
import cmath

CX=(0,1,0,-1,0,1,-1,-1,1)
CY=(0,0,1,0,-1,1,1,-1,-1)
OPP=(0,3,4,1,2,7,8,5,6)
W=(4/9,1/9,1/9,1/9,1/9,1/36,1/36,1/36,1/36)


def moments(f):
    rho=sum(f)
    if not math.isfinite(rho) or rho<=0:
        raise ArithmeticError("Ungültige Gitterdichte")
    return rho, (f[1]-f[3]+f[5]-f[6]-f[7]+f[8])/rho, (f[2]-f[4]+f[5]+f[6]-f[7]-f[8])/rho


def equilibrium(rho,ux,uy):
    base=1-1.5*(ux*ux+uy*uy)
    cu=(0.,ux,uy,-ux,-uy,ux+uy,-ux+uy,-ux-uy,ux-uy)
    return [w*rho*(base+v*(3+4.5*v)) for w,v in zip(W,cu)]


def collide(f,omega):
    eq=equilibrium(*moments(f))
    return [a+omega*(b-a) for a,b in zip(f,eq)]


def horizontal_wall(f, upper, velocity):
    """Zou–He für eine tangential bewegte horizontale Wand mit u_y=0."""
    if upper:
        rho=f[0]+f[1]+f[3]+2*(f[2]+f[5]+f[6])
        f[4]=f[2]
        f[7]=f[5]+.5*(f[1]-f[3])-.5*rho*velocity
        f[8]=f[6]+.5*(f[3]-f[1])+.5*rho*velocity
    else:
        rho=f[0]+f[1]+f[3]+2*(f[4]+f[7]+f[8])
        f[2]=f[4]
        f[5]=f[7]+.5*(f[3]-f[1])+.5*rho*velocity
        f[6]=f[8]+.5*(f[1]-f[3])-.5*rho*velocity


class D2Q9:
    def __init__(self,nx,ny,tau,lid=0.,boundary="halbweg",periodic_x=False):
        if nx<1 or ny<3 or not math.isfinite(tau) or tau<=.5:
            raise ValueError("Gitter oder Relaxationszeit ungültig")
        if boundary not in ("halbweg","zouhe","periodisch") or not math.isfinite(lid):
            raise ValueError("Unbekannter Rand oder ungültige Deckelgeschwindigkeit")
        self.nx,self.ny,self.omega,self.lid=nx,ny,1/tau,lid
        self.boundary=boundary
        self.f=[list(W) for _ in range(nx*ny)]
        self.links=[]
        for y in range(ny):
            for x in range(nx):
                src=y*nx+x
                local=[]
                for i,(dx,dy) in enumerate(zip(CX,CY)):
                    X,Y=x+dx,y+dy
                    # (Zielzelle, Zielrichtung, Wandkorrektur), rho_ref=1.
                    if boundary=="periodisch":
                        dest=((Y%ny)*nx+X%nx,i,0.)
                    elif not 0<=Y<ny:
                        if boundary=="zouhe":
                            dest=None
                        else:
                            wall_speed=lid if Y>=ny else 0.
                            dest=(src,OPP[i],-6*W[i]*dx*wall_speed)
                    elif not periodic_x and not 0<=X<nx:
                        dest=(src,OPP[i],0.)
                    else:
                        dest=(Y*nx+X%nx,i,0.)
                    local.append(dest)
                self.links.append(local)
        if boundary=="zouhe":
            for f in self.f[-nx:]: horizontal_wall(f,True,lid)

    def step(self):
        # Alle neun Zielrichtungen pro Knoten werden aus dem alten Feld
        # genau einmal geliefert oder nach dem Streaming am Rand ergänzt.
        new=[[0.]*9 for _ in self.f]
        for f,links in zip(self.f,self.links):
            for val,link in zip(collide(f,self.omega),links):
                if link is not None:
                    j,k,correction=link
                    new[j][k]=val+correction
        if self.boundary=="zouhe":
            for f in new[:self.nx]: horizontal_wall(f,False,0.)
            for f in new[-self.nx:]: horizontal_wall(f,True,self.lid)
        self.f=new

    def field(self):
        return [moments(f) for f in self.f]


def cavity(n=48,steps=500,U=.05,Re=100.,boundary="zouhe"):
    # Die lichte Höhe ist N. Zou–He braucht N+1 horizontale Knotenreihen.
    if Re<=0 or U<=0 or boundary not in ("halbweg","zouhe"):
        raise ValueError("Cavity benötigt Re>0, U>0 und eine geschlossene Wand")
    tau=.5+3*U*n/Re
    box=D2Q9(n,n+int(boundary=="zouhe"),tau,U,boundary)
    fields={}
    for k in range(1,steps+1):
        box.step()
        if k in (steps//2,steps-25,steps): fields[k]=box.field()
    return box,fields


def center(box, field):
    rows=sorted({(box.ny-1)//2,box.ny//2})
    cols=sorted({(box.nx-1)//2,box.nx//2})
    return sum(field[y*box.nx+x][1] for y in rows for x in cols)/(len(rows)*len(cols))


def shear_viscosity(n,nu=.1,amplitude=.01):
    """Transversale Scherwelle. Zwei späte Amplituden isolieren die Abklingrate."""
    tau=.5+3*nu
    box=D2Q9(1,n,tau,boundary="periodisch")
    k=2*math.pi/n
    box.f=[equilibrium(1.,amplitude*math.sin(k*j),0.) for j in range(n)]
    beta=(2/3,1/6,1/6)
    groups=[complex(v*amplitude) for v in beta]
    phases=[cmath.exp(-1j*k*d) for d in (0,1,-1)]
    t1,t2=n*n//8,n*n//4
    values=[]
    for t in range(1,t2+1):
        combined=sum(groups)
        groups=[phase*(w+(b*combined-w)/tau) for w,b,phase in zip(groups,beta,phases)]
        box.step()
        if t in (t1,t2):
            measured=2/n*math.fsum(moments(f)[1]*math.sin(k*j) for j,f in enumerate(box.f))
            assert abs(measured-sum(groups).real)<=64*t*math.ulp(1.)
            values.append(measured)
    return -math.log(values[1]/values[0])/(k*k*(t2-t1))


def check():
    from fractions import Fraction as F
    w=(F(4,9),)+(F(1,9),)*4+(F(1,36),)*4
    assert sum(w)==1 and sum(a*x*x*y*y for a,x,y in zip(w,CX,CY))==F(1,9)
    assert sum(a*x**4 for a,x in zip(w,CX))==F(1,3)
    initial=equilibrium(1.,.07,-.03)
    initial[0]-=.02;initial[1]+=.01;initial[3]+=.01
    before=moments(initial);after=moments(collide(initial,1.25))
    assert max(abs(a-b) for a,b in zip(before,after))<32*math.ulp(1.)
    torus=D2Q9(5,4,.8,boundary="periodisch")
    torus.f[7]=initial
    def totals(box):
        fields=box.field()
        return tuple(math.fsum(r*[1,u,v][k] for r,u,v in fields) for k in range(3))
    start=totals(torus)
    for _ in range(12): torus.step()
    assert max(abs(a-b) for a,b in zip(start,totals(torus)))<=64*12*math.ulp(start[0])
    # Anders als ein zyklischer Array-Shift reflektiert die Seitenwand
    # den Ostkanal am letzten Knoten. Die gegenüberliegende Wand bleibt frei.
    wall=D2Q9(4,4,.8)
    right=2*4+3
    assert wall.links[right][1]==(right,3,0.)
    assert torus.links[4][1]==(0,1,0.)
    for n in (16,32):
        observed=shear_viscosity(n)
        print(f"Scherwelle N={n}: nu_eff={observed:.8f}, relative Abweichung={abs(observed/.1-1):.3e}")
        if n==32: assert abs(observed/.1-1)<.01  # 1 Prozent Viskositätsbudget.
    N,U,nu=8,.04,.1
    couette=D2Q9(2,N+1,.5+3*nu,U,"zouhe",periodic_x=True)
    steps=math.ceil(1.1*N*N/nu)
    for _ in range(steps): couette.step()
    field=couette.field()
    profile=[field[j*2][1]/U for j in range(N+1)]
    error=max(abs(z-j/N) for j,z in enumerate(profile))
    # 0.1 Prozent des Deckeltempos als räumliches Fehlerziel. In der
    # Kontinuumslösung bleibt vom Anlauf höchstens der folgende Reihenrest.
    a=math.pi**2*nu*steps/N**2
    transient=2/math.pi*math.exp(-a)/(1-math.exp(-3*a))
    assert error<=.001+transient
    print(f"Couette: {steps} Schritte, max|u/U-y/H|={error:.4e}, Restbudget={transient:.3e}")
    for mode in ("halbweg","zouhe"):
        box,history=cavity(boundary=mode)
        last=history[500];prev=history[475]
        masses=[r for r,_,_ in last]
        drift=abs(math.fsum(masses)/len(masses)-1)
        if mode=="halbweg":
            assert drift<=64*500*math.ulp(1.)
        else:
            for r,u,v in last[-box.nx:]:
                assert abs(u-.05)+abs(v)<32*math.ulp(1.)
        assert min(masses)>0 and all(math.isfinite(v) for row in last for v in row)
        shift=math.sqrt(sum((a[1]-b[1])**2+(a[2]-b[2])**2 for a,b in zip(last,prev))/
                        sum(a[1]**2+a[2]**2 for a in last))
        assert center(box,last)<0
        print(f"Kavität {mode}: u_Mitte/U={center(box,last)/.05:.5f}, "
              f"rel. Massenänderung={drift:.3e}, Feldänderung über 25 Schritte={shift:.3e}")


if __name__=="__main__":
    check()
