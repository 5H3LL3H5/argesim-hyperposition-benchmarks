"""Kapitel 2. Eingebettete RK-Paare, PI-Regelung und dichte Ausgabe."""
import math
from fractions import Fraction

# c, A (streng untere Dreieckszeilen), b_hoch, b_tief, Exponent des Defekts.
BS32 = ((0, 1/2, 3/4, 1), ((), (1/2,), (0, 3/4), (2/9, 1/3, 4/9)),
        (2/9, 1/3, 4/9, 0), (7/24, 1/4, 1/3, 1/8), 3)
DP54 = ((0, 1/5, 3/10, 4/5, 8/9, 1, 1),
        ((), (1/5,), (3/40, 9/40), (44/45, -56/15, 32/9),
         (19372/6561, -25360/2187, 64448/6561, -212/729),
         (9017/3168, -355/33, 46732/5247, 49/176, -5103/18656),
         (35/384, 0, 500/1113, 125/192, -2187/6784, 11/84)),
        (35/384, 0, 500/1113, 125/192, -2187/6784, 11/84, 0),
        (5179/57600, 0, 7571/16695, 393/640, -92097/339200, 187/2100, 1/40), 5)


def proposal(rhs, t, y, h, pair):
    nodes, rows, high, low, _ = pair
    stages = []
    def combination(weights):
        return tuple(v + h*math.fsum(a*k[j] for a,k in zip(weights, stages))
                     for j,v in enumerate(y))
    for c, row in zip(nodes, rows):
        stages.append(rhs(t+c*h, combination(row)))
    return combination(high), combination(low), stages[0], stages[-1]


def interpolate(theta, h, y, end, f0, f1):
    s=theta
    return tuple((1+2*s)*(1-s)**2*a + s*(1-s)**2*h*c
                 + s*s*(3-2*s)*b + s*s*(s-1)*h*d
                 for a,b,c,d in zip(y,end,f0,f1,strict=True))


def solve(rhs, y, end, h, pair, atol, rtol):
    if not (end>=0 and h>0 and rtol>=0 and len(atol)==len(y) and min(atol)>0):
        raise ValueError("Ungültige Skalen oder Zeitspanne")
    t, previous, rejected = 0.0, 1.0, 0
    record=[]
    while t < end:
        h=min(h,end-t)
        if t+h<=t:
            raise ArithmeticError("Schritt unter Zeitauflösung")
        a,b,f0,f1=proposal(rhs,t,y,h,pair)
        ratios=[(u-v)/(s+rtol*max(abs(before),abs(u)))
                for before,u,v,s in zip(y,a,b,atol,strict=True)]
        err=math.sqrt(math.fsum(z*z for z in ratios)/len(y))
        if not math.isfinite(err):
            raise ArithmeticError("Nichtendlicher Schätzfehler")
        power=pair[-1]
        if err<=1:
            record.append((t,h,y,a,f0,f1))
            factor=5 if err==0 else .9*err**(-.7/power)*previous**(.4/power)
            t, y=t+h,a
            previous=max(err,1e-14)
            h*=min(5,max(.2,factor))
        else:
            rejected+=1
            h*=max(.2,min(.9,.9*err**(-1/power)))
    return record,rejected


def check():
    rhs=lambda t,y: (-y[0],)
    high,low,*_=proposal(rhs,0.,(1.,),1.,BS32)
    assert abs(high[0]-low[0])<=2*math.ulp(1.) and abs(high[0]-math.exp(-1))>.03
    for name,pair in (("BS3(2)",BS32),("DP5(4)",DP54)):
        steps,rej=solve(rhs,(1.,),1.,.8,pair,(1e-9,),1e-6)
        y=steps[-1][3][0]
        # Stabilisierende Multiplikatoren für 0<=h<=1. Bei DP ist
        # R(-h)=T5(-h)+h^6/600, exp(-h)=T5(-h)+exp(-xi)h^6/720.
        degree=4 if pair is BS32 else 6
        constant=1/24 if pair is BS32 else 1/600
        budget=sum(constant*r[1]**degree for r in steps)
        fuzz=80*len(steps)*math.ulp(1.0)
        assert abs(y-math.exp(-1))<=budget+fuzz and rej>0
        for t,h,old,new,f0,f1 in steps:
            mid=interpolate(.5,h,old,new,f0,f1)[0]
            assert abs(mid-math.exp(-t-h/2))<=(1+h/4)*(budget+fuzz)+h**4/384+fuzz
        print(f"{name}: {len(steps)} angenommen, {rej} verworfen, Endfehler "
              f"{abs(y-math.exp(-1)):.3e}, Budget {budget:.3e}")
    # Unabhängiges Intervall für v(1)=w'(1)/w(1), w''=t*w.
    # a_k ist hier der Koeffizient der Potenz t^(3k).
    coeff=Fraction(1); w=coeff; derivative=Fraction(0); last=6
    for k in range(1,last+1):
        coeff/=3*k*(3*k-1)
        w+=coeff; derivative+=3*k*coeff
    next_term=coeff/((3*last+3)*(3*last+2))
    # Nach dem ersten ausgelassenen Term sind beide Quotienten kleiner als 1/2.
    lower=derivative/(w+2*next_term)
    upper=(derivative+2*(3*last+3)*next_term)/w
    data,_=solve(lambda t,y:(t-y[0]*abs(y[0]),),(0.,),1.,.2,DP54,(1e-12,),1e-10)
    final=data[-1][3][0]
    assert float(upper-lower)<1e-10
    assert max(abs(final-float(lower)),abs(final-float(upper)))<1e-7
    assert float(upper)<.48
    print(f"Prüfwagen: v(1)={final:.9f} m/s, Schwelle 0.48 m/s unterschritten")
    for pair in (BS32,DP54):
        assert proposal(lambda t,y:(2.,-1.),0.,(0.,3.),.5,pair)[0]==(1.,2.5)


if __name__=="__main__":
    check()
