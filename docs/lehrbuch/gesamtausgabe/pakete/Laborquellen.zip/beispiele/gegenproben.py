"""Vier kurze Gegenproben zu eingebettetem RK, Pendelbindung, QSS und FVM."""
from fractions import Fraction as F

def midpoint():
    # y' = -y, y(0) = 1. Der eingebettete Eulerwert nutzt die erste Stufe.
    def pair(h):
        first = -1
        second = -(1 + h * first / 2)
        return 1 + h * second, 1 + h * first
    high, low = pair(F(1, 4))
    high2, low2 = pair(F(1, 8))
    assert (high, low) == (F(25, 32), F(3, 4))
    assert high-low == 4*(high2-low2) == F(1, 32)

def pendulum():
    # Tiefpunkt, r = (0,-l), v = (w,0); alle Längen in m, Zeiten in s.
    length, speed = F(1), F(3, 5)
    assert 0*speed + (-length)*0 == 0
    ay = speed**2 / length
    assert speed**2 - length*ay == 0
    assert speed**2 - length*(-F(981,100)) == F(1017,100)

def qss():
    # QSS1 für dx/dt = -q. Nach jeder Schwellenerreichung q := x, Delta = 1/4.
    t, state, quant = F(0), F(1), F(1,4)
    events = []
    for _ in range(2):
        slope = -state
        duration = quant / abs(slope)
        state += slope*duration
        t += duration
        events.append((t, state))
    assert events == [(F(1,4),F(3,4)),(F(7,12),F(1,2))]

def finite_volumes():
    # Vier Einheitszellen, je ein Fluss pro gemeinsamer Fläche, dM/dt dimensionslos.
    flux = [F(0), F(3,4), F(1,4), F(1,2), F(0)]
    change = [a-b for a,b in zip(flux,flux[1:])]
    assert sum(change) == flux[0]-flux[-1] == 0
    change[1] += F(1,100)  # nur eine Seite derselben Fläche verändert
    assert sum(change) == F(1,100)

if __name__ == "__main__":
    for check in (midpoint, pendulum, qss, finite_volumes):
        check()
        print(check.__name__, "bestanden")
