"""Einzelner freier Fall bis zum ersten Kontakt, alle Zahlen in SI."""
from math import ceil, log2, sqrt


hoehe, g, masse, e = 1.0, 9.81, 1.0, 0.8
rechts_start, zeitbudget = 0.5, 1e-6


def abstand(t):
    return hoehe - g * t*t / 2


links, rechts = 0.0, rechts_start
assert abstand(links) > 0.0 > abstand(rechts)
anzahl = ceil(log2((rechts - links) / (2 * zeitbudget)))
for _ in range(anzahl):
    mitte = (links + rechts) / 2
    if abstand(mitte) > 0.0:
        links = mitte
    else:
        rechts = mitte

t_stoss = (links + rechts) / 2
t_exakt = sqrt(2 * hoehe / g)
assert links <= t_exakt <= rechts
assert abs(t_stoss - t_exakt) <= (rechts - links) / 2 <= zeitbudget
v_minus = -g * t_stoss
v_plus = -e * v_minus
assert v_minus < 0 < v_plus
energie_plus = masse * v_plus**2 / 2
budget_joule = masse * e**2 * g**2 * rechts_start * zeitbudget
assert abs(energie_plus - e**2 * masse * g * hoehe) <= budget_joule
print(f"{anzahl} Halbierungen, Stoß nach {t_stoss:.9f} s, "
      f"Zeitfehler {abs(t_stoss-t_exakt)*1e6:.3f} µs")
