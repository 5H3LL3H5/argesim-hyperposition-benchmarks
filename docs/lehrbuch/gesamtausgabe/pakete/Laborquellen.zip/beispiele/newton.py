"""Rückwärts-Euler für y'=-y², alle Größen normiert."""
from math import sqrt


def loese(h, y, budget, eingefroren=False):
    if min(h, y, budget) <= 0:
        raise ValueError("Positive Versuchsdaten erforderlich")
    wert = y
    matrix = None
    matrizen = korrekturen = 0
    while True:
        defekt = wert + h * wert**2 - y
        if wert >= 0 and abs(defekt) <= budget:
            return wert, defekt, korrekturen, matrizen
        if korrekturen == 40:
            raise ArithmeticError("Newton-Ziel verfehlt")
        if matrix is None or not eingefroren:
            matrix = 1 + 2*h*wert
            matrizen += 1
        wert -= defekt / matrix
        korrekturen += 1


if __name__ == "__main__":
    h, y, budget = 0.1, 1.0, 1e-10
    wurzel = 2*y / (1 + sqrt(1 + 4*h*y))
    ode = y / (1 + h*y)
    for fest in (False, True):
        wert, defekt, n, m = loese(h, y, budget, fest)
        assert abs(wert - wurzel) <= budget
        assert abs(wert - ode) > 1e-3
        assert (n, m) == ((5, 1) if fest else (3, 3))
        print(f"Fest={fest!s:5s}  Y={wert:.12f}  |G|={abs(defekt):.2e}  "
              f"Korrekturen={n}  Matrizen={m}")
    try:
        loese(10.0, 1.0, 1e-14, True)
    except ArithmeticError:
        print("Erschöpftes Iterationsbudget für h=10 erkannt.")
    else:
        raise AssertionError("Fehlschlag der festen Iteration erwartet")
