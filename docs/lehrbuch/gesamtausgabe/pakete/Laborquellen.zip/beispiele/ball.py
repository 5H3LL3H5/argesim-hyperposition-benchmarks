"""Fallversuch, gerichteter Rückprall und Fehlerbudget für den Ruhezustand."""
import math
from ereignis import first_crossing, rk4_dense

G = 9.81                # m/s²
ET = 0.001              # s, größte abgeschnittene Restflugzeit
EH = 1e-6               # m, größte ausgelassene Höhe
EV = 0.01               # m/s, größte ausgelassene Geschwindigkeit
XTOL = 2e-14            # s, halbe maximale Brent-Klammerbreite


def simulate(end, step, q=2.0, v=0.0, e=0.85, g=G, xtol=XTOL):
    """Start bei t=0. Rückgabe: Zustand, Stoßprotokoll, ggf. Ruheprotokoll.

    Stoß: (Zeit, v_minus, v_plus). Ruhe: (Zeit, Restzeit, Resthöhe).
    Das Modell enthält ausschließlich freien Fall und einen starren Boden.
    """
    if (not all(map(math.isfinite, (end, step, q, v, e, g, xtol)))
            or end < 0 or step <= 0 or q < 0 or not 0 <= e <= 1
            or g <= 0 or xtol <= 0):
        raise ValueError("Ungültige Falldaten")
    t = 0.0
    events = []
    rest = None
    limit = min(math.sqrt(2*g*EH), EV, g*(1-e)*ET/2)

    def impact(time, velocity):
        u = -e * velocity
        events.append((time, velocity, u))
        if u == 0 or (e < 1 and u <= limit):
            tail = 0.0 if u == 0 else 2*u/(g*(1-e))
            return 0.0, (time, tail, u*u/(2*g))
        return u, None

    if q == 0:
        if v < 0:
            v, rest = impact(t, v)
        elif v == 0:
            rest = (t, 0.0, 0.0)

    def rhs(time, state):
        return (state[1], -g)

    while t < end and rest is None:
        stop = min(end, t + step)
        if stop <= t:
            raise ArithmeticError("Der gewählte Schritt ändert die Modellzeit nicht")
        y1, dense = rk4_dense(rhs, t, (q, v), stop)
        # Die Höhe ist quadratisch. Ihr einziges inneres Extremum ist der Scheitel.
        cuts = (t + v/g,) if v > 0 else ()
        hit = first_crossing(lambda s: dense(s)[0], t, stop, -1, xtol,
                             cuts, rate=lambda s: dense(s)[1])
        if hit is None:
            if y1[0] < 0:
                raise ArithmeticError("Unaufgelöster Bodenkontakt")
            t, (q, v) = stop, y1
        else:
            if hit <= t:
                raise ArithmeticError("Stoßfolge unterschreitet die Zeitauflösung")
            q = 0.0
            v, rest = impact(hit, dense(hit)[1])
            t = hit
    return (q, v), events, rest


def reference(k, height=2.0, e=0.85, g=G):
    """k-ter Stoß, gezählt ab 1, nach Loslassen in Ruhe."""
    first = math.sqrt(2*height/g)
    cycles = sum(e**j for j in range(1, k))
    return first*(1+2*cycles), -g*first*e**(k-1)


def check():
    state, events, rest = simulate(3.0, 0.02)
    assert len(events) == 3 and rest is None
    # Messauflösung: 1 ns. Sie begrenzt den Geschwindigkeitsfehler eines
    # freien Flugs auf g mal den Fehler seiner Dauer. Beide Enden können
    # je 1 ns abweichen; die drei Anflüge werden konservativ addiert.
    time_budget = 1e-9
    for k, (t, v, u) in enumerate(events, 1):
        exact_t, exact_v = reference(k)
        assert abs(t-exact_t) <= time_budget
        assert abs(v-exact_v) <= 2*k*G*time_budget
        assert u == -0.85*v
        print(f"Stoß {k}: {t:.9f} s  {v:.9f} -> {u:.9f} m/s")
    # Restflug nach dem letzten Stoß: Vergleich mit unabhängigem Fallgesetz.
    te, ve = reference(3)
    dt, u = 3.0-te, -0.85*ve
    v_budget = 7*G*time_budget
    q_budget = dt*v_budget + (abs(u)+G*dt)*time_budget
    assert abs(state[0]-(u*dt-G*dt*dt/2)) <= q_budget
    assert abs(state[1]-(u-G*dt)) <= v_budget

    # Ein einziger Vorschlag überdeckt anfangs die gesamte Stoßfolge.
    state, hits, rest = simulate(10.0, 10.0)
    assert state == (0.0, 0.0) and rest is not None
    t, tail, height = rest
    exact_limit = math.sqrt(4/G)*1.85/0.15
    assert tail <= ET and height <= EH and hits[-1][2] <= EV
    assert abs(t + tail - exact_limit) <= time_budget
    assert all(a[0] < b[0] for a, b in zip(hits, hits[1:]))
    print(f"Ruhe ab {t:.9f} s nach {len(hits)} Stößen; "
          f"Rest {tail:.9f} s, {height:.3e} m; Grenzzeit {exact_limit:.9f} s")

    # Binär exakt: erster Fall endet am rechten Schrittende, nächster
    # Kontakt nach einem ganzen Flug ab linker Null. Der Scheitel trennt sie.
    _, hits, _ = simulate(3, 1, q=1, g=2, e=1)
    assert [z[0] for z in hits] == [1.0, 3.0]
    _, hits, _ = simulate(1, 1, q=0, v=1, g=2, e=1)
    assert [z[0] for z in hits] == [1.0]
    assert simulate(1, 1, q=0, v=-1, e=0)[1:] == ([(0.0,-1,0.0)], (0.0,0.0,0.0))
    assert simulate(1, 1, q=0, v=0)[1:] == ([], (0.0,0.0,0.0))
    # Separater C21-Projektfall. Das Fenster 5 s enthält zwei Kontakte.
    _, hits, _ = simulate(5, 0.08, q=10, e=0.9)
    assert len(hits) == 2
    for k, (time, _, _) in enumerate(hits, 1):
        assert abs(time - reference(k, 10, 0.9)[0]) <= time_budget
    print("C21-Projektfall, Treffer in s:", *(f"{z[0]:.9f}" for z in hits))


if __name__ == "__main__":
    check()
