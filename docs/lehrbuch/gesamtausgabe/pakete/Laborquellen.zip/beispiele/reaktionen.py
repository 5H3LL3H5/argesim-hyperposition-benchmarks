from math import exp


C0, K, VERLUST = 1.0, 499.5, 1.0  # mmol/L, 1/s, 1/s
RATE_D = VERLUST + 2.0 * K


def explizit(a, b, h, k, verlust):
    austausch = k * (a - b)
    da = -verlust * a - austausch
    db = -verlust * b + austausch
    return a + h * da, b + h * db


def implizit(a, b, h, k, verlust):
    summe = (a + b) / (1.0 + h * verlust)
    differenz = (a - b) / (1.0 + h * (verlust + 2.0 * k))
    return (summe + differenz) / 2, (summe - differenz) / 2


def versuch(schritt, h, anzahl):
    a, b = C0, 0.0
    for _ in range(anzahl):
        a, b = schritt(a, b, h, K, VERLUST)
    return a + b, a - b


def verlaufsfehler(h, anzahl):
    a, b = C0, 0.0
    maximum = 0.0
    for j in range(1, anzahl + 1):
        a, b = explizit(a, b, h, K, VERLUST)
        fehler = abs((a - b) - C0 * exp(-RATE_D * j * h))
        maximum = max(maximum, fehler)
    return maximum


if __name__ == "__main__":
    h, n = 0.003, 4
    t = n * h
    s_ref = C0 * exp(-VERLUST * t)
    d_ref = C0 * exp(-RATE_D * t)
    se, de = versuch(explizit, h, n)
    si, di = versuch(implizit, h, n)
    print("Verfahren         Summe      Differenz  [mmol/L]")
    for name, s, d in (("exakt", s_ref, d_ref),
                       ("explizit", se, de), ("implizit", si, di)):
        print(f"{name:10} {s:12.9f} {d:14.9f}")

    ablesegrenze = 0.5e-9  # mmol/L, halbe letzte Tabellenstelle
    for j in range(1, n + 1):
        _, d_e = versuch(explizit, h, j)
        _, d_i = versuch(implizit, h, j)
        assert abs(d_e - C0 * (-2)**j) <= ablesegrenze
        assert abs(d_i - C0 * (1/4)**j) <= ablesegrenze
    a1, b1 = explizit(C0, 0.0, h, K, VERLUST)
    assert a1 < 0 < b1
    grenze_s = C0 * n * (h * VERLUST)**2 / 2
    assert abs(se - s_ref) <= grenze_s + ablesegrenze < 2e-5
    budget_d = 1e-3  # mmol/L
    assert abs(de - d_ref) > budget_d and abs(di - d_ref) > budget_d

    s_100 = C0 * (1.0 - 0.01 * VERLUST)**100
    assert abs(s_100 / (C0 * exp(-VERLUST * 1.0)) - 1.0) < 0.01

    # Gleiches Endzeitfenster von 12 ms, zusätzliche Prüfung des Verlaufs.
    _, d_ende = versuch(explizit, 0.001, 12)
    assert abs(d_ende - d_ref) < budget_d
    grob = verlaufsfehler(0.001, 12)
    assert abs(grob - C0 * exp(-1)) <= ablesegrenze
    assert grob > budget_d

    h_fein = 1e-6
    x = RATE_D * h_fein
    fein = verlaufsfehler(h_fein, 12_000)
    assert fein <= C0 * x / (2.0 - x) < budget_d
    print(f"Maximaler Gitterfehler in d [mmol/L]: "
          f"1 ms {grob:.9f}, 1 µs {fein:.9f}")
