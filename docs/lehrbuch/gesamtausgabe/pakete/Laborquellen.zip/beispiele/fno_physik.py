"""Kapitel 9. Lernen des Wellengesetzes und Physiktraining einer Fourier-Schicht.

Python ab 3.10, nur Standardbibliothek. Alle Versuche laufen mit python3 fno_physik.py.
"""
from dataclasses import dataclass
import math
import random
import statistics

from fourier_operator import layer, pluck, relative, sine_coeff, synthesis

LENGTH = 1.0
K = 16
SPEED = 1.25  # Nur Datenerzeugung und Referenz. Die Fitfunktionen erhalten keinen Sollwert.
ACC_NOISE = 0.20
SEEDS = (11, 23, 37, 53, 71)
TEST_TIMES = (0.19, 0.83)
DT = 0.025
NONLINEAR_MODES = 6
EPS = math.ulp(1.0)


def kappa(mode):
    return mode * math.pi / LENGTH


def modal_observations(seed, scale, exponent, noise):
    """Acht glatte Anregungen mit unabhängigen, beschränkten modalen Messfehlern."""
    profiles = random.Random(816)
    sensor = random.Random(seed)
    observations = [[] for _ in range(K)]
    for _ in range(8):
        for k, rows in enumerate(observations, 1):
            a = profiles.uniform(-1.0, 1.0) / k ** 3
            target = scale * (kappa(k) * LENGTH) ** exponent * a
            rows.append((a, target + sensor.uniform(-noise, noise)))
    return observations


def calibration(seed, speed, noise):
    return modal_observations(seed, speed**2/LENGTH**2, 2, noise)


def compare_laws(observations):
    """Ein Koeffizient je Kandidat; ungerade Moden für den Fit, gerade zur Auswahl."""
    scores = {}
    for exponent in (0,2,4):
        odd, even = [], []
        for k,rows in enumerate(observations,1):
            split = odd if k % 2 else even
            for a,y in rows:
                split.append(((kappa(k)*LENGTH)**exponent * a, y))
        power = math.fsum(x*x for x,_ in odd)
        if not power or not even:
            raise ValueError("Moden für Fit und Validierung erforderlich.")
        coeff = math.fsum(x*y for x,y in odd) / power
        rms = math.sqrt(math.fsum((coeff*x-y)**2 for x,y in even)/len(even))
        scores[exponent] = rms
    return scores


@dataclass(frozen=True)
class Fit:
    independent: tuple
    shared: float
    bound: float


def fit_acceleration(observations, noise_bound):
    curvature = [[(kappa(k)**2*a,y) for a,y in rows]
                 for k,rows in enumerate(observations,1)]
    power = [math.fsum(z * z for z, _ in rows) for rows in curvature]
    cross = [math.fsum(z * y for z, y in rows) for rows in curvature]
    if not power or any(value <= 0.0 for value in power):
        raise ValueError("Mindestens eine Mode ist durch die Trainingsdaten unbestimmt.")
    shared = math.fsum(cross) / math.fsum(power)
    independent = tuple(b / a for a, b in zip(power, cross, strict=True))
    if min(independent) <= 0 or shared <= 0:
        raise ValueError("Das harmonische Modell erfordert positive Geschwindigkeitsquadrate.")
    # Worst Case bei |Messfehler| <= noise_bound und fehlerfreiem z.
    bound = noise_bound * math.fsum(abs(z) for rows in curvature for z, _ in rows) / math.fsum(power)
    return Fit(independent, shared, bound)


def propagate(field, squared_speeds, time):
    """Exakte Zeitentwicklung im gelernten modalen Modell, Anfangsgeschwindigkeit null."""
    coefficients = sine_coeff(field, len(squared_speeds))
    evolved = [a * math.cos(kappa(k) * math.sqrt(s) * time)
               for k, (a, s) in enumerate(zip(coefficients, squared_speeds, strict=True), 1)]
    return synthesis(evolved, len(field) - 1)


def dalembert(profile, n, time, speed):
    distance = time * speed / LENGTH
    return [0.] + [(profile(j/n - distance) + profile(j/n + distance))/2
                   for j in range(1, n)] + [0.]


def field_error(fit, n, time):
    # Ausschließlich im Test sichtbares Dreieck. Die Referenz benutzt Ortsverschiebungen.
    profile = lambda x: pluck(x, .37)
    initial = [profile(j/n) for j in range(n+1)]
    exact = dalembert(profile, n, time, SPEED)
    choices = (fit.independent, (fit.shared,) * K, (SPEED ** 2,) * K)
    predictions = [propagate(initial, speeds, time) for speeds in choices]
    errors = tuple(relative(pred, exact) for pred in predictions)
    # Diskrete Sinusorthogonalität: jede behaltene Mode hat Quadratsumme n/2.
    coeff = sine_coeff(initial, K)
    derivative_norm = math.sqrt(n/2 * math.fsum((kappa(k)*a)**2 for k,a in enumerate(coeff,1)))
    reference_norm = math.sqrt(math.fsum(val**2 for val in exact))
    phase_budget = time*abs(math.sqrt(fit.shared)-SPEED)*derivative_norm/reference_norm
    assert errors[1] <= errors[2] + phase_budget + 64*n*EPS
    return errors


def trig_profile(coefficients, x):
    return math.fsum(a * math.sin(math.pi * k * x) for k, a in enumerate(coefficients, 1))


def signal(rng, smooth):
    # Immer sieben Koeffizienten. Der siebte macht den lokalen Pfad separat sichtbar.
    n = NONLINEAR_MODES + 1
    return [rng.uniform(-.75,.75) / k ** (2.3 if smooth else 1.0) for k in range(1,n+1)]


@dataclass(frozen=True)
class Node:
    features: tuple
    input_value: float
    target: float


def feature_rows(field):
    n = len(field) - 1
    coeff = sine_coeff(field, NONLINEAR_MODES)
    return [(a,) + tuple(ak * math.sin(math.pi*k*j/n) for k,ak in enumerate(coeff,1))
            for j,a in enumerate(field)]


def make_training(squared_speed, seed):
    """Snapshots mit Referenzlabels und getrennte, ungelabelte, glatte Kollokationsfelder."""
    draw_labels = random.Random(309)
    draw_unlabelled = random.Random(402)
    noise = random.Random(seed)
    measured, physics = [], []
    for _ in range(4):
        a = signal(draw_labels, smooth=True)
        field = synthesis(a, 32)
        reference = dalembert(lambda x: trig_profile(a,x), 32, DT, SPEED)
        for j,z in enumerate(feature_rows(field)[1:-1],1):
            measured.append(Node(z, field[j], reference[j] + noise.uniform(-.015,.015)))
    for _ in range(8):
        a = signal(draw_unlabelled, smooth=False)
        field = synthesis(a, 64)
        curvature = synthesis([-kappa(k)**2*b for k,b in enumerate(a,1)], 64)
        for j,z in enumerate(feature_rows(field)[1:-1],1):
            # Ortskrümmung der bekannten Eingabe; kein späteres Lösungsfeld erforderlich.
            target = field[j] + .5 * DT**2 * squared_speed * curvature[j]
            physics.append(Node(z, field[j], target))
    return measured, physics


def solve_spd(matrix, rhs):
    """Cholesky für die kleine positiv definite gedämpfte Normalmatrix."""
    n = len(rhs)
    lower = [[0.0]*n for _ in range(n)]
    for i in range(n):
        for j in range(i+1):
            rest = matrix[i][j] - math.fsum(lower[i][k]*lower[j][k] for k in range(j))
            lower[i][j] = math.sqrt(rest) if i == j else rest/lower[j][j]
    forward = [0.0]*n
    answer = [0.0]*n
    for i in range(n):
        forward[i] = (rhs[i] - math.fsum(lower[i][j]*forward[j] for j in range(i)))/lower[i][i]
    for i in reversed(range(n)):
        answer[i] = (forward[i] - math.fsum(lower[j][i]*answer[j] for j in range(i+1,n)))/lower[i][i]
    return answer


def normal_equations(groups, params):
    n = len(params)
    grad = [0.0]*n
    normal = [[0.0]*n for _ in range(n)]
    loss = 0.0
    for rows, group_weight in groups:
        if group_weight == 0:
            continue
        weight = group_weight / len(rows)
        for item in rows:
            z = item.features
            value = math.tanh(sum(w*x for w,x in zip(params,z,strict=True)))
            error = item.input_value + value - item.target
            slope = 1 - value*value
            loss += .5 * weight * error**2
            for i,xi in enumerate(z):
                grad[i] += weight * error * slope * xi
                factor = weight * slope*slope * xi
                for j in range(i+1):
                    normal[i][j] += factor*z[j]
    for i in range(n):
        for j in range(i):
            normal[j][i] = normal[i][j]
    return loss,grad,normal


def train_step(measured, physics, weight):
    """Alle sieben Gewichte passen sich an. Beide Läufe starten bei derselben Identität."""
    groups = ((measured,1.0),(physics,weight))
    params = [0.0]*(NONLINEAR_MODES+1)
    damp = 1e-6
    for _ in range(45):
        loss,grad,normal = normal_equations(groups,params)
        if max(map(abs,grad)) <= 1e-12:
            break
        for j,row in enumerate(normal):
            row[j] += damp
        update = solve_spd(normal,[-g for g in grad])
        trial = [w+d for w,d in zip(params,update,strict=True)]
        new_loss,_,_ = normal_equations(groups,trial)
        if new_loss < loss:
            params = trial
            damp = max(damp/3,1e-12)
        else:
            damp *= 10
    _,grad,_ = normal_equations(groups,params)
    assert max(map(abs,grad)) <= 1e-10, "Trainingsziel noch nicht stationär."
    return params


def eval_step(params, field):
    """Die allgemeine Fourier-Schicht aus 9.2 auf der ungeraden Fortsetzung auswerten."""
    n = len(field)-1
    extended = list(field)+[-v for v in field[-2:0:-1]]
    spectrum = [[[0.]]] + [[[r]] for r in params[1:]]
    residual = layer([extended],[[params[0]]],spectrum,[0.])[0]
    return [field[j]+residual[j] for j in range(n+1)]


def test_profiles():
    rng = random.Random(722)
    return [signal(rng,False) for _ in range(6)]


def mean_step_error(params, n):
    scores = []
    for a in test_profiles():
        field = synthesis(a,n)
        truth = dalembert(lambda x:trig_profile(a,x),n,DT,SPEED)
        pred = eval_step(params,field)
        assert max(abs(pred[0]),abs(pred[-1])) <= 64*n*EPS
        scores.append(relative(pred,truth))
    return statistics.mean(scores)


def verify_time_budget(params, n, fitted_s):
    """Aus Fitrest, Kalibrierfehler und Taylorrest folgt eine unabhängige Feldschranke."""
    for coeff in test_profiles():
        field = synthesis(coeff,n)
        curvature = synthesis([-kappa(k)**2*a for k,a in enumerate(coeff,1)],n)
        predicted = eval_step(params,field)
        exact = dalembert(lambda x:trig_profile(coeff,x),n,DT,SPEED)
        target = [a+.5*DT**2*fitted_s*d for a,d in zip(field,curvature)]
        norm = lambda x: math.sqrt(math.fsum(v*v for v in x))
        mismatch = norm([u-v for u,v in zip(predicted,target)])
        speed_term = .5*DT**2*abs(fitted_s-SPEED**2)*norm(curvature)
        # Für die aufgelösten Sinusmoden gilt die diskrete Parseval-Identität.
        fourth_norm = math.sqrt(n/2 * math.fsum((kappa(k)**4*a)**2 for k,a in enumerate(coeff,1)))
        taylor_term = (DT*SPEED)**4 * fourth_norm/24
        assert norm([u-v for u,v in zip(predicted,exact)]) <= (
            mismatch + speed_term + taylor_term + 256*n*EPS*max(1.,norm(field)))


def triangle_step_error(params, n):
    initial = [pluck(j/n,.37) for j in range(n+1)]
    reference = dalembert(lambda x:pluck(x,.37),n,DT,SPEED)
    return relative(eval_step(params,initial),reference)


def train_variants(fit, seed):
    measured,physics = make_training(fit.shared, seed)
    free = train_step(measured,physics,0.)
    informed = train_step(measured,physics,1.)
    # Dieselben Inputs und dieselben Datenlabels; das falsche c ist ein Negativversuch.
    _,wrong = make_training(4*fit.shared, seed)
    misspecified = train_step(measured,wrong,1.)
    return free,informed,misspecified


def run():
    clean = fit_acceleration(calibration(0,SPEED,0.),0.)
    assert max(abs(v-SPEED**2) for v in (*clean.independent,clean.shared)) <= 16*math.ulp(SPEED**2)
    try:
        fit_acceleration([[(0.,1.)]],ACC_NOISE)
    except ValueError:
        pass
    else:
        raise AssertionError("Eine unbestimmte Mode wurde akzeptiert.")
    records = [calibration(seed,SPEED,ACC_NOISE) for seed in SEEDS]
    scores = [compare_laws(rows) for rows in records]
    assert all(min(trial,key=trial.get)==2 for trial in scores)
    for true_power in (0,2,4):
        exact_scores = compare_laws(modal_observations(0,.1,true_power,0.))
        assert min(exact_scores,key=exact_scores.get)==true_power
        # Im rauschfreien Fall muss das richtige Gesetz bis auf Summenrundung passen.
        assert exact_scores[true_power] <= 128*K*EPS*max(1.,max(exact_scores.values()))
    print("Modengesetze, Median des Validierungs-RMS auf geraden Moden [m/s²]: "
          + " / ".join(f"p={p}: {statistics.median(r[p] for r in scores):.5f}" for p in (0,2,4)))
    fits = [fit_acceleration(rows,ACC_NOISE) for rows in records]
    for fit in fits:
        assert abs(fit.shared-SPEED**2) <= fit.bound + 16*math.ulp(SPEED**2)
    print("Geschwindigkeit aus acht Kalibrierprofilen")
    for seed,fit in zip(SEEDS,fits):
        print(f"  Seed {seed}: c={math.sqrt(fit.shared):.7f} m/s, Budget für c²={fit.bound:.6f} m²/s²")
    all_errors = {}
    for time in TEST_TIMES:
        for n in (64,256):
            trials = [field_error(fit,n,time) for fit in fits]
            medians = tuple(statistics.median(values) for values in zip(*trials))
            all_errors[n,time] = medians
            print(f"Dreieck N={n+1}, t={time:.2f} s, Median freier/gekoppelter Fit/Referenzfilter [%]: "
                  + " / ".join(f"{100*x:.4f}" for x in medians))
    fit = fits[0]
    # Prüfe die Kosinus-Sensitivität: |d cos(k*c*T)/dc| <= kappa(k)*T.
    for time in TEST_TIMES:
        delta_speed = abs(math.sqrt(fit.shared)-SPEED)
        for k in range(1,K+1):
            phase = kappa(k)*time
            assert abs(math.cos(phase*math.sqrt(fit.shared))-math.cos(phase*SPEED)) <= phase*delta_speed+16*EPS
    print("Nichtlinearer FNO, ein Schritt, Mittel über sechs unbenutzte Felder")
    step_results = []
    triangles = []
    for seed, fit in zip(SEEDS,fits):
        variants = train_variants(fit,seed)
        if seed == SEEDS[0]:
            # Prüfe den Gradienten unabhängig durch zentrale Differenzen im Prüfpunkt.
            measured,phys = make_training(fit.shared,seed)
            point = [.05*(i-3) for i in range(7)]
            groups = ((measured,1.),(phys,1.))
            _,grad,_ = normal_equations(groups,point)
            h=EPS**(1/3)
            for j in range(len(point)):
                plus=point.copy();minus=point.copy()
                plus[j]+=h;minus[j]-=h
                finite=(normal_equations(groups,plus)[0]-normal_equations(groups,minus)[0])/(2*h)
                # Division durch h verstärkt Rundung; zentrale Differenz hat Rest O(h²).
                assert abs(finite-grad[j]) < 256*(EPS/h+h*h)
            # Unabhängiger Abgleich: dieselben Gewichte in ortsweiser Merkmalsform und FFT-Schicht.
            field = synthesis(test_profiles()[0],128)
            for params in variants:
                manual=[a+math.tanh(math.fsum(p*x for p,x in zip(params,z))) for a,z in zip(field,feature_rows(field))]
                assert max(abs(a-b) for a,b in zip(manual,eval_step(params,field))) <= 256*len(field)*EPS
        scores = tuple(mean_step_error(p,128) for p in variants)
        verify_time_budget(variants[1],128,fit.shared)
        # Paarweise Gegenprobe im festgelegten Experiment, keine allgemeine Fehlerschranke.
        assert scores[1] + 256*128*EPS < min(scores[0],scores[2])
        triangles.append(tuple(triangle_step_error(p,128) for p in variants))
        step_results.append(scores)
        print(f"  Seed {seed}, 129 Punkte, Daten / PDE / falsches c [%]: "
              + " / ".join(f"{100*v:.4f}" for v in scores))
    print("  Median [%]: " + " / ".join(f"{100*statistics.median(col):.4f}" for col in zip(*step_results)))
    print("  Separates Dreiecksprofil, Median [%]: "
          + " / ".join(f"{100*statistics.median(col):.4f}" for col in zip(*triangles)))
    return fits,all_errors,step_results


if __name__ == "__main__":
    run()
