"""BDF1 und variable BDF2 für skalare affine Gleichungen."""


def euler_rueck(y, h, lam, g_ende):
    return (y + h*g_ende) / (1.0 - h*lam)


def bdf2(y, y_alt, h, h_alt, lam, g_ende):
    if min(h, h_alt) <= 0:
        raise ValueError("Beide Schrittweiten müssen positiv sein")
    r = h / h_alt
    a0 = (1 + 2*r) / (1 + r)
    a2 = r*r / (1 + r)
    return ((1+r)*y - a2*y_alt + h*g_ende) / (a0 - h*lam)


if __name__ == "__main__":
    tol = 0.5e-12  # halbe Stelle der auf zwölf Stellen geprüften Größe
    for h in (0.0625, 0.25, 0.5):
        t, h_alt = 1.0, 0.25
        # y(t)=t², y'=2t. Der quadratische Interpolant trifft die Bahn.
        ende = bdf2(t*t, (t-h_alt)**2, h, h_alt, 0, 2*(t+h))
        assert abs(ende - (t+h)**2) <= tol

    g, v_minus, e = 9.81, -2.0, 0.75  # m/s², m/s, dimensionslos
    v_plus = -e * v_minus
    for h in (0.1, 0.05, 0.025):
        alt = v_minus + g*h
        exakt = v_plus - g*h
        falsch = bdf2(v_plus, alt, h, h, 0.0, -g)
        neu = euler_rueck(v_plus, h, 0.0, -g)
        sollfehler = (v_plus - v_minus) / 3
        assert abs((falsch-exakt)-sollfehler) <= tol
        assert abs(neu-exakt) <= tol
        v2 = bdf2(neu, v_plus, h, h, 0.0, -g)
        assert abs(v2 - (v_plus-2*g*h)) <= tol
        print(f"h={h:.3f} s  mit alter Historie {falsch-exakt:.9f} m/s"
              f"  nach Neustart {abs(neu-exakt):.9f} m/s")
