"""Dreistufiger Radau-Schritt für y'=lam*y+g(t), skalare affine ODE."""
from math import exp, sqrt


r = sqrt(6.0)
C = ((4-r)/10, (4+r)/10, 1.0)
B = ((16-r)/36, (16+r)/36, 1/9)
A = (((88-7*r)/360, (296-169*r)/1800, (-2+3*r)/225),
     ((296+169*r)/1800, (88+7*r)/360, (-2-3*r)/225),
     B)


def faktorisiere(matrix):
    lu = [list(zeile) for zeile in matrix]
    n = len(lu)
    reihenfolge = list(range(n))
    for k in range(n):
        p = max(range(k, n), key=lambda i: abs(lu[i][k]))
        if lu[p][k] == 0:
            raise ArithmeticError("Singuläre Stufenmatrix")
        lu[k], lu[p] = lu[p], lu[k]
        reihenfolge[k], reihenfolge[p] = reihenfolge[p], reihenfolge[k]
        for i in range(k+1, n):
            lu[i][k] /= lu[k][k]
            for j in range(k+1, n):
                lu[i][j] -= lu[i][k] * lu[k][j]
    return lu, reihenfolge


def einsetzloesen(faktoren, rechte_seite):
    lu, reihenfolge = faktoren
    x = [rechte_seite[i] for i in reihenfolge]
    for i in range(len(x)):
        x[i] -= sum(lu[i][j]*x[j] for j in range(i))
    for i in reversed(range(len(x))):
        rest = sum(lu[i][j]*x[j] for j in range(i+1, len(x)))
        x[i] = (x[i] - rest) / lu[i][i]
    return x


class RadauLinear:
    def __init__(self):
        self.produkt = None
        self.faktoren = None
        self.zerlegungen = 0

    def stufen(self, t, y, h, lam, quelle):
        z = h * lam
        if z != self.produkt:
            matrix = [[float(i == j) - z*A[i][j] for j in range(3)]
                      for i in range(3)]
            self.faktoren = faktorisiere(matrix)
            self.produkt = z
            self.zerlegungen += 1
        g = [quelle(t + c*h) for c in C]
        rhs = [y + h*sum(a*g_j for a, g_j in zip(zeile, g))
               for zeile in A]
        return einsetzloesen(self.faktoren, rhs)


if __name__ == "__main__":
    tol = 0.5e-12  # halbe Stelle bei zwölf Nachkommastellen
    for m in range(5):
        assert abs(sum(b*c**m for b, c in zip(B, C))-1/(m+1)) <= tol
    for zeile, c_i in zip(A, C):
        for m in range(3):
            moment = sum(a*c**m for a, c in zip(zeile, C))
            assert abs(moment - c_i**(m+1)/(m+1)) <= tol

    # Ein unabhängiger Test erzwingt eine Zeilenvertauschung.
    faktoren = faktorisiere([[0.0, 2.0], [1.0, 1.0]])
    assert einsetzloesen(faktoren, [4.0, 3.0]) == [1.0, 2.0]
    solver = RadauLinear()
    for h in (0.01, 0.01, 0.005):
        stufen = solver.stufen(0.0, 1.0, h, -1000.0, lambda t: 0.0)
        ende = 1 - 1000*h*sum(b*y for b, y in zip(B, stufen))
        assert abs(stufen[-1] - ende) <= tol
        if h == 0.01:
            assert abs(ende - 3/58) <= tol
    assert solver.zerlegungen == 2

    fehler = []
    for n in (4, 8, 16):
        y = 1.0
        for j in range(n):
            y = solver.stufen(j/n, y, 1/n, -2.0, lambda t: 0.0)[-1]
        fehler.append(abs(y - exp(-2)))
    print("Endfehler für n=4,8,16:", *(f"{e:.3e}" for e in fehler))
    print("Fehlerquotienten:", *(f"{a/b:.3f}"
                                for a, b in zip(fehler, fehler[1:])))
    # Für die gewählten drei Gitter: der aus R exakt bestimmbare Fehler.
    for n, gemessen in zip((4, 8, 16), fehler):
        z = -2/n
        p = 1 + 2*z/5 + z*z/20
        q = 1 - 3*z/5 + 3*z*z/20 - z**3/60
        assert abs(gemessen - abs((p/q)**n-exp(-2))) <= tol
