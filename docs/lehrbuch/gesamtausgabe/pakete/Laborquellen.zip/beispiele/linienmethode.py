"""Kapitel 7. Getrennte Raum- und Zeitfehler, TVD-Transport und FEM."""
import math


def heat(n, r=.25, stop=.03125):
    # L=1 m, alpha=1 m²/s; feste Randtemperatur null (Temperaturabweichung).
    dx=1/n; steps=math.ceil(stop/(r*dx*dx)); h=stop/steps; r=h/dx**2
    state=[math.sin(math.pi*j/n) for j in range(n+1)]; state[-1]=0.
    for _ in range(steps):
        state=[0.] + [b+r*(a-2*b+c) for a,b,c in zip(state,state[1:],state[2:])] + [0.]
    lam=-4/dx**2*math.sin(math.pi/(2*n))**2
    return state[n//2], math.exp(lam*stop), math.exp(-math.pi**2*stop), lam,h,steps


def minmod(a,b):
    return math.copysign(min(abs(a),abs(b)),a) if a*b>0 else 0.


def transport(q, cfl, limited=True):
    """Konstante positive Geschwindigkeit, periodische Finite Volumen."""
    if not 0<=cfl<=1: raise ValueError("CFL-Vertrag für den TVD-Schritt")
    n=len(q)
    slopes=[minmod(q[i]-q[i-1],q[(i+1)%n]-q[i]) if limited else 0.
            for i in range(n)]
    traces=[v+.5*(1-cfl)*s for v,s in zip(q,slopes)]
    return [v-cfl*(traces[i]-traces[i-1]) for i,v in enumerate(q)]


def check():
    for n in (8,16,32):
        y,sem,exact,lam,h,steps=heat(n)
        # Euler-Faktor gegen Exponentialfaktor. Beide Beträge <=1;
        # Taylor mit z=h*lambda<=0 liefert Differenz <= z²/2.
        assert abs(y-sem)<=steps*(h*lam)**2/2+32*steps*math.ulp(1.)
        # sin²(z) >= z²-z⁴/3 und |d exp(-k*T)/dk|<=T.
        assert abs(sem-exact)<=.03125*math.pi**4/(12*n*n)+8*math.ulp(1.)
        discrete=(1+h*lam)**steps
        assert abs(y-discrete)<=32*steps*math.ulp(1.)
        print(f"N={n}: Raumfehler {abs(sem-exact):.5e}, Zeitfehler {abs(y-sem):.5e}, Schritte {steps}")
    q=[float(8<=j<20) for j in range(40)]
    tv=lambda u:sum(abs(v-u[i-1]) for i,v in enumerate(u))
    mass=sum(q); start=q.copy()
    for k in range(80):
        old=tv(q);q=transport(q,.5)
        eps=32*(k+1)*math.ulp(1.)
        assert abs(sum(q)-mass)<=len(q)*eps and tv(q)<=old+len(q)*eps
        assert min(q)>=-eps and max(q)<=1+eps
    assert transport(start,1.)==start[-1:]+start[:-1]
    print(f"Transport: Masse {sum(q):.9f}, TV {tv(q):.6f}, Werte [{min(q):.4f},{max(q):.4f}]")
    K,G,T,ambient=2.,1.,19.,10.
    surface=(K*T+G*ambient)/(K+G)
    assert surface==16. and K*(T-surface)==G*(surface-ambient)==6.
    for dx,expected in ((.1,.52),(.05,-.12)):
        C=.2*.2/dx
        r=.002*.2/dx**2
        weights=(C+r,1-C-2*r,r)
        assert abs(math.fsum(weights)-1)<=4*math.ulp(1.)
        assert abs(weights[1]-expected)<=4*math.ulp(1.)
    # Eine lineare FEM-Zelle. Wendet man M und K auf (1,1) an,
    # erhält man die Gesamtwärmekapazität und null inneren Leitfluss.
    length,capacity,k=0.5,2.,3.
    M=[[capacity*length*s/6 for s in row] for row in ((2,1),(1,2))]
    K=[[k*s/length for s in row] for row in ((1,-1),(-1,1))]
    assert abs(sum(map(sum,M))-capacity*length)<=2*math.ulp(1.)
    assert all(sum(row)==0 for row in K)


if __name__=="__main__":
    check()
