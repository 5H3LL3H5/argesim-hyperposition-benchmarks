"""Short single-core profile of the published CP2/2 cavity and current QSS solver."""
import functools
import hashlib
import inspect
import json
import os
from pathlib import Path
import sys
import time
import zipfile

import numpy as np

repo = Path(sys.argv[1]).resolve()
mode = sys.argv[2]
order = int(sys.argv[3])
limit = 8
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
sys.path.insert(0, str(repo))
from argesim_benchmarks import InitialValueProblem, solve_ivp
from argesim_benchmarks.solvers import advanced_qss

with zipfile.ZipFile(repo / 'docs/lehrbuch/gesamtausgabe/pakete/Laborquellen.zip') as archive:
    name = 'rechenlabor/kavitaet_vollgitter/basis/kavitaet.py'
    cavity_source = archive.read(name)
model_module = {'__file__': str(Path(__file__).parent / 'kavitaet.py'), '__name__': 'book_cavity'}
exec(compile(cavity_source, name, 'exec'), model_module)
cavity = model_module['Cavity'](257, 1000)
clock = time.process_time
phase = {key: 0.0 for key in ('root_candidates', 'minimum', 'shift', 'taylor', 'model_rhs', 'poisson')}
counts = {key: 0 for key in phase}

def measured(fn, key):
    @functools.wraps(fn)
    def wrapped(*a, **kw):
        start = clock()
        v = fn(*a, **kw)
        phase[key] += clock() - start
        counts[key] += 1
        return v
    return wrapped

if mode == 'profile':
    cavity.psi = measured(cavity.psi, 'poisson')
    cavity.rhs = measured(cavity.rhs, 'model_rhs')
    advanced_qss._rhs_taylor = measured(advanced_qss._rhs_taylor, 'taylor')
    # Bracket the intact list comprehension, minimum and recentering once per segment.
    # Placing a callback inside the per-state root finder would bias the profile.
    src = inspect.getsource(advanced_qss._qss_high_order.__wrapped__)
    start = '        crossings = ['
    end = '        elapsed = min(crossings)'
    shift_start = '        x = [shift_polynomial(polynomial, elapsed) for polynomial in x]'
    shift_end = '        q = [shift_polynomial(polynomial, elapsed) for polynomial in q]'
    assert all(src.count(token) == 1 for token in (start, end, shift_start, shift_end))
    src = src.replace(start, '        profile_start = profile_clock()\n' + start)
    src = src.replace(end, '\n'.join((
        '        profile_phase["root_candidates"] += profile_clock() - profile_start',
        '        profile_counts["root_candidates"] += 1',
        '        profile_start = profile_clock()', end,
        '        profile_phase["minimum"] += profile_clock() - profile_start',
        '        profile_counts["minimum"] += 1',
    )))
    src = src.replace(shift_start, '        profile_start = profile_clock()\n' + shift_start)
    src = src.replace(shift_end, '\n'.join((shift_end,
        '        profile_phase["shift"] += profile_clock() - profile_start',
        '        profile_counts["shift"] += 1',
    )))
    namespace = {**vars(advanced_qss), 'profile_clock': clock, 'profile_phase': phase, 'profile_counts': counts}
    exec(compile(src, '<instrumented-current-qss>', 'exec'), namespace)
    advanced_qss._qss_high_order = namespace['_qss_high_order']

grid_times = []
def stop(left, before, right, after):
    grid_times.append(right)
    return len(grid_times) == limit

problem = InitialValueProblem(lambda t,x: cavity.rhs(t,np.asarray(x)), 0, (0.0,)*cavity.dim, 350000*0.1/256, autonomous=True, _stop_after_step=stop)
cpu0, wall0 = clock(), time.perf_counter()
result = solve_ivp(problem, method=f'qss{order}', options={'quantum':0.001, 'max_events':1200000})
wall, cpu = time.perf_counter()-wall0, clock()-cpu0
assert len(grid_times) == limit and tuple(grid_times) == result.times[1:]
if mode == 'profile':
    assert counts['root_candidates'] == counts['minimum'] == counts['shift'] == limit
    assert counts['poisson'] == result.stats.rhs_evaluations
digest = hashlib.sha256(np.asarray(result.times, dtype='<f8').tobytes() + np.asarray(result.states, dtype='<f8').tobytes()).hexdigest()
print(json.dumps(dict(mode=mode, order=order, segments=limit, time=grid_times[-1], seconds_cpu=cpu, seconds_wall=wall, states=cavity.dim, events=result.stats.accepted_steps, rhs=result.stats.rhs_evaluations, phase_cpu=phase, calls=counts, sha256=digest)), flush=True)

