# CP2/2-Kavität auf 257 × 257 Knoten

## Fragestellung

Welchen Anteil der seriellen CPU-Zeit beanspruchen die Schwellenprognosen, die Auswahl des frühesten Termins und die Taylor-Polynome zu Beginn eines QSS-Laufs? Die Messung umfasst die ersten acht akzeptierten Zeitabschnitte je Verfahren. Ein Kontrolllauf liefert alle Zeitstempel und vollständigen Wirbelzustände für den Vergleich. Der vollständige CP2-Versuch umfasst 350 000 D2Q9-Takte. Seine veröffentlichten parallelen Wandzeiten stehen in Kapitel 16.

## Rechenstand und Messung

- Repository `5H3LL3H5/argesim-hyperposition-benchmarks`, Commit `eb1e5519c446d4b226006e30cadda6fda9d3dd76`.
- Kavitätsmodell aus `docs/lehrbuch/gesamtausgabe/pakete/Laborquellen.zip`, Datei `rechenlabor/kavitaet_vollgitter/basis/kavitaet.py`. Die Solver stammen aus dem Repository-Stamm dieses Commits.
- 65 025 innere Wirbelzustände, Reynolds-Zahl 1000 und Quantum 0,001. Das Fluid ruht anfangs. Der Deckel setzt sich bei Simulationsbeginn in Bewegung. Die obere Integrationsgrenze bleibt bei 136,71875. Ein Beobachter beendet die Messung nach acht Segmenten.
- Linux x86-64, AMD EPYC 9V45, Python 3.12.14, NumPy 2.3.5 und SciPy 1.17.0. Jeder Lauf startet in einem eigenen Prozess und bindet sich an dieselbe logische CPU. Die unten genannten Threadzahlen stehen auf eins.
- Je Ordnung drei instrumentierte Läufe und ein abschließender Kontrolllauf ohne Phasentimer. Die Initialisierung der Taylor-Polynome zählt zur Solverzeit. Import, Gitterkonstruktion und das abschließende Hashen liegen außerhalb des Messintervalls. Die SHA-256-Prüfsumme umfasst die Bytes aller ausgegebenen Zeiten und aller vollständigen Zustandsvektoren als Little-Endian-Binär64.

## Daten lesen

`messlaeufe.jsonl` enthält die sechs instrumentierten Läufe in Ausführungsreihenfolge. `kontrollen.jsonl` enthält die beiden abschließenden Kontrollläufe. Die Phasenwerte dieser Kontrollen sind null, weil die Phasentimer dort ausgeschaltet sind. `auswertung.json` enthält den Median der pro Lauf berechneten CPU-Anteile. Getrennt gebildete Mediane addieren sich nicht zwingend auf hundert Prozent.

| Feld | Gemessener Abschnitt |
|---|---|
| `root_candidates` | Schwellenzeit für jeden der 65 025 Zustände berechnen. |
| `minimum` | Aus dem fertigen Kandidatenvektor den frühesten Zeitpunkt auswählen. |
| `shift` | Sämtliche kontinuierlichen und quantisierten Polynome zum Ereigniszeitpunkt verschieben. |
| `taylor` | Taylor-Koeffizienten der rechten Seite bestimmen, einschließlich der Modellaufrufe. |
| `model_rhs` | Rechte Seite der Wirbelgleichung auswerten. Dieser Anteil ist bereits in `taylor` enthalten. |
| `poisson` | Stromfunktion mittels diskreter Sinustransformation berechnen. Dieser Anteil ist bereits in `model_rhs` enthalten. |

Die Wanduhr und die Prozess-CPU-Uhr umschließen jeweils einen vollständigen Aufruf des Solvers mit dem beschriebenen frühen Stopp. Der Kurzlauf liefert ein Profil der Startphase. Für einen parallelen Speedup sind dieselbe Trajektorie und derselbe Endzeitpunkt auf einem und auf mehreren physischen Kernen erforderlich.

## Lokal wiederholen

Im Verzeichnis dieses Pakets den Pfad zum Checkout des angegebenen Commits setzen und die folgenden Befehle unter Linux ausführen.

```bash
repo=/pfad/zum/argesim-hyperposition-benchmarks
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
for order in 3 4 4 3 3 4
do
    python profile_cavity_prefix.py "$repo" profile "$order"
done
for order in 3 4
do
    python profile_cavity_prefix.py "$repo" plain "$order"
done
```

[Archivierte Vollgittermessungen](https://github.com/5H3LL3H5/argesim-hyperposition-benchmarks/blob/eb1e5519c446d4b226006e30cadda6fda9d3dd76/docs/lehrbuch/gesamtausgabe/kapitel/16.md#cp2-voll-zeiten) · [PDES-Versuchsplan](https://github.com/5H3LL3H5/argesim-hyperposition-benchmarks/blob/eb1e5519c446d4b226006e30cadda6fda9d3dd76/docs/lehrbuch/QSS_PDES_Studie.md)

