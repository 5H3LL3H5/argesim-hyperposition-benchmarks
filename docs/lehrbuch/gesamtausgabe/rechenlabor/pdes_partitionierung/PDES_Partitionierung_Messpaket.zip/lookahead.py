"""Count distinct earliest exports for every admissible rectangular partition of C19R."""
import argparse
import json
import math
from pathlib import Path
import numpy as np
from partitions import cartesian


def bands(n, p):
    low=max(1, math.floor(.9*n/p)); high=math.ceil(1.1*n/p)
    def tail(start, left):
        if left==1:
            if low<=n-start<=high: yield ()
            return
        for c in range(max(start+low,n-(left-1)*high),min(start+high,n-(left-1)*low)+1):
            for rest in tail(c,left-1):yield (c,*rest)
    return tail(0,p)


def masks_for_axis(coord,n,index,nstamps):
    values=[0]
    costs=[0]
    for cut in range(1,n):
        idx=index[(coord==cut-1) | (coord==cut)]
        bits=np.zeros(nstamps,dtype=np.uint8)
        bits[idx]=1
        values.append(int.from_bytes(np.packbits(bits,bitorder='little').tobytes(),'little'))
        costs.append(len(idx))
    return values,costs


def evaluate(path):
    meta=json.loads((path/'metadata.json').read_text())
    ny,nx=meta['shape'];horizon=meta['horizon'];samples=meta['samples']
    events=np.fromfile(path/'pilot.trace0',dtype=[('t','<f8'),('node','<i4'),('q','<i4')])
    assert np.all(np.diff(events['t'])>=0)
    expected=np.fromfile(path/'base.counts',dtype='<u8')
    np.testing.assert_array_equal(np.bincount(events['node'],minlength=nx*ny),expected)
    outputs=np.arange(1,samples+1)*horizon/samples
    stamps,index=np.unique(np.r_[events['t'],outputs],return_inverse=True)
    fixed=sum(1<<int(i) for i in index[len(events):])
    index=index[:len(events)]
    masks=[]
    for coord,n in ((events['node']%nx,nx),(events['node']//nx,ny)):
        masks.append(masks_for_axis(coord,n,index,len(stamps)))
    outcomes=[]
    for ranks in (4,8):
        opt_comm=opt_safe=None; count=0
        def score(xs,ys):
            mask=fixed;comm=0
            for cs,(bits,costs) in zip((xs,ys),masks):
                for c in cs:mask |= bits[c]; comm +=costs[c]
            return comm, mask.bit_count()
        for px in range(1,ranks+1):
            if ranks%px:continue
            for xs in bands(nx,px):
                for ys in bands(ny,ranks//px):
                    cnt,steps=score(xs,ys)
                    cc=(cnt,steps,xs,ys);ss=(steps,cnt,xs,ys)
                    opt_comm=cc if opt_comm is None else min(opt_comm,cc)
                    opt_safe=ss if opt_safe is None else min(opt_safe,ss)
                    count+=1
        def entry(comm,steps,xs,ys):
            return dict(committed_exports=comm, cuts=steps,mean_safe_s=horizon/steps,cx=xs,cy=ys)
        validated=[]
        named=json.loads(Path('c19_nom/maps.json').read_text())
        recorded=[json.loads(line) for line in (path/'cons.jsonl').read_text().splitlines()]
        for spec in named:
            if spec['ranks']!=ranks:continue
            cc,steps=score(spec['cx'],spec['cy'])
            obs=next(r for r in recorded if r['ranks']==ranks and r['layout']==spec['layout'])
            assert steps==obs['safe_cuts'] and cc==obs['committed_exports'],(spec,cc,steps,obs)
            validated.append(dict(layout=spec['layout'],**entry(cc,steps,spec['cx'],spec['cy'])))
        cc,steps,cx,cy=opt_comm;ssteps,scc,sx,sy=opt_safe
        outcomes.append(dict(ranks=ranks,admissible_maps=count,comm_optimum=entry(cc,steps,cx,cy),
                             safe_optimum=entry(scc,ssteps,sx,sy),measured_crosschecks=validated))
        for name,edges_x,edges_y in (('profile_comm',cx,cy),('profile_safe',sx,sy)):
            np.savetxt(path/f'{name}-{ranks}.map',cartesian(ny,nx,edges_x,edges_y).ravel(),fmt='%d')
        if path.name=='c19_nom':
            owner=cartesian(ny,nx,sx,sy).ravel()
            for dest in (path,Path('c19_pulse')):
                np.savetxt(dest/f'safe-{ranks}.map',owner,fmt='%d')
    (path/'lookahead_optimum.json').write_text(json.dumps(outcomes,indent=2))
    return outcomes


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('case',type=Path)
    evaluate(p.parse_args().case)
