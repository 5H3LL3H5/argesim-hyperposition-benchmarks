import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import tempfile
from run_sparse import parse_result

def main(steps,repeats):
    topology=json.loads(Path('d2q9_topology.json').read_text())
    cases=[(1,1),*((a['px'],a['py']) for a in topology)]
    expected={(a['px'],a['py']):a['population_transfers'] for a in topology}
    env=dict(os.environ,OMPI_MCA_pml='ob1',UCX_VFS_ENABLE='n',OMP_NUM_THREADS='1')
    rnd=random.Random(81742+steps)
    with tempfile.TemporaryDirectory() as tmp:
        base=Path(tmp);mark=base/'steps';mark.write_text(str(steps))
        subprocess.run(['./d2q9_book','257','1000','1',str(base),str(mark)],check=True,env=env)
        sha=hashlib.sha256((base/f'feld_{steps}.bin').read_bytes()).hexdigest()
        for repeat in range(repeats):
            rnd.shuffle(cases)
            for x,y in cases:
                result=subprocess.run(['mpiexec','--oversubscribe','--bind-to','none','-n',str(x*y),'./d2q9_halos',
                                       str(x),str(y),str(steps),str(base/'test')],capture_output=True,text=True,env=env)
                if result.returncode:raise RuntimeError(result.stderr)
                r=parse_result(result.stdout);r['repeat']=repeat+1
                r['sha256']=hashlib.sha256((base/'test.fields').read_bytes()).hexdigest()
                assert r['sha256']==sha and r['populations_per_step']==expected.get((x,y),0)
                r['equal_published_solver']=True
                print(json.dumps(r,separators=(',',':')),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('steps',type=int);p.add_argument('repeats',type=int)
    a=p.parse_args();main(a.steps,a.repeats)
