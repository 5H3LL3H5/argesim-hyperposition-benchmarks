#!/usr/bin/env bash
set -euo pipefail
repo=$(realpath "${1:?Pfad zum Repository-Checkout fehlt}")
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 OMPI_MCA_pml=ob1 UCX_VFS_ENABLE=n
python models.py "$repo" rope_nom rope 30 .0001 nominal 120
mpiexec --oversubscribe --bind-to none -n 1 ./sparse_pdes rope_nom/model.txt rope_nom/one.map optimistic .25 rope_nom/base 0 > rope_nom/base.json
python rope_full.py "$repo"
