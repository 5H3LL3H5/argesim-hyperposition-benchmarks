#!/usr/bin/env bash
set -euo pipefail
repo=$(realpath "${1:?Pfad zum Repository-Checkout fehlt}")
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export OMPI_MCA_pml=ob1 UCX_VFS_ENABLE=n
for o in 3 4; do
  python cavity_pdes.py "$repo" --order "$o" > "cavity_qss$o.jsonl"
  python cavity_pdes.py "$repo" --order "$o" --segments 32 --repeats 1 --ranks 1 8 --modes optimistic > "cavity_long_qss$o.jsonl"
  python cavity_pdes.py "$repo" --order "$o" --window 0.0001 --segments 8 --repeats 1 --ranks 8 --modes optimistic > "cavity_shortwindow_qss$o.jsonl"
done
mpicxx -DOMPI_SKIP_MPICXX -std=c++20 -O3 -ffp-contract=off -Wall -Wextra -Werror sparse_pdes.cpp -o sparse_pdes
for spec in 'c19_nom c19r 864000 .001 nominal 8' 'c19_pulse c19r 864000 .001 pulse 8' 'rope_pilot rope 4 .0001 nominal 16' 'rope_pilot_freq rope 4 .0001 frequency 16'; do
  read -r case_name model horizon quantum profile samples <<< "$spec"
  python models.py "$repo" "$case_name" "$model" "$horizon" "$quantum" "$profile" "$samples"
  if [[ "$model" == c19r ]]; then window=108000; capture=1; else window=.25; capture=0; fi
  mpiexec --oversubscribe --bind-to none -n 1 ./sparse_pdes "$case_name/model.txt" "$case_name/one.map" optimistic "$window" "$case_name/base" 0 > "$case_name/base.json"
  if (( capture )); then
    mpiexec --oversubscribe --bind-to none -n 1 ./sparse_pdes "$case_name/model.txt" "$case_name/one.map" optimistic "$window" "$case_name/pilot" 1 > /dev/null
  fi
done
python partitions.py c19_nom c19_nom c19_pulse
python partitions.py rope_pilot rope_pilot rope_pilot_freq
for case_name in c19_nom c19_pulse; do
  python run_sparse.py "$case_name" conservative 108000 --layouts weighted tiles x y > "$case_name/cons.jsonl"
  python run_sparse.py "$case_name" optimistic 6750 --layouts weighted tiles x y > "$case_name/opt_short.jsonl"
  python run_sparse.py "$case_name" optimistic 13500 --layouts weighted tiles x > "$case_name/opt_long.jsonl"
  python lookahead.py "$case_name"
done
python run_sparse.py c19_pulse conservative 108000 --ranks 4 8 --layouts profile_comm profile_safe > c19_pulse/profile_cons.jsonl
python run_sparse.py c19_pulse optimistic 6750 --ranks 4 8 --layouts profile_comm profile_safe > c19_pulse/profile_opt.jsonl
for case_name in rope_pilot rope_pilot_freq; do
  python run_sparse.py "$case_name" conservative .25 --layouts weighted x > "$case_name/cons.jsonl"
  python run_sparse.py "$case_name" optimistic .0125 --layouts weighted x > "$case_name/opt_short.jsonl"
done
python prepare_d2q9.py "$repo"
mpicxx -DOMPI_SKIP_MPICXX -std=c++20 -O3 -march=native -ffp-contract=off -fopenmp-simd -Wall -Wextra -Werror d2q9_halos.cpp -o d2q9_halos
g++ -std=c++20 -O3 -march=native -ffp-contract=off -fopenmp -Wall -Wextra -Werror d2q9_book.cpp -o d2q9_book
python run_d2q9.py 1024 3 > d2q9_halos.jsonl
python paired_sparse.py > c19_paired.jsonl
python run_d2q9.py 1024 3 > d2q9_paired.jsonl
python summarize.py
python physical.py "$repo" c19_nom c19_pulse rope_pilot rope_pilot_freq > physical.json
python report.py
