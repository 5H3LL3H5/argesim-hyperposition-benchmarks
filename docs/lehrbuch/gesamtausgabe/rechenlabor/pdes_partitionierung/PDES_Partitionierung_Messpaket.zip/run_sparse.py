"""Run partitioned PDE cases with real MPI programs, check every output against one rank."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import numpy as np


def parse_result(lines):
    return json.loads(next(s for s in reversed(lines.splitlines()) if s.startswith('{')))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def trial(path,ranks,layout,mode,window,repeat):
    prefix = path/'base'
    baselines={ext:digest(prefix.with_suffix('.'+ext)) for ext in ('fields','hash','counts')}
    with tempfile.TemporaryDirectory(dir=path) as tmp:
        out=Path(tmp)/'result'
        owner=path/('one.map' if ranks==1 else f'{layout}-{ranks}.map')
        cmd=['mpiexec','--oversubscribe','--bind-to','none','-n',str(ranks),'./sparse_pdes',str(path/'model.txt'),
             str(owner),mode,str(window),str(out),'0']
        env=dict(os.environ, UCX_VFS_ENABLE='n', OMPI_MCA_pml='ob1', OPENBLAS_NUM_THREADS='1')
        start=time.perf_counter()
        log=subprocess.run(cmd,env=env,capture_output=True,text=True,timeout=600)
        end=time.perf_counter()
        if log.returncode:
            raise RuntimeError(log.stdout[-1000:]+' '+log.stderr[-2000:])
        result=parse_result(log.stdout)
        hashes={ext:digest(out.with_suffix('.'+ext)) for ext in baselines}
        result.update(case=path.name, ranks=ranks, layout=layout, mode=mode, window=window, repeat=repeat,
                      launcher_wall_s=end-start, sha256=hashes, verified=(hashes==baselines))
        if not result['verified']:
            vals=np.fromfile(out.with_suffix('.fields'),dtype='<f8')
            ref=np.fromfile(prefix.with_suffix('.fields'),dtype='<f8')
            result.update(field_max_abs_difference=float(max(abs(vals-ref))),
                          differing_components=int(np.count_nonzero(np.fromfile(out.with_suffix('.hash'),dtype='<u8')!=
                                                                    np.fromfile(prefix.with_suffix('.hash'),dtype='<u8'))))
        return result


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('case',type=Path);p.add_argument('mode',choices=['optimistic','conservative'])
    p.add_argument('window',type=float);p.add_argument('--ranks',type=int,nargs='+',default=[1,4,8])
    p.add_argument('--layouts',nargs='+',default=['tiles','x','weighted']);p.add_argument('--repeats',type=int,default=1)
    a=p.parse_args()
    for rep in range(a.repeats):
        for rank in a.ranks:
            for layout in (['one'] if rank==1 else a.layouts):
                row=trial(a.case,rank,layout,a.mode,a.window,rep+1)
                print(json.dumps(row,separators=(',',':')),flush=True)
                if not row['verified']:raise RuntimeError('Fields or per-node event history differ from one rank')
