"""Validate results and convert measured rows to compact, reproducible tables."""
import csv
import json
from pathlib import Path
from statistics import median
import numpy as np
from run_sparse import parse_result

def records(path):
    return [json.loads(v) for v in Path(path).read_text().splitlines()]

def write(name,rows):
    with Path(name+'.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def build():
    cavity=[]; profiles=[]
    for order in (3,4):
        for series in ('','long_','shortwindow_'):
            name='cavity_'+series+f'qss{order}.jsonl'
            rows=records(name);assert rows and all(r['digest']==r['oracle_sha256'] and r['ranks']==r['distinct_processes'] for r in rows)
            baseline=[r['wall_s'] for r in rows if r['ranks']==1]
            for key in sorted(set((r['ranks'],r['layout'],r['mode']) for r in rows)):
                group=[r for r in rows if (r['ranks'],r['layout'],r['mode'])==key]
                r=group[0];assert all(g['rollbacks']==r['rollbacks'] and g['emitted']==r['emitted'] for g in group)
                med=median(g['wall_s'] for g in group);times=np.diff(r['times'])
                cavity.append(dict(order=order,segments=r['segments'],ranks=key[0],layout=key[1],mode=key[2],window=r['window'],
                                   repeats=len(group),median_s=med,speedup=(median(baseline)/med if baseline else ''),
                                   rollbacks=r['rollbacks'],attempts=r['speculation'],revoked=r['revoked_quantizer_outputs'],
                                   poisson_bytes=r['payload_bytes'].get('poisson_fields',0),poisson_messages=r['messages'].get('poisson_fields',0),
                                   t_end=r['times'][-1],median_gap=float(np.median(times)),min_gap=float(min(times)),max_gap=float(max(times))))
    write('cavity_summary',cavity)
    for path in (Path('c19_nom'),Path('c19_pulse'),Path('rope_pilot'),Path('rope_pilot_freq')):
        meta=json.loads((path/'metadata.json').read_text())
        source=Path('c19_nom') if meta['model']=='c19r' else Path('rope_pilot')
        layouts=json.loads((source/'maps.json').read_text())
        for f in sorted(path.glob('*.jsonl')):
            for r in records(f):
                assert r['verified']
                if r['ranks']>1 and r['layout'] in ('x','y','tiles','weighted') and path==source:
                    model=next(v for v in layouts if v['ranks']==r['ranks'] and v['layout']==r['layout'])
                    assert r['committed_exports']==model['training_exports']
                vals={k:r[k] for k in ('case','ranks','layout','mode','window','wall_s','launcher_wall_s','committed','committed_exports',
                    'packets','wire_events','count_header_bytes','rollbacks','discarded_events','rounds','probe_events','safe_mean','safe_min','safe_max')}
                profiles.append(vals)
    write('sparse_summary',profiles)
    paired=[]
    rows=records('c19_paired.jsonl')
    assert len(rows)==36 and all(r['verified'] for r in rows)
    for case in ['c19_nom','c19_pulse']:
        for mode in ['conservative','optimistic']:
            group=[r for r in rows if r['case']==case and r['mode']==mode]
            base=median(r['wall_s'] for r in group if r['ranks']==1)
            for n in [1,4,8]:
                sub=[r for r in group if r['ranks']==n]
                med=median(r['wall_s'] for r in sub)
                paired.append(dict(case=case,mode=mode,ranks=n,repeats=len(sub),median_s=med,speedup=base/med,
                                   median_launcher_s=median(r['launcher_wall_s'] for r in sub)))
    write('sparse_paired_summary',paired)
    rows=records('d2q9_paired.jsonl')
    assert len(rows)==24 and all(r['equal_published_solver'] for r in rows)
    base=median(r['kernel_s'] for r in rows if r['ranks']==1)
    halos=[]
    for x,y in sorted(set((r['px'],r['py']) for r in rows)):
        sub=[r for r in rows if r['px']==x and r['py']==y]
        assert len(sub)==3 and len(set(r['sha256'] for r in sub))==1
        med=median(r['kernel_s'] for r in sub)
        halos.append(dict(ranks=x*y,px=x,py=y,steps=sub[0]['steps'],repeats=len(sub),
                          populations_per_step=sub[0]['populations_per_step'],bytes_per_step=sub[0]['populations_per_step']*8,
                          communicating_rank_pairs_directed=sub[0]['directed_peer_pairs'],median_kernel_s=med,speedup=base/med))
    write('d2q9_summary',halos)

if __name__=='__main__':build()
