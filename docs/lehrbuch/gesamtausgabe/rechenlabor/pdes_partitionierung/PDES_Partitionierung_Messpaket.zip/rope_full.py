"""Compare static four-second-trained and full-profile cuts on the 30-second CP1/C trajectory."""
from pathlib import Path
import json
import numpy as np
from partitions import write
from run_sparse import parse_result
from physical import measure


def assess(repo):
    case=Path('rope_nom');write(case,[case])
    counts=np.fromfile(case/'base.counts',dtype='<u8')
    assert int(counts.sum())==parse_result((case/'base.json').read_text())['committed']
    maps=json.loads((case/'maps.json').read_text())
    for r in maps:
        n=799
        map4=np.loadtxt(Path('rope_pilot')/f"{r['layout']}-{r['ranks']}.map",dtype=int)
        cuts=(np.flatnonzero(np.diff(map4[:n]))+1).tolist()
        r['exports_with_4s_map']=sum(int(counts[c-1])+int(counts[c]) for c in cuts)
    out=dict(horizon=30,committed_events=int(counts.sum()),physical=measure(case,repo),partitions=maps,
             first_profile='nominal, omega 1',parallel_full_run=False)
    (case/'full_assessment.json').write_text(json.dumps(out,indent=2))

if __name__=='__main__':
    import sys
    assess(Path(sys.argv[1]))
