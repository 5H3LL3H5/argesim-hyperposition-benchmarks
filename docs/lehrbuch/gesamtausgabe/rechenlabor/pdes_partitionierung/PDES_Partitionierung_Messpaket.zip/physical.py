"""Independent, semidiscrete time-integration diagnostics and book accuracy budgets."""
from pathlib import Path
import json
import sys
import numpy as np
from models import load_groundwater

def measure(path,repo):
    meta=json.loads((path/'metadata.json').read_text())
    ref=np.load(path/'reference.npy');x=np.fromfile(path/'base.fields',dtype='<f8').reshape(ref.shape)
    result=dict(horizon=meta['horizon'],samples=meta['samples']+1)
    if meta['model']=='c19r':
        b,profiles=load_groundwater(repo)
        idx={'nominal':0,'pulse':4}[meta['profile']]
        rates=np.asarray(profiles['test_rates_mg_s'][idx:idx+1])
        ref_open=b.observation_field(rates,b.green_basis(192))
        scores=b.report_scores(x[-1:].reshape(1,*meta['shape']),ref_open,
                               rates@b.point_basis(),rates.sum(axis=1)*b.HORIZON/b.SEGMENTS)
        result.update(relative_against_same_ode=float(np.linalg.norm(x[-1]-ref[-1])/np.linalg.norm(ref[-1])),
                      green={k:v[0] for k,v in scores.items()})
    else:
        n=meta['shape'][1]; intervals=meta['parameters']['intervals']
        field=x[:,:n];true=ref[:,:n]
        error=float(np.linalg.norm(field-true)/np.linalg.norm(true))
        grid=np.linspace(0,1,intervals+1)
        probes=[.10,.25,.50,.75,.90]
        delta=np.column_stack((np.zeros(len(ref)),field-true,x[:,-2]-ref[:,-2]))
        sensor=float(max(max(abs(np.interp(probes,grid,y))) for y in delta))
        score=max(error/.01,sensor/.001)
        result.update(relative_against_same_ode=error, max_sensor_error_m=sensor,score=score,passed=score<=1)
    return result

if __name__=='__main__':
    repo=Path(sys.argv[1])
    paths=[Path(v) for v in sys.argv[2:]]
    print(json.dumps({path.name:measure(path,repo) for path in paths},indent=2))
