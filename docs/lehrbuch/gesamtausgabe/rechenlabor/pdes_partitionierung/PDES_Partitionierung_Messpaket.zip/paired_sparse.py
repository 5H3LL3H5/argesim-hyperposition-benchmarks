import json
from pathlib import Path
import random
from run_sparse import trial

rng=random.Random(2611)
for path in (Path('c19_nom'),Path('c19_pulse')):
    for repeat in range(1,4):
        for mode,window in (('optimistic',6750.),('conservative',108000.)):
            group=[(1,'one'),(4,'weighted'),(8,'weighted')]
            rng.shuffle(group)
            for ranks,layout in group:
                r=trial(path,ranks,layout,mode,window,repeat)
                assert r['verified']
                print(json.dumps(r,separators=(',',':')),flush=True)
