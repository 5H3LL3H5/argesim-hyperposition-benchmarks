"""Produce exact sparse affine ODE matrices from the book parameters and reference fields."""
import argparse
import json
import math
from pathlib import Path
import sys
import zipfile

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import expm_multiply


def load_groundwater(repo):
    with zipfile.ZipFile(repo/'docs/lehrbuch/gesamtausgabe/pakete/Laborquellen.zip') as z:
        code=z.read('rechenlabor/fno_benchmarks/c19r.py')
        profiles=json.loads(z.read('rechenlabor/fno_benchmarks/messung/vergleich.json'))['c19r']
    import types
    model=types.ModuleType('book_groundwater')
    exec(compile(code,'c19r.py','exec'),model.__dict__)
    return model,profiles


def groundwater(repo, horizon, rel, profile):
    book,profiles=load_groundwater(repo);nx,ny=len(book.X),len(book.Y)
    diff=book.DIFFUSION/book.DX**2; adv=book.VELOCITY/book.DX
    rows=[]
    for y in range(ny):
        for x in range(nx):
            i=y*nx+x; co={}
            for yy,xx in ((y-1,x),(y+1,x),(y,x-1),(y,x+1)):
                if 0<=yy<ny and 0<=xx<nx: co[yy*nx+xx]=diff
            co[i]=-adv-len(co)*diff
            if x: co[i-1]+=adv
            rows.append(sorted(co.items()))
    ref_basis=book.green_basis(192)
    nominal=np.array(profiles['test_rates_mg_s'][0]); ref_scale=float((nominal@ref_basis.reshape(book.SEGMENTS,-1)).max())
    index={'nominal':0,'pulse':4}[profile]
    rate=np.array(profiles['test_rates_mg_s'][index]); source=np.ravel_multi_index(book.SOURCE,(ny,nx)).item()
    if horizon != book.HORIZON and index!=0:raise ValueError('Profile times are fixed by the book')
    rates=rate/book.CELL_WATER if horizon==book.HORIZON else rate[:1]/book.CELL_WATER
    n=nx*ny
    a=as_matrix(rows);probe=np.arange(n,dtype=float).reshape(1,ny,nx)/n
    test=a@probe.ravel();test[source]+=1/book.CELL_WATER
    derivative,_=book.flux_derivative(probe,np.array([1.]))
    np.testing.assert_allclose(test,derivative.ravel(),atol=1e-18)
    return rows,np.zeros(n),np.full(n,ref_scale*rel),source,rates,(ny,nx),dict(scale=ref_scale,rel=rel,profile=profiles['test_names'][index])


def rope(intervals, rel, profile):
    n=intervals-1; k=(intervals/10)**2/2; omega={'nominal':1.,'frequency':2.6}[profile]
    # Quantize displacement, velocity and the two autonomous drive states independently.
    rows=[[(n+i,1.)] for i in range(n)]
    for i in range(n):
        co=[(i,-2*k)]
        if i: co.append((i-1,k))
        co.append((i+1 if i+1<n else 2*n,k))
        rows.append(sorted(co))
    rows.extend([[(2*n,-.2),(2*n+1,omega)],[(2*n,-omega),(2*n+1,-.2)]])
    initial=np.zeros(2*n+2);initial[-1]=1.
    # Scale velocity by sqrt(k) so that u and v/sqrt(k) use the same quantum.
    quantum=np.r_[np.full(n,rel),np.full(n,rel*math.sqrt(k)),[rel,rel]]
    return rows,initial,quantum,-1,[0.],(1,n),dict(intervals=intervals,omega=omega,delta_u=rel,delta_v=quantum[n])


def as_matrix(rows):
    ir=[];ic=[];a=[]
    for i,row in enumerate(rows):
        for j,v in row:ir.append(i);ic.append(j);a.append(v)
    return sparse.csr_matrix((a,(ir,ic)),shape=(len(rows),len(rows)))


def reference(rows,initial,source,rates,horizon,samples):
    a=as_matrix(rows);n=len(rows)
    src=np.zeros((n,1))
    if source>=0:src[source,0]=1.
    mat=sparse.bmat([[a,sparse.csr_matrix(src)],[sparse.csr_matrix((1,n)),sparse.csr_matrix((1,1))]],format='csr')
    assert samples%len(rates)==0
    pieces=[initial[None,:]]
    state=initial
    for rate in rates:
        y=expm_multiply(mat,np.r_[state,rate],start=0,stop=horizon/len(rates),num=samples//len(rates)+1)
        state=y[-1,:-1];pieces.append(y[1:,:-1])
    return np.concatenate(pieces)


def prepare(repo,out,model,horizon,quantum,profile,samples,intervals=800):
    if model=='c19r': rows,y0,delta,source,rates,shape,details=groundwater(repo,horizon,quantum,profile)
    else: rows,y0,delta,source,rates,shape,details=rope(intervals,quantum,profile)
    out.mkdir(parents=True,exist_ok=True)
    with (out/'model.txt').open('w') as f:
        print(len(rows),horizon,samples,source,len(rates),file=f)
        print(*[repr(float(r)) for r in rates],file=f)
        for i,row in enumerate(rows):
            print(repr(float(y0[i])),repr(float(delta[i])),len(row),*[v for j,a in row for v in (str(j),repr(float(a)))],file=f)
    (out/'metadata.json').write_text(json.dumps(dict(model=model,horizon=horizon,samples=samples,shape=shape,
                                                    profile=profile,quantum=quantum,**{'parameters': details}),indent=2))
    values=reference(rows,y0,source,rates,horizon,samples);np.save(out/'reference.npy',values)
    np.savetxt(out/'one.map',np.zeros(len(y0),dtype=int),fmt='%d')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('repo',type=Path);p.add_argument('out',type=Path)
    p.add_argument('model',choices=('c19r','rope'));p.add_argument('horizon',type=float)
    p.add_argument('quantum',type=float);p.add_argument('profile');p.add_argument('samples',type=int)
    p.add_argument('--intervals',type=int,default=800);a=p.parse_args()
    prepare(a.repo,a.out,a.model,a.horizon,a.quantum,a.profile,a.samples,a.intervals)

