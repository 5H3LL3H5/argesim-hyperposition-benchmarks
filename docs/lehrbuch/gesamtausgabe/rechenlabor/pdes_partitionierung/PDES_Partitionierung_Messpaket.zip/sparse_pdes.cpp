// Exact-in-time QSS1 event calendars for sparse affine ODEs, one LP per MPI rank.
// Bounded optimistic waveform iteration and a conservative earliest-export protocol.
#include <mpi.h>
#include <sched.h>
#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <queue>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

using std::vector;
constexpr double inf = std::numeric_limits<double>::infinity();

struct Model {
    int size{}, source{}, samples{};
    double horizon{};
    vector<double> initial, quantum, rates;
    vector<vector<std::pair<int,double>>> inputs;
    vector<vector<int>> dependents;
    explicit Model(const std::string& file) {
        std::ifstream f(file);
        int bins;
        if (!(f >> size >> horizon >> samples >> source >> bins) || size<1 || bins<1 || samples<1)
            throw std::runtime_error("Invalid model header");
        rates.resize(bins);
        for (auto& value: rates) f >> value;
        initial.resize(size); quantum.resize(size); inputs.resize(size); dependents.resize(size);
        for (int i=0; i<size; ++i) {
            int n; f >> initial[i] >> quantum[i] >> n;
            if (quantum[i]<=0 || n<0) throw std::runtime_error("Invalid node");
            for (int j=0; j<n; ++j) {
                int id; double a; f>>id>>a;
                if (id<0 || id>=size) throw std::runtime_error("Invalid dependency");
                inputs[i].emplace_back(id,a); dependents[id].push_back(i);
            }
        }
        if (!f) throw std::runtime_error("Truncated model");
    }
};

struct Event {
    double time;
    std::int32_t node, level;
    bool operator==(const Event&) const=default;
};
static_assert(sizeof(Event)==16);
bool before(const Event& a,const Event& b) {
    return a.time<b.time || (a.time==b.time && a.node<b.node);
}
using Waves=vector<vector<Event>>;
struct Cell {
    double anchor{}, x{}, slope{}, due{inf};
    std::uint64_t count{}, hash{14695981039346656037ull};
};
struct State {
    vector<Cell> cell;
    vector<int> level;
};
struct Metrics {
    std::uint64_t comm{}, transmitted{}, packets{}, headers{}, restores{}, iterations{}, committed{},
        simulated{}, probe_events{}, undo_events{}, probes{}, safe_cuts{};
    double safe_sum{},safe_min{inf},safe_max{};
};
using Deadline=std::pair<double,int>;

struct Engine {
    const Model& m;
    vector<int> owner, mine;
    vector<vector<int>> recipients;
    int rank, ranks;
    bool save_trace;
    vector<Event> trace;
    double source_rate{};

    Engine(const Model& model, const std::string& map, int r, int p, bool capture):
        m(model),owner(m.size),recipients(m.size),rank(r),ranks(p),save_trace(capture) {
        std::ifstream f(map);
        for (int i=0;i<m.size;++i) {
            if (!(f>>owner[i]) || owner[i]<0 || owner[i]>=ranks)
                throw std::runtime_error("Invalid owner map");
            if (owner[i]==rank) mine.push_back(i);
        }
        if (mine.empty()) throw std::runtime_error("Empty rank");
        for (int i:mine) {
            std::set<int> dest;
            for (int k:m.dependents[i]) if (owner[k]!=rank) dest.insert(owner[k]);
            recipients[i].assign(dest.begin(),dest.end());
        }
    }
    double q(const State& s,int i) const {return m.initial[i]+m.quantum[i]*s.level[i];}
    void refresh(State& s,int i,double time) const {
        Cell& c=s.cell[i];
        c.x += c.slope*(time-c.anchor); c.anchor=time;
        double slope=i==m.source?source_rate:0.;
        for (auto [id,a]:m.inputs[i]) slope+=a*q(s,id);
        c.slope=slope;
        if (slope==0.) {c.due=inf;return;}
        double gap=(q(s,i)+std::copysign(m.quantum[i],slope)-c.x)/slope;
        double scale=std::max({1.,std::abs(c.x),std::abs(q(s,i))});
        if (gap < 0. && -gap*std::abs(slope)>128*std::numeric_limits<double>::epsilon()*scale)
            throw std::runtime_error("Quantizer left its band");
        c.due=time+std::max(0.,gap);
        if (c.due<=time) c.due=std::nextafter(time,inf);
    }
    State initial() const {
        State s{vector<Cell>(m.size), vector<int>(m.size)};
        for(int i:mine) {s.cell[i].x=m.initial[i];refresh(s,i,0.);}
        return s;
    }
    void foreign(State& s,const vector<Event>& incoming,double at) const {
        vector<int> affected;
        for (const auto& e:incoming) {
            if (e.time!=at || owner[e.node]==rank) throw std::runtime_error("Invalid boundary event");
            s.level[e.node]=e.level;
            for (int i:m.dependents[e.node]) if (owner[i]==rank) affected.push_back(i);
        }
        std::sort(affected.begin(),affected.end()); affected.erase(std::unique(affected.begin(),affected.end()),affected.end());
        for(int i:affected) refresh(s,i,at);
    }

    // Time is never re-anchored at artificial window boundaries. Replays therefore
    // use the same floating-point operations as the single-rank event trajectory.
    double advance(State& s,double end,const vector<Event>& inbox,Waves& out,
                   bool first_export,std::uint64_t& work,vector<Event>* local_trace=nullptr) const {
        vector<Deadline> deadlines;
        for (int i:mine) if (s.cell[i].due<=end) deadlines.emplace_back(s.cell[i].due,i);
        std::priority_queue<Deadline,vector<Deadline>,std::greater<Deadline>> pending(std::greater<Deadline>(),std::move(deadlines));
        std::size_t input=0;
        while (true) {
            while (!pending.empty() && pending.top().first!=s.cell[pending.top().second].due) pending.pop();
            double t=std::min(pending.empty()?inf:pending.top().first,input<inbox.size()?inbox[input].time:inf);
            if (t>end) return end;
            vector<int> affected;
            vector<Event> changes;
            bool exports=false;
            while (!pending.empty() && pending.top().first==t) {
                int i=pending.top().second; pending.pop();
                auto& c=s.cell[i];
                if (c.due!=t) continue;
                c.due=inf;
                const int level=s.level[i]+(c.slope>0.?1:-1);
                Event e{t,i,level};changes.push_back(e);affected.push_back(i);
                ++c.count; ++work;
                c.hash=(c.hash^std::bit_cast<std::uint64_t>(t))*1099511628211ull;
                c.hash=(c.hash^static_cast<std::uint32_t>(level))*1099511628211ull;
                for (int dest:recipients[i]) {out[dest].push_back(e);exports=true;}
                if (local_trace) local_trace->push_back(e);
            }
            if (first_export && exports) return t;
            while (input<inbox.size() && inbox[input].time==t) changes.push_back(inbox[input++]);
            for (const auto& e:changes) {
                s.level[e.node]=e.level;
                for (int j:m.dependents[e.node]) if (owner[j]==rank) affected.push_back(j);
            }
            std::sort(affected.begin(),affected.end());
            affected.erase(std::unique(affected.begin(),affected.end()),affected.end());
            for (int i:affected) {
                refresh(s,i,t);
                if (s.cell[i].due<=end) pending.emplace(s.cell[i].due,i);
            }
        }
    }
};

vector<Event> flatten(const Waves& waves) {
    vector<Event> all;
    for (const auto& w:waves) all.insert(all.end(),w.begin(),w.end());
    std::sort(all.begin(),all.end(),before);
    return all;
}

// Send replacement waves only when their contents change. A zero header retracts
// an old wave, -1 means unchanged. Wire counts are application payloads.
bool exchange(const Waves& next,const Waves& previous,Waves& incoming,int rank,Metrics& stats) {
    int p=static_cast<int>(next.size());
    if (p==1) return false;
    vector<int> send(p,-1),recv(p,-1),sc(p),rc(p),sd(p),rd(p);
    for(int i=0;i<p;++i) if (next[i]!=previous[i]) send[i]=static_cast<int>(next[i].size());
    MPI_Alltoall(send.data(),1,MPI_INT,recv.data(),1,MPI_INT,MPI_COMM_WORLD);
    stats.headers+=std::uint64_t(p-1)*sizeof(int);
    int ns=0,nr=0;bool changed=false;
    for(int i=0;i<p;++i) {
        sc[i]=std::max(0,send[i])*sizeof(Event);rc[i]=std::max(0,recv[i])*sizeof(Event);
        sd[i]=ns;rd[i]=nr;ns+=sc[i];nr+=rc[i];
        if (send[i]>=0 && i!=rank) {stats.transmitted+=send[i];++stats.packets;}
        if (recv[i]>=0) changed=true;
    }
    vector<char> sb(std::max(1,ns)),rb(std::max(1,nr));
    for(int i=0;i<p;++i) if(sc[i]) std::memcpy(sb.data()+sd[i],next[i].data(),sc[i]);
    MPI_Alltoallv(sb.data(),sc.data(),sd.data(),MPI_BYTE,rb.data(),rc.data(),rd.data(),MPI_BYTE,MPI_COMM_WORLD);
    for(int i=0;i<p;++i) if(recv[i]>=0) {
        incoming[i].resize(recv[i]);
        if(rc[i]) std::memcpy(incoming[i].data(),rb.data()+rd[i],rc[i]);
    }
    return changed;
}

void optimistic(Engine& e,State& state,double end,Metrics& stats) {
    Waves inputs(e.ranks),old(e.ranks);
    State candidate;
    vector<Event> trace;
    bool dirty=true;std::uint64_t candidate_work=0;
    for (int round=0;round<5000;++round) {
        Waves next=old;
        if(dirty) {
            if(round) {++stats.restores;stats.undo_events+=candidate_work;}
            candidate=state;next.assign(e.ranks,{});trace.clear();
            auto ordered=flatten(inputs);candidate_work=0;
            e.advance(candidate,end,ordered,next,false,candidate_work,e.save_trace?&trace:nullptr);
            stats.simulated+=candidate_work;
        }
        dirty=exchange(next,old,inputs,e.rank,stats);
        old=std::move(next);
        int vote=dirty,any=0;MPI_Allreduce(&vote,&any,1,MPI_INT,MPI_MAX,MPI_COMM_WORLD);
        ++stats.iterations;
        if (!any) {
            for (const auto& v:old) stats.comm+=v.size();
            stats.committed+=candidate_work;state=std::move(candidate);
            e.trace.insert(e.trace.end(),trace.begin(),trace.end());
            return;
        }
    }
    throw std::runtime_error("Optimistic window failed to converge");
}

void conservative(Engine& e,State& state,double begin,double end,Metrics& stats) {
    while (begin<end) {
        double cut=end;
        if(e.ranks>1) {
            auto probe=state;Waves predicted(e.ranks);
            double local=e.advance(probe,end,{},predicted,true,stats.probe_events);
            MPI_Allreduce(&local,&cut,1,MPI_DOUBLE,MPI_MIN,MPI_COMM_WORLD);
            ++stats.probes;
        }
        if(!(begin<cut)) throw std::runtime_error("Safe cut failed to advance");
        double h=cut-begin;
        stats.safe_sum+=h;stats.safe_min=std::min(stats.safe_min,h);
        stats.safe_max=std::max(stats.safe_max,h);++stats.safe_cuts;
        Waves sent(e.ranks),received(e.ranks),empty(e.ranks);
        std::uint64_t work=0;
        e.advance(state,cut,{},sent,false,work,e.save_trace?&e.trace:nullptr);
        stats.committed+=work; stats.simulated+=work;
        for(const auto& v:sent) stats.comm+=v.size();
        exchange(sent,empty,received,e.rank,stats);
        e.foreign(state,flatten(received),cut);
        begin=cut;
    }
}

template<class T> void binary(const std::string& name,const vector<T>& v) {
    std::ofstream f(name,std::ios::binary);
    f.write(reinterpret_cast<const char*>(v.data()),static_cast<std::streamsize>(v.size()*sizeof(T)));
    if(!f) throw std::runtime_error("Could not write "+name);
}

int main(int argc,char** argv) {
    MPI_Init(&argc,&argv);int rank,p;MPI_Comm_rank(MPI_COMM_WORLD,&rank);MPI_Comm_size(MPI_COMM_WORLD,&p);
    try {
        if(argc!=7) throw std::runtime_error("model map optimistic|conservative window output trace(0|1)");
        cpu_set_t available,bound;CPU_ZERO(&available);CPU_ZERO(&bound);
        if(sched_getaffinity(0,sizeof(available),&available)) throw std::runtime_error("Cannot read affinity");
        vector<int> available_ids;
        for(int i=0;i<CPU_SETSIZE;++i) if(CPU_ISSET(i,&available)) available_ids.push_back(i);
        if(int(available_ids.size())<p) throw std::runtime_error("Insufficient CPUs");
        CPU_SET(available_ids[rank],&bound);
        if(sched_setaffinity(0,sizeof(bound),&bound)) throw std::runtime_error("Cannot bind LP");
        Model m(argv[1]);Engine e(m,argv[2],rank,p,std::stoi(argv[6])!=0);
        std::string mode(argv[3]), out(argv[5]);double window=std::stod(argv[4]);
        if(!(window>0.) || (mode!="optimistic" && mode!="conservative")) throw std::runtime_error("Invalid configuration");
        e.source_rate=m.rates.front();
        State state=e.initial();Metrics stats;
        vector<double> fields,local(m.size),global(m.size);
        auto sample=[&](double t) {
            for(int i:e.mine) local[i]=state.cell[i].x+(t-state.cell[i].anchor)*state.cell[i].slope;
            MPI_Reduce(local.data(),global.data(),m.size,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
            if(rank==0) fields.insert(fields.end(),global.begin(),global.end());
        };
        MPI_Barrier(MPI_COMM_WORLD);double start=MPI_Wtime();sample(0.);
        double t=0.;int bin=0;
        for(int sample_index=1;sample_index<=m.samples;++sample_index) {
            const double sample_time=m.horizon*sample_index/m.samples;
            while(t<sample_time) {
                double bin_end=m.horizon*(bin+1)/m.rates.size();
                double end=std::min({sample_time,bin_end,t+window});
                if(!(end>t)) throw std::runtime_error("Invalid time window");
                if(mode=="optimistic") optimistic(e,state,end,stats);
                else conservative(e,state,t,end,stats);
                t=end;
                if(t==bin_end && bin+1<int(m.rates.size())) {
                    e.source_rate=m.rates[++bin];
                    if(m.source>=0 && e.owner[m.source]==rank) e.refresh(state,m.source,t);
                }
            }
            sample(t);
        }
        vector<std::uint64_t> hashes(m.size),counts(m.size),allhash(m.size),allcount(m.size);
        for(int i:e.mine) {hashes[i]=state.cell[i].hash; counts[i]=state.cell[i].count;}
        MPI_Reduce(hashes.data(),allhash.data(),m.size,MPI_UINT64_T,MPI_BXOR,0,MPI_COMM_WORLD);
        MPI_Reduce(counts.data(),allcount.data(),m.size,MPI_UINT64_T,MPI_SUM,0,MPI_COMM_WORLD);
        if(rank==0) {binary(out+".fields",fields);binary(out+".hash",allhash);binary(out+".counts",allcount);}
        if(e.save_trace) binary(out+".trace"+std::to_string(rank),e.trace);
        MPI_Barrier(MPI_COMM_WORLD);
        double local_wall=MPI_Wtime()-start,wall;
        MPI_Reduce(&local_wall,&wall,1,MPI_DOUBLE,MPI_MAX,0,MPI_COMM_WORLD);
        std::uint64_t raw[]={stats.comm,stats.transmitted,stats.packets,stats.headers,stats.restores,stats.simulated,
            stats.committed,stats.probe_events,stats.undo_events};
        std::uint64_t total[9]={};
        MPI_Reduce(raw,total,9,MPI_UINT64_T,MPI_SUM,0,MPI_COMM_WORLD);
        if(rank==0) std::cout<<std::setprecision(17)<<"{\"wall_s\":"<<wall
            <<",\"committed_exports\":"<<total[0]<<",\"wire_events\":"<<total[1]<<",\"packets\":"<<total[2]
            <<",\"count_header_bytes\":"<<total[3]<<",\"rollbacks\":"<<total[4]<<",\"processed\":"<<total[5]
            <<",\"committed\":"<<total[6]<<",\"probe_events\":"<<total[7]<<",\"discarded_events\":"<<total[8]
            <<",\"rounds\":"<<(mode=="optimistic"?stats.iterations:stats.safe_cuts)
            <<",\"safe_cuts\":"<<stats.safe_cuts<<",\"safe_mean\":"<<(stats.safe_cuts?stats.safe_sum/stats.safe_cuts:0.)
            <<",\"safe_min\":"<<(stats.safe_cuts?stats.safe_min:0.)<<",\"safe_max\":"<<stats.safe_max<<"}\n";
    } catch(const std::exception& exc) {std::cerr<<"rank "<<rank<<": "<<exc.what()<<"\n";MPI_Abort(MPI_COMM_WORLD,2);}
    MPI_Finalize();
}

