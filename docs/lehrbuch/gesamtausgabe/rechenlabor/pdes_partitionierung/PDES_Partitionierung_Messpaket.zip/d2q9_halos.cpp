// CP2 D2Q9. Transfer each streamed population that crosses an MPI ownership boundary once.
#include <mpi.h>
#include <sched.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
#include "kernel_local.hpp"

std::vector<int> cuts(int n,int p) {
    std::vector<int> result{0};
    for(int r=0;r<p;++r) result.push_back(result.back()+n/p+(r<n%p));
    return result;
}

int main(int argc,char** argv) {
    MPI_Init(&argc,&argv);
    int rank, nr;MPI_Comm_rank(MPI_COMM_WORLD,&rank);MPI_Comm_size(MPI_COMM_WORLD,&nr);
    try {
        if(argc!=5) throw std::runtime_error("px py steps result_prefix");
        int px=std::stoi(argv[1]),py=std::stoi(argv[2]),steps=std::stoi(argv[3]);
        if(px*py!=nr || steps<=0) throw std::runtime_error("Invalid dimensions");
        cpu_set_t allowed,pin;CPU_ZERO(&allowed);CPU_ZERO(&pin);
        if(sched_getaffinity(0,sizeof(allowed),&allowed)) throw std::runtime_error("Affinity");
        std::vector<int> cpus;
        for(int i=0;i<CPU_SETSIZE;++i) if(CPU_ISSET(i,&allowed)) cpus.push_back(i);
        if(int(cpus.size())<nr) throw std::runtime_error("Insufficient CPUs");
        CPU_SET(cpus.at(rank),&pin);
        if(sched_setaffinity(0,sizeof(pin),&pin)) throw std::runtime_error("Affinity");
        const int n=257, st=(n+15)/16*16, pl=st*n;
        double rate=1./(.5+3*(n-1)*lid/1000.);
        auto xs=cuts(n,px),ys=cuts(n,py);
        int x0=xs[rank%px],x1=xs[rank%px+1],y0=ys[rank/px],y1=ys[rank/px+1];
        std::vector<int> owner(n*n);
        for(int ry=0;ry<py;++ry) for(int rx=0;rx<px;++rx)
            for(int y=ys[ry];y<ys[ry+1];++y) for(int x=xs[rx];x<xs[rx+1];++x) owner[y*n+x]=ry*px+rx;
        std::vector<std::vector<int>> sendto(nr),recvfrom(nr);
        for(int y=0;y<n;++y) for(int x=0;x<n;++x) for(int j=1;j<9;++j) {
            int tx=x+cx[j],ty=y+cy[j];if(tx<0||tx>=n||ty<0||ty>=n) continue;
            int a=owner[y*n+x],b=owner[ty*n+tx];
            if(a==b)continue;
            int index=j*pl+ty*st+tx;
            if(a==rank)sendto[b].push_back(index);
            if(b==rank)recvfrom[a].push_back(index);
        }
        std::vector<int> si,ri,sc(nr),rc(nr),sd(nr),rd(nr);
        std::uint64_t packets=0;
        for(int r=0;r<nr;++r) {
            sd[r]=si.size();rd[r]=ri.size();sc[r]=sendto[r].size();rc[r]=recvfrom[r].size();
            packets+=sc[r]>0;
            si.insert(si.end(),sendto[r].begin(),sendto[r].end());
            ri.insert(ri.end(),recvfrom[r].begin(),recvfrom[r].end());
        }
        std::vector<double> sb(std::max(std::size_t{1},si.size())),rb(std::max(std::size_t{1},ri.size()));
        std::array<std::vector<double>,2> buf{std::vector<double>(9*pl),std::vector<double>(9*pl)};
        for(int j=0;j<9;++j)std::fill_n(buf[0].data()+j*pl,pl,weight[j]);
        MPI_Barrier(MPI_COMM_WORLD);
        double start=MPI_Wtime();
        for(int k=0;k<steps;++k) {
            const auto* a=buf[k%2].data();auto* b=buf[(k+1)%2].data();
            for(int y=y0;y<y1;++y) {
                if(y==0||y==n-1) for(int x=x0;x<x1;++x) edge(a,b,n,st,pl,y,x);
                else {
                    row(a,b,n,st,pl,y,rate,std::max(1,x0),std::min(n-1,x1));
                    if(x0==0)edge(a,b,n,st,pl,y,0);
                    if(x1==n)edge(a,b,n,st,pl,y,n-1);
                }
            }
            if(nr>1) {
                for(std::size_t i=0;i<si.size();++i)sb[i]=b[si[i]];
                MPI_Alltoallv(sb.data(),sc.data(),sd.data(),MPI_DOUBLE,rb.data(),rc.data(),rd.data(),MPI_DOUBLE,MPI_COMM_WORLD);
                for(std::size_t i=0;i<ri.size();++i)b[ri[i]]=rb[i];
            }
        }
        MPI_Barrier(MPI_COMM_WORLD);
        double elapsed=MPI_Wtime()-start,wall=0;
        MPI_Reduce(&elapsed,&wall,1,MPI_DOUBLE,MPI_MAX,0,MPI_COMM_WORLD);
        const auto* a=buf[steps%2].data();
        std::vector<double> local(3*n*n),full(3*n*n);
        for(int y=y0;y<y1;++y) for(int x=x0;x<x1;++x) {
            double f[9],rho=0;
            for(int j=0;j<9;++j) {f[j]=a[j*pl+y*st+x];rho+=f[j];}
            if(!(rho>0))throw std::runtime_error("Invalid state");
            int i=y*n+x;local[i]=rho;
            local[n*n+i]=(f[1]+f[5]+f[8]-f[3]-f[6]-f[7])/(rho*lid);
            local[2*n*n+i]=(f[2]+f[5]+f[6]-f[4]-f[7]-f[8])/(rho*lid);
        }
        MPI_Reduce(local.data(),full.data(),3*n*n,MPI_DOUBLE,MPI_SUM,0,MPI_COMM_WORLD);
        std::uint64_t metrics[]={si.size(),packets}, totals[2]={};
        MPI_Reduce(metrics,totals,2,MPI_UINT64_T,MPI_SUM,0,MPI_COMM_WORLD);
        if(rank==0) {
            std::ofstream output(std::string(argv[4])+".fields",std::ios::binary);
            output.write(reinterpret_cast<const char*>(full.data()),full.size()*sizeof(double));
            if(!output) throw std::runtime_error("Cannot write field");
            std::cout<<std::setprecision(16)<<"{\"steps\":"<<steps<<",\"px\":"<<px<<",\"py\":"<<py
                <<",\"ranks\":"<<nr<<",\"populations_per_step\":"<<totals[0]<<",\"directed_peer_pairs\":"
                <<totals[1]<<",\"kernel_s\":"<<wall<<"}\n";
        }
    } catch(const std::exception& ex) { std::cerr<<"Rank "<<rank<<": "<<ex.what()<<"\n";MPI_Abort(MPI_COMM_WORLD,1); }
    MPI_Finalize();
}
