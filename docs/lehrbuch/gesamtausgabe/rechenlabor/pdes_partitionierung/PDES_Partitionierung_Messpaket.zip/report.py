"""Render the German results with the verified summary CSV files and committed event counts."""
import csv
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import Paragraph

W,H=A4;L=43;R=W-43;BW=R-L
blue='#17354B';teal='#007B76';slate='#40576A';line='#CBD8DD'
fontdir=Path('/usr/share/fonts/truetype/dejavu')
for n,f in [('Sans','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Serif','DejaVuSerif.ttf')]:
    pdfmetrics.registerFont(TTFont(n,str(fontdir/f)))
pdfmetrics.registerFontFamily('Sans',normal='Sans',bold='Bold')

def heatmap():
    a=np.fromfile('c19_nom/base.counts',dtype='<u8').reshape(33,65)
    fig,axs=plt.subplots(1,2,figsize=(8,2.50))
    for ax,title,cx,cy in zip(axs,['Gleichmäßige Kacheln','Ereignisgewichtete Streifen'],
                              [[17,33,49],[9,18,27,36,44,51,58]],[[17],[]]):
        im=ax.imshow(np.log10(1+a),vmin=0,vmax=np.log10(1+a.max()),cmap='Blues',origin='lower',interpolation='nearest')
        for x in cx:ax.axvline(x-.5,color='#c34f19',lw=1.1)
        for y in cy:ax.axhline(y-.5,color='#c34f19',lw=1.1)
        ax.plot(12,16,'o',ms=4,mfc='#ffd052',mec='#32280d',mew=.8)
        ax.set(title=title,xticks=[0,32,64],yticks=[0,16,32]);ax.tick_params(labelsize=8,length=2)
        ax.set_title(title,fontsize=11,color=blue)
    fig.subplots_adjust(left=.045,right=.99,top=.86,bottom=.12,wspace=.12)
    fig.savefig('c19_partitions.png',dpi=165,bbox_inches='tight',pad_inches=.04,facecolor='white');plt.close(fig)

def para(c,txt,x,top,width,fontsize=10,leading=15,color=slate,font='Sans'):
    style=ParagraphStyle('local',fontName=font,fontSize=fontsize,leading=leading,textColor=HexColor(color),alignment=TA_LEFT)
    p=Paragraph(txt,style);_,h=p.wrap(width,9999);p.drawOn(c,x,top-h);return top-h

def body(txt,y):return para(c,txt,L,y,BW)
def title(txt,y):return para(c,txt,L,y,BW,23,29,blue,'Serif')-8
def head(txt,y):return para(c,txt,L,y,BW,12,16,teal,'Bold')-5
def foot(page):
    c.setStrokeColor(HexColor(line));c.line(L,40,R,40);c.setFont('Sans',8);c.setFillColor(HexColor(slate))
    c.drawString(L,26,'ARGESIM  ·  PDES-Partitionierung  ·  26. November 2026');c.drawRightString(R,26,str(page))
def top(section):
    c.setFillColor(HexColor(teal));c.rect(L,H-52,27,3,fill=1,stroke=0)
    c.setFont('Bold',9);c.drawString(L+36,H-54,section)
    return H-72

def table(y,widths,headers,rows):
    x=L
    heights=[0]
    for rownum,row in enumerate([headers,*rows]):
        f='Bold' if rownum==0 else 'Sans';fs=8.5 if rownum==0 else 9
        cells=[Paragraph(str(val),ParagraphStyle('cell',fontName=f,fontSize=fs,leading=12,textColor=HexColor(blue)))
               for val in row]
        ht=max(p.wrap(w-14,600)[1] for p,w in zip(cells,widths))+11
        if rownum==0 or rownum%2:
            c.setFillColor(HexColor('#E0EBEE' if rownum==0 else '#F4F7F8'))
            c.rect(L,y-ht,sum(widths),ht,stroke=0,fill=1)
        xx=L
        for p,w in zip(cells,widths):
            _,h=p.wrap(w-14,600);p.drawOn(c,xx+7,y-5-h);xx+=w
        y-=ht
    return y-10

def de(x,n=2):return f'{x:,.{n}f}'.replace(',','@').replace('.',',').replace('@','.')
def select(file,**query):
    return next(r for r in csv.DictReader(open(file)) if all(r[k]==str(v) for k,v in query.items()))

if __name__=='__main__':
    heatmap()
    c=Canvas('PDES_Partitionierung_Messbericht.pdf',pagesize=A4)
    c.setTitle('PDES-Partitionierung bei Kavität, Grundwasser und Saite')
    y=title('Wie viel Parallelität gewinnt die Kavität?',top('CP2/2  ·  QSS3 UND QSS4'))
    y=body('Auf dem Gitter mit 257 × 257 Punkten beschleunigen acht Prozesse die ersten acht Ereignisabschnitte um bis zu <b>5,03× bei QSS3</b> und <b>5,32× bei QSS4</b>. Die 65.025 inneren Wirbelzustände und ihre Zeitstempel stimmen in allen geprüften Varianten bytegenau mit dem seriellen Solver überein.',y)-15
    y=head('Acht Prozesse am bewegten Deckel',y)
    rows=[]
    for name,layout in [('Zeilen','rows'),('Kacheln','tiles'),('Spalten','columns')]:
        cs=[select('cavity_summary.csv',order=o,segments=8,ranks=8,layout=layout,mode='conservative',window=.003) for o in (3,4)]
        os=[select('cavity_summary.csv',order=o,segments=32,ranks=8,layout=layout,mode='optimistic',window=.003) for o in (3,4)]
        rows.append([name,*[de(float(r['speedup']))+'×' for r in cs],*[r['rollbacks'] for r in os]])
    y=table(y,[102,94,94,110,110],['Aufteilung','Speedup QSS3','Speedup QSS4','Rollbacks QSS3','Rollbacks QSS4'],rows)
    y=body('Speedup = Median der Wandzeit mit einem Prozess geteilt durch den Median mit acht Prozessen. Je drei Läufe über acht Abschnitte, beide Seiten konservativ. Die beiden rechten Spalten zeigen zurückgesetzte lokale Vorläufe über 32 Abschnitte, je Aufteilung ein deterministisch geprüfter Lauf mit spekulativem Fenster 0,003.',y)-15
    y=head('Was die Schnittlinien ändern',y)
    y=body('Der bewegte Deckel löst die ersten Ereignisse in einem schmalen Bereich entlang des Randes aus. Zeilen halten einen größeren Teil dieser Aktivität zusammen. Ein engeres spekulatives Fenster von 0,0001 reduziert bei QSS3 und acht Zeilenpartitionen die Rücksetzungen in den ersten acht Abschnitten von sieben auf null. Der konservative Modus erreicht bei jeder Geometrie null.',y)-12
    y=body('Der Poisson-Löser auf Rang 0 rekonstruiert das Geschwindigkeitsfeld aus dem gesamten Wirbelfeld. Für jeden RHS-Aufruf sendet und empfängt er je einen Double-Wert pro fremder Zelle. Bei acht Prozessen fallen für QSS3 in 32 Abschnitten 159,22 MB für Zeilen bzw. Spalten und 159,13 MB für Kacheln an. Der kleine Unterschied entspricht der leicht anderen Größe des Teilgebiets auf Rang 0.',y)-15
    y=head('Grenze des Nachweises',y)
    y=body('Die akzeptierten Zeiten sind für alle Aufteilungen identisch. Nach 32 Abschnitten erreicht QSS3 t* = 0,000894246 und QSS4 t* = 0,001849961. Das erste vereinbarte Vergleichsfeld liegt bei t* = 0,1. Für eine komplette QSS-Kavitätstrajektorie ist damit noch kein Speedup gemessen. Die spekulative Implementierung puffert Ausgaben bis zur Bestätigung. Sie testet lokale Rücksetzungen ohne bereits versandte Anti-Nachrichten.',y)
    assert y>50;foot(1);c.showPage()
    y=title('Wo sich ein Schnitt wirklich lohnt',top('C19R  ·  ZEHN SIMULIERTE TAGE'))
    y=body('Für 65 × 33 Zellen wurden alle zulässigen kartesischen Aufteilungen durchgerechnet. Je Achse liegt die Bandbreite zwischen den nach außen gerundeten Grenzen von 90 und 110 % der gleichmäßigen Breite. Das ergibt 168 Karten mit vier und 2.832 mit acht Prozessen. Die ausgewählten Minima wurden mit echten MPI-Prozessen nachgemessen.',y)-11
    img=ImageReader('c19_partitions.png');iw,ih=img.getSize();draw_w=440;draw_h=draw_w*ih/iw;c.drawImage(img,L+(BW-draw_w)/2,y-draw_h,draw_w,draw_h);y-=draw_h+4
    y=para(c,'Nennfall, acht Prozesse. Dunkelblau kennzeichnet häufig quantisierende Zellen, Orange die Schnitte, Gelb die Quelle. Die Farbskala ist logarithmisch und in beiden Bildern gleich.',L,y,BW,8,11,slate)-12
    y=head('Kommunikation, sicherer Fortschritt und spekulative Arbeit',y)
    y=table(y,[123,104,85,100,98],['Quellprofil','Aufteilung, 8 LP','Bestätigte Exporte','Sicherer Schritt, Mittel','Rollbacks, optimistisch'],[
        ['Konstant','Kacheln','31.848','32,03 s','5.803'],['Konstant','Gewichtete Streifen','14.609','74,77 s','2.988'],
        ['Doppelpuls','Kacheln','82.727','12,45 s','7.384'],['Doppelpuls','Nennfall-Streifen','23.866','47,32 s','3.717'],
        ['Doppelpuls','Profiloptimum','19.079','48,70 s','2.755']])
    y=body('Ein Export zählt eine bestätigte Zustandsmeldung an einen fremden Prozess. Der sichere Schritt ist der früheste Grenzexport aller Prozesse ab einem gemeinsam bestätigten Zustand, begrenzt durch den nächsten Ausgabetermin. Rollbacks zählen zurückgesetzte lokale Fenster bei einer spekulativen Weite von 6.750 s. Alle Läufe stimmen in Feldern, Ereigniszahlen sowie Zeit- und Wertverläufen je Zelle mit einem Prozess überein.',y)-13
    y=head('Vier Prozesse zeigen den Zielkonflikt',y)
    y=body('Beim Doppelpuls minimieren horizontale Streifen mit 16.350 Exporten das Kommunikationsvolumen. Sie erlauben im Mittel 52,82 s und benötigen 1.774 Rollbacks. Vertikale Streifen maximieren mit 67,79 s den sicheren Fortschritt, senden 16.516 Exporte und benötigen 2.681 Rollbacks. Die beiden absoluten Optima gelten für die untersuchte Kartenklasse und den jeweiligen Verlauf.',y)
    assert y>50;foot(2);c.showPage()
    y=title('Wann weniger Kommunikation Zeit spart',top('LAUFZEIT, KONTROLLEN UND GÜLTIGKEIT'))
    y=head('C19R bleibt bei dieser Arbeitslast seriell schneller',y)
    y=body('Im Nennfall braucht der konservative QSS1-Lauf mit einem Prozess 31,7 ms. Mit acht ereignisgewichtet aufgeteilten Prozessen sind es 353,9 ms. Auf 65.292 bestätigte Ereignisse kommen 11.556 globale Freigaben, im Mittel nur 5,65 Ereignisse je Freigabe über das ganze Gitter. Optimistisch werden bei gleicher Lösung 507.117 lokale Ereignisverarbeitungen verworfen. Die drei Zeitpaare je Betriebsart stehen im Messpaket. Auch die kontrollierte QSS1-Lösung verfehlt bei beiden Quellprofilen das physikalische Feldbudget der Green-Referenz.',y)-14
    y=head('D2Q9 hat lokale Nachbarn und einen festen Gittertakt',y)
    y=body('Bei derselben Kavitätsgeometrie führt der D2Q9-Prozessversuch den archivierten Kollisionskern aus und überträgt genau die Populationen, die im nächsten Takt beim Nachbarn liegen. Dichte und beide Geschwindigkeitsfelder nach 1.024 Takten sind in allen 48 MPI-Läufen zur archivierten seriellen Implementierung bytegleich.',y)-9
    drows=[]
    for v,x,p in [('4 Prozesse · Zeilen',1,4),('4 Prozesse · Kacheln',2,2),('8 Prozesse · Zeilen',1,8),('8 Prozesse · Kacheln',4,2)]:
        r=select('d2q9_summary.csv',px=x,py=p)
        drows.append([v,de(int(r['populations_per_step']),0),r['communicating_rank_pairs_directed'],de(float(r['speedup']))+'×'])
    y=table(y,[160,128,115,107],['Aufteilung','Populationen / Takt','Gerichtete Rangpaare','Speedup'],drows)
    y=body('Kacheln minimieren das Volumen unter den kartesischen Zerlegungen. Bei acht Prozessen bedienen sie zugleich 32 gerichtete Nachbarschaftsverbindungen, Zeilen nur 14. Im kontrollierten Zeitvergleich liefen Zeilen schneller. Der synchrone Algorithmus hat eine Taktverzögerung an der Schnittstelle und braucht keine Rollbacks. Der frühere vollständige OpenMP-Test erreichte mit vier gebundenen Threads über 350.000 Takte 2,74–2,85×.',y)-14
    y=head('CP1/C-Saite und Scheduler',y)
    y=body('Beim Anlauf der Saite mit 800 Intervallen (0–4 s) sinkt die Zahl der Grenzexporte bei vier Prozessen von 8.381 auf 1.773 und die Zahl der spekulativen Rollbacks von 605 auf 177. Im optimierten Nennfall entfallen 99,93 % der bestätigten Ereignisse auf einen Prozess. Damit sind geringe Kommunikation und gleichmäßige Rechenlast unterschiedliche Ziele. Der serielle Nennlauf über volle 30 s liefert 1,94 Milliarden Ereignisse. Über diesen Zeitraum spart die beste zulässige Viererpartition rechnerisch nur noch 2,74 % der Exporte. Der maximale Sensorfehler beträgt 170 mm bei 1 mm Budget. Die parallele Gegenprobe der Saite umfasst vier Sekunden.',y)-10
    y=body('Im früheren seriellen Startprofil der Kavität beansprucht die Minimumsuche nur 0,03–0,04 % der CPU-Zeit. Die Berechnung sämtlicher Schwellendurchtritte benötigt 25–27 %, das Verschieben der Polynome 25–28 % und die Taylor-Koeffizienten 37–43 %. Ein Austausch des Ereigniskalenders allein lässt die dominierende Arbeit bestehen.',y)-10
    y=para(c,'GCC 14.2 · Open MPI 5.0.7 · CPython 3.12.14 · AMD EPYC 9V45. Laufzeiten sind host- und implementierungsspezifisch. <link href="https://github.com/5H3LL3H5/argesim-hyperposition-benchmarks/tree/eb1e5519c446d4b226006e30cadda6fda9d3dd76" color="#007B76">Quellstand eb1e5519 auf GitHub</link>. Rohdaten, Grenzschnitte, Modelle und Wiederholungsbefehle liegen im zugehörigen Messpaket.',L,y,BW,8,11,slate)
    assert y>50;foot(3);c.save()
