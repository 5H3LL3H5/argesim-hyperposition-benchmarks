"""Spatial owner maps and exact event-weighted cut on balanced Cartesian partitions."""
from functools import lru_cache
import itertools
import json
import math
from pathlib import Path
import numpy as np


def best_bands(weights, parts):
    n = len(weights) - 1
    low = max(1, math.floor(0.9 * n / parts))
    high = math.ceil(1.1 * n / parts)
    @lru_cache(maxsize=None)
    def best(start, left):
        if left == 1:
            return (0, ()) if low <= n - start <= high else (math.inf, ())
        choices = []
        for edge in range(start + low, min(n - 1, start + high) + 1):
            rest, cuts = best(edge, left - 1)
            choices.append((int(weights[edge]) + rest, (edge, *cuts)))
        return min(choices, default=(math.inf, ()))
    return best(0, parts)


def equal(n, parts):
    return np.cumsum([len(v) for v in np.array_split(np.arange(n), parts)])[:-1].tolist()


def cut(weights, edges):
    return sum(int(weights[x]) for x in edges)


def edge_weights(a):
    return [0, *(int(v) for v in a[:-1] + a[1:]), 0]


def cartesian(ny, nx, cx, cy):
    xx = np.searchsorted(cx, np.arange(nx), side='right')
    yy = np.searchsorted(cy, np.arange(ny), side='right')
    return yy[:, None] * (len(cx) + 1) + xx[None, :]


def enumerate_grid(meta, counts, p):
    ny, nx = meta['shape']
    square = meta['model'] == 'c19r'
    if square:
        grid = counts.reshape(ny, nx)
        wx, wy = edge_weights(grid.sum(axis=0)), edge_weights(grid.sum(axis=1))
    else:
        wx, wy = edge_weights(counts[:nx]), [0, 0]
    variants = {'x': (equal(nx, p), [])}
    if square:
        variants.update(y=([], equal(ny, p)), tiles=(equal(nx, p//2), equal(ny, 2)))
    options = []
    for px in range(1, p + 1):
        if p % px or (not square and px != p):
            continue
        py = p // px
        a, cx = best_bands(wx, px)
        b, cy = best_bands(wy, py)
        options.append((a+b, tuple(cx), tuple(cy)))
    _, cx, cy = min(options)
    variants['weighted'] = list(cx), list(cy)
    for name, (cx, cy) in variants.items():
        grid = cartesian(ny, nx, cx, cy)
        if square:
            owner = grid.ravel()
        else:
            owner = np.r_[grid.ravel(), grid.ravel(), grid[0,-1], grid[0,-1]]
        weight = cut(wx, cx) + cut(wy, cy)
        boundary = ny * len(cx) + nx * len(cy)
        yield name,owner,dict(cx=cx, cy=cy, training_exports=weight, physical_edges=boundary,
                              training_work=np.bincount(owner,weights=counts).astype(int).tolist())


def write(source, targets):
    meta = json.loads((source/'metadata.json').read_text())
    counts = np.fromfile(source/'base.counts',dtype='<u8')
    results = []
    for p in (4,8):
        for name,owner,entry in enumerate_grid(meta, counts, p):
            for dest in targets:
                np.savetxt(dest/f'{name}-{p}.map',owner,fmt='%d')
            results.append(dict(ranks=p, layout=name, **entry))
    (source/'maps.json').write_text(json.dumps(results,indent=2))
    return results


def d2q9():
    side=257; result=[]
    for p in (4,8):
        for px in range(1,p+1):
            if p%px: continue
            py=p//px
            owner=cartesian(side,side,equal(side,px),equal(side,py))
            cross=0
            for dy,dx in itertools.product((-1,0,1),repeat=2):
                if not dx and not dy:continue
                y=slice(max(-dy,0), min(side,side-dy));x=slice(max(-dx,0),min(side,side-dx))
                yy=slice(max(dy,0), min(side,side+dy));xx=slice(max(dx,0),min(side,side+dx))
                cross+=int(np.count_nonzero(owner[y,x]!=owner[yy,xx]))
            ax,ay=px-1,py-1
            assert cross==(ax+ay)*(6*side-4)-4*ax*ay
            result.append(dict(ranks=p,px=px,py=py,population_transfers=cross))
    Path('d2q9_topology.json').write_text(json.dumps(result, indent=2))


if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('training',type=Path);parser.add_argument('targets',nargs='+',type=Path)
    args=parser.parse_args()
    write(args.training,args.targets)
    d2q9()
