# CP2-Kavität auf 257 × 257 Knoten

## Warum konnte der OpenMP-Lauf langsamer sein?

Im archivierten Hauptlauf betrug der Speedup des D2Q9-Kerns 0,396. In der Pilotmessung desselben Archivs waren vier Threads über die ersten 1024 Schritte 1,97-mal so schnell wie einer. Beim Vier-Thread-Piloten kamen auf eine Wandsekunde 3,97 Prozess-CPU-Sekunden. Über alle 350 000 Schritte des Hauptlaufs waren es 1,69. Der Kern enthält pro Gittertakt eine implizite OpenMP-Barriere am Ende der statisch verteilten Zeilenschleife. Durch Verzögerung eines beteiligten Threads kann sich der nächste Takt für das ganze Team verzögern.

Im ursprünglichen Messprotokoll ist zeitweise parallele Rechnerlast dokumentiert. Welche Aufgaben konkret CPU-Zeit beanspruchten, welche Affinität und CPU-Quote galten und wie viel Zeit die Threads in Barrieren warteten, wurde dort nicht ausgewiesen. Die Prozess-CPU-Zeit summiert Ausführungszeit über alle Threads und kann auch aktives Warten enthalten.

## Vollständige Gegenprobe vom 26. November 2026

Ausgeführt wurde der archivierte C++-Quelltext aus dem Commit `eb1e5519c446d4b226006e30cadda6fda9d3dd76`. Host der neuen Messungen war ein AMD EPYC 9V45 mit Linux 6.18.57. Übersetzung mit GCC 14.2.0, OpenMP, Optimierung `-O3 -march=native -ffp-contract=off`. Der Ausgangslauf ist auf einem Intel Xeon Platinum 8370C dokumentiert. Die Maschinen unterscheiden sich, auch bei identischen Quelltexten und Compileroptionen.

Eine Trajektorie umfasst 350 000 Schritte bei Re = 1000 und 37 archivierte Ausgabetakte. Der reguläre Einzelthread war an die erste virtuelle CPU gebunden. Vier Threads waren über die ersten vier sichtbaren virtuellen CPUs verteilt. Das OpenMP-Team war fest, libgomp verwendete seine Standard-Wartepolitik. Es gab bei diesen vier Läufen keine von diesem Versuch erzeugte konkurrierende Last.

| Lauf | Threads | Wandsekunden des Kerns | Prozess-CPU-Sekunden des Kerns |
|---:|---:|---:|---:|
| 1 | 1 | 59,979 | 59,833 |
| 2 | 4 | 21,873 | 86,690 |
| 3 | 4 | 20,540 | 82,008 |
| 4 | 1 | 58,620 | 58,475 |

Aus den Paaren 1/2 und 4/3 folgen die Speedups 2,742 und 2,854. Mit Prozessstart und Dateiausgabe sind es 2,740 und 2,850. Die 37 vollständigen Dateien für Dichte und beide Geschwindigkeitskomponenten sind zwischen allen vier neuen Läufen bytegleich. Die gespeicherten Minima, Maxima und Mittelwerte der Dichte stimmen zudem an allen 37 Takten mit dem archivierten seriellen Lauf überein.

## Kontrollierte Konkurrenz auf einer CPU

Der unveränderte Kern lief pro Paar über 4096 Schritte. Beide Varianten erhielten dieselben OpenMP-Einstellungen wie beim vollständigen Lauf. Als einzige experimentelle Änderung kamen in der Belastungsbedingung drei zusätzliche rechenintensive Prozesse auf genau die vierte virtuelle CPU. Der Einzelthread lief weiter auf der ersten CPU. Die vier OpenMP-Threads belegten jeweils eine eigene der vier CPUs. Die Ausführungsreihenfolge beider Bedingungen und der seriellen und parallelen Läufe variierte zwischen fünf gepaarten Wiederholungen. Die vollständige Rechnung und diese Lastversuche liefen nacheinander.

| Bedingung | Median Wanduhr 1 Thread | Median Wanduhr 4 Threads | Median der fünf gepaarten Speedups |
|---|---:|---:|---:|
| Ohne Zusatzlast | 0,688 s | 0,270 s | 2,542 |
| Drei konkurrierende Prozesse auf der vierten CPU des Teams | 0,703 s | 1,111 s | 0,633 |

Alle 20 Endfelder dieser Reihe sind bytegleich. Die Versuchsanordnung belegt, dass asymmetrische CPU-Konkurrenz unter diesen Bedingungen einen Slowdown auslösen kann. Die Zuordnung der historischen Messung zu genau diesem Lastprofil bleibt offen.

## Inhalt und Wiederholung

- `auswertung.json` enthält Kennzahlen, Prüfsummen und die Angabe des archivierten Quelltexts.
- `messungen/full_runs.jsonl` enthält die vollständigen Läufe mit interner und externer Zeitmessung sowie je 37 Feld-Prüfsummen. Die vier zugehörigen CSV-Dateien dokumentieren Zeit und Dichte an jedem Ausgabezeitpunkt.
- `messungen/contention_runs.jsonl` enthält alle 20 Werte der kontrollierten Lastmessung. `messungen/against_1024.jsonl` enthält die ergänzende Kurzreihe mit verschiedenen Threadzahlen, Affinitäten und OpenMP-Wartepolitiken.
- `skripte` enthält die verwendeten Messprogramme. Jeder Zeitwert des C++-Integrationskerns schließt das Schreiben der Felddateien aus. Die gesonderte Wanduhrzeit `total_wall_s` im vollständigen Lauf schließt Prozessinitialisierung und Ausgabe ein.

Für die Wiederholung werden vier verfügbare logische CPUs, Linux mit `taskset`, Python 3 und GCC mit OpenMP benötigt. Nach dem Auspacken des Messpakets im folgenden Beispiel den Pfad auf den angegebenen Stand des Repositorys setzen. Die Lastprozesse werden nach jeder Messgruppe beendet.

```bash
repo=/pfad/zum/argesim-hyperposition-benchmarks
mkdir wiederholung
cp skripte/*.py wiederholung/
cd wiederholung
python3 - "$repo" <<'PY'
from pathlib import Path
from zipfile import ZipFile
import sys
archive = Path(sys.argv[1]) / 'docs/lehrbuch/gesamtausgabe/pakete/Laborquellen.zip'
with ZipFile(archive) as z:
    for name in ('src/d2q9.cpp', 'daten/laufzeiten/re1000.csv', 'daten/laufzeiten/pruef4.csv'):
        Path(Path(name).name).write_bytes(z.read('rechenlabor/kavitaet_vollgitter/' + name))
PY
g++ -std=c++20 -O3 -march=native -ffp-contract=off -Wall -Wextra -Werror -fopenmp d2q9.cpp -o d2q9
python3 paired.py 1024 5 > against_1024.jsonl
python3 full.py > full_runs.jsonl
python3 contention.py > contention_runs.jsonl
```

[Lehrbuch und historische Wandzeiten](https://github.com/5H3LL3H5/argesim-hyperposition-benchmarks/blob/eb1e5519c446d4b226006e30cadda6fda9d3dd76/docs/lehrbuch/gesamtausgabe/kapitel/16.md#cp2-voll-zeiten) · [Ursprüngliches Laborarchiv](https://github.com/5H3LL3H5/argesim-hyperposition-benchmarks/blob/eb1e5519c446d4b226006e30cadda6fda9d3dd76/docs/lehrbuch/gesamtausgabe/pakete/Laborquellen.zip) · [OpenMP-Arbeitsteilung und Barriere](https://www.openmp.org/spec-html/5.2/openmpse66.html)

