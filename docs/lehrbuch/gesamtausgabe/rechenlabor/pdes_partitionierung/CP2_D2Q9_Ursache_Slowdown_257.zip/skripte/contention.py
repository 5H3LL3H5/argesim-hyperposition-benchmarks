"""Vary only competing CPU work on the fourth of four virtual CPUs."""
import contextlib
import csv
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import time

root = Path(__file__).resolve().parent
cpus = sorted(os.sched_getaffinity(0))[:4]
assert len(cpus)==4

def load_cpu(cpu):
    os.sched_setaffinity(0, {cpu})
    print('ready',flush=True)
    deadline=time.monotonic()+65
    state=1
    while time.monotonic()<deadline:
        for _ in range(20000):
            state = (1664525*state + 1013904223) & 0xffffffff

@contextlib.contextmanager
def competition(count):
    workers=[]
    try:
        for i in range(count):
            p=subprocess.Popen([sys.executable,__file__,'worker',str(cpus[3])],stdout=subprocess.PIPE,text=True)
            workers.append(p)
            assert p.stdout.readline().strip()=='ready'
        yield
        assert all(p.poll() is None for p in workers)
    finally:
        for p in workers:
            if p.poll() is None:
                p.terminate()
        for p in workers:
            p.wait(timeout=5)
            p.stdout.close()

def run():
    rng=random.Random(87257)
    reference=None
    with tempfile.TemporaryDirectory(dir=root) as td:
        tmp=Path(td)
        (tmp/'marks').write_text('4096\n')
        (tmp/'warm').write_text('256\n')
        def kernel(threads,marks):
            allowed=cpus[:threads]
            env=dict(os.environ)
            for k in ('GOMP_CPU_AFFINITY','GOMP_SPINCOUNT','OMP_WAIT_POLICY','OMP_THREAD_LIMIT'):
                env.pop(k,None)
            env.update(OMP_PLACES=','.join('{'+str(n)+'}' for n in allowed),
                       OMP_PROC_BIND='close',OMP_DYNAMIC='FALSE')
            proc=subprocess.run(['taskset','-c',','.join(map(str,allowed)),str(root/'d2q9'),'257','1000',str(threads),str(tmp/'out'),str(marks)],
                                env=env,capture_output=True,text=True,timeout=45)
            if proc.returncode or proc.stderr: raise RuntimeError((proc.returncode,proc.stderr))
            with (tmp/'out'/'zeiten.csv').open() as f:
                row,=csv.DictReader(f)
            return row
        for threads in (1,4):
            kernel(threads,tmp/'warm')
        for repeat in range(1,6):
            conditions=[0,3];rng.shuffle(conditions)
            for competitors in conditions:
                with competition(competitors):
                    order=[1,4];rng.shuffle(order)
                    for threads in order:
                        row=kernel(threads,tmp/'marks')
                        digest=hashlib.sha256((tmp/'out'/'feld_4096.bin').read_bytes()).hexdigest()
                        if reference is None: reference=digest
                        assert digest==reference
                        wall=float(row['wall_s']);cpu=float(row['cpu_s'])
                        print(json.dumps(dict(repeat=repeat,competitors=competitors,
                                competitor_cpu=cpus[3],threads=threads,allowed_cpus=cpus[:threads],
                                steps=int(row['step']),wall_s=wall,cpu_s=cpu,cpu_per_wall=cpu/wall,
                                field_sha256=digest)),flush=True)

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='worker':
        load_cpu(int(sys.argv[2]))
    else:
        run()

