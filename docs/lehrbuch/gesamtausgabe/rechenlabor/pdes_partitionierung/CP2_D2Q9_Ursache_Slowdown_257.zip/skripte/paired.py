import csv
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent
base_cpus = sorted(os.sched_getaffinity(0))[:4]
assert len(base_cpus) == 4
cases = {
    '1t_1cpu_default': (1,1,None),
    '2t_2cpu_default': (2,2,None),
    '4t_4cpu_default': (4,4,None),
    '4t_2cpu_default': (4,2,None),
    '4t_2cpu_passive': (4,2,'PASSIVE'),
    '4t_2cpu_active': (4,2,'ACTIVE'),
    '4t_4cpu_active': (4,4,'ACTIVE'),
    '4t_4cpu_passive': (4,4,'PASSIVE'),
}
def run(case, directory, marks):
    threads, available, waiting = cases[case]
    cpus = base_cpus[:available]
    env=dict(os.environ)
    for key in ('OMP_WAIT_POLICY','GOMP_SPINCOUNT','GOMP_CPU_AFFINITY','OMP_THREAD_LIMIT'):
        env.pop(key,None)
    env.update(OMP_PROC_BIND='close', OMP_PLACES=','.join('{'+str(c)+'}' for c in cpus), OMP_DYNAMIC='FALSE')
    if waiting:
        env['OMP_WAIT_POLICY']=waiting
    args=['taskset','-c',','.join(map(str,cpus)),str(root/'d2q9'),'257','1000',str(threads),str(directory),str(marks)]
    child=subprocess.run(args,env=env,text=True,capture_output=True,timeout=65)
    if child.returncode!=0 or child.stderr: raise RuntimeError((case,child.returncode,child.stderr))
    with (directory/'zeiten.csv').open() as f: measurements=list(csv.DictReader(f))
    result={}
    for r in measurements:
        step=int(r['step'])
        data=(directory/f'feld_{step}.bin').read_bytes()
        assert len(data)==257*257*3*8
        result[step]=(float(r['wall_s']),float(r['cpu_s']),hashlib.sha256(data).hexdigest())
    return result

steps = [1024] if len(sys.argv)<2 else [int(sys.argv[1])]
reps = int(sys.argv[2]) if len(sys.argv)>2 else 5
selected = sys.argv[3:] or list(cases)
randomizer=random.Random(20261126)
with tempfile.TemporaryDirectory(dir=root) as td:
    tmp=Path(td)
    marks=tmp/'marks';marks.write_text(''.join(f'{n}\n' for n in steps))
    warm=tmp/'warm';warm.write_text('256\n')
    for case in selected:
        run(case,tmp/'out',warm)
    expected={}
    for repeat in range(1,reps+1):
        order=selected.copy();randomizer.shuffle(order)
        for case in order:
            measurements=run(case,tmp/'out',marks)
            for step,(wall,cpu,digest) in measurements.items():
                assert expected.setdefault(step,digest)==digest
                threads,affinity,wait = cases[case]
                print(json.dumps(dict(case=case,step=step,repeat=repeat,threads=threads,allowed_cpus=base_cpus[:affinity],wait_policy=wait or 'default',wall_s=wall,cpu_s=cpu,cpu_per_wall=cpu/wall,field_sha256=digest)),flush=True)

