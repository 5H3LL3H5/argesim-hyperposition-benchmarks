"""Repeat the archived D2Q9 kernel with its 37 published checkpoints."""
import csv
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import tempfile
import time

root = Path(__file__).resolve().parent
cpus = sorted(os.sched_getaffinity(0))[:4]
assert len(cpus) == 4

with (root / 're1000.csv').open() as f:
    steps = [int(r['step']) for r in csv.DictReader(f)]
with (root / 'pruef4.csv').open() as f:
    assert steps == [int(r['step']) for r in csv.DictReader(f)]
assert len(steps) == 37 and steps[-1] == 350000
reference = None
with tempfile.TemporaryDirectory(dir=root) as td:
    workspace = Path(td)
    checkpoints = workspace / 'marks'
    checkpoints.write_text(''.join(f'{s}\n' for s in steps))
    for run,threads in enumerate((1,4,4,1),1):
        processors = cpus[:threads]
        env = dict(os.environ)
        for k in ('OMP_WAIT_POLICY','GOMP_SPINCOUNT','GOMP_CPU_AFFINITY','OMP_THREAD_LIMIT'):
            env.pop(k,None)
        env.update(OMP_DYNAMIC='FALSE',OMP_PROC_BIND='close',
                   OMP_PLACES=','.join('{'+str(n)+'}' for n in processors))
        dest = workspace/'out'
        args = ['taskset','-c',','.join(map(str,processors)),str(root/'d2q9'),'257','1000',str(threads),str(dest),str(checkpoints)]
        usage0 = resource.getrusage(resource.RUSAGE_CHILDREN)
        t0 = time.monotonic()
        c = subprocess.run(args,env=env,capture_output=True,text=True,timeout=350)
        elapsed = time.monotonic() - t0
        usage1 = resource.getrusage(resource.RUSAGE_CHILDREN)
        if c.returncode or c.stderr:
            raise RuntimeError((run,c.returncode,c.stderr))
        external_cpu = (usage1.ru_stime-usage0.ru_stime)+(usage1.ru_utime-usage0.ru_utime)
        with (dest/'zeiten.csv').open() as f:
            measurements = list(csv.DictReader(f))
        assert steps == [int(r['step']) for r in measurements]
        hashes = {}
        for step in steps:
            field = (dest/f'feld_{step}.bin').read_bytes()
            assert len(field) == 257*257*3*8
            hashes[step] = hashlib.sha256(field).hexdigest()
        if reference is None:
            reference = hashes
        assert hashes == reference
        data = dict(run=run,threads=threads,allowed_cpus=processors,checkpoints=len(steps),
                    kernel_wall_s=float(measurements[-1]['wall_s']),kernel_cpu_s=float(measurements[-1]['cpu_s']),
                    total_wall_s=elapsed,total_cpu_s=external_cpu,field_hashes=hashes)
        (root/f'intervals_run_{run}.csv').write_bytes((dest/'zeiten.csv').read_bytes())
        print(json.dumps(data),flush=True)

